﻿using BinaryProtocol.Common;

using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.Utility;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using ConsumerDBComponent.Core;
using ConsumerDBComponent.Publisher;

using CTCL.BinaryProtocol.Common.CMA.Response;
using CTCL_OpCode= CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using Utility;

namespace ConsumerDBComponent.Common
{
    internal class CommonHelper
    {
        private static Conversion conversion;
        public static string RequestID;
        static CommonHelper()
        {
            conversion = new();
        }
        public static string SerializeObject(object obj)
        {
            try
            {
                return JsonConvert.SerializeObject(obj);
            }
            catch (Exception ex)
            {
                return "Error in serialize :" + ex.Message;
            }

        }
        public static CTCL_MessageHeader PrepareMessageHeader<T>(CTCL_OpCode opCode, int desComponentIdentifier, int desInstanceId, CTCL_ExchangeSegmentId exchangeSegmentId)
        {
            var time = DateTime.Now.ToCTCLEpoch();
            return PrepareMessageHeader<T>(opCode, desComponentIdentifier, desInstanceId, exchangeSegmentId, new CTCL_TimeStamp(time));

        }
        public static CTCL_MessageHeader PrepareMessageHeader<T>(CTCL_OpCode opCode, int desComponentIdentifier, int desInstanceId, CTCL_ExchangeSegmentId exchangeSegmentId, CTCL_TimeStamp timeStamp)
        {
            CTCL_MessageHeader messageHeader = new();
            messageHeader.OpCode = opCode;
            messageHeader.TimeStamp.TimeStamp = timeStamp.TimeStamp;
            messageHeader.MessageLength.Messagelength = Marshal.SizeOf(typeof(T));
            messageHeader.SourceComponentIdentifier.ComponentId = (int)ComponentType.DBWriter;
            messageHeader.SourceComponentInstance.ComponentInstanceId = -1;
            messageHeader.DestinationComponentIdentifier.ComponentId = desComponentIdentifier;
            messageHeader.DestComponentInstance.ComponentInstanceId = desInstanceId;
            messageHeader.ExchangeSegmentId = exchangeSegmentId;

            return messageHeader;
        }
        public static Response EnqueueInAgentProcess(byte[] data)
        {
            Response response = new();
            if (InterfaceProcessor.AgentProcessor.TryGetValue(InterfaceProcessor.AgentWorkerId, out CMAAgentProcessor agentProcessor))
            {
                if (agentProcessor != null)
                {
                    response = agentProcessor.Enqueue(data);
                }
            }
            return response;
        }
        public static CMA_COMPONENT_MESSAGE_UPDATE getCMACompUpdateResponse(CTCL.BinaryProtocol.Common.CMA.Enum.CMA_StatusCode status, string message, string requestId)
        {
            CMA_COMPONENT_MESSAGE_UPDATE compupdate = new CMA_COMPONENT_MESSAGE_UPDATE();
            compupdate.MessageHeader = new CTCL_MessageHeader();
            compupdate.MessageHeader.OpCode = CTCL_OpCode.CMA_COMPONENT_STATUS;
            compupdate.MessageHeader.TimeStamp.TimeStamp = DateTime.Now.ToCTCLEpoch();
            compupdate.MessageHeader.SourceComponentIdentifier.ComponentId = (int)ComponentType.DBWriter;
            compupdate.MessageHeader.DestinationComponentIdentifier.ComponentId = (int)ComponentType.AgentWorker;
            compupdate.MessageHeader.SourceComponentInstance.ComponentInstanceId = -1;

            compupdate.ResponseString = new CTCL_Message(message.ToCharArray());
            compupdate.SuccessFailureFlag = status;
            compupdate.LocalUpdateTime.TimeStamp = DateTime.Now.ToCTCLEpoch();
            compupdate.RequestID = new(requestId.ToCharArray());

            return compupdate;

        }
        public static void SendGlobalExceptionToAgent(CMA_COMPONENT_MESSAGE_UPDATE CompResponese)
        {
            byte[] omsappresp = conversion.GetBytesFromObject(CompResponese);

            EnqueueInAgentProcess(omsappresp);
        }
    }
}
