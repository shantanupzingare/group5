﻿using System.Configuration;
using CTCL.RedisClient;
using RedisClient.Utility;

namespace ConsumerDBComponent.Common
{
    internal class Constant
    {
        public static int InstanceId = -1;
        public static ushort prefetchCount;
        public static string DbConnectionString = "";
        public static string DbConnectionStringCTCLCommonDb = "";
        public static ushort batchSize=0;
        public static int SQLBulkInsertBatchSize=0;
        static Constant()
        {
            prefetchCount = Convert.ToUInt16(AppSettingHelper.Configuration["PrefetchCount"]);
            DbConnectionString = AppSettingHelper.Configuration["ConnectionStrings:DBCTCL"];
            DbConnectionStringCTCLCommonDb = AppSettingHelper.Configuration["ConnectionStrings:DBCTCLCommon"];
            batchSize = Convert.ToUInt16(AppSettingHelper.Configuration["BATCHSIZE"]);
            SQLBulkInsertBatchSize = Convert.ToUInt16(AppSettingHelper.Configuration["SQLBulkInsertBatchSize"]);
        }

    }
}
