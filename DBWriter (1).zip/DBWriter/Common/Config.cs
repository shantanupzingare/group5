﻿using CTCL.CacheManagement.Structs;
using Utility;

namespace ConsumerDBComponent.Common
{
    internal class Config
    {
        public static string logfile;
        public static int logLevel;
        public static int logFileCount { get; set; }
        public static int decimalLocatorNSEFO;
        public static int decimalLocatorNSECM;
        public static int tradingCurrencyId;
        public static int settlementCurrencyId;
        public static int instanceId;
        public static string connectionString;
        public static int timeInSecondsDisconnectedClients;
        public static int timeInSecondsLastReceive;
        public static int heartTimeInterval;
        public Config()
        {
            logfile = AppendDateInPath(AppSettingHelper.Configuration["LogFile"]);
            logLevel = Convert.ToInt32(AppSettingHelper.Configuration["LogLevel"]);
            logFileCount = Convert.ToInt32(AppSettingHelper.Configuration["LogFileCount"]);
            
        //    instanceId = -1;
        }

        static Config()
        {
            logfile = AppendDateInPath(AppSettingHelper.Configuration["LogFile"]);
            logLevel = Convert.ToInt32(AppSettingHelper.Configuration["LogLevel"]);
            logFileCount = Convert.ToInt32(AppSettingHelper.Configuration["LogFileCount"]);
            decimalLocatorNSEFO = Convert.ToInt32(AppSettingHelper.Configuration["decimalLocatorNSEFO"]);
            decimalLocatorNSECM = Convert.ToInt32(AppSettingHelper.Configuration["decimalLocatorNSECM"]);
            tradingCurrencyId = Convert.ToInt32(AppSettingHelper.Configuration["tradingCurrencyId"]);
            settlementCurrencyId = Convert.ToInt32(AppSettingHelper.Configuration["settlementCurrencyId"]);
            connectionString = AppSettingHelper.Configuration["ConnectionStrings:DBCTCL"];
            timeInSecondsDisconnectedClients = Convert.ToUInt16(AppSettingHelper.Configuration["TimeIntervalInSecondsDisconnectedClients"]);
            timeInSecondsLastReceive = Convert.ToUInt16(AppSettingHelper.Configuration["TimeIntervalInSecondsLastReceive"]);
            heartTimeInterval = 5000;
        }

		private static string AppendDateInPath(string path)
		{
			var paths = path.Split("\\");
			var i = paths.Length - 1;
			if (i > -1)
				paths[i] = DateTime.Now.ToString("yyyyMMdd") + "\\" + DateTime.Now.ToString("yyyyMMdd") + "-" + paths[i];
			return string.Join("\\", paths);
		}

	}
}
