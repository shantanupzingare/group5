﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.DB;
using MQueue;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.X509;
using Utility;

namespace ConsumerDBComponent.Common
{
    class ExternalQueuePublisher
    {
        MQPublisher mQPublisher;
        QueueBinding queueBinding;
        Conversion conversion;
        private Compression compression;
        string _pubisherType;
        Response _response;

        public ExternalQueuePublisher(MQConfiguration mQConfiguration, string publisherType)
        {
            try
            {
                _pubisherType = publisherType;
                mQPublisher = new MQPublisher(mQConfiguration, MsgAck, MsgNAck, MessageReturn);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public void SetupQueue(QueueBinding queueBinding)
        {
            try
            {
                mQPublisher.SetupQueue(queueBinding);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        private void MsgNAck(ulong deliveryTag)
        {
            LogExceptionMessage("Publish to MQ Failed for Message of Delivery Tag" + deliveryTag, _pubisherType);
        }

        private void MsgAck(ulong deliveryTag)
        {
            throw new NotImplementedException();
        }

        //private void MessageReturn(byte[] data, string msg)
        //{
        //    if (_pubisherType == "DeadPool")
        //    {
        //        ORDER_INFO_FOR_DB order = conversion.FromBytesToObject<ORDER_INFO_FOR_DB>(data);
        //        Log.Error(msg + "Publish to MQ Message Return(Message Return Event) For Order in DeaddPoolOf Order :" + JsonConvert.SerializeObject(order));
        //    }
        //    else
        //    {
        //        ORDER_INFO_FOR_DB order = conversion.FromBytesToObject<ORDER_INFO_FOR_DB>(data);
        //        Log.Error(msg + "Publish to MQ Message Return(Message Return Event) For Order in RePublishDedpool Order :" + JsonConvert.SerializeObject(order));
        //    }

        //}
        private void MessageReturn(ReadOnlyMemory<byte> data, string reply)
        {
            var validData = data.ToArray();
            //var validData = compression.Decompress(data.ToArray());
            if (_pubisherType == "DeadPool")
            {
                ORDER_INFO_FOR_DB order = conversion.FromBytesToObject<ORDER_INFO_FOR_DB>(validData);
                Log.Error(reply + "Publish to MQ Message Return(Message Return Event) For Order in DeaddPoolOf Order :" + JsonConvert.SerializeObject(order));
            }
            else
            {
                ORDER_INFO_FOR_DB order = conversion.FromBytesToObject<ORDER_INFO_FOR_DB>(validData);
                Log.Error(reply + "Publish to MQ Message Return(Message Return Event) For Order in RePublishDedpool Order :" + JsonConvert.SerializeObject(order));
            }
        }

        internal Response PublishMQ(byte[] data, bool isPersistant)
        {
            try
            {
                _response = mQPublisher.PublishMQ(data, isPersistant);
                LogInfoMessage("Message Successfully published in Queue.", _pubisherType);
                return _response;
            }
            catch (Exception ex)
            {
                LogExceptionMessagewithObject("Error Occuurred while Publihsing the Message in Queue", ex, _pubisherType);
                _response.ExtraInfo = ex;
                _response.Message = "Error Occuurred while Publihsing the Message in Queue" + ex.Message;
                _response.StatusCode = StatusCode.Failure;
                return _response;
            }
        }

        private void LogExceptionMessage(string Message, string PubisherType)
        {
            if (PubisherType == "DeadPool")
            {
                Log.Error("Error Occurred At DeadPool Publish Side :" + Message);
            }
            else
            {
                Log.Error("Error Occurred At RePublishDedpool Publish Side :" + Message);
            }
        }

        private void LogExceptionMessagewithObject(string Message, Exception ex, string PubisherType)
        {
            if (PubisherType == "DeadPool")
            {
                Log.Error(ex, "Error Occurred At DeadPool Publish Side :" + Message);
            }
            else
            {
                Log.Error(ex, "Error Occurred At RePublishDedpool Publish Side :" + Message);
            }
        }

        private void LogInfoMessage(string Message, string PubisherType)
        {
            if (PubisherType == "DeadPool")
            {
                Log.Info("Info Message At deadPool Side :" + Message);
            }
            else
            {
                Log.Info("Info Message At RePublishDedpool Side :" + Message);
            }
        }
    }
}
