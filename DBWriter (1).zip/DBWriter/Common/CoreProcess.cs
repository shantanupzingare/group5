﻿using BinaryProtocol.Common;
using ConsumerDBComponent.Core;
using ConsumerDBComponent.Global;
using ConsumerDBComponent.MessageProcessor.CMBG;
using ConsumerDBComponent.MessageProcessor.FOBG;
using Exchange.Logs;

namespace ConsumerDBComponent.Common
{
    public class CoreProcess
    {
        private static Log _globalLog;
        private static LogProcessor logProcessor; //Log insertion thread
        private static Response response;
        public static InterfaceProcessor interfaceProcessor;
        public static ComponentHandshakeManager handshakeManager;
        public static CMBGQueueProcessor cmBgQueueProcessor;
        public static FOBGQueueProcessor foBgQueueProcessor;

        public static void Initialize()
        {
            LogConfiguration logConfiguration = new LogConfiguration
            {
                FilesizeLimitBytes = 50000000,
                LogFileNameWithPath = Config.logfile,
                LoggingLevelSwitch = new Serilog.Core.LoggingLevelSwitch
                {
                    MinimumLevel = Config.logLevel == 0 ? Serilog.Events.LogEventLevel.Debug : (Serilog.Events.LogEventLevel)Config.logLevel,
                },
                OutputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}",
                RetainedFileCount = Config.logFileCount,
                RollingInterval = Serilog.RollingInterval.Day,
                RollOnFileSizeLimit = true,
            };

            LogType logType = (LogType)Config.logLevel;
            _globalLog = new Log(logType);

            if (logProcessor == null)
            {
                logProcessor = new LogProcessor(logConfiguration);
            }
            interfaceProcessor = new InterfaceProcessor();
            handshakeManager = new ComponentHandshakeManager();
            cmBgQueueProcessor = new();
            foBgQueueProcessor = new();
        }



        public static Response SendToLogQueue(LogObject data)
        {
            if (!data.Equals(default(LogObject)) && logProcessor != null)
            {
                return logProcessor.Enqueue(data);
            }
            else if (logProcessor == null)
            {
                Log.Error(null, "logProcessor is null");
                return response.Set(StatusCode.OMS_Failure, "logProcessor is null");
            }
            else
            {
                Log.Error(null, "SendToLogQueue data is null");
                return response.Set(StatusCode.OMS_Failure, "data is null");
            }
        }
    }
}
