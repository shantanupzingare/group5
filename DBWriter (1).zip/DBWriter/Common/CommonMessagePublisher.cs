﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;

namespace ConsumerDBComponent.Common
{
    public class CommonMessagePublisher
    {
        private Conversion conversion;
        private Compression compression;
        private ExternalQueuePublisher deadPoolPublisher;

        public CommonMessagePublisher()
        {
            conversion = new Conversion();

        }
        internal bool PublishMessageInDeadPoolQ(object obj)
        {
            bool result = true;
            try
            {
                Response compressresponse = DataProcessWithPreCompressionPacking(obj);


                if (compressresponse.StatusCode == StatusCode.Success)
                {

                    Response response = deadPoolPublisher.PublishMQ((byte[])compressresponse.ExtraInfo, true);
                    if (response.StatusCode == StatusCode.Failure)
                    {
                        result = false;
                    }
                }
                else
                {
                    result = false;
                    Log.Info($"----Error Occured on Compression Data for orderInfo:- {obj}");
                }
                Log.Info($"----Message Publish In DeadPool Queue for orderInfo:  {obj}");
            }
            catch (Exception ex)
            {
                result = false;
                Log.Info($"----Error Occured in Message Publish In DeadPool Queue :- {ex.Message}");
            }

            return false;
        }
        static byte[] PreAllocBufferNew = new byte[16384];
        private Response DataProcessWithPreCompressionPacking(object obj)
        {
            Response response = new Response();
            Array.Clear(PreAllocBufferNew, 0, PreAllocBufferNew.Length);
            int counterPushSize = 0;
            int totalLengthAdded = 0;
            var compressData = conversion.GetBytesFromObject(obj);//).ExtraInfo;
            conversion.CopyByteArray(BitConverter.GetBytes(compressData.Length), ref PreAllocBufferNew, ref counterPushSize);//size
            totalLengthAdded = totalLengthAdded + sizeof(int);
            conversion.CopyByteArray(compressData, ref PreAllocBufferNew, ref counterPushSize);//Msg
            totalLengthAdded = totalLengthAdded + compressData.Length;

            //Publish
            var sendingBytes = new byte[totalLengthAdded];
            Buffer.BlockCopy(PreAllocBufferNew, 0, sendingBytes, 0, totalLengthAdded);
            var compressBytesToSendRes = compression.Compress(sendingBytes);//.ExtraInfo;
            if (compressBytesToSendRes.StatusCode == StatusCode.Success)
            {
                response.StatusCode = StatusCode.Success;
                response.Message = "";
                response.ExtraInfo = compressBytesToSendRes.ExtraInfo;
                return response;
            }
            else
            {
                response.StatusCode = StatusCode.Failure;
                response.Message = "";
                response.ExtraInfo = obj;
                return response;
            }
        }
    }
}
