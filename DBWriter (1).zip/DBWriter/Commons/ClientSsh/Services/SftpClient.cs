﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.CacheManagement.Enums;
using CTCL.ClientSFTP.Models;
using Renci.SshNet;
using System.Xml.Linq;

namespace CTCL.ClientSFTP.Services
{
    public class WinSftpClient
    {
        LoginDetail _loginDetail;
        SftpClient _sftpclient;
        long MaxSize;
		readonly int SizeOfKb = 1024;
        public WinSftpClient()
        {
            _loginDetail = new LoginDetail();
        }

        public bool initialize(string ipaddress, int port, string userID, string password, long maxSize)
        {
            try
            {
                _loginDetail.Ipaddress = ipaddress;
                _loginDetail.Port = port;
                _loginDetail.Userid = userID;
                _loginDetail.Password = password;
                MaxSize = maxSize == 0 ? SizeOfKb : maxSize;
                connectionOpen();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
        public void connectionOpen()
        {
            try
            {
                var connInfo = new ConnectionInfo(_loginDetail.Ipaddress, _loginDetail.Port, _loginDetail.Userid,
                     new AuthenticationMethod[]
                     {
                    // Password auth
                    new PasswordAuthenticationMethod(_loginDetail.Userid, _loginDetail.Password)
                     }
                 );

                _sftpclient = new SftpClient(connInfo);
                _sftpclient.Connect();
            }
            catch (Exception)
            {
                _sftpclient.Disconnect();
            }
        }
        public void connectionClose()
        {
            try
            {
                Thread.Sleep(2000);
                _sftpclient.Disconnect();
            }
            catch (Exception)
            {
                _sftpclient.Disconnect();
            }
        }
        public Response UploadFile(CTCL_UploadFileType updateType, string file, ProofType proofType, DocumentType documentType, string terminalID)
        {
            Response response = new Response();
            try
            {
                if (string.IsNullOrEmpty(file) || string.IsNullOrWhiteSpace(file))
                {
                    return response.Set(StatusCode.Failure, "file Cannot Be Null, Empty or WhiteSpace");
                }
                _loginDetail.FileType = documentType.ToString();
                _loginDetail.File = file;
                _loginDetail.Terminalid = terminalID;


                //var ss = _sftpclient.ListDirectory("/");
                FileStream fs = new FileStream(file, FileMode.Open);

                if(fs.Length > MaxSize * SizeOfKb) 
                {
					return response.Set(StatusCode.Failure, $"File must be less than {MaxSize}");
				}
                
                string[] fileDetails = fs.Name.ToString().Split("\\");
                string filename = Path.GetFileName(file);
				filename = (short)updateType + "|" + _loginDetail.Terminalid + "|" + (short)proofType + "|" + (short)documentType + "|" + filename;
                bool bRet = true;
                bool bWait = true;
                IAsyncResult arUpload = null;
                AsyncCallback cbFinished = (IAsyncResult ar) =>
                {
                    bRet = true;
                    bWait = true;
                };

                Stream input = fs;

                var result = _sftpclient.BeginUploadFile(input, filename, cbFinished, filename, (kk) =>  { });

                result.AsyncWaitHandle.WaitOne();

                return response.Set(StatusCode.Success, "File Uploaded Successfully");
            }
            catch (Exception ex)
            {
                return response.Set(StatusCode.Failure, $"Error occured while file uploading {ex.Message}");
                throw;
            }
        }

        public Response DownloadFile(CTCL_UploadFileType updateType, string file, ProofType proofType, DocumentType documentType, string terminalID, string downloadFolderPath)
        {
			Response response = new Response();
			try
			{
				if (string.IsNullOrEmpty(file) || string.IsNullOrWhiteSpace(file))
				{
					return response.Set(StatusCode.Failure, "file Cannot Be Null, Empty or WhiteSpace");
				}

				_loginDetail.FileType = documentType.ToString();
				_loginDetail.File = file;
				_loginDetail.Terminalid = terminalID;

				string[] fileDetails = file.Split("\\");
				string filename = Path.GetFileName(file);
                string fileNameValue = Path.GetFileName(file);
				filename = (short)updateType + "|" + _loginDetail.Terminalid + "|" + (short)proofType + "|" + (short)documentType + "|" + filename;

				bool bRet = true;
				bool bWait = true;
				IAsyncResult arUpload = null;
				AsyncCallback cbFinished = (IAsyncResult ar) =>
				{
					bRet = true;
					bWait = true;
				};

                if (!Directory.Exists(downloadFolderPath))
                {
                    Directory.CreateDirectory(downloadFolderPath);
                }

                var downloadPath = Path.Combine(downloadFolderPath, fileNameValue);
				Stream output = File.Create(downloadPath);

				var res2 = _sftpclient.BeginDownloadFile(filename, output, cbFinished, filename, (dd) =>
				{

				});
				res2.AsyncWaitHandle.WaitOne();

				return response.Set(StatusCode.Success, "File Downloaded Successfully");
			}
			catch (Exception ex)
			{
				return response.Set(StatusCode.Failure, $"Error occured while file downloading {ex.Message}");
				throw;
			}
		}

        public Response UploadFile(CTCL_UploadFileType updateType, string file, string terminalID, int segmentId, int id, int attributeId, string certificateName, string certificateNumber)
        {
            Response response = new();

			try
			{
				if (string.IsNullOrEmpty(file) || string.IsNullOrWhiteSpace(file))
				{
					return response.Set(StatusCode.Failure, "file Cannot Be Null, Empty or WhiteSpace");
				}

				
				FileStream fs = new FileStream(file, FileMode.Open);

				if (fs.Length > MaxSize * SizeOfKb)
				{
					return response.Set(StatusCode.Failure, $"File must be less than {MaxSize}");
				}

				_loginDetail.Terminalid = terminalID;

				string[] fileDetails = fs.Name.ToString().Split("\\");
				string filename = Path.GetFileName(file);
				filename = (short)updateType + "|" + _loginDetail.Terminalid + "|" + segmentId + "|" + id + "|" + attributeId + "|" + certificateName + "|" + certificateNumber + "|" + filename;
				bool bRet = true;
				bool bWait = true;
				IAsyncResult arUpload = null;
				AsyncCallback cbFinished = (IAsyncResult ar) =>
				{
					bRet = true;
					bWait = true;
				};

				Stream input = fs;

				var result = _sftpclient.BeginUploadFile(input, filename, cbFinished, filename, (kk) => { });

				result.AsyncWaitHandle.WaitOne();

				return response.Set(StatusCode.Success, "File Uploaded Successfully");
			}
			catch (Exception ex)
			{
				return response.Set(StatusCode.Failure, $"Error occured while file uploading {ex.Message}");
				throw;
			}
		}

		public Response DownloadFile(CTCL_UploadFileType updateType, string file, string terminalID, int segmentId, int id, int attributeId, string certificateName, string certificateNumber, string downloadFolderPath)
		{
			Response response = new Response();
			try
			{
				if (string.IsNullOrEmpty(file) || string.IsNullOrWhiteSpace(file))
				{
					return response.Set(StatusCode.Failure, "file Cannot Be Null, Empty or WhiteSpace");
				}
				_loginDetail.Terminalid = terminalID;

				string[] fileDetails = file.Split("\\");
				string filename = Path.GetFileName(file);
				string fileNameValue = Path.GetFileName(file);
				filename = (short)updateType + "|" + _loginDetail.Terminalid + "|" + segmentId + "|" + id + "|" + attributeId + "|" + certificateName + "|" + certificateNumber + "|" + filename;

				bool bRet = true;
				bool bWait = true;
				IAsyncResult arUpload = null;
				AsyncCallback cbFinished = (IAsyncResult ar) =>
				{
					bRet = true;
					bWait = true;
				};

				if (!Directory.Exists(downloadFolderPath))
				{
					Directory.CreateDirectory(downloadFolderPath);
				}

				var downloadPath = Path.Combine(downloadFolderPath, fileNameValue);
				Stream output = File.Create(downloadPath);

				var res2 = _sftpclient.BeginDownloadFile(filename, output, cbFinished, filename, (dd) =>
				{

				});
				res2.AsyncWaitHandle.WaitOne();

				return response.Set(StatusCode.Success, "File Downloaded Successfully");
			}
			catch (Exception ex)
			{
				return response.Set(StatusCode.Failure, $"Error occured while file downloading {ex.Message}");
				throw;
			}
		}
	}
}
