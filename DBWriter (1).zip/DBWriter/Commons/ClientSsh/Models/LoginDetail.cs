﻿using System.Reflection;

namespace CTCL.ClientSFTP.Models
{
    public class LoginDetail
    {
        public string Userid { get; set; }
        public string Password { get; set; }
        public int Port { get; set; } = 22;
        public string Ipaddress { get; set; }
        public string FileType { get; set; }
        public string File { get; set; }
        public string Terminalid { get; set; }

    }
    
}