﻿namespace CTCL.BinaryProtocol.BSE.Enum;

public enum BSE_AccountType : byte
{
    Own = 20,
    Client = 30
}

public enum BSE_PartyIDEnteringFirm : byte
{
    Participant = 1,
    MarketSupervision = 2,
}

public enum BSE_ProductComplex : byte
{
    SimpleInstrument = 1,
    StandardOptionStrategy = 2,
    FuturesSpread = 5,
}

public enum BSE_EOrderStatus
{
    New = '0',
    PartiallyFilled = '1',
    Filled = '2',
    Cancelled = '4',
    Suspended = '9'
}

public enum BSE_EExecType
{
    New = '0',
    Cancelled = '4',
    Replaced = '5',
    Suspended = '9',
    Restated = 'D',
    Triggered = 'L',
    Trade = 'F',
    RRMOrderAccept = 'M',
    RRMOrderReject = 'N',
    ProvisionalAccept = 'X',
    ProvisionalReject = 'Y',
}

public enum BSE_Side : byte
{
    Buy = 1,
    Sell = 2,
    Recal = 3,
    EarlyReturn = 4,
}

public enum BSE_OrderType : byte
{
    Limit = 2,
    StopMarket = 3,
    StopLimit = 4,
    Market = 5,
    BlockDeal = 6,
}

public enum BSE_TimeInForce : byte
{
    Day = 0,
    IOC = 3,
    GFS = 7
}

public enum BSE_ExecInst : byte
{
    NA = 0,
    PersistentOrder = 1,
    NonPersistentOrder = 2,
    PersistentAndNonPersistentOrderBoth = 3,
    PersistentBOCOrder = 5,
    NonPersistentBOCOrder = 6,
}

public enum BSE_ApplSeqIndicator : byte
{
    LeanOrder = 0,
    StandardOrder = 1,
}

public enum BSE_STPCFlag : byte
{
    Passive = 0,
    Active = 1,
}

public enum BSE_SessionMode : byte
{
    HF = 1,
    LF = 2,
}

public enum BSE_SubSessionMode : byte
{
    RegularTradingSession = 0,
    FixTradingSession = 1,
    RegularBackOfficeSession = 2,
}

public enum BSE_TradeSessionMode : byte
{
    Development = 1,
    Simulation = 2,
    Production = 3,
    Acceptance = 4,
    DisasterRecovery = 5,
}

public enum BSE_EApplUsageOrders
{
    Automated = 'A',
    Manual = 'M',
    BothManualANDAutomated = 'B',
    NONE = 'N',
}

public enum BSE_EApplUsageQuotes
{
    Automated = 'A',
    Manual = 'M',
    BothManualANDAutomated = 'B',
    NONE = 'N',
}

public enum BSE_EOrderRoutingIndicator
{
    Automated = 'A',
    Manual = 'M',
    BothManualANDAutomated = 'B',
    NONE = 'N',
}

public enum BSE_RefApplID : byte
{
    Trade = 1,
    News = 2,
    SessionData = 4,
    ListenerData = 5,
    RiskControl = 6,
    RiskAdmin = 8,
    TradeEnhancement = 0
}

public enum BSE_PriceValidityCheckType : byte
{
   None = 0,
}

public enum BSE_ExecRestatementReason : short
{
    OrderBookRestatement = 001,
    OrderAdded = 101,
    OrderReplaced = 102,
    IOCOrderCancelled = 105,
    BookOrderExecuted = 108,
    BOCOrderCancelled = 212,
    MarketOrderTriggered = 135,
    OCOOrderTriggered = 164,
    StopOrderTriggered = 172,
    PendingCancellationExecuted = 199,
    RRMOrderAdded = 215,
    RRMOrderAccepted = 216,
    RRMOrderDeleted = 219,
    RRMOrderTriggered = 220,
    ProvisionalOrderAdded = 221,
    ProvisionalOrderAccepted = 222,
    ProvisionalOrderUpdationRejected = 223,
    ProvisionalOrderUpdatedSussfully = 223,
    SelfTradeOrderDelete = 246,
    ReverseTradeOrderDeleted = 247,
    MarketOrderOutRange = 265,
}

public enum BSE_Triggered : byte
{
    NotTriggered = 0,       
    TriggeredStopOrder = 1,
    TriggeredOCOOrder = 2, 
}

public enum BSE_MultiLegReportingType : byte
{
    SingleOrder = 1,
    IndividualLegofComplexOrder = 2

}

public enum BSE_TradeReportType : byte
{
    NA = 0,   

}

public enum BSE_TransferReason : byte
{
    Owner = 1,
    Clearer = 2,
}

public enum BSE_MatchType : byte
{
    AutoMatchIncoming  = 4,
    CallAuction = 7,
    AutoMatchResting = 11
}

public enum BSE_SubMatchType : byte
{
    OpeningAuction = 1,
    IntradayAuction = 3,
}

public enum BSE_AggressorIndicator : byte
{
    Passive = 0,
    Aggressive = 1,
}

public enum BSE_EOrderCategory
{
    Order = '1',
    Quote = '2',
    MultiLegOrder = '3'
}

public enum BSE_RelatedProductComplex : byte
{
    StandardOptionStrategy = 2,
    FuturesSpread = 5,

}

public enum BSE_SessionStatus : byte
{
    SessionActive = 0,
    SessionLogoutComplete = 4,

}

public enum BSE_TradeSesEvent : byte
{
    StartOfService = 101,
    MarketReset = 102,
    EndOfRestatement = 103,
    EndOfDayService = 104,

}







