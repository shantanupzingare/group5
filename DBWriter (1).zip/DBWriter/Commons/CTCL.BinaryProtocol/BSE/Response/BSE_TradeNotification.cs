﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_TradeNotification
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderRBC ResponseHeader;

    //Message Body
    public BSE_SecurityID SecurityID;
    public BSE_SecurityID RelatedSecurityID;
    public BSE_Price Price;
    public BSE_Price LastPx;
    public BSE_Price SideLastPx;
    public BSE_Price ClearingTradePrice;
    public BSE_Price Yield;
    public BSE_Price UnderlyingDirtyPrice;
    public BSE_Timestamp TransactTime;
    public BSE_OrderNumber OrderID;
    public BSE_SenderLocationID SenderLocationID;
    public BSE_OrderNumber ClOrdID;
    public BSE_Timestamp ActivityTime;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;
    public BSE_MessageTag MessageTag;
    public BSE_TradeID TradeID;
    public BSE_TradeID OrigTradeID;
    public BSE_RootPartyIDExecutingUnit RootPartyIDExecutingUnit;
    public BSE_SessionID RootPartyIDSessionID;
    public BSE_TradeID RootPartyIDExecutingTrader;
    public BSE_RootPartyIDClearingUnit RootPartyIDClearingUnit;    
    public BSE_Quantity CumQty;
    public BSE_Quantity LeavesQty;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_Symbol RelatedSymbol;
    public BSE_Quantity LastQty;
    public BSE_Quantity SideLastQty;
    public BSE_Quantity ClearingTradeQty;
    public BSE_TradeID SideTradeID;
    public BSE_LocalMktDate MatchDate;
    public BSE_FillMatchID TRDMatchID;
    public BSE_StrategyLinkID StrategyLinkID;
    public BSE_TotNumTradeReports TotNumTradeReports;
    public BSE_Filler2 Filler21;
    public BSE_MultiLegReportingType MultiLegReportingType;
    public BSE_TradeReportType TradeReportType;
    public BSE_TransferReason TransferReason;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_RootPartyIDBeneficiary RootPartyIDBeneficiary;
    public BSE_RootPartyIDTakeUpTradingFirm RootPartyIDTakeUpTradingFirm;
    public BSE_RootPartyIDOrderOriginationFirm RootPartyIDOrderOriginationFirm;
    public BSE_AccountType AccountType;
    public BSE_MatchType MatchType;
    public BSE_SubMatchType MatchSubType;
    public BSE_Side Side;
    public BSE_AggressorIndicator AggressorIndicator;
    public BSE_TradingCapacity TradingCapacity;
    public BSE_Account Account;
    public BSE_PositionEffect PositionEffect;
    public BSE_CustOrderHandlingInst CustOrderHandlingInst;
    public BSE_AlgoID AlgoID;
    public BSE_ClientCode ClientCode;
    public BSE_CPCode CPCode;
    public BSE_FreeText FreeText;
    public BSE_OrderCategory OrderCategory;
    public BSE_OrderType OrderType;
    public BSE_RelatedProductComplex RelatedProductComplex;
    public BSE_Side OrderSide;
    public BSE_RootPartyClearingOrganization RootPartyClearingOrganization;
    public BSE_RootPartyExecutingFirm RootPartyExecutingFirm;
    public BSE_RootPartyExecutingTrader RootPartyExecutingTrader;
    public BSE_RootPartyClearingFirm RootPartyClearingFirm;
    public BSE_Pad7 Pad7;
}
