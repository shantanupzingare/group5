﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderEntryConfirm
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Price PriceMkToLimitPx;
    public BSE_Price Yield;
    public BSE_Price UnderlyingDirtyPrice;
    public BSE_Timestamp ExecID;
    public BSE_Timestamp TrdRegTSEntryTime;
    public BSE_Timestamp TrdRegTSTimePriority;
    public BSE_Timestamp ActivityTime;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;    
    public BSE_Filler2 Filler21;
    public BSE_OrderStatus OrderStatus;
    public BSE_ExecType ExecType;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_ProductComplex ProductComplex;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_Pad4 Pad4;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_LeanOrderEntryConfirm
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_LeanResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_SecurityID SecurityID;
    public BSE_Price PriceMkToLimitPx;
    public BSE_Price Yield;
    public BSE_Price UnderlyingDirtyPrice;
    public BSE_Timestamp ExecID;
    public BSE_Timestamp TrdRegTSEntryTime;
    public BSE_Timestamp TrdRegTSTimePriority;
    public BSE_Timestamp ActivityTime;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;
    public BSE_Filler2 Filler21;
    public BSE_OrderStatus OrderStatus;
    public BSE_ExecType ExecType;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_ProductComplex ProductComplex;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_Pad4 Pad4;
}
