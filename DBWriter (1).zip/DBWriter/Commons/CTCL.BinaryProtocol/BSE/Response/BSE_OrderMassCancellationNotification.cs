﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderMassCancellation
{
    public BSE_OrderMassCancellationNotification OrderMassCancellationNotification;
    public BSE_NotAffectedOrdersGrp[] NotAffectedOrdersGrp;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderMassCancellationNotification
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_Timestamp MassActionReportID;
    public BSE_InstrumentID SecurityID;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_SessionID TargetPartyIDSessionID;
    public BSE_TraderID TargetPartyIDExecutingTrader;
    public BSE_TraderID PartyIDEnteringTrader;
    public BSE_Count2 NoNotAffectedOrders;
    public BSE_PartyIDEnteringFirm PartyIDEnteringFirm;
    public BSE_MassActionReason MassActionReason;
    public BSE_ExecInst ExecInst;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_NotAffectedOrdersGrp
{
    public BSE_OrderNumber NotAffectedOrderID;
    public BSE_OrderNumber NotAffOrigClOrdID;
}