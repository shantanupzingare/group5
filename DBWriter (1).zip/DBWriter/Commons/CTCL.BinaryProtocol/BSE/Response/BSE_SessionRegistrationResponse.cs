﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response; 

[StructLayout(LayoutKind.Sequential, Pack = 1)] 
public class BSE_SessionRegistrationResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_Status Status;
    public BSE_Pad1 Pad1;
    public BSE_Count2 VarTextLen;  
    public BSE_Pad4 Pad4;
    public BSE_VarText VarText;

}
