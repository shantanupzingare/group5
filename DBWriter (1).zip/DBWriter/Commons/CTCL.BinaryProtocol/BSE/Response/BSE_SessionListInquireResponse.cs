﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionListInquire
{
    public BSE_SessionListInquireResponse SessionListInquireResponse;    
    public BSE_SessionGroup[] SessionGroup;
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionListInquireResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_Count2 NoSessions;
    public BSE_Pad6 Pad6;   
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionGroup
{
    public BSE_SessionID PartySessionID;
    public BSE_SessionMode SessionMode;
    public BSE_SubSessionMode SubSessionMode;
    public BSE_Pad2 Pad2;
}