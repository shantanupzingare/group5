﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ExtendedOrderInfo
{
    public BSE_ExtendedOrder ExtendedOrder;
    public BSE_LegOrderGroup[] LegOrderGroup;
    public BSE_FillsGroup[] FillsGroup;
    public BSE_InstrmntLegExecGrp[] InstrmntLegExecGrp;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ExtendedOrder
{
    public BSE_ResponseMessageHeader MessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;

    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrderID;
    public BSE_OrderNumber OrigClOrderID;
    public BSE_InstrumentID SecurityID;
    public BSE_Price MaxPricePercentage;
    public BSE_SenderLocationID SenderLocationID;

    public BSE_Timestamp ExecID;
    public BSE_Timestamp TrdRegTSEntryTime;
    public BSE_Timestamp TrdRegTSTimePriority;

    public BSE_Price Price;
    public BSE_Price StopPx;
    public BSE_Price UnderlyingDirtyPrice;
    public BSE_Price Yield;

    public BSE_Timestamp ActivityTime;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_MessageTag MessageTag;

    public BSE_Quantity LeavesQty; // Remaining Qty of order if order executed partially
    public BSE_Quantity MaxShow; // Disclosed Qty
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_Quantity OrderQty;
    public BSE_LocalMktDate LocalMktDate;

    public BSE_PartyIDExecutingUnit PartyIDExecutingUnit;
    public BSE_SessionID PartyIDSessionID;
    public BSE_PartyIDExecutingUnit PartyIDExecutingTrader;
    public BSE_SessionID PartyIDEnteringTrader;
    public BSE_Filler2 Filler2;

    public BSE_Count2 NoLegExecs;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_AccountType AccountType;
    public BSE_PartyIDEnteringFirm PartyIDEnteringFirm;
    public BSE_ProductComplex ProductComplex;
    public BSE_OrderStatus OrderStatus;
    public BSE_ExecType ExecType;
    public BSE_Side Side;
    public BSE_OrderType OrderType;
    public BSE_TradingCapacity TradingCapacity;
    public BSE_TimeInForce TimeInForce;
    public BSE_ExecInst ExecInst;
    public BSE_TradingSessionSubID TradingSessionSubID;
    public BSE_ApplSeqIndicator ApplSeqIndicator;
    public BSE_STPCFlag STPCFlag;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_Account Account;
    public BSE_PositionEffect PositionEffect;
    public BSE_PartyIDTakeUpTradingFirm PartyIDTakeUpTradingFirm;
    public BSE_PartyIDOrderOriginationFirm PartyIDOrderOriginationFirm;
    public BSE_PartyIDBeneficiary PartyIDBeneficiary;
    public BSE_PartyIDLocationID PartyIDLocationID;
    public BSE_CustOrderHandlingInst CustOrderHandlingInst;
    public BSE_RegulatoryText RegulatoryText;
    public BSE_AlgoID AlgoID;
    public BSE_ClientCode ClientCode;
    public BSE_ClientCode CPCode;
    public BSE_FreeText FreeText;
    public BSE_Count1 NoFills;
    public BSE_Count1 NoLegs;
    public BSE_Triggered Triggered;
    public BSE_Pad2 Pad2;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_LegOrderGroup
{
    public BSE_Account LegAccount;
    public BSE_PositionEffect LegPositionEffect;
    public BSE_Pad5 Pad5;
}