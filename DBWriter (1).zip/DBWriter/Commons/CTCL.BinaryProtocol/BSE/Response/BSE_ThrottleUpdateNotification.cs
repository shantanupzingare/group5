﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ThrottleUpdateNotification
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;

    public BSE_Timestamp SendingTime;
    public BSE_ThrottleTimeInterval ThrottleTimeInterval;
    public BSE_ThrottleNoMsgs ThrottleNoMsgs;
    public BSE_ThrottleDisconnectLimit ThrottleDisconnectLimit;
}
