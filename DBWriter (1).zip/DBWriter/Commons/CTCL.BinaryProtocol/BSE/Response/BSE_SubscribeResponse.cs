﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SubscribeResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_SenderID ApplSubID;
    public BSE_Pad4 Pad4;

}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UnSubscribeResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;
    
}

