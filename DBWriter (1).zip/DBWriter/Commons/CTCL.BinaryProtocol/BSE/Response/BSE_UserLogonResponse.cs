﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UserLogonResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_Timestamp LastLoginTime;
    public BSE_DaysLeftForPasswdExpiry DaysLeftForPasswdExpiry;
    public BSE_GraceLoginsLeft GraceLoginsLeft;
    public BSE_Pad4 Pad4;
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UserLogotResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;
}
