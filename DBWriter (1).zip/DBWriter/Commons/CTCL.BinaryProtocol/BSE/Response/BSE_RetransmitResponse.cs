﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_RetransmitResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_ApplSeqNum ApplEndSeqNum;
    public BSE_ApplSeqNum RefApplLastSeqNum;
    public BSE_Count2 ApplTotalMessageCount;
    public BSE_Pad6 Pad6;
}
