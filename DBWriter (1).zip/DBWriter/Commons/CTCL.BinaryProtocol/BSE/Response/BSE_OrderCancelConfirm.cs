﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderCancelConfirm
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Timestamp ExecID;
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_OrderStatus OrdStatus;
    public BSE_ExecType ExecType;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_ProductComplex ProductComplex;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_LeanOrderCancelConfirm
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_LeanResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Timestamp ExecID;
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_OrderStatus OrdStatus;
    public BSE_ExecType ExecType;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_ProductComplex ProductComplex;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_CancelOrderNotification
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;
    //Body Message
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Timestamp ExecID;
    public BSE_MessageTag MessageTag;
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_TraderID PartyIDEnteringTrader;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_PartyIDEnteringFirm PartyIDEnteringFirm;
    public BSE_OrderStatus OrdStatus;
    public BSE_ExecType ExecType;    
    public BSE_ProductComplex ProductComplex;
    public BSE_Side Side;
    public BSE_Pad5 Pad5;
}

