﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_DebtInquiryResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderME ResponseHeader;

    //Message Body
    public BSE_Price UnderlyingPx;
    public BSE_Price Yield;
    public BSE_Price AccruedInterestAmt;
    public BSE_Amount GrossTradeAmt;
    public BSE_Price UnderlyingDirtyPrice;
    public BSE_SecurityID SecurityID;
    public BSE_Quantity OrderQty;
}
