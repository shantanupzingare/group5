﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderConfirm
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Message Body
    public BSE_OrderNumber PrimaryOrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_MessageTag MessageTag;
    public BSE_Pad4 Pad4;
}
