﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ImmediateOrderExecution
{
    public BSE_ImmediateExecutionOrderResponse ImmediateExecutionOrderResponse;
    public BSE_FillsGroup[] FillsGroup;
    public BSE_InstrmntLegExecGrp[] InstrmntLegExecGrp;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ImmediateExecutionOrderResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderME ResponseHeader;

    //Message Body
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Timestamp ExecID;
    public BSE_Timestamp TrdRegTSEntryTime;
    public BSE_Timestamp TrdRegTSTimePriority;
    public BSE_Timestamp ActivityTime;
    public BSE_Price Price;
    public BSE_Filler4 Filler41;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_Quantity LeavesQty;
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_Filler2 Filler21;
    public BSE_Count2 NoLegExecs;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_ProductComplex ProductComplex;
    public BSE_OrderStatus OrderStatus;
    public BSE_ExecType ExecType;
    public BSE_Triggered Triggered;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_Count1 NoFills;
    public BSE_AlgoID AlgoID;    
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_FillsGroup
{
    public BSE_Price FillPx;
    public BSE_Price FillYield;
    public BSE_Price FillDirtyPx;
    public BSE_Quantity FillQty;
    public BSE_FillMatchID FillMatchID;
    public BSE_FillExecID FillExecID;
    public BSE_FillLiquidityInd FillLiquidityInd;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_InstrmntLegExecGrp
{
    public BSE_SecurityID LegSecurityID;
    public BSE_Price LegLastPx;
    public BSE_Quantity LegLastQty;
    public BSE_LegExecID LegExecID;
    public BSE_Side LegSide;
    public BSE_NoFillsIndex NoFillsIndex;
    public BSE_Pad6 Pad6;
}
