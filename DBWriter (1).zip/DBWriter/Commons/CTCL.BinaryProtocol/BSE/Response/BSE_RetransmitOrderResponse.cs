﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_RetransmitOrderResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_Count2 ApplTotalMessageCount;
    public BSE_ApplMsgID ApplEndMsgID;
    public BSE_ApplMsgID RefApplLastMsgID;
    public BSE_Pad6 Pad6;
}
