﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ConnectionGatewayResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Message Body
    public BSE_IP GatewayID;
    public BSE_Port GatewaySubID;
    public BSE_IP SecondaryGatewayID;
    public BSE_Port SecondaryGatewaySubID;
    public BSE_SessionMode SessionMode;
    public BSE_TradeSessionMode TradeSessionMode;
    public BSE_SecurityKey KEY;
    public BSE_IV IV;
    public BSE_Pad6 Pad6;

}
