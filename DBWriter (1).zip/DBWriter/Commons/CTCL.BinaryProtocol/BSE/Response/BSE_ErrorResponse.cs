﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ErrorResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeaderErrror ResponseHeader;

    //Message Body
    public BSE_SessionRejectReason SessionRejectReason;
    public BSE_Count2 VarTextLen;
    public BSE_SessionStatus SessionStatus;
    public BSE_Pad1 Pad1;
    public BSE_VarText VarText;
}
