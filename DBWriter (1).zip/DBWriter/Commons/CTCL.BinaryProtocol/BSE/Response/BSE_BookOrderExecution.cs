﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_BookOrderExecution
{
    public BSE_BookOrderExecutionResponse BookOrderExecutionResponse;
    public BSE_FillsGroup[] FillsGroup;
    public BSE_InstrmntLegExecGrp[] InstrmntLegExecGrp;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_BookOrderExecutionResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;

    //Message Body
    public BSE_OrderNumber OrderID;
    public BSE_SenderLocationID SenderLocationID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_InstrumentID SecurityID;
    public BSE_Timestamp ExecID;
    public BSE_Timestamp ActivityTime;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;
    public BSE_MessageTag MessageTag;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_Quantity LeavesQty;
    public BSE_Quantity CumQty;
    public BSE_Quantity CxlQty;
    public BSE_Count2 NoLegExecs;
    public BSE_Filler2 Filler21;
    public BSE_ExecRestatementReason ExecRestatementReason;
    public BSE_AccountType AccountType;
    public BSE_ProductComplex ProductComplex;
    public BSE_OrderStatus OrderStatus;
    public BSE_ExecType ExecType;
    public BSE_Triggered Triggered;
    public BSE_Count1 NoFills;
    public BSE_Side Side;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_Account Account;
    public BSE_AlgoID AlgoID;
    public BSE_ClientCode ClientCode;
    public BSE_CPCode CPCode;
    public BSE_FreeText FreeText;
    public BSE_Pad4 Pad4;
}
