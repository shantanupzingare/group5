﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionLogonResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    //Body Message
    public BSE_ThrottleTimeInterval ThrottleTimeInterval;
    public BSE_Timestamp LastLoginTime;
    public BSE_IP LastLoginIP;
    public BSE_ThrottleNoMsgs ThrottleNoMsgs;
    public BSE_ThrottleDisconnectLimit ThrottleDisconnectLimit;
    public BSE_HeartBtInt HeartBtInt;
    public BSE_SessionInstanceID SessionInstanceID;
    public BSE_TradeSessionMode TradeSessionMode;
    public BSE_NoOfPartition NoOfPartition;
    public BSE_DaysLeftForPasswdExpiry DaysLeftForPasswdExpiry;
    public BSE_GraceLoginsLeft GraceLoginsLeft;
    public BSE_DefaultCstmApplVerID DefaultCstmApplVerID;
    public BSE_Pad2 Pad2;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionLogoutResponse
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionLogoutNotification
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_ResponseHeader ResponseHeader;

    public BSE_Timestamp SendingTime;
    public BSE_Count2 VarTextLen;
    public BSE_Pad6 Pad6;
    public BSE_VarText VarText;
}