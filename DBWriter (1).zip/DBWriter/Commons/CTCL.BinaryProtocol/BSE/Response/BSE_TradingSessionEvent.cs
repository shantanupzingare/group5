﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_TradingSessionEvent
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_LocalMktDate TradeDate;
    public BSE_TradeSesEvent TradeSesEvent;
    public BSE_ApplMsgID RefApplLastMsgID;
    public BSE_Pad7 Pad7;
}
