﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;

namespace CTCL.BinaryProtocol.BSE.Response;

public class BSE_OrderMassCancellationEvent
{
    public BSE_ResponseMessageHeader ResponseMessageHeader;
    public BSE_TRDResponseHeaderME ResponseHeader;

    //Body Message
    public BSE_Timestamp MassActionReportID;
    public BSE_InstrumentID SecurityID;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_MassActionReason MassActionReason;
    public BSE_ExecInst ExecInst;
    public BSE_Pad2 Pad2;
}
