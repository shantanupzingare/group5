﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_RequestMessageHeader
{
    public BSE_BdyLen BdyLen;
    public BSE_TemplateID TemplateID;
    public BSE_NetworkMsgID NetworkMsgID;
    public BSE_Pad2 Pad2;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_RequestHeader
{
    public BSE_MsgSeqNum MsgSeqNum;
    public BSE_SenderID SenderSubID;   
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ResponseMessageHeader
{
    public BSE_BdyLen BdyLen;
    public BSE_TemplateID TemplateID;   
    public BSE_Pad2 Pad2;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ResponseHeader
{
    public BSE_Timestamp RequestTime;
    public BSE_Timestamp SendingTime;
    public BSE_MsgSeqNum MsgSeqNum;
    public BSE_Pad4 Pad4;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ResponseHeaderME
{
    public BSE_Timestamp RequestTime;
    public BSE_Timestamp RequestOut;
    public BSE_Timestamp TrdRegTSTimeIn;
    public BSE_Timestamp TrdRegTSTimeOut;
    public BSE_Timestamp ResponseIn;
    public BSE_Timestamp SendingTime;
    public BSE_MsgSeqNum MsgSeqNum;
    public BSE_PartitionID PartitionID;
    public BSE_ApplID ApplID;
    public BSE_ApplMsgID ApplMsgID;
    public BSE_LastFragment LastFragment;   
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_LeanResponseHeaderME
{
    public BSE_Timestamp RequestTime;
    public BSE_Timestamp RequestOut;
    public BSE_Timestamp TrdRegTSTimeIn;
    public BSE_Timestamp TrdRegTSTimeOut;
    public BSE_Timestamp ResponseIn;
    public BSE_Timestamp SendingTime;
    public BSE_MsgSeqNum MsgSeqNum;
    public BSE_LastFragment LastFragment;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_TRDResponseHeaderME
{   
    public BSE_Timestamp TrdRegTSTimeOut;
    public BSE_Timestamp SendingTime;
    public BSE_ApplSubID ApplSubID;
    public BSE_PartitionID PartitionID;
    public BSE_ApplMsgID ApplMsgID;
    public BSE_ApplID ApplID;
    public BSE_ApplResendFlag ApplResendFlag;
    public BSE_LastFragment LastFragment;
    public BSE_Pad7 Pad7;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ResponseHeaderRBC
{
    public BSE_Timestamp SendingTime;
    public BSE_ApplSeqNum ApplSeqNum;
    public BSE_ApplSubID ApplSubID;
    public BSE_PartitionID PartitionID;
    public BSE_ApplResendFlag ApplResendFlag;
    public BSE_ApplID ApplID;
    public BSE_LastFragment LastFragment;
    public BSE_Pad7 Pad7;    
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ResponseHeaderErrror
{
    public BSE_Timestamp RequestTime;
    public BSE_Timestamp RequestOut;
    public BSE_Timestamp TrdRegTSTimeIn;
    public BSE_Timestamp TrdRegTSTimeOut;
    public BSE_Timestamp ResponseIn;
    public BSE_Timestamp SendingTime;
    public BSE_MsgSeqNum MsgSeqNum;  
    public BSE_LastFragment LastFragment;
    public BSE_Pad3 Pad3;   

}



