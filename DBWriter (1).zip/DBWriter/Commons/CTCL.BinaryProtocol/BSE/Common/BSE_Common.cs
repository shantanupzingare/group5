﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Common;


#region Message Header

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_BdyLen
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_BdyLen(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TemplateID
{
    [MarshalAs(UnmanagedType.I2)]
    private short _val;
    public BSE_TemplateID(short _value)
    {
        _val = _value;
    }
    public short Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_NetworkMsgID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
    private char[] _val;
    public BSE_NetworkMsgID(char[] _value)
    {
        _val = new char[8];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_NetworkMsgID()
    {
        _val = new char[8];
    }
    public char[] Value { get => _val; set => _val = value; }
}

#endregion

#region Request Header

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MsgSeqNum
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_MsgSeqNum(Int32 _value)
    {
        _val = _value;
    }
    public BSE_MsgSeqNum()
    {
        _val = 1;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SenderID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SenderID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SessionID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SessionID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

#endregion

#region Pad

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad1
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_Pad1(char[] _value)
    {
        _val = new char[1];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad1()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad2
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _val;
    public BSE_Pad2(char[] _value)
    {
        _val = new char[2];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad2()
    {
        _val = new char[2];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad3
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _val;
    public BSE_Pad3(char[] _value)
    {
        _val = new char[3];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad3()
    {
        _val = new char[3];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad4
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _val;
    public BSE_Pad4(char[] _value)
    {
        _val = new char[4];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad4()
    {
        _val = new char[4];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad5
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_Pad5(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad5()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad6
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
    private char[] _val;
    public BSE_Pad6(char[] _value)
    {
        _val = new char[6];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad6()
    {
        _val = new char[6];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Pad7
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
    private char[] _val;
    public BSE_Pad7(char[] _value)
    {
        _val = new char[7];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Pad7()
    {
        _val = new char[7];
    }
    public char[] Value { get => _val; set => _val = value; }
}


#endregion

#region Timestamp

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Timestamp
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_Timestamp(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_LocalMktDate
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_LocalMktDate(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}




#endregion

#region IP & Port

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_IP
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private byte[] _val;
    public BSE_IP(byte[] _value)
    {
        _val = _value;
    }
    public byte[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Port
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_Port(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}


#endregion

#region Security Key & IV

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SecurityKey
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private byte[] _val;
    public BSE_SecurityKey(byte[] _value)
    {      
        _val = _value;
    }
    public BSE_SecurityKey()
    {
        _val = new byte[32];
    }
    public byte[] Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_IV
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private byte[] _val;
    public BSE_IV(byte[] _value)
    {
        _val = _value;
    }
    public BSE_IV()
    {
        _val = new byte[16];
    }
    public byte[] Value { get => _val; set => _val = value; }
}


#endregion

#region Fix Engine

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FIXEngineName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_FIXEngineName(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FIXEngineVersion
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_FIXEngineVersion(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FIXEngineVendor
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_FIXEngineVendor(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplicationSystemName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_ApplicationSystemName(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplicationSystemVersion
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_ApplicationSystemVersion(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplicationSystemVendor
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_ApplicationSystemVendor(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}



#endregion

#region Filler


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Filler8
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_Filler8(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Filler4
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_Filler4(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Filler2
{
    [MarshalAs(UnmanagedType.I2)]
    private Int16 _val;
    public BSE_Filler2(Int16 _value)
    {
        _val = _value;
    }
    public Int16 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Filler1
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_Filler1(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}


#endregion

#region Price & Quantity & Order

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Price
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_Price(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PricePercentage
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_PricePercentage(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_OrderNumber
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_OrderNumber(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Amount
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_Amount(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Quantity
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_Quantity(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SettlType
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SettlType(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MaxShow
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_MaxShow(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MessageTag
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_MessageTag(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MarketSegmentID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_MarketSegmentID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SecurityID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SecurityID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RegulatoryID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_RegulatoryID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RolloverFlag
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_RolloverFlag(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TradingSessionSubID
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_TradingSessionSubID(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TradingCapacity
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_TradingCapacity(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_DeltaQtyFlag
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_DeltaQtyFlag(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Account
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _val;
    public BSE_Account(char[] _value)
    {       
        _val = _value;
    }
    public BSE_Account()
    {
        _val = new char[2];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PositionEffect
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_PositionEffect(char[] _value)
    {
        _val = _value;
    }
    public BSE_PositionEffect()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartyIDLocationID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _val;
    public BSE_PartyIDLocationID(char[] _value)
    {
        _val = new char[2];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_PartyIDLocationID()
    {
        _val = new char[2];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_CustOrderHandlingInst
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_CustOrderHandlingInst(char[] _value)
    {
        _val = _value;
    }
    public BSE_CustOrderHandlingInst()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RegulatoryText
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
    private char[] _val;
    public BSE_RegulatoryText(char[] _value)
    {
        _val = new char[20];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RegulatoryText()
    {
        _val = new char[20];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_AlgoID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _val;
    public BSE_AlgoID()
    {
        _val = new char[16];
    }
    public BSE_AlgoID(char[] _value)
    {
        _val = new char[16];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }  
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ClientCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _val;
    public BSE_ClientCode()
    {
        _val = new char[12];
    }
    public BSE_ClientCode(char[] _value)
    {
        _val = new char[12];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_CPCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _val;
    public BSE_CPCode()
    {
        _val = new char[12];
    }
    public BSE_CPCode(char[] _value)
    {
        _val = new char[12];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FreeText
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _val;
    public BSE_FreeText()
    {
        _val = new char[12];
    }
    public BSE_FreeText(char[] _value)
    {
        _val = new char[12];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}



#endregion

#region Party ID

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartyIDTakeUpTradingFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_PartyIDTakeUpTradingFirm(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_PartyIDTakeUpTradingFirm()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartyIDOrderOriginationFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
    private char[] _val;
    public BSE_PartyIDOrderOriginationFirm(char[] _value)
    {
        _val = new char[7];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_PartyIDOrderOriginationFirm()
    {
        _val = new char[7];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartyIDBeneficiary
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
    private char[] _val;
    public BSE_PartyIDBeneficiary(char[] _value)
    {
        _val = new char[9];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_PartyIDBeneficiary()
    {
        _val = new char[9];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyIDTakeUpTradingFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_RootPartyIDTakeUpTradingFirm(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyIDTakeUpTradingFirm()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyIDOrderOriginationFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
    private char[] _val;
    public BSE_RootPartyIDOrderOriginationFirm(char[] _value)
    {
        _val = new char[7];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyIDOrderOriginationFirm()
    {
        _val = new char[7];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyIDBeneficiary
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
    private char[] _val;
    public BSE_RootPartyIDBeneficiary(char[] _value)
    {
        _val = new char[9];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyIDBeneficiary()
    {
        _val = new char[9];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyClearingOrganization
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _val;
    public BSE_RootPartyClearingOrganization(char[] _value)
    {
        _val = new char[4];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyClearingOrganization()
    {
        _val = new char[4];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyExecutingFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_RootPartyExecutingFirm(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyExecutingFirm()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyExecutingTrader
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
    private char[] _val;
    public BSE_RootPartyExecutingTrader(char[] _value)
    {
        _val = new char[6];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyExecutingTrader()
    {
        _val = new char[6];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyClearingFirm
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_RootPartyClearingFirm(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_RootPartyClearingFirm()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}



#endregion

#region ALl

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SenderLocationID
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_SenderLocationID(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_DefaultCstmApplVerID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _val;
    public BSE_DefaultCstmApplVerID(char[] _value)
    {
        _val = new char[30];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Password
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _val;
    public BSE_Password(char[] _value)
    {
        _val = new char[32];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Count2
{
    [MarshalAs(UnmanagedType.I2)]
    private short _val;
    public BSE_Count2(short _value)
    {
        _val = _value;
    }
    public short Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Count1
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_Count1(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_HeartBtInt
{
    [MarshalAs(UnmanagedType.I4)]
    private int _val;
    public BSE_HeartBtInt(int _value)
    {
        _val = _value;
    }
    public int Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplUsageOrders
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_ApplUsageOrders(char[] _value)
    {
        _val = _value;
    }
    public BSE_ApplUsageOrders()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ExecType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_ExecType(char[] _value)
    {
        _val = _value;
    }
    public BSE_ExecType()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_OrderCategory
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_OrderCategory(char[] _value)
    {
        _val = _value;
    }
    public BSE_OrderCategory()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_OrderStatus
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_OrderStatus(char[] _value)
    {
        _val = _value;
    }
    public BSE_OrderStatus()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplUsageQuotes
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_ApplUsageQuotes(char[] _value)
    {
        _val = _value;
    }
    public BSE_ApplUsageQuotes()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_OrderRoutingIndicator
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_OrderRoutingIndicator(char[] _value)
    {
        _val = _value;
    }
    public BSE_OrderRoutingIndicator()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_VarText
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2000)]
    private char[] _val;
    public BSE_VarText(char[] _value)
    {
        _val = _value;
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ThrottleTimeInterval
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_ThrottleTimeInterval(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_LastLoginIP
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_LastLoginIP(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SessionRejectReason
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SessionRejectReason(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ThrottleNoMsgs
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_ThrottleNoMsgs(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ThrottleDisconnectLimit
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_ThrottleDisconnectLimit(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SessionInstanceID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_SessionInstanceID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_NoOfPartition
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_NoOfPartition(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_DaysLeftForPasswdExpiry
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_DaysLeftForPasswdExpiry(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_GraceLoginsLeft
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_GraceLoginsLeft(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Status
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_Status(char[] _value)
    {      
        _val = _value;
    }
    public BSE_Status()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TraderID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_TraderID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplSeqNum
{
    [MarshalAs(UnmanagedType.I8)]
    private UInt64 _val;
    public BSE_ApplSeqNum(UInt64 _value)
    {
        _val = _value;
    }
    public UInt64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartitionID
{
    [MarshalAs(UnmanagedType.I2)]
    private UInt16 _val;
    public BSE_PartitionID(UInt16 _value)
    {
        _val = _value;
    }
    public UInt16 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_LastFragment
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_LastFragment(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplResendFlag
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_ApplResendFlag(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplID
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_ApplID(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplMsgID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private byte[] _val;
    public BSE_ApplMsgID(byte[] _value)
    {
        _val = _value;
    }
    public BSE_ApplMsgID()
    {
        _val = new byte[16];
    }
    public byte[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FillMatchID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_FillMatchID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FillExecID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_FillExecID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ApplSubID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_ApplSubID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_LegExecID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_LegExecID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FillLiquidityInd
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_FillLiquidityInd(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_NoFillsIndex
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_NoFillsIndex(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TradeID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_TradeID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyIDExecutingUnit
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_RootPartyIDExecutingUnit(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_RootPartyIDClearingUnit
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_RootPartyIDClearingUnit(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Symbol
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_Symbol(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_StrategyLinkID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_StrategyLinkID(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TotNumTradeReports
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_TotNumTradeReports(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}


#endregion

#region Security Master

public struct BSE_IssueCapital
{
   
    private decimal _val;
    public BSE_IssueCapital(decimal _value)
    {
        _val = _value;
    }
    public decimal Value { get => _val; set => _val = value; }
}

public struct BSE_Decial
{

    private decimal _val;
    public BSE_Decial(decimal _value)
    {
        _val = _value;
    }
    public decimal Value { get => _val; set => _val = value; }
}


public struct BSE_NumericTickSize1
{

    private decimal _val;
    public BSE_NumericTickSize1(decimal _value)
    {
        _val = _value;
    }
    public decimal Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_InstrumentID
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_InstrumentID(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MarketLotQty
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_MarketLotQty(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_FaceValue
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_FaceValue(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SecurityShort
{
    [MarshalAs(UnmanagedType.I2)]
    private short _val;
    public BSE_SecurityShort(short _value)
    {
        _val = _value;
    }
    public short Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SecurityLong
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _val;
    public BSE_SecurityLong(Int64 _value)
    {
        _val = _value;
    }
    public Int64 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SymbolChar12
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _val;
    public BSE_SymbolChar12(char[] _value)
    {
        _val = new char[12];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_SymbolChar12()
    {
        _val = new char[12];
    }
    public char[] Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_GroupName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _val;
    public BSE_GroupName(char[] _value)
    {
        _val = new char[3];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_GroupName()
    {
        _val = new char[3];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_InstrumentName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] _val;
    public BSE_InstrumentName(char[] _value)
    {
        _val = new char[40];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_InstrumentName()
    {
        _val = new char[40];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_ISINCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
    private char[] _val;
    public BSE_ISINCode(char[] _value)
    {
        _val = new char[19];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_ISINCode()
    {
        _val = new char[19];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_SecurityTypeFlag
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _val;
    public BSE_SecurityTypeFlag(char[] _value)
    {
        _val = new char[10];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_SecurityTypeFlag()
    {
        _val = new char[10];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_TickSize
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _val;
    public BSE_TickSize(char[] _value)
    {
        _val = new char[10];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_TickSize()
    {
        _val = new char[10];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char10
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _val;
    public BSE_Char10(char[] _value)
    {
        _val = new char[10];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char10()
    {
        _val = new char[10];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char1
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _val;
    public BSE_Char1(char[] _value)
    {
        _val = _value;
    }
    public BSE_Char1()
    {
        _val = new char[1];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char4
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _val;
    public BSE_Char4(char[] _value)
    {
        _val = new char[4];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char4()
    {
        _val = new char[4];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char19
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
    private char[] _val;
    public BSE_Char19(char[] _value)
    {
        _val = new char[19];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char19()
    {
        _val = new char[19];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char50
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _val;
    public BSE_Char50(char[] _value)
    {
        _val = new char[50];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char50()
    {
        _val = new char[50];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char40
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] _val;
    public BSE_Char40(char[] _value)
    {
        _val = new char[40];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char40()
    {
        _val = new char[40];
    }
    public char[] Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char25
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _val;
    public BSE_Char25(char[] _value)
    {
        _val = new char[25];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char25()
    {
        _val = new char[25];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_InstrumentNameChar6
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
    private char[] _val;
    public BSE_InstrumentNameChar6(char[] _value)
    {
        _val = new char[6];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_InstrumentNameChar6()
    {
        _val = new char[6];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_InstrumentNameChar5
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _val;
    public BSE_InstrumentNameChar5(char[] _value)
    {
        _val = new char[5];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_InstrumentNameChar5()
    {
        _val = new char[5];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_Char100
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
    private char[] _val;
    public BSE_Char100(char[] _value)
    {
        _val = new char[100];
        Array.Copy(_value, 0, _val, 0, _value.Length > _val.Length ? _val.Length : _value.Length);
    }
    public BSE_Char100()
    {
        _val = new char[100];
    }
    public char[] Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_PartyIDExecutingUnit
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public BSE_PartyIDExecutingUnit(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct BSE_MassActionReason
{
    [MarshalAs(UnmanagedType.I1)]
    private byte _val;
    public BSE_MassActionReason(byte _value)
    {
        _val = _value;
    }
    public byte Value { get => _val; set => _val = value; }
}

#endregion