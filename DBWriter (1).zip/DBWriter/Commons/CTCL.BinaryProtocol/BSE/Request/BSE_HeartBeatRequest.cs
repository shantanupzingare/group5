﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_HeartBeatRequest
{
    public BSE_RequestMessageHeader MessageHeader;
}
