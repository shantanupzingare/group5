﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_RetransmitRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_ApplSeqNum ApplBegSeqNum;
    public BSE_ApplSeqNum ApplEndSeqNum;
    public BSE_SessionID SubscriptionScope;
    public BSE_PartitionID PartitionID;
    public BSE_RefApplID RefApplID;
    public BSE_Pad1 Pad1;
}
