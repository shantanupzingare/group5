﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_ConnectionGatewayRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_SessionID PartyIDSessionID; 
    public BSE_DefaultCstmApplVerID DefaultCstmApplVerID;
    public BSE_Password Password;
    public BSE_Pad6 Pad6;
}
