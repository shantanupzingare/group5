﻿using CTCL.BinaryProtocol.BSE.Common;
using CTCL.BinaryProtocol.BSE.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderEnterRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_Price Price;
    public BSE_Price StopPx;
    public BSE_PricePercentage MaxPricePercentage;
    public BSE_SenderLocationID SenderLocationID;
    public BSE_OrderNumber ClOrdID;
    public BSE_Filler8 Filler81;
    public BSE_Filler4 Filler41;
    public BSE_MessageTag MessageTag;
    public BSE_Quantity OrderQty;
    public BSE_MaxShow MaxShow;
    public BSE_LocalMktDate ExpiryDate;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_SecurityID SimpleSecurityID;
    public BSE_RegulatoryID RegulatoryID;
    public BSE_Filler2 Filler21;
    public BSE_PartyIDTakeUpTradingFirm PartyIDTakeUpTradingFirm;
    public BSE_PartyIDOrderOriginationFirm PartyIDOrderOriginationFirm;
    public BSE_PartyIDBeneficiary PartyIDBeneficiary;
    public BSE_AccountType AccountType;
    public BSE_ApplSeqIndicator ApplSeqIndicator;
    public BSE_Side Side;
    public BSE_OrderType OrderType;
    public BSE_PriceValidityCheckType PriceValidityCheckType;
    public BSE_TimeInForce TimeInForce;
    public BSE_ExecInst ExecInst;
    public BSE_STPCFlag STPCFlag;
    public BSE_RolloverFlag RolloverFlag;
    public BSE_TradingSessionSubID TradingSessionSubID;
    public BSE_TradingCapacity TradingCapacity;
    public BSE_Account Account;
    public BSE_PositionEffect PositionEffect;
    public BSE_PartyIDLocationID PartyIDLocationID;
    public BSE_CustOrderHandlingInst CustOrderHandlingInst;
    public BSE_RegulatoryText RegulatoryText;
    public BSE_AlgoID AlgoID;
    public BSE_ClientCode ClientCode;
    public BSE_CPCode CPCode;
    public BSE_FreeText FreeText;
}
