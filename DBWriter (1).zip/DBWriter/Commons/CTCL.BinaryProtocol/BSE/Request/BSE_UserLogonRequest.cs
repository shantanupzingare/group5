﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UserLogonRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_TraderID UserID;
    public BSE_Password Password;
    public BSE_Pad4 Pad4;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UserLogoutRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_TraderID UserID;    
    public BSE_Pad4 Pad4;
}
