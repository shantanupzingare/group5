﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionLogonRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_HeartBtInt HeartBtInt;
    public BSE_SessionID PartyIDSessionID;
    public BSE_DefaultCstmApplVerID DefaultCstmApplVerID;
    public BSE_Password Password;
    public BSE_ApplUsageOrders ApplUsageOrders;
    public BSE_ApplUsageQuotes ApplUsageQuotes;
    public BSE_OrderRoutingIndicator OrderRoutingIndicator;
    public BSE_FIXEngineName FixEngineName;
    public BSE_FIXEngineVersion FixEngineVersion;
    public BSE_FIXEngineVendor FIXEngineVendor;
    public BSE_ApplicationSystemName ApplicationSystemName;
    public BSE_ApplicationSystemVersion ApplicationSystemVersion;
    public BSE_ApplicationSystemVendor ApplicationSystemVendor;
    public BSE_Pad3 Pad3;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionLogoutRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;
}