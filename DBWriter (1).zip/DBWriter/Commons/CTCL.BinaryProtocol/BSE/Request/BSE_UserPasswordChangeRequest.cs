﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_UserPasswordChangeRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_TraderID UserID;
    public BSE_Password Password;
    public BSE_Password NewPassword;
    public BSE_Pad4 Pad4;
}
