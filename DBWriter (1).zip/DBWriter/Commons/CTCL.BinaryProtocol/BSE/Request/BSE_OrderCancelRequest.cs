﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_OrderCancelRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Message Body
    public BSE_OrderNumber OrderID;
    public BSE_OrderNumber ClOrdID;
    public BSE_OrderNumber OrigClOrdID;
    public BSE_Filler8 Filler81;
    public BSE_MessageTag MessageTag;
    public BSE_MarketSegmentID MarketSegmentID;
    public BSE_SecurityID SimpleSecurityID;
    public BSE_SessionID TargetPartyIDSessionID;
    public BSE_RegulatoryID RegulatoryID;
    public BSE_AlgoID AlgoID;
    public BSE_Pad4 Pad4;
}
