﻿using CTCL.BinaryProtocol.BSE.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.BSE.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class BSE_SessionRegistrationRequest
{
    public BSE_RequestMessageHeader MessageHeader;
    public BSE_RequestHeader RequestHeader;

    //Body Message 
    public BSE_SessionID PartyIDSessionID;
    public BSE_Pad4 Pad4;
    public BSE_Filler8 Filler;
}
