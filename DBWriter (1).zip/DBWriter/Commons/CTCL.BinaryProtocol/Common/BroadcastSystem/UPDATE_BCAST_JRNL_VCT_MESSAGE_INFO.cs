﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class UPDATE_BCAST_JRNL_VCT_MESSAGE_INFO
    {
        public BroadcastMessageHeader BroadcastMessageHeader;
        public CTCL_BranchID BranchNumber;
        public CTCL_BrokerID BrokerNumber;
        public CTCL_ActionCode ActionCode;
        public CTCL_ST_BCAST_DESTINATION2Byte CTCL_ST_BCAST_DESTINATION;
        public CTCL_BroadcastMessageLength BroadcastMessageLength;
        public CTCL_BroadcastMessage BroadcastMessage;
    }
}
