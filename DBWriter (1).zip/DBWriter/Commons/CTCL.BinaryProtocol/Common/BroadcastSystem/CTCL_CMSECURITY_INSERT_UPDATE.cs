﻿using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_CMSECURITY_INSERT_UPDATE_NEW
    {
        public CTCL_MessageHeader messageHeader;
        public NSE_CM_SECURITY_MASTER_NEW NewSecurity;
    }
}
