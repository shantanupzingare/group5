﻿using BinaryProtocol.TCP;
using CTCL.BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using CTCL_SegmentSpecificAttribute = CTCL.BinaryProtocol.Common.CTCL.Common.CTCL_SegmentSpecificAttribute;

namespace CTCL.Broadcast
{

    
   

    
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Start_Subscribe_Feed_Request
    {
        private CTCL_MessageHeader _MessageHeader;
        private CTCL_ContextIdentifier _ContextIdentifier;
        public CTCL_MessageHeader MessageHeader { get => _MessageHeader; set => _MessageHeader = value; }
        public CTCL_ContextIdentifier ContextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }

    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Subscribe_Feed_Info
    {
        //private const int TokenSize = 100;

        private CTCL_MessageHeader _MessageHeader;
        private CTCL_ContextIdentifier _ContextIdentifier;
        private CTCL_NoOfRecords _NoOfRecords;
        private TokenContextinfo[] _TokenContextinfo = new TokenContextinfo[100];// = new TokenContextinfo[2];

        //private TokenLength _TokenLength;

        //private BS_Token[] _TokenContextinfo = new BS_Token[100];
        //private TokenContextinfo[] _TokenContextinfo = new TokenContextinfo[2];
        //private TokenContextinfo _TokenContextinfo[2];

        public CTCL_MessageHeader MessageHeader { get => _MessageHeader; set => _MessageHeader = value; }
        public CTCL_ContextIdentifier ContextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }
        public CTCL_NoOfRecords NoOfRecords { get => _NoOfRecords; set => _NoOfRecords = value; }
        public TokenContextinfo[] TokenContextinfo { get => _TokenContextinfo; set => _TokenContextinfo = value; }

        //public BS_Token[] TokenContextinfo { get => _TokenContextinfo; set => _TokenContextinfo = value;}
        //public TokenContextinfo[] TokenContextinfo { get => _TokenContextinfo; set => _TokenContextinfo = value; }


    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class End_Subscribe_Feed_Request
    {
        private CTCL_MessageHeader _MessageHeader;
        private CTCL_ContextIdentifier _ContextIdentifier;
        private CTCL_NoOfRecords _NoOfRecords;

        public CTCL_MessageHeader MessageHeader { get => _MessageHeader; set => _MessageHeader = value; }
        public CTCL_ContextIdentifier ContextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }
        public CTCL_NoOfRecords NoOfRecords { get => _NoOfRecords; set => _NoOfRecords = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]

    public class Subscribe_Feed_Response
    {
        private CTCL_MessageHeader _MessageHeader;
        private CTCL_ContextIdentifier _ContextIdentifier;

        public CTCL_MessageHeader MessageHeader { get => _MessageHeader; set => _MessageHeader = value; }
        public CTCL_ContextIdentifier ContextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }

    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct TokenContextinfo
    {
        private CTCL_ExchangeSegmentId _ExchangeSegment;
        private CTCL_Token _Token;
        private CTCL_SegmentSpecificAttribute _SegmentSpecificAttribute;
        private CTCL_Symbol _symbol;
        private CTCL_TimeStamp _expirydate;

        public CTCL_ExchangeSegmentId ExchangeSegment { get => _ExchangeSegment; set => _ExchangeSegment = value; }
        public CTCL_Token Token { get => _Token; set => _Token = value; }
        public CTCL_SegmentSpecificAttribute SegmentSpecificAttribute { get => _SegmentSpecificAttribute; set => _SegmentSpecificAttribute = value; }

        public CTCL_Symbol Symbol { get => _symbol; set => _symbol = value; }
        public CTCL_TimeStamp ExpiryDate { get => _expirydate; set => _expirydate = value; }

    }
    

    public struct CTCL_Reserved_8Byte
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        private char[] _reserved;

        public CTCL_Reserved_8Byte(char[] _value)
        {
            _reserved = new char[2];
            _reserved = _value;
        }

        public CTCL_Reserved_8Byte()
        {
            _reserved = new char[2];
            _reserved = "        ".ToCharArray();
        }

        public char[] Reserved { get => _reserved; set => _reserved = value; }
    }








}
