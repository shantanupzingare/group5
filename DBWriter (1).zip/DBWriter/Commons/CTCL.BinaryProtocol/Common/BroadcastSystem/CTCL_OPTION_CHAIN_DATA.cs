﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_OPTION_CHAIN_DATA :OptionBase
    {
        public CTCL_OPTIONDATADETAILS[] OptionChainsData = new CTCL_OPTIONDATADETAILS[21];
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class OptionBase
    {
        public BroadcastMessageHeader BroadcastMessageHeader;
        public CTCL_Symbol Symbol;
        public CTCL_TimeStamp ExpiryDate;
        public CTCL_NoOfRecords FrequencyInSeconds;
       public OptionBase()
        {
        }
        public OptionBase(OptionBase optionBase)
        {
            BroadcastMessageHeader = optionBase.BroadcastMessageHeader;
            Symbol = optionBase.Symbol; 
            ExpiryDate = optionBase.ExpiryDate;
            FrequencyInSeconds = optionBase.FrequencyInSeconds;
        }


        

    }
}
