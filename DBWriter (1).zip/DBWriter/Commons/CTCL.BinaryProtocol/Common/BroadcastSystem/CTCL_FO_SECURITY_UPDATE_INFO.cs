﻿using CTCL.BinaryProtocol.Common.NSE_FO.Common;
using CTCL.BinaryProtocol.Common.NSE_FO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_FO_SECURITY_UPDATE_INFO
    {
        public CTCL_MessageHeader MESSAGE_HEADER;
        public CTCL_Token Token;
        public CTCL_SEC_INFO SEC_INFO;
        public CTCL_PermittedToTrade PermittedToTrade;
        public CTCL_IssuedCapital_Double IssuedCapital;
        public CTCL_Quantity WarningQuantity;
        public CTCL_Quantity FreezeQuantity;
        public CTCL_CreditRating CreditRating;
        public CTCL_Indicator[] ST_SEC_ELIGIBILITY_PER_MARKET = new CTCL_Indicator[4]; //need to create one another property for 3 bytes
        public CTCL_IssueRate IssueRate;
        public CTCL_TimeStamp IssueStartDate;
        public CTCL_TimeStamp InterestPaymentDate;
        public CTCL_TimeStamp IssueMaturityDate;
        public CTCL_Percent MarginPercentage;
        public CTCL_Quantity MinimumLotQuantity;
        public CTCL_Quantity BoardLotQuantity;
        public CTCL_TickSize TickSize;
        public CTCL_Name Name;
        public CTCL_Reserved1 Reserved;
        public CTCL_TimeStamp ListingDate;
        public CTCL_TimeStamp ExpulsionDate;
        public CTCL_TimeStamp ReAdmissionDate;
        public CTCL_TimeStamp RecordDate;
        public CTCL_Price LowPriceRange;
        public CTCL_Price HighPriceRange;
        public CTCL_TimeStamp ExpiryDate;
        public CTCL_TimeStamp NoDeliveryStartDate;
        public CTCL_TimeStamp NoDeliveryEndDate;
        public NSE_FO_INDICATOR ST_ELIGIBLITY_INDICATORS;
        public CTCL_TimeStamp BookClosureStartDate;
        public CTCL_TimeStamp BookClosureEndDate;
        public CTCL_TimeStamp ExerciseStartDate;
        public CTCL_TimeStamp ExerciseEndDate;
        public CTCL_Token OldToken;
        public CTCL_AssetInstrument AssetInstrument;
        public CTCL_AssetName AssetName;
        public CTCL_Token AssetToken;
        public CTCL_IntrinsicValue IntrinsicValue;
        public CTCL_IntrinsicValue ExtrinsicValue;
        public NSE_FO_INDICATOR ST_PURPOSE;
        public CTCL_TimeStamp LocalUpdateDateTime;
        public CTCL_DeleteFlag DeleteFlag;
        public CTCL_Remark Remark;
        public CTCL_Price BasePrice;
    }
}
