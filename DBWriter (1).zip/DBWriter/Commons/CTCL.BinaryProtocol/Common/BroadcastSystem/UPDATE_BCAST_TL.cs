﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class UPDATE_BCAST_TL
    {
        public BroadcastMessageHeader BroadcastMessageHeader;
        public CTCL_Contract_Desc ContractInfo;
        public CTCL_BSMarketType MarketType;
        public CTCL_TimeStamp LastupdateTime;
        public MBPInfo MBPBuy;
        public MBPInfo MBPSell;
        public CTCL_BCastDataActivityInfo BroadcastDataActivityInfo;
    }
}
