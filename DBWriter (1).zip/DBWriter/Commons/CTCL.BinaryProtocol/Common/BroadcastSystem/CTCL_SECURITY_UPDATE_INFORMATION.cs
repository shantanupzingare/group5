﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    public class CTCL_SECURITY_UPDATE_INFORMATION
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_Token token;
        public CTCL_SEC_INFO secInfo;
        public CTCL_InstrumentType instrumentType;
        public CTCL_PermittedToTrade permittedToTrade;
        public CTCL_IssuedCapital issuedCapital;
        public CTCL_SettlementType settlementType;
        public CTCL_Percent FreezePercent;
        public CTCL_CreditRating CreditRating;
        public CTCL_Reserved1 Reserved1;
        public CTCL_ELIGIBLITY_PERMARKET_4Bytes[] SECURITY_ELIGIBILITY_PER_MARKET = new CTCL_ELIGIBLITY_PERMARKET_4Bytes[6];
        public CTCL_SurvIndicator SurvInd;
        public CTCL_DateTime IssueStartDate;
        public CTCL_DateTime InterestPaymentDate;
        public CTCL_DateTime IssueMaturityDate;
        public CTCL_Quantity BoardLotQuantity;
        public CTCL_TickSize TickSize;
        public CTCL_Name Name;
        public CTCL_Reserved1 Reserved2;
        public CTCL_DateTime ListingDate;
        public CTCL_DateTime ExpulsionDate;
        public CTCL_DateTime ReAdmissionDate;
        public CTCL_DateTime RecordDate;
        public CTCL_DateTime ExpiryDate;
        public CTCL_DateTime NoDeliveryStartDate;
        public CTCL_DateTime NoDeliveryEndDate;
        //public NSE_CM_ELIGIBLITY_INDICATORS ELIGIBLITY_INDICATORS;
        public CTCL_EligibilityIndicators ELIGIBLITY_INDICATORS;
        public CTCL_DateTime BookClosureStartDate;
        public CTCL_DateTime BookClosureEndDate;
        //public NSE_CM_PURPOSE PURPOSE_structures;
        public CTCL_PURPOSE PURPOSE_structures;
        public CTCL_DateTime LocalUpdateDateTime;
        public CTCL_DeleteFlag DeleteFlag;
        public CTCL_Remark Remark;
        public CTCL_FaceValue FaceValue;
        public CTCL_ISINNumber ISINNumber;
        public CTCL_mktMakerSpread MktMakerSpread;
        public CTCL_Quantity MktMakerMinQty;
        public CTCL_CallAuc1Flag CallAuction1Flag;

    }
}
