﻿using CTCL.BinaryProtocol.Common.CTCL.DBWrite;
using CTCL.BinaryProtocol.Common.CTCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_CMSECURITY_INSERT_UPDATE_OLD
    {
        public CTCL_MessageHeader messageHeader;
        public NSE_CM_SECURITY_MASTER NewSecurity;
    }
}
