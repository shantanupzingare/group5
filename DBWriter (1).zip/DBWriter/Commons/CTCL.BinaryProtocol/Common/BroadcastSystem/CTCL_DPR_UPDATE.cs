﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CTCL.BinaryProtocol.Common.NSE_CM.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_DPR_UPDATE
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_Token Token;
        public CTCL_CreditRating CreditRating;
        public CTCL_TimeStamp LocalUpdateTime;
    }
}
