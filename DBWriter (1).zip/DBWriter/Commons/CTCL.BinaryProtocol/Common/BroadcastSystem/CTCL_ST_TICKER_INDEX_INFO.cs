﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.NSE_FO.Common;
using CTCL.BinaryProtocol.Common.NSE_FO.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ST_TICKER_INDEX_INFO
    {
        public CTCL_ExchangeSegmentId SegmentId;
        public CTCL_Token Token;
        public CTCL_BSMarketType MarketType;
        public CTCL_Price FillPrice;
        public CTCL_Volume FillVolume;
        public CTCL_OpenInterest OpenInterest;
        public CTCL_DayOI DayHiOI;
        public CTCL_DayOI DayLoOI;
        public CTCL_OpenInterest PrevOI;
        public CTCL_TimeStamp LastUpdateTimeStamp;

        public Response Update(CTCL_ST_TICKER_INDEX_INFO data)
        {
            SegmentId = data.SegmentId;
            Token = data.Token;
            MarketType = data.MarketType;
            FillPrice = data.FillPrice;
            FillVolume = data.FillVolume;
            OpenInterest = data.OpenInterest;
            DayHiOI = data.DayHiOI;
            DayLoOI = data.DayLoOI;
            PrevOI = data.PrevOI;
            LastUpdateTimeStamp = data.LastUpdateTimeStamp;


			return new Response() { StatusCode = StatusCode.Success, Message =  "ST Ticker index info updated" };
        }
    }
}
