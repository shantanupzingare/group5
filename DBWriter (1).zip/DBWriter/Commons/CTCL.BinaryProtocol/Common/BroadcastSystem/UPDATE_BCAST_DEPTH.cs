﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.Broadcast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class UPDATE_BCAST_DEPTH : DepthBestBase
    {      
        public MBPInfo[] MBPBuy = new MBPInfo[5];

        public MBPInfo[] MBPSell = new MBPInfo[5];

        public CTCL_BCastDataActivityInfo BroadcastDataActivityInfo;

    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class DepthBestBase
    {
        public BroadcastMessageHeader BroadcastMessageHeader;

        public CTCL_Contract_Desc ContractInfo;

        public CTCL_BSMarketType MarketType;

        public CTCL_TimeStamp LastupdateTime;
        public DepthBestBase()
        {

        }
        public DepthBestBase(DepthBestBase depthBestBase)
        {
            BroadcastMessageHeader = depthBestBase.BroadcastMessageHeader;
            ContractInfo = depthBestBase.ContractInfo;
            MarketType = depthBestBase.MarketType;
            LastupdateTime = depthBestBase.LastupdateTime;
        }
    }



    [StructLayout(LayoutKind.Sequential, Pack = 1)]

    public class CTCL_LastTradeInfo
    {
        public CTCL_Quantity LTQty;
        public CTCL_Price LTPrice;
        public CTCL_TimeStamp LTT;
    }
    

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MBPInfo
    {
        public CTCL_Quantity Qty;
        public CTCL_Price Price;
        public CTCL_NoOfOrders NoOfOrders;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class BroadcastMessageHeader
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_BCSeqNo BroadcastSequenceNo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_BCastDataActivityInfo
    {
        public CTCL_Quantity_Double TotalBuyQty;
        public CTCL_Quantity_Double TotalSellQty;
        public CTCL_Price Open;
        public CTCL_Price High;
        public CTCL_Price Low;
        public CTCL_Price Close;
        public CTCL_Price PreviousClose;
        public CTCL_Quantity VolumeTradedToday;
        public CTCL_LastTradeInfo LTInfo;

        public CTCL_NetChangeIndicator NetChangeIndicator;

        public CTCL_Price NetChangeFromPrevClose;

        public CTCL_Price ATP;

        public CTCL_Quantity TotalNumberOfTrades;

        public CTCL_Reserved_8Byte Reserved;
    }
}
