﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class UPDATE_MARKET_STATUS
    {
        public BroadcastMessageHeader BroadcastMessageHeader;
        public CTCL_BSMarketType MarketType;
        public CTCL_BSMarketStatus MarketStatus;
        public CTCL_BroadcastMessage BroadcastMessage;
    }
}
