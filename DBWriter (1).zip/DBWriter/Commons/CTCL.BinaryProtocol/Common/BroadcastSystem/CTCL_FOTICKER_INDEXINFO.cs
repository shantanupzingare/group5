﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_FOTICKER_INDEXINFO
    {
        public BroadcastMessageHeader messageHeader;
        public CTCL_NoOfRecords noOfRecords;
        public CTCL_ST_TICKER_INDEX_INFO[] ST_TICKER_INDEX_INFO = new CTCL_ST_TICKER_INDEX_INFO[17];
    }
}
