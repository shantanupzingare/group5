﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MS_TICKER_TRADE_DATA
    {
        public BroadcastMessageHeader BroadcastMessageHeader;
        public CTCL_NoOfRecords NoOfRecords;
        public CTCL_ST_TICKER_INDEX_INFO[] TICKER_INDEX_INFO = new CTCL_ST_TICKER_INDEX_INFO[17];

    }
}
