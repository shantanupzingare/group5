﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    public class MarketPulseStats
    {
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MarketPulseStatsDataTopGL
    {
        public BroadcastMessageHeader messageHeader { get; set; }
        public CTCL_TimeStamp lastUpdateTime { get; set; }
        public CTCL_IndexToken IndexToken { get; set; }

        public CTCL_TotalNoOfRecords gainerRecords { get; set; }
        public CTCL_TotalNoOfRecords loserRecords { get; set; }

        public TopGainLoseMarketPulse[] topGainData ;
        public TopGainLoseMarketPulse[] topLoseData ;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MarketPulseStatsDataMostActiveByValVol
    {
        public BroadcastMessageHeader messageHeader { get; set; }
        public CTCL_TimeStamp lastUpdateTime { get; set; }
        public CTCL_IndexToken IndexToken { get; set; }
        public CTCL_TotalNoOfRecords mostActiveVolRecords { get; set; }
        public CTCL_TotalNoOfRecords mostActiveValRecords { get; set; }

        public MostActibeByValVolMarketPulse[] mostActiveByVolData ;
        public MostActibeByValVolMarketPulse[] mostActiveByValData ;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class TopGainLoseMarketPulse
    {
        public CTCL_Token token { get; set; }
        public CTCL_Symbol symbol { get; set; }
        public CTCL_Price LTPPrice { get; set; }
        public CTCL_Price PrevClose { get; set; }
        public CTCL_PercentageDecimal Percentage { get; set; }
        public CTCL_Volume Volume { get; set; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MostActibeByValVolMarketPulse
    {
        public CTCL_Token token { get; set; }
        public CTCL_Symbol symbol { get; set; }
        public CTCL_Price LTPPrice { get; set; }
        public CTCL_Volume Volume { get; set; }
        public CTCL_Price PrevClose { get; set; }
        public CTCL_Price Value { get; set; }
        public CTCL_PercentageDecimal Percentage { get; set; }
    }
}
