﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.BroadcastSystem
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_LIMIT_PRICE_PROTECTION_RANGE_DETAILS
    {
        public CTCL_ExchangeSegmentId SegmentId;
        public CTCL_Token Token;
        public CTCL_Band HighExecBand;
        public CTCL_Band LowExecBand;
	    public CTCL_TimeStamp LastUpdateTimeStamp;
		public Response Update(CTCL_LIMIT_PRICE_PROTECTION_RANGE_DETAILS data)
        {
            SegmentId = data.SegmentId;
            Token = data.Token;
            HighExecBand = data.HighExecBand;
            LowExecBand = data.LowExecBand;
            LastUpdateTimeStamp = data.LastUpdateTimeStamp;

            return new Response() { StatusCode = StatusCode.Success, Message = "" };
        }
    }

}
