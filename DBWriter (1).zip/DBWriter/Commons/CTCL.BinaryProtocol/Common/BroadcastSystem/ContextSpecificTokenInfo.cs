﻿using BinaryProtocol.Common;
using BinaryProtocol.TCP;
using CTCL.BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.Broadcast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.Broadcast
{
    public class ContextSpecificTokenInfo
    {
        private List<TokenContextinfo> _tokenContextinfos;
        public ContextSpecificTokenInfo()
        {
            _tokenContextinfos = new List<TokenContextinfo>();
        }


        public List<TokenContextinfo> tokenContextinfos { get => _tokenContextinfos; set => _tokenContextinfos = value; }



        public void Add(TokenContextinfo tokenContextinfo)
        {
            _tokenContextinfos.Add(tokenContextinfo);
        }


    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MessageCommunication
    {
        private AliasName _AliasName;
        private Socket_SocketDescriptor _SocketDescriptor;
        private Socket_Length _Length;
        private byte[] _Socket_ByteData;
        private Int64 _descriptorUID;
        private CTCL_SourceType _sourceType; 

        //public MessageCommunication(Socket_SocketDescriptor _SocketDescriptor, Socket_ByteData _Socket_ByteData, Socket_Length _Length, TokenContextinfo[] _TokenContextinfo)
        //{

        //}
        public AliasName AliasName { get => _AliasName; set => _AliasName = value; }
        public Socket_SocketDescriptor SocketDescriptor { get => _SocketDescriptor; set => _SocketDescriptor = value; }
        public Socket_Length Length { get => _Length; set => _Length = value; }
        public byte[] ByteData { get => _Socket_ByteData; set => _Socket_ByteData = value; }
        public Int64 DescriptorUID { get => _descriptorUID; set => _descriptorUID = value; }
        public CTCL_SourceType SourceType { get => _sourceType; set => _sourceType = value; }


    }
}

  