﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.RmsLimitMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_LIMIT_TYPES
    {
        public CTCL_RMS_GrossExposure GrossExposure;
        public CTCL_RMS_NetPurchase NetPurchase;
        public CTCL_RMS_NetSale NetSale;
        public CTCL_RMS_NetPremium NetPremium;
        public CTCL_RMS_NetWrite NetWrite;
        public CTCL_RMS_Turnover Turnover;
        public CTCL_RMS_MTM MTM;
        public CTCL_RMS_Margin Margin;
    }
}
