﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.RmsLimitMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_USER_TO_RMS_MAPPING
    {
        public CTCL_MessageHeader MessageHeader;
		public CTCL_Id TemplateId;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public CTCL_RMS_Remark Remark;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
		public List<CTCL_TerminalID> ListOfTerminalId;

    }
}
