﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels;
using System.Runtime.InteropServices;
namespace CTCL.BinaryProtocol.Common.CTCL.RMS.RmsLimitMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_Limit_Template_Attribute
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_RMS_LIMIT_TEMPLATE_ATTRIBUTE_DB RmsLImitTemplateAttribute;
    }
}
