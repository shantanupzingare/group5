﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.TER
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_TERTemplate : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id TERTemplateId;
		public CTCL_RMS_TemplateName TERTemplateName;
	}
}
