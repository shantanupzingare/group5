﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.TER.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_TERTemplateGroupMappingRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_OperationMode OperationMode;
		public CTCL_TERTemplateGroupMapping TERTemplateGroupMapping;
	}
}
