﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;


namespace CTCL.BinaryProtocol.Common.CTCL.RMS.TER
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_TERSecurityGroupTemplate : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id GroupId;
		public CTCL_RMS_TemplateName TERSecurityGroupName;
		public CTCL_PercentageDecimal TERPercentage;
	}

}
