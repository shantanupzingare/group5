﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.TER
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_TERSecurityGroupMapping : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id GroupMapingId;
		public CTCL_Id GroupId;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_ISINNumber ISINNumber;
		public CTCL_Token Token;
		public CTCL_Symbol Symbol;
	}
}
