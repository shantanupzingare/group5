﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;
using StatusCode = BinaryProtocol.Common.StatusCode;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class RMSPosition
{
    public CTCL_TerminalID DealerId;
    public CTCL_TerminalID ClientId;
    public CTCL_ExchangeSegmentId Segment;
    public CTCL_Token Token;
    public CTCL_Quantity BuyQuantity;
    public CTCL_Price BuyAverage;
    public CTCL_Quantity SellQuantity;
    public CTCL_Price SellAverage;
    public CTCL_TypeId TranType;
    public CTCL_LastActivityReference LastReferenceNo;
    public CTCL_TimeStamp LastUpdateTime;
    public CTCL_UserID LastUpdatedBy;
    public CTCL_RMS_Remark Remarks;
	public CTCL_ProductType ProductType;
	public CTCL_AccountInformation AccountInformation;
	public CTCL_Settlor Participant;
	public CTCL_Price BuySettlementPrice;
	public CTCL_Price SellSettlementPrice;
	public CTCL_Price PrevClosePrice;
	public Responses Update(RMSPosition rmsPosition)
    {
        Responses response = new();
        AccountInformation = rmsPosition.AccountInformation;
        DealerId = rmsPosition.DealerId;
        ClientId = rmsPosition.ClientId;
        Segment = rmsPosition.Segment;
        Token = rmsPosition.Token;
        BuyQuantity = rmsPosition.BuyQuantity;
        BuyAverage = rmsPosition.BuyAverage;
        SellQuantity = rmsPosition.SellQuantity;
        SellAverage = rmsPosition.SellAverage;
        TranType = rmsPosition.TranType;
        LastUpdatedBy = rmsPosition.LastUpdatedBy;
        LastUpdateTime = rmsPosition.LastUpdateTime;
        LastReferenceNo = rmsPosition.LastReferenceNo;
        Remarks = rmsPosition.Remarks;
		ProductType = rmsPosition.ProductType;
		Participant = rmsPosition.Participant;
		BuySettlementPrice = rmsPosition.BuySettlementPrice;
		SellSettlementPrice = rmsPosition.SellSettlementPrice;
		PrevClosePrice = rmsPosition.PrevClosePrice;

		response.Set(StatusCode.Success, "");
        return response;
    }
}

