﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using CTCL_Name = CTCL.BinaryProtocol.Common.CTCL.Common.CTCL_Name;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Span
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_FileUpdate
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_Name FileName;
		public CTCL_Address Path;
		public CTCL_TimeStamp Date;
		public CTCL_TimeStamp UpdateTime;
		public CTCL_SequenceNumber SequenceNumber;
	}
}
