﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Span
{
	public class CTCL_BrokerageChargesResponse
	{
		public CTCL_BuySellIndicator TransactionType;
		public CTCL_Symbol Symbol;
		public CTCL_ExchangeIdentifier Exchange;
		public CTCL_DoublePrice Span;
		public CTCL_DoublePrice Exposure;
		public CTCL_DoublePrice Option_premium;
		public CTCL_DoublePrice Additional;
		public CTCL_DoublePrice Bo;
		public CTCL_DoublePrice Cash;
		public CTCL_DoublePrice Var;
		public CTCL_DoublePrice Leverage;
		public CTCL_DoublePrice Total;
		public CTCL_ProfitAndLoss ProfitAndLoss;
		public CTCL_Charges Charges;
	}
	public class CTCL_ProfitAndLoss
	{
		public CTCL_DoublePrice Realised { get; set; }
		public CTCL_DoublePrice Unrealised { get; set; }
	}
	public class CTCL_Charges
	{
		public CTCL_DecimalPrice Stt;
		public CTCL_DecimalPrice Exchange_turnover_charge;
		public CTCL_DecimalPrice Sebi_turnover_charge;
		public CTCL_DecimalPrice Brokerage;
		public CTCL_DecimalPrice Stamp_duty;
		public CTCL_GST Gst;
		public CTCL_DecimalPrice Total;
	}

	public class CTCL_GST
	{
		public CTCL_DecimalPrice Igst;
		public CTCL_DecimalPrice Cgst;
		public CTCL_DecimalPrice Sgst;
		public CTCL_DecimalPrice Total;
	}
}