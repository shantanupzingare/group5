﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Span
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_BrokerageCharges
	{
        public CTCL_Id Id;
        public CTCL_TimeStamp ApplicableDate;
        public CTCL_ExchangeIdentifier Segement;
        public CTCL_SubInstrument IntrumenetType;
        public CTCL_ProductType ProductType;
        public CTCL_BuySellIndicator TransactionType;
        public CTCL_BrokerageChargesInfo Brokerage;
        public CTCL_BrokerageChargesInfo STTAndCTT;
        public CTCL_BrokerageChargesInfo TransactionCharges;
        public CTCL_BrokerageChargesInfo GST;
        public CTCL_BrokerageChargesInfo SebiCharges;
        public CTCL_BrokerageChargesInfo StampCharges;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_BrokerageChargesInfo
	{
        public CTCL_BrokerageType Type;
        public CTCL_BrokerageType MaxChargeType;
		public CTCL_DecimalPrice Charge;
		public CTCL_DecimalPrice MaxCharge;
	}
}
