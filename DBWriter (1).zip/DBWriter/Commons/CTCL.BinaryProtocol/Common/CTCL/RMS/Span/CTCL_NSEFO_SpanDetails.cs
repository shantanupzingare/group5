﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using Responses = BinaryProtocol.Common.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Span
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_NSEFO_SpanDetails
	{
		public CTCL_ExchangeSegmentId segmentID;
		public CTCL_InstrumentName Instrument;
		public CTCL_Symbol symbol;
		public CTCL_Series series;
		public CTCL_TimeStamp expiryDate;
		public CTCL_Price strikePrice;
		public CTCL_OptionType optionType;
		public CTCL_CALevel caLevel;
		public CTCL_Token token;
		public CTCL_Token assetToken;
		public CTCL_DoublePrice contractPrice;
		public CTCL_DoublePrice contractVolatility;
		public CTCL_DoublePrice Scen1;
		public CTCL_DoublePrice Scen2;
		public CTCL_DoublePrice Scen3;
		public CTCL_DoublePrice Scen4;
		public CTCL_DoublePrice Scen5;
		public CTCL_DoublePrice Scen6;
		public CTCL_DoublePrice Scen7;
		public CTCL_DoublePrice Scen8;
		public CTCL_DoublePrice Scen9;
		public CTCL_DoublePrice Scen10;
		public CTCL_DoublePrice Scen11;
		public CTCL_DoublePrice Scen12;
		public CTCL_DoublePrice Scen13;
		public CTCL_DoublePrice Scen14;
		public CTCL_DoublePrice Scen15;
		public CTCL_DoublePrice Scen16;
		public CTCL_DoublePrice compDelta;


		public Responses Update(CTCL_NSEFO_SpanDetails nsefoSpandetails)
		{
			Responses response = new();
			segmentID = nsefoSpandetails.segmentID;
			Instrument = nsefoSpandetails.Instrument;
			symbol= nsefoSpandetails.symbol;
			series = nsefoSpandetails.series;
			expiryDate = nsefoSpandetails.expiryDate;
			strikePrice = nsefoSpandetails.strikePrice;
			optionType = nsefoSpandetails.optionType;
			caLevel = nsefoSpandetails.caLevel;
			token = nsefoSpandetails.token;
			assetToken = nsefoSpandetails.assetToken;
			contractPrice = nsefoSpandetails.contractPrice;
			contractVolatility = nsefoSpandetails.contractVolatility;
			Scen1 = nsefoSpandetails.Scen1;
			Scen2 = nsefoSpandetails.Scen2;
			Scen3 = nsefoSpandetails.Scen3;
			Scen4 = nsefoSpandetails.Scen4;
			Scen5 = nsefoSpandetails.Scen5;
			Scen6 = nsefoSpandetails.Scen6;
			Scen7 = nsefoSpandetails.Scen7;
			Scen8 = nsefoSpandetails.Scen8;
			Scen9 = nsefoSpandetails.Scen9;
			Scen10 = nsefoSpandetails.Scen10;
			Scen11 = nsefoSpandetails.Scen11;
			Scen12 = nsefoSpandetails.Scen12;
			Scen13 = nsefoSpandetails.Scen13;
			Scen14 = nsefoSpandetails.Scen14;
			Scen15 = nsefoSpandetails.Scen15;
			Scen16 = nsefoSpandetails.Scen16;
			compDelta = nsefoSpandetails.compDelta;

			response.Set(StatusCode.Success, "");
			return response;
		}
	}
}
