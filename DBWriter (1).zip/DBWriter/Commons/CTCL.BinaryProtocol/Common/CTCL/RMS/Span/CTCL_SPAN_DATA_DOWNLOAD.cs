﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Span
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SPAN_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_Name FileName;
		public CTCL_TimeStamp LastTimeUpdateTime;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_SPAN_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_ExchangeSegmentId SegementID;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_SPAN_DATA_DOWNLOAD_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_ExchangeSegmentId SegementID;
		public CTCL_MessageLength MessageLength;
		public CTCL_EMData spanMasterData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_SPAN_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_ExchangeSegmentId SegementID;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SPAN_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}
}
