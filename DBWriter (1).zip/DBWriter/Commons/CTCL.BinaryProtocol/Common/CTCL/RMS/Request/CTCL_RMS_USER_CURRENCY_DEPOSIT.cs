﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_USER_CURRENCY_DEPOSIT
    {
        [Validator(validationType.numericRequired, "Please enter a valid Currency Id")]
        public CTCL_CurrencyId DepositCurrencyId;
        [Validator(validationType.numericRequired, "Please enter a valid Currency amount")]
        public CTCL_DepositAmount DepositCurrencyAmount;

        public CTCL_TimeStamp DepositDate;
        public CTCL_TimeStamp CreatedOn;
        public CTCL_TimeStamp ModifiedOn;
        public CTCL_EntityId CreatedBy;
        public CTCL_EntityId ModifiedBy;
    }
}
