﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_DMA_USER_MAPPING_CACHE_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_TerminalID DMAUser;
		public CTCL_TerminalID DMAUccClient;
		public CTCL_EntityId LastUpdatedBy;
		public CTCL_TimeStamp LastUpdatedTime;
		public CTCL_Remark Remarks;
		public CTCL_RMSTemplateStatus intStatus;
	}
}
