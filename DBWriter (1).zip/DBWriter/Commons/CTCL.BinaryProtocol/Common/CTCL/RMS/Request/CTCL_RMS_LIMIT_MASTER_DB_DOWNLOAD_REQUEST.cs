﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.RMS.RmsLimitMaster;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_LIMIT_MASTER_DB_DOWNLOAD_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecords TotalNoOfRecords;
        public List<RMSLimitMasterIncrementalUpdateInfo> RMSLimitMasterContext;
    }
}
