﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_USER_DEPOSIT_ADD_UPDATE_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        [Validator(validationType.alpha_numeric, "Special characters not allowed in Entity name.")]
        public CTCL_TerminalID TerminalId;

        public CTCL_PrimaryId AdhocMiscDepositId;
        public CTCL_TimeStamp AdhocMiscDepositDate;
        public CTCL_DepositAmount AdhocDepositAmount;
        public CTCL_DepositAmount MiscellenaousDepositAmount;

        [Validator(validationType.numericRequired, "Please enter a valid Base currency id")]
        public CTCL_CurrencyId BaseCurrencyId;

        public CTCL_TimeStamp CreatedOn;
        public CTCL_TimeStamp ModifiedOn;
        public CTCL_EntityId CreatedBy;
        public CTCL_EntityId ModifiedBy;

        [Validator(validationType.numericRequired, "Please send number of currency wise deposit records")]
        public CTCL_NoOfRecords NumberOfRecords;
        public List<CTCL_RMS_USER_CURRENCY_DEPOSIT> CurrencyWiseDeposit;

    }
}
