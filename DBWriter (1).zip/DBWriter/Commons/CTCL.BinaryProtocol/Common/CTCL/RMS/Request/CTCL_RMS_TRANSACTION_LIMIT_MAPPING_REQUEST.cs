﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_START_TRANSACTION_LIMIT_MAPPING_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecords NoOfRecords;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_MAPPING_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecords NoOfRecords;
		public List<CTCL_RMS_TRANSACTION_MAPPING> MappingInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_MAPPING
	{
		public CTCL_Id TemplateId;
		public CTCL_TerminalID TerminalID;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
		public CTCL_OperationMode OperationMode;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_END_TRANSACTION_LIMIT_MAPPING_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecords NoOfRecords;
	}
}
