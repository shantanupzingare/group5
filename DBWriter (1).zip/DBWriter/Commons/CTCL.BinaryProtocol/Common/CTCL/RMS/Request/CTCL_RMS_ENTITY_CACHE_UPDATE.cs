﻿using BinaryProtocol.TCP;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;
using CTCL_Id = CTCL.BinaryProtocol.Common.CTCL.Common.CTCL_Id;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_ENTITY_CACHE_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId EntityID;
		public AliasName EntityDisplayCode;
		public CTCL_EntityId ParentEntityId;
		public CTCL_CategoryId EntityCategory;
		public CTCL_TypeId EntityType;
		public CTCL_OperationStatus OperationStatus;
		public CTCL_TradingStatus TradingStatus;
		public CTCL_ConnectionMode ConnectionMode;
		public CTCL_Flag DMAFlag;
	}
}
