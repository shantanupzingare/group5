﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_RMS_TRANSACTION_LIMIT_TEMPLATE TemplateInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_TEMPLATE 
	{
		public CTCL_RMS_TRANSACTION_LIMIT_TEMPLATE_INFO TemplateInfo;
		public CTCL_TotalNoOfRecords NoOfRecords;
		public List<CTCL_RMS_TRANSACTION_LIMIT_ATTRIBUTE> AttributesInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_TEMPLATE_INFO 
	{
		public Common.CTCL_Id TemplateId;
		public CTCL_TemplateName TemplateName;
		public CTCL_TerminalID TemplateOwner;
		public CTCL_OperationMode OperationMode;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
	}


	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_ATTRIBUTE 
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_TotalNoOfRecords NoOfRecords;
		public List<CTCL_RMS_TRANSACTION_LIMIT_ATTRIBUTE_INFO> LimitInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_TRANSACTION_LIMIT_ATTRIBUTE_INFO
	{
		public Common.CTCL_Id TemplateAttributeId;
		public CTCL_LimitIndicator LimitIndicator;
		public CTCL_DoublePrice Limit;
		public CTCL_OperationMode OperationMode;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
	}

}
