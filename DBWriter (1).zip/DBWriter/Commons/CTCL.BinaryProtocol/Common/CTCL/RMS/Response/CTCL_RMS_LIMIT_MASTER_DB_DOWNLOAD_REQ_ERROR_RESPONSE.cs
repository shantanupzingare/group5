﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Response;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_LIMIT_MASTER_DB_DOWNLOAD_REQ_ERROR_RESPONSE : CTCL_BASE_RESPONSE
    {
        public CTCL_Status StatusCode;
    }
}
