﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_USER_DEPOSIT_DB
    {
        public CTCL_USER_ADHOC_AND_MISCELLANEOUS_DEPOSIT_DB UserAdhocDeposit;
        public CTCL_TotalNoOfRecords TotalUserCurrencyDepositRecords;
        public List<CTCL_USER_CURRENCY_WISE_DEPOSIT_DB> UserCurrencyWiseDeposit;
    }
}
