﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_SUB_RMS_USER_DEPOSIT_DB_DOWNLOAD
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_RMSLimitMasterInformationIdentifier RMSUserDepositInformationIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }
}
