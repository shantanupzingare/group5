﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.RMS.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_RMS_USER_DEPOSIT_ADD_UPDATE_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TerminalID TerminalId;
        public CTCL_RMSStatusString StatusString;
        public StatusCode StatusCode;
    }
}
