﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.QVL.QVLModel;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_ATTRIBUTE_ADD_UPDATE_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_OperationMode OperationMode;
		public CTCL_QuantityValuedLimitAttribute QVLAttribute;
	}
}
