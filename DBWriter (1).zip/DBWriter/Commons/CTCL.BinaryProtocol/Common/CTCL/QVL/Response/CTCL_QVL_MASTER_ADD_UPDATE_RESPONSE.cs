﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_MASTER_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_StatusString StatusString;
		public CTCL_QVLResponseBuffer ResponseBuffer;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_ATTRIBUTE_ADD_UPDATE_RESPONSE 
	{
		public CTCL_TotalNoOfRecords NumberOfResponse;
		public List<CTCL_QVL_ATTRIBUTE_RESPONSE> AttributeResponse;
	}
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_ATTRIBUTE_RESPONSE 
	{
		public CTCL_ProductType ProductType;
		public CTCL_Id AttributeId;
	}
}
