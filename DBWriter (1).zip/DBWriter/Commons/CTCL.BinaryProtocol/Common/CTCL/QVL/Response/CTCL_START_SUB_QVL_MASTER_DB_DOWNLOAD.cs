﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_QVL_MASTER_DB_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_QVLInformationIdentifier QVLMasterInformationIdentifier;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}
}
