﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_TEMPLATE_WISE_MAPPING_DB_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EMInformationIdentifier  EMInformationIdentifier ;
		public CTCL_MessageLength MessageLength;
		public CTCL_Id TemplateId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofMapping;
		public CTCL_EMData QVLMappingData;
	}
}
