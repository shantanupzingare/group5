﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVL_MASTER_DB_DOWNLOAD_REQ_ERROR_RESPONSE : CTCL_BASE_RESPONSE
	{
		public CTCL_Status StatusCode;
	}
}
