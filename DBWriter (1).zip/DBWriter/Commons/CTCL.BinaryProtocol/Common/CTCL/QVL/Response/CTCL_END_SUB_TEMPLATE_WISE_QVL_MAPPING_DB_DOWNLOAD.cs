﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_TEMPLATE_WISE_QVL_MAPPING_DB_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_Id TemplateId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}
}
