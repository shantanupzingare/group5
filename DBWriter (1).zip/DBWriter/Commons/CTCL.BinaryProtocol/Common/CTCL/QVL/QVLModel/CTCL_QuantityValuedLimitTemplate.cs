﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.QVLModel
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_QuantityValuedLimitTemplate : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Id TemplateId;
        [Validator(validationType.alpha_numeric, "Please enter valid template name")]
        public CTCL_RMS_TemplateName QVLTemplateName;
    }
}
