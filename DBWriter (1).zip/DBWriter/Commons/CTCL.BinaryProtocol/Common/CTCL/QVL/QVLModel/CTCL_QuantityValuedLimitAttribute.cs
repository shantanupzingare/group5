﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.QVL.QVLModel
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_QuantityValuedLimitAttribute : CTCL_RMSCommonMasterAttributes
	{
        public CTCL_Id QVLTemplateAttributeId;
        public CTCL_Id QVLTemplateMasterId;
        public CTCL_ExchangeSegmentId Segment;
        public CTCL_Token Token;
        public CTCL_ExpiryType ExpiryType;
        public CTCL_StrikePriceType StrikePriceType;
        public CTCL_Quantity GrossBuyQuantity;
        public CTCL_Quantity GrossSellQuantity;
        public CTCL_DoublePrice GrossBuyValue;
        public CTCL_DoublePrice GrossSellValue;
        public CTCL_Quantity NetQuantity;
        public CTCL_Quantity NetLot;
        public CTCL_DoublePrice NetBuyValue;
        public CTCL_DoublePrice NetSellValue;
        public CTCL_DoublePrice Turnover;
        public CTCL_Quantity MaxSingleOrderQuantity;
        public CTCL_Quantity MinSingleOrderQuantity;
        public CTCL_DoublePrice MaxSingleOrderValue;
        public CTCL_DoublePrice MinSingleOrderValue;
        public CTCL_DoublePrice PendingBuyOrderValue;
        public CTCL_DoublePrice PendingSellOrderValue;
        public CTCL_DoublePrice PendingOrderValue;
        public CTCL_ProductType ProductType;
		public CTCL_Quantity MaxAllSegmentAllowedQuantity;
	}
}
