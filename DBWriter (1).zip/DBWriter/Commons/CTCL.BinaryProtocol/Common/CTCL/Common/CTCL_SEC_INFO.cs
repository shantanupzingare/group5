﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_SEC_INFO
{
    public CTCL_InstrumentName InstrumentName;
    public CTCL_OptionType OptionType;
    public CTCL_Symbol Symbol; // char length - 10
    public CTCL_Series Series;
    public CTCL_TimeStamp ExpiryDate;
    public CTCL_Price StrikePrice;
    public CTCL_CALevel CALevel;
}

