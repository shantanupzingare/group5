﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct CTCL_PrimaryId
	{
		[MarshalAs(UnmanagedType.I4)]
		private Int32 _id;

		public CTCL_PrimaryId(Int32 _value)
		{
			_id = _value;
		}
		public Int32 Id { get => _id; set => _id = value; }
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct CTCL_CurrencyId
	{
		[MarshalAs(UnmanagedType.I4)]
		private Int32 _currencyId;
		public CTCL_CurrencyId(Int32 _value)
		{
			_currencyId = _value;
		}
		public Int32 CurrencyId { get => _currencyId; set => _currencyId = value; }
	}
}
