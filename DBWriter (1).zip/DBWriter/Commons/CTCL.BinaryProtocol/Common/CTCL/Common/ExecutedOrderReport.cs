﻿using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Licensing.DataType;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class ExecutedOrderReport
    {   
        public CTCL_ExchangeSegmentId SegmentId;
        public CTCL_NoOfOrders NoOfOrders;
        public DateTime TradeStartDate;
        public DateTime TradeEndDate;
        public CTCL_Email Email;      
        public LicenseStr ClientName;
    }
}
