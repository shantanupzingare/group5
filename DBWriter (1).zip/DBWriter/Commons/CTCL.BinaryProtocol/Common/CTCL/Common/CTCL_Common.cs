﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

#region DateTime

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DateTime
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _dateTime;

    public CTCL_DateTime(Int32 _value)
    {
        _dateTime = _value;
    }
    public Int32 DateTime { get => _dateTime; set => _dateTime = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DateTime_OMS
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _dateTime;

    public CTCL_DateTime_OMS(Int64 _value)
    {
        _dateTime = _value;
    }
    public Int64 DateTime { get => _dateTime; set => _dateTime = value; }
}

#endregion




[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct ComponentIdentifier
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _componentId;
    public ComponentIdentifier(Int32 _value)
    {
        _componentId = _value;
    }
    public Int32 ComponentId { get => _componentId; set => _componentId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MarketStatus
{
    [MarshalAs(UnmanagedType.I2)]
    private short _marketStatus;
    public CTCL_MarketStatus(short _value)
    {
        _marketStatus = _value;
    }
    public short MarketStatus { get => _marketStatus; set => _marketStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OpCode
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _opCode;

    public CTCL_OpCode(Int32 _value)
    {
        _opCode = _value;
    }
    public Int32 OpCode { get => _opCode; set => _opCode = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Transaction_Code
{
    [MarshalAs(UnmanagedType.I2)]
    private short _transactionCode;

    public CTCL_Transaction_Code(short _value)
    {
        _transactionCode = _value;
    }
    public short TransactionCode { get => _transactionCode; set => _transactionCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AlphaChar
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _alphachar;
    public CTCL_AlphaChar(char[] _value)
    {
        _alphachar = new char[2];
        Array.Copy(_value, 0, _alphachar, 0, _value.Length > _alphachar.Length ? _alphachar.Length : _value.Length);
    }
    public CTCL_AlphaChar()
    {
        _alphachar = new char[2];

    }
    public char[] Alphachar { get => _alphachar; set => _alphachar = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TraderId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _traderid;
    public CTCL_TraderId(Int32 _value)
    {
        _traderid = _value;
    }
    public Int32 Traderid { get => _traderid; set => _traderid = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TimeStamp
{
    [MarshalAs(UnmanagedType.I8)]
    private long _timestamp;
    public CTCL_TimeStamp(long _value)
    {
        _timestamp = _value;
    }
    public long TimeStamp { get => _timestamp; set => _timestamp = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MessageLength
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _messagelength;
    public CTCL_MessageLength(Int32 _value)
    {
        _messagelength = _value;
    }
    public Int32 Messagelength { get => _messagelength; set => _messagelength = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TimeStamp1 // 8 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
    private char[] _timestamp1;
    public CTCL_TimeStamp1(char[] _value)
    {
        _timestamp1 = new char[8];
        Array.Copy(_value, 0, _timestamp1, 0, _value.Length > _timestamp1.Length ? _timestamp1.Length : _value.Length);
    }
    public CTCL_TimeStamp1()
    {
        _timestamp1 = new char[8];

    }
    public char[] TimeStamp { get => _timestamp1; set => _timestamp1 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_VersionInfo
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _versionInfo;
    public CTCL_VersionInfo(char[] _value)
    {
        _versionInfo = new char[16];
        Array.Copy(_value, 0, _versionInfo, 0, _value.Length > _versionInfo.Length ? _versionInfo.Length : _value.Length);
    }
    public CTCL_VersionInfo()
    {
        _versionInfo = new char[16];
    }
    public char[] VersionInfo { get => _versionInfo; set => _versionInfo = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OrderContextIdentifier
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _contextIdentifier;
    public CTCL_OrderContextIdentifier(char[] _value)
    {
        _contextIdentifier = new char[32];
        Array.Copy(_value, 0, _contextIdentifier, 0, _value.Length > _contextIdentifier.Length ? _contextIdentifier.Length : _value.Length);
    }
    public CTCL_OrderContextIdentifier()
    {
        _contextIdentifier = new char[32];
    }
    public char[] OrderContextIdentifier { get => _contextIdentifier; set => _contextIdentifier = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UserID
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _userID;
    public CTCL_UserID(Int64 _value)
    {
        _userID = _value;
    }
    public Int64 UserID { get => _userID; set => _userID = value; }
}


//before uncommenting let vinay/shubham know
//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_Password
//{
//    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
//    private char[] _password;
//    public CTCL_Password(char[] _value)
//    {
//        _password = new char[8];
//        Array.Copy(_value, 0, _password, 0, _value.Length > _password.Length ? _password.Length : _value.Length);
//    }
//    public CTCL_Password()
//    {
//        _password = new char[8];

//    }
//    public char[] Password { get => _password; set => _password = value; }
//}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TraderName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26)]
    private char[] _traderName;
    public CTCL_TraderName(char[] _value)
    {
        _traderName = new char[26];
        Array.Copy(_value, 0, _traderName, 0, _value.Length > _traderName.Length ? _traderName.Length : _value.Length);

    }
    public CTCL_TraderName()
    {
        _traderName = new char[26];

    }
    public char[] TraderName { get => _traderName; set => _traderName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BrokerID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _brokerId;
    public CTCL_BrokerID(char[] _value)
    {
        _brokerId = new char[16];
        Array.Copy(_value, 0, _brokerId, 0, _value.Length > _brokerId.Length ? _brokerId.Length : _value.Length);

    }
    public CTCL_BrokerID()
    {
        _brokerId = new char[16];
    }
    public char[] BrokerID { get => _brokerId; set => _brokerId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BranchID
{
    [MarshalAs(UnmanagedType.I2)]
    private short _branchId;
    public CTCL_BranchID(short _value)
    {
        _branchId = _value;
    }
    public short BranchID { get => _branchId; set => _branchId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_VersionNumber
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _versionNumber;
    public Int32 VersionNumber { get => _versionNumber; set => _versionNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_HostSwitchContext
{
    [MarshalAs(UnmanagedType.I1)]
    private char _hostsWwitchContext;
    public char HostSwitchContext { get => _hostsWwitchContext; set => _hostsWwitchContext = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Colour
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _colour;
    public CTCL_Colour(char[] _value)
    {
        _colour = new char[50];
        Array.Copy(_value, 0, _colour, 0, _value.Length > _colour.Length ? _colour.Length : _value.Length);

    }
    public CTCL_Colour()
    {
        _colour = new char[50];
    }
    public char[] Colour { get => _colour; set => _colour = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UserType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _userType;
    public short UserType { get => _userType; set => _userType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SequenceNumber
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _sequenceNumber;
    public CTCL_SequenceNumber(Int64 _value)
    {
        _sequenceNumber = _value;
    }
    public Int64 SequenceNumber { get => _sequenceNumber; set => _sequenceNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WsClassName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
    private char[] _wsClassName;
    public char[] WsClassName { get => _wsClassName; set => _wsClassName = value; }
    public CTCL_WsClassName()
    {
        _wsClassName = new char[14];
    }
    public CTCL_WsClassName(char[] _value)
    {
        _wsClassName = new char[14];
        Array.Copy(_value, 0, _wsClassName, 0, _value.Length > _wsClassName.Length ? _wsClassName.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BrokerStatus
{
    [MarshalAs(UnmanagedType.I1)]
    private char _brokerStatus;
    public char BrokerStatus { get => _brokerStatus; set => _brokerStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ShowIndex
{
    [MarshalAs(UnmanagedType.I1)]
    private char _showIndex;
    public char ShowIndex { get => _showIndex; set => _showIndex = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ClearingStatus
{
    [MarshalAs(UnmanagedType.I1)]
    private char _clearingStatus;
    public char ClearingStatus { get => _clearingStatus; set => _clearingStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MemberType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _memberType;
    public CTCL_MemberType(short _value)
    {
        _memberType = _value;
    }
    public short MemberType { get => _memberType; set => _memberType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BrokerName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _brokerName;
    public char[] BrokerName { get => _brokerName; set => _brokerName = value; }
    public CTCL_BrokerName()
    {
        _brokerName = new char[25];
    }
    public CTCL_BrokerName(char[] _value)
    {
        _brokerName = new char[25];
        Array.Copy(_value, 0, _brokerName, 0, _value.Length > _brokerName.Length ? _brokerName.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UpdatePortfolio
{
    [MarshalAs(UnmanagedType.I1)]
    private char _updatePortfolio;
    public char UpdatePortfolio { get => _updatePortfolio; set => _updatePortfolio = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MarketIndex
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _marketIndex;
    public Int32 MarketIndex { get => _marketIndex; set => _marketIndex = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AuctionMarket
{

    private bool _auctionMarket;
    public bool AuctionMarket { get => _auctionMarket; set => _auctionMarket = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SpotMarket
{

    private bool _spotMarket;
    public bool SpotMarket { get => _spotMarket; set => _spotMarket = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OddlotMarket
{

    private bool _oddlotMarket;
    public bool OddlotMarket { get => _oddlotMarket; set => _oddlotMarket = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NormalMarket
{

    private bool _normalMarket;
    public bool NormalMarket { get => _normalMarket; set => _normalMarket = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Key
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
    private char[] _key;
    public char[] Key { get => _key; set => _key = value; }
    public CTCL_Key()
    {
        _key = new char[14];
    }
    public CTCL_Key(char[] _value)
    {
        _key = new char[14];
        Array.Copy(_value, 0, _key, 0, _value.Length > _key.Length ? _key.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Message
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
    private char[] _message;
    public CTCL_Message()
    {
        _message = new char[256];
    }
    public CTCL_Message(char[] _value)
    {
        _message = new char[256];
        Array.Copy(_value, 0, _message, 0, _value.Length > _message.Length ? _message.Length : _value.Length);
    }
    public char[] Message { get => _message; set => _message = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Period
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _period;
    public CTCL_Period(Int32 _value)
    {
        _period = _value;
    }
    public Int32 Period { get => _period; set => _period = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ErrorCode
{
    [MarshalAs(UnmanagedType.I4)]
    private long _errorCode;
    public CTCL_ErrorCode(long _value)
    {
        _errorCode = _value;
    }
    public long ErrorCode { get => _errorCode; set => _errorCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Percent
{
    [MarshalAs(UnmanagedType.I2)]
    private short _percent;
    public short Percent { get => _percent; set => _percent = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Quantity
{
    [MarshalAs(UnmanagedType.I8)] //I4 to I8
    private long _quantity;
    public CTCL_Quantity(long _value)
    {
        _quantity = _value;
    }
    public long Quantity { get => _quantity; set => _quantity = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TickSize
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _tickSize;
    public Int32 TickSize { get => _tickSize; set => _tickSize = value; }
    public CTCL_TickSize()
    {

    }
    public CTCL_TickSize IncrementTickSize()
    {
        _tickSize++;
        return this;
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InterestRate
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _interestRate;
    public Int32 InterestRate { get => _interestRate; set => _interestRate = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ParticipantType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _participantType;
    public CTCL_ParticipantType(char[] _value)
    {
        _participantType = new char[1];
        Array.Copy(_value, 0, _participantType, 0, _value.Length > _participantType.Length ? _participantType.Length : _value.Length);
    }
    public CTCL_ParticipantType()
    {
        _participantType = new char[1];
    }
    public char[] ParticipantType { get => _participantType; set => _participantType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Modified
{
    [MarshalAs(UnmanagedType.I1)]
    private char _modified;
    public CTCL_Modified(char _value)
    {
        _modified = _value;
    }
    public char Modified { get => _modified; set => _modified = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Code
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _code;
    public CTCL_Code(short _value)
    {
        _code = _value;
    }
    public Int32 Code { get => _code; set => _code = value; }
}

//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_ReasonCode
//{
//    [MarshalAs(UnmanagedType.I4)]
//    private Int32 _reasonCode;
//    public CTCL_ReasonCode(Int32 _value)
//    {
//        _reasonCode = _value;
//    }
//    public Int32 ReasonCode { get => _reasonCode; set => _reasonCode = value; }
//}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Normal
{
    [MarshalAs(UnmanagedType.I2)]
    private short _normal;
    public short Normal { get => _normal; set => _normal = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Oddlot
{
    [MarshalAs(UnmanagedType.I2)]
    private short _oddlot;
    public short Oddlot { get => _oddlot; set => _oddlot = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Spot
{
    [MarshalAs(UnmanagedType.I2)]
    private short _spot;
    public short Spot { get => _spot; set => _spot = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Auction
{
    [MarshalAs(UnmanagedType.I2)]
    private short _auction;
    public short Auction { get => _auction; set => _auction = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BooksMerged
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _booksMerged;
    public bool BooksMerged { get => _booksMerged; set => _booksMerged = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MinimumFill
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _minimumFill;
    public bool MinimumFill { get => _minimumFill; set => _minimumFill = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AON
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _aon;
    public CTCL_AON(bool _value)
    {
        _aon = _value;
    }
    public bool AON { get => _aon; set => _aon = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RequestForOpenOrders
{
    private char _requestForOpenOrders;
    public char RequestForOpenOrders { get => _requestForOpenOrders; set => _requestForOpenOrders = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NoOfRecords
{
    [MarshalAs(UnmanagedType.I2)]
    private short _noOfRecords;
    public short NoOfRecords { get => _noOfRecords; set => _noOfRecords = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MaximumGtcDays
{
    [MarshalAs(UnmanagedType.I2)]
    private short _maximumGtcDays;
    public short MaximumGtcDays { get => _maximumGtcDays; set => _maximumGtcDays = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IndexName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _indexName;
    public char[] IndexName { get => _indexName; set => _indexName = value; }
    public CTCL_IndexName(char[] _value)
    {
        _indexName = new char[32];
        Array.Copy(_value, 0, _indexName, 0, _value.Length > _indexName.Length ? _indexName.Length : _value.Length);
    }
    public CTCL_IndexName()
    {
        _indexName = new char[32];
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExchangeSpecificAttributeComposition
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _exchangeSpecificAttributeComposition;
    public CTCL_ExchangeSpecificAttributeComposition(char[] _value)
    {
        _exchangeSpecificAttributeComposition = new char[16];
        Array.Copy(_value, 0, _exchangeSpecificAttributeComposition, 0, _value.Length > _exchangeSpecificAttributeComposition.Length ? _exchangeSpecificAttributeComposition.Length : _value.Length);
    }
    public CTCL_ExchangeSpecificAttributeComposition()
    {
        _exchangeSpecificAttributeComposition = new char[16];
    }
    public char[] ExchangeSpecificAttributeComposition { get => _exchangeSpecificAttributeComposition; set => _exchangeSpecificAttributeComposition = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Token
{
    [MarshalAs(UnmanagedType.I8)]    //from i4 to i8 as in doc it is 8 byte
    private long _token;
    public CTCL_Token(long _value)
    {
        _token = _value;
    }
    public long Token { get => _token; set => _token = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrentOI
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _currentOI;
    public Int32 CurrentOI { get => _currentOI; set => _currentOI = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BcastName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26)]
    private char[] _bcastName;
    public char[] BcastName { get => _bcastName; set => _bcastName = value; }
    public CTCL_BcastName(char[] _value)
    {
        _bcastName = new char[26];
        Array.Copy(_value, 0, _bcastName, 0, _value.Length > _bcastName.Length ? _bcastName.Length : _value.Length);
    }
    public CTCL_BcastName()
    {
        _bcastName = new char[26];
    }

}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ChangedName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _changedName;
    public char[] ChangedName { get => _changedName; set => _changedName = value; }
    public CTCL_ChangedName(char[] _value)
    {
        _changedName = new char[10];
        Array.Copy(_value, 0, _changedName, 0, _value.Length > _changedName.Length ? _changedName.Length : _value.Length);
    }
    public CTCL_ChangedName()
    {
        _changedName = new char[10];
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DeleteFlag
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _deleteFlag;
    public CTCL_DeleteFlag(char[] _value)
    {
        _deleteFlag = new char[1];
        Array.Copy(_value, 0, _deleteFlag, 0, _value.Length > _deleteFlag.Length ? _deleteFlag.Length : _value.Length);
    }
    public CTCL_DeleteFlag()
    {
        _deleteFlag = new char[1];
    }
    public char[] DeleteFlag { get => _deleteFlag; set => _deleteFlag = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Portfolio
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _portfolio;
    public char[] Portfolio { get => _portfolio; set => _portfolio = value; }
    public CTCL_Portfolio()
    {
        _portfolio = new char[10];
    }
    public CTCL_Portfolio(char[] _value)
    {
        _portfolio = new char[10];
        Array.Copy(_value, 0, _portfolio, 0, _value.Length > _portfolio.Length ? _portfolio.Length : _value.Length);
    }

}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _instrumentName;
    public CTCL_InstrumentName(char[] _value)
    {
        _instrumentName = new char[16];
        Array.Copy(_value, 0, _instrumentName, 0, _value.Length > _instrumentName.Length ? _instrumentName.Length : _value.Length);

    }
    public CTCL_InstrumentName()
    {
        _instrumentName = new char[16];

    }
    public char[] InstrumentName { get => _instrumentName; set => _instrumentName = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Symbol
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _symbol;
    public CTCL_Symbol(char[] _value)
    {
        _symbol = new char[16];
        Array.Copy(_value, 0, _symbol, 0, _value.Length > _symbol.Length ? _symbol.Length : _value.Length);

    }
    public CTCL_Symbol()
    {
        _symbol = new char[16];
    }
    public char[] Symbol { get => _symbol; set => _symbol = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Symbol10Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _symbol;
    public CTCL_Symbol10Byte(char[] _value)
    {
        _symbol = new char[10];
        Array.Copy(_value, 0, _symbol, 0, _value.Length > _symbol.Length ? _symbol.Length : _value.Length);

    }
    public CTCL_Symbol10Byte()
    {
        _symbol = new char[10];
    }
    public char[] Symbol { get => _symbol; set => _symbol = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WatchListSymbol
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _watchListSymbol;

    public CTCL_WatchListSymbol(char[] _value)
    {
        _watchListSymbol = new char[64];
        Array.Copy(_value, 0, _watchListSymbol, 0, _value.Length > _watchListSymbol.Length ? _watchListSymbol.Length : _value.Length);
    }

    public CTCL_WatchListSymbol()
    {
        _watchListSymbol = new char[64];
    }

    public char[] WatchListSymbol { get => _watchListSymbol; set => _watchListSymbol = value; }

}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Price
{
    [MarshalAs(UnmanagedType.I8)]  //I4 to I8
    private long _price;
    public CTCL_Price(long _value)
    {
        _price = _value;
    }
    public long Price { get => _price; set => _price = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OptionType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _optionType;
    public CTCL_OptionType(char[] _value)
    {
        _optionType = new char[2];
        Array.Copy(_value, 0, _optionType, 0, _value.Length > _optionType.Length ? _optionType.Length : _value.Length);
    }
    public CTCL_OptionType()
    {
        _optionType = new char[2];
    }
    public char[] OptionType { get => _optionType; set => _optionType = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CALevel
{
    [MarshalAs(UnmanagedType.I2)]
    private short _caLevel;
    public CTCL_CALevel(short _value)
    {
        _caLevel = _value;
    }
    public short CALevel { get => _caLevel; set => _caLevel = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CounterPartyBrokerId
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _counterPartyBrokerId;
    public CTCL_CounterPartyBrokerId(char[] _value)
    {
        _counterPartyBrokerId = new char[16];
        Array.Copy(_value, 0, _counterPartyBrokerId, 0, _value.Length > _counterPartyBrokerId.Length ? _counterPartyBrokerId.Length : _value.Length);
    }
    public CTCL_CounterPartyBrokerId()
    {
        _counterPartyBrokerId = new char[16];
    }
    public char[] CounterPartyBrokerId { get => _counterPartyBrokerId; set => _counterPartyBrokerId = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CloseoutFlag
{
    [MarshalAs(UnmanagedType.I1)]
    private char _closeoutFlag;
    public CTCL_CloseoutFlag(char _value)
    {
        _closeoutFlag = _value;
    }
    public char CloseoutFlag { get => _closeoutFlag; set => _closeoutFlag = value; }
}

//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_OrderType
//{
//    [MarshalAs(UnmanagedType.I2)]
//    private short _orderType;
//    public CTCL_OrderType(short _value)
//    {
//        _orderType = _value;
//    }
//    public short OrderType { get => _orderType; set => _orderType = value; }
//}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OrderNumber
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _orderNumber;
    public CTCL_OrderNumber(Int64 _value)
    {
        _orderNumber = _value;
    }
    public Int64 OrderNumber { get => _orderNumber; set => _orderNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExchangeOrderNumber
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _orderNumber;
    public CTCL_ExchangeOrderNumber(Int64 _value)
    {
        _orderNumber = _value;
    }
    public Int64 OrderNumber { get => _orderNumber; set => _orderNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AccountNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _accountNumber;
    public char[] AccountNumber { get => _accountNumber; set => _accountNumber = value; }
    public CTCL_AccountNumber(char[] _value)
    {
        _accountNumber = new char[10];
        Array.Copy(_value, 0, _accountNumber, 0, _value.Length > _accountNumber.Length ? _accountNumber.Length : _value.Length);
    }
    public CTCL_AccountNumber()
    {
        _accountNumber = new char[10];
    }
}
//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_BookType
//{
//    [MarshalAs(UnmanagedType.I2)]
//    private short _bookType;
//    public CTCL_BookType(short _value)
//    {
//        _bookType = _value;
//    }
//    public short BookType { get => _bookType; set => _bookType = value; }
//}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Buy_SellIndicator
{
    [MarshalAs(UnmanagedType.I2)]
    private short _buy_SellIndicator;
    public CTCL_Buy_SellIndicator(short _value)
    {
        _buy_SellIndicator = _value;
    }
    public short Buy_SellIndicator { get => _buy_SellIndicator; set => _buy_SellIndicator = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Volume
{
    [MarshalAs(UnmanagedType.I8)]
    private long _volume;
    public CTCL_Volume(long _value)
    {
        _volume = _value;
    }
    public long Volume { get => _volume; set => _volume = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IOC
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _IOC;
    public CTCL_IOC(bool _value)
    {
        _IOC = _value;
    }
    public bool IOC { get => _IOC; set => _IOC = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_GTC
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _GTC;
    public CTCL_GTC(bool _value)
    {
        _GTC = _value;
    }
    public bool GTC { get => _GTC; set => _GTC = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Day
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _day;
    public CTCL_Day(bool _value)
    {
        _day = _value;
    }
    public bool Day { get => _day; set => _day = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MIT
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _MIT;
    public CTCL_MIT(bool _value)
    {
        _MIT = _value;
    }
    public bool MIT { get => _MIT; set => _MIT = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SL
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _SL;
    public CTCL_SL(bool _value)
    {
        _SL = _value;
    }
    public bool SL { get => _SL; set => _SL = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Market
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _market;
    public CTCL_Market(bool _value)
    {
        _market = _value;
    }
    public bool Market { get => _market; set => _market = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ATO
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _ATO;
    public CTCL_ATO(bool _value)
    {
        _ATO = _value;
    }
    public bool ATO { get => _ATO; set => _ATO = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Frozen
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _frozen;
    public CTCL_Frozen(bool _value)
    {
        _frozen = _value;
    }
    public bool Frozen { get => _frozen; set => _frozen = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Traded
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _traded;
    public CTCL_Traded(bool _value)
    {
        _traded = _value;
    }
    public bool Traded { get => _traded; set => _traded = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MatchedInd
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _matchedInd;
    public CTCL_MatchedInd(bool _value)
    {
        _matchedInd = _value;
    }
    public bool MatchedInd { get => _matchedInd; set => _matchedInd = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MF
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _MF;
    public CTCL_MF(bool _value)
    {
        _MF = _value;
    }
    public bool MF { get => _MF; set => _MF = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_cOrdFiller
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _cOrdFiller;
    public CTCL_cOrdFiller(bool _value)
    {
        _cOrdFiller = _value;
    }
    public bool COrdFiller { get => _cOrdFiller; set => _cOrdFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OE_cOrdFiller
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
    private char[] _cOrdFiller;
    public char[] COrdFiller { get => _cOrdFiller; set => _cOrdFiller = value; }
    public CTCL_OE_cOrdFiller()
    {
        _cOrdFiller = new char[24];
    }
    public CTCL_OE_cOrdFiller(char[] _value)
    {
        _cOrdFiller = new char[24];
        Array.Copy(_value, 0, _cOrdFiller, 0, _value.Length > _cOrdFiller.Length ? _cOrdFiller.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Open_Close
{
    private char _open_Close;
    public CTCL_Open_Close(char _value)
    {
        _open_Close = _value;
    }
    public char Open_Close { get => _open_Close; set => _open_Close = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PreOpen
{
    private bool _open;
    public CTCL_PreOpen(bool _value)
    {
        _open = _value;
    }
    public bool PreOpen { get => _open; set => _open = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OnStop
{
    private bool _stop;
    public CTCL_OnStop(bool _value)
    {
        _stop = _value;
    }
    public bool OnStopp { get => _stop; set => _stop = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Settlor
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _settlor;
    public CTCL_Settlor(char[] _value)
    {
        _settlor = new char[12];
        Array.Copy(_value, 0, _settlor, 0, _value.Length > _settlor.Length ? _settlor.Length : _value.Length);

    }
    public CTCL_Settlor()
    {
        _settlor = new char[12];

    }
    public char[] Settlor { get => _settlor; set => _settlor = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ClientIndicator
{
    [MarshalAs(UnmanagedType.I2)]
    private short _clientIndicator;
    public CTCL_ClientIndicator(short _value)
    {
        _clientIndicator = _value;
    }
    public short ClientIndicator { get => _clientIndicator; set => _clientIndicator = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BOC
{

    private bool _BOC;
    public CTCL_BOC(bool _value)
    {
        _BOC = _value;
    }
    public bool BOC { get => _BOC; set => _BOC = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_COL
{

    private bool _COL;
    public CTCL_COL(bool _value)
    {
        _COL = _value;
    }
    public bool COL { get => _COL; set => _COL = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_Order_Flag_bool
{
    [MarshalAs(UnmanagedType.I1)]
    private bool _storderbool;
    public CTCL_ST_Order_Flag_bool(bool _value)
    {
        _storderbool = _value;
    }
    public bool Storderbool { get => _storderbool; set => _storderbool = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STPC
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _STPC;
    public CTCL_STPC(bool _value)
    {
        _STPC = _value;
    }
    public bool STPC { get => _STPC; set => _STPC = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NnfField
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _nnfField;
    public CTCL_NnfField(Int64 _value)
    {
        _nnfField = _value;
    }
    public Int64 NnfField { get => _nnfField; set => _nnfField = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MktReplay
{
    [MarshalAs(UnmanagedType.I8)]
    private long _mktReplay;
    public CTCL_MktReplay(long _value)
    {
        _mktReplay = _value;
    }
    public long MktReplay { get => _mktReplay; set => _mktReplay = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PAN
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _PAN;
    public CTCL_PAN(char[] _value)
    {
        _PAN = new char[10];
        Array.Copy(_value, 0, _PAN, 0, _value.Length > _PAN.Length ? _PAN.Length : _value.Length);

    }
    public char[] PAN { get => _PAN; set => _PAN = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AccountSpecificAttribute
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _accountSpecificAttribute;
    public CTCL_AccountSpecificAttribute(char[] _value)
    {
        _accountSpecificAttribute = new char[32];
        Array.Copy(_value, 0, _accountSpecificAttribute, 0, _value.Length > _accountSpecificAttribute.Length ? _accountSpecificAttribute.Length : _value.Length);

    }
    public CTCL_AccountSpecificAttribute()
    {
        _accountSpecificAttribute = new char[32];
    }
    public char[] AccountSpecificAttribute { get => _accountSpecificAttribute; set => _accountSpecificAttribute = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Algo_ID
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _algo_ID;
    public CTCL_Algo_ID(Int32 _value)
    {
        _algo_ID = _value;
    }
    public Int32 Algo_ID { get => _algo_ID; set => _algo_ID = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LastActivityReference
{
    [MarshalAs(UnmanagedType.I8)]
    private long _lastActivityReference;
    public CTCL_LastActivityReference(long _value)
    {
        _lastActivityReference = _value;
    }
    public long LastActivityReference { get => _lastActivityReference; set => _lastActivityReference = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reference
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _reference;
    public char[] Reference { get => _reference; set => _reference = value; }
    public CTCL_Reference()
    {
        _reference = new char[4];
    }
    public CTCL_Reference(char[] _value)
    {
        _reference = new char[4];
        Array.Copy(_value, 0, _reference, 0, _value.Length > _reference.Length ? _reference.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TraderNumber
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _traderNumber;
    public Int32 TraderNumber { get => _traderNumber; set => _traderNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TradeNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _traderNumber;
    public CTCL_TradeNumber(char[] _value)
    {
        _traderNumber = new char[16];
        Array.Copy(_value, 0, _traderNumber, 0, _value.Length > _traderNumber.Length ? _traderNumber.Length : _value.Length);

    }
    public CTCL_TradeNumber()
    {
        _traderNumber = new char[16];
    }
    public char[] TradeNumber { get => _traderNumber; set => _traderNumber = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillNumber
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _fillNumber;
    public CTCL_FillNumber(Int32 _value)
    {
        _fillNumber = _value;
    }
    public Int32 FillNumber { get => _fillNumber; set => _fillNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ActivityType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _activityType;
    public char[] ActivityType { get => _activityType; set => _activityType = value; }

    public CTCL_ActivityType()
    {
        _activityType = new char[2];
    }
    public CTCL_ActivityType(char[] _value)
    {
        _activityType = new char[2];
        Array.Copy(_value, 0, _activityType, 0, _value.Length > _activityType.Length ? _activityType.Length : _value.Length);
    }

}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CounterBrokerId
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _counterBrokerId;
    public char[] CounterBrokerId { get => _counterBrokerId; set => _counterBrokerId = value; }
    public CTCL_CounterBrokerId()
    {
        _counterBrokerId = new char[5];
    }
    public CTCL_CounterBrokerId(char[] _value)
    {
        _counterBrokerId = new char[5];
        Array.Copy(_value, 0, _counterBrokerId, 0, _value.Length > _counterBrokerId.Length ? _counterBrokerId.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Participant
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _participant;

    public CTCL_Participant(char[] _value)
    {
        _participant = new char[16];
        Array.Copy(_value, 0, _participant, 0, _value.Length > _participant.Length ? _participant.Length : _value.Length);

    }
    public CTCL_Participant()
    {
        _participant = new char[16];
    }
    public char[] Participant { get => _participant; set => _participant = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ReservedFiller
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _reservedFiller;
    public char[] ReservedFiller { get => _reservedFiller; set => _reservedFiller = value; }

    public CTCL_ReservedFiller()
    {
        _reservedFiller = new char[2];
    }
    public CTCL_ReservedFiller(char[] _value)
    {
        _reservedFiller = new char[2];
        Array.Copy(_value, 0, _reservedFiller, 0, _value.Length > _reservedFiller.Length ? _reservedFiller.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BCSeqNo
{
    [MarshalAs(UnmanagedType.I8)]
    private long _BCSeqNo;
    public long BCSeqNo { get => _BCSeqNo; set => _BCSeqNo = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ActionCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _actionCode;
    public char[] ActionCode { get => _actionCode; set => _actionCode = value; }
    public CTCL_ActionCode()
    {
        _actionCode = new char[3];
    }
    public CTCL_ActionCode(char[] _value)
    {
        _actionCode = new char[3];
        Array.Copy(_value, 0, _actionCode, 0, _value.Length > _actionCode.Length ? _actionCode.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_JournalingRequired
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _journalingRequired;
    public bool JournalingRequired { get => _journalingRequired; set => _journalingRequired = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Tandem
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _tandem;
    public bool Tandem { get => _tandem; set => _tandem = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ControlWorkstation
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _controlWorkstation;
    public bool ControlWorkstation { get => _controlWorkstation; set => _controlWorkstation = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TraderWorkstation
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _traderWorkstation;
    public bool TraderWorkstation { get => _traderWorkstation; set => _traderWorkstation = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BroadcastMessageLength
{
    [MarshalAs(UnmanagedType.I2)]
    private short _broadcastMessageLength;
    public short BroadcastMessageLength { get => _broadcastMessageLength; set => _broadcastMessageLength = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BroadcastMessage
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
    private char[] _broadcastMessage;
    public char[] BroadcastMessage { get => _broadcastMessage; set => _broadcastMessage = value; }
    public CTCL_BroadcastMessage()
    {
        _broadcastMessage = new char[256];
    }
    public CTCL_BroadcastMessage(char[] _value)
    {
        _broadcastMessage = new char[256];
        Array.Copy(_value, 0, _broadcastMessage, 0, _value.Length > _broadcastMessage.Length ? _broadcastMessage.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Series
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _series;
    public CTCL_Series(char[] _value)
    {
        _series = new char[2];
        Array.Copy(_value, 0, _series, 0, _value.Length > _series.Length ? _series.Length : _value.Length);

    }
    public CTCL_Series()
    {
        _series = new char[2];
    }

    public char[] Series { get => _series; set => _series = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CALevel_Short
{
    private short _caLevel;
    public short CALevel { get => _caLevel; set => _caLevel = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PermittedToTrade
{
    [MarshalAs(UnmanagedType.I2)]
    private short _permittedToTrade;
    public short PermittedToTrade { get => _permittedToTrade; set => _permittedToTrade = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _instrumenttype;
    public short Instrumenttype { get => _instrumenttype; set => _instrumenttype = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CallAuc1Flag
{
    [MarshalAs(UnmanagedType.I2)]
    private short _callAucFlag1;
    public short CallAugFlag { get => _callAucFlag1; set => _callAucFlag1 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurvIndicator
{
    [MarshalAs(UnmanagedType.I2)]
    private short _survInd;
    public short SurvInd { get => _survInd; set => _survInd = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IssuedCapital
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _issuedCapital;
    public CTCL_IssuedCapital(Int64 _value)
    {
        _issuedCapital = _value;
    }
    public Int64 IssuedCapital { get => _issuedCapital; set => _issuedCapital = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CreditRating
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _creditRating;
    public CTCL_CreditRating(char[] _value)
    {
        _creditRating = new char[32];
        Array.Copy(_value, 0, _creditRating, 0, _value.Length > _creditRating.Length ? _creditRating.Length : _value.Length);

    }
    public CTCL_CreditRating()
    {
        _creditRating = new char[32];

    }
    public char[] CreditRating { get => _creditRating; set => _creditRating = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CreditRating12Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _creditRating;
    public CTCL_CreditRating12Byte(char[] _value)
    {
        _creditRating = new char[12];
        Array.Copy(_value, 0, _creditRating, 0, _value.Length > _creditRating.Length ? _creditRating.Length : _value.Length);

    }
    public CTCL_CreditRating12Byte()
    {
        _creditRating = new char[12];

    }
    public char[] CreditRating { get => _creditRating; set => _creditRating = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_SEC_ELIGIBILITY_PER_MARKET_Reserved
{
    private bool[] _reserved;
    public bool[] Reserved { get => _reserved; set => _reserved = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Eligibility
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _eligibility;
    public bool Eligibility { get => _eligibility; set => _eligibility = value; }
}
//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_Status
//{
//    [MarshalAs(UnmanagedType.I2)]
//    private short _status;
//    public short Status { get => _status; set => _status = value; }
//}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IssueRate
{
    [MarshalAs(UnmanagedType.I2)]
    private short _issueRate;
    public short IssueRate { get => _issueRate; set => _issueRate = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Name
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _name;
    public CTCL_Name(char[] _value)
    {
        _name = new char[32];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public CTCL_Name()
    {
        _name = new char[32];
    }
    public char[] Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Name25Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _name;
    public CTCL_Name25Byte(char[] _value)
    {
        _name = new char[25];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public CTCL_Name25Byte()

    {
        _name = new char[25];
    }
    public char[] Name { get => _name; set => _name = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_ELIGIBLITY_INDICATORS_Reserved
{
    private bool[] _reserved;
    public bool[] Reserved { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IntrinsicValue
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _intrinsicValue;
    public Int32 IntrinsicValue { get => _intrinsicValue; set => _intrinsicValue = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AssetInstrument
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
    private char[] _assetInstrument;
    public char[] AssetInstrument { get => _assetInstrument; set => _assetInstrument = value; }
    public CTCL_AssetInstrument()
    {
        _assetInstrument = new char[6];
    }
    public CTCL_AssetInstrument(char[] _value)
    {
        _assetInstrument = new char[6];
        Array.Copy(_value, 0, _assetInstrument, 0, _value.Length > _assetInstrument.Length ? _assetInstrument.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AssetName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _assetName;
    public char[] AssetName { get => _assetName; set => _assetName = value; }
    public CTCL_AssetName()
    {
        _assetName = new char[10];
    }
    public CTCL_AssetName(char[] _value)
    {
        _assetName = new char[10];
        Array.Copy(_value, 0, _assetName, 0, _value.Length > _assetName.Length ? _assetName.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ParticipateInMarketIndex
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _participateInMarketIndex;
    public bool ParticipateInMarketIndex { get => _participateInMarketIndex; set => _participateInMarketIndex = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExerciseStyle
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _exerciseStyle;
    public bool ExerciseStyle { get => _exerciseStyle; set => _exerciseStyle = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EGM
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _EGM;
    public bool EGM { get => _EGM; set => _EGM = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AGM
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _AGM;
    public bool AGM { get => _AGM; set => _AGM = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Interest
{
    private bool _interest;
    public bool Interest { get => _interest; set => _interest = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Bonus
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _bonus;
    public bool Bonus { get => _bonus; set => _bonus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Rights
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _rights;
    public bool Rights { get => _rights; set => _rights = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Dividend
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _dividend;
    public bool Dividend { get => _dividend; set => _dividend = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_Purpose_Reserved
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool[] _reserved;
    public bool[] Reserved { get => _reserved; set => _reserved = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IsCorporateAdjusted
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _isCorporateAdjusted;
    public bool IsCorporateAdjusted { get => _isCorporateAdjusted; set => _isCorporateAdjusted = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IsThisAsse
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _isThisAsse;
    public bool IsThisAsse { get => _isThisAsse; set => _isThisAsse = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PlAllowed
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _plAllowed;
    public bool PlAllowed { get => _plAllowed; set => _plAllowed = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExRejectionAllowed
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _exRejectionAllowed;
    public bool ExRejectionAllowed { get => _exRejectionAllowed; set => _exRejectionAllowed = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExAllowed
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _exAllowed;
    public bool ExAllowed { get => _exAllowed; set => _exAllowed = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentId
{
    [MarshalAs(UnmanagedType.I2)]
    private short _instrumentId;
    public short InstrumentId { get => _instrumentId; set => _instrumentId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentDescription
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _instrumentDescription;
    public char[] InstrumentDescription { get => _instrumentDescription; set => _instrumentDescription = value; }
    public CTCL_InstrumentDescription()
    {
        _instrumentDescription = new char[5];
    }
    public CTCL_InstrumentDescription(char[] _value)
    {
        _instrumentDescription = new char[5];
        Array.Copy(_value, 0, _instrumentDescription, 0, _value.Length > _instrumentDescription.Length ? _instrumentDescription.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ParticipantStatus
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _participantStatus;
    public CTCL_ParticipantStatus(char[] _value)
    {
        _participantStatus = new char[1];
        Array.Copy(_value, 0, _participantStatus, 0, _value.Length > _participantStatus.Length ? _participantStatus.Length : _value.Length);

    }
    public CTCL_ParticipantStatus()
    {
        _participantStatus = new char[1];

    }
    public char[] ParticipantStatus { get => _participantStatus; set => _participantStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WarningType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _warningType;
    public short WarningType { get => _warningType; set => _warningType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Final
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char _final;
    public char Final { get => _final; set => _final = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OpenInterest
{
    [MarshalAs(UnmanagedType.I4)]
    private UInt32 _openInterest;
    public UInt32 OpenInterest { get => _openInterest; set => _openInterest = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DayOI
{
    [MarshalAs(UnmanagedType.I4)]
    private UInt32 _dayOI;
    public UInt32 DayOI { get => _dayOI; set => _dayOI = value; }
}

//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_TradingStatus
//{
//    [MarshalAs(UnmanagedType.I2)]
//    private short _tradingStatus;
//    public short TradingStatus { get => _tradingStatus; set => _tradingStatus = value; }
//}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NetChangeIndicator
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _netChangeIndicator;

    public CTCL_NetChangeIndicator(char[] _value)
    {
        _netChangeIndicator = new char[1];
        Array.Copy(_value, 0, _netChangeIndicator, 0, _value.Length > _netChangeIndicator.Length ? _netChangeIndicator.Length : _value.Length);

    }
    public char[] NetChangeIndicator { get => _netChangeIndicator; set => _netChangeIndicator = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AuctionNumber
{
    [MarshalAs(UnmanagedType.I2)]
    private short _auctionNumber;
    public short AuctionNumber { get => _auctionNumber; set => _auctionNumber = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AuctionStatus
{
    [MarshalAs(UnmanagedType.I2)]
    private short _auctionStatus;
    public short AuctionStatus { get => _auctionStatus; set => _auctionStatus = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InitiatorType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _initiatorType;
    public short InitiatorType { get => _initiatorType; set => _initiatorType = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RecordBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char _recordBuffer;
    public char RecordBuffer { get => _recordBuffer; set => _recordBuffer = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Buy
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _buy;
    public bool Buy { get => _buy; set => _buy = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Sell
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _sell;
    public bool Sell { get => _sell; set => _sell = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LastTradeLess
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _lastTradeLess;
    public bool LastTradeLess { get => _lastTradeLess; set => _lastTradeLess = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LastTradeMore
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _lastTradeMore;
    public bool LastTradeMore { get => _lastTradeMore; set => _lastTradeMore = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NoOfOrders
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _noOfOrders;
    public Int32 NoOfOrders { get => _noOfOrders; set => _noOfOrders = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BbTotalBuySellFlag
{
    [MarshalAs(UnmanagedType.I2)]
    private short _BbTotalBuyFlag;
    public short BbTotalBuyFlag { get => _BbTotalBuyFlag; set => _BbTotalBuyFlag = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IndexValue
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _indexValue;
    public Int32 IndexValue { get => _indexValue; set => _indexValue = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_HighIndexValue
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _highIndexValue;
    public Int32 HighIndexValue { get => _highIndexValue; set => _highIndexValue = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LowIndexValue
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _lowIndexValue;
    public Int32 LowIndexValue { get => _lowIndexValue; set => _lowIndexValue = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OpeningIndex
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _openingIndex;
    public Int32 OpeningIndex { get => _openingIndex; set => _openingIndex = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ClosingIndex
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _closingIndex;
    public Int32 ClosingIndex { get => _closingIndex; set => _closingIndex = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_YearlyHigh
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _yearlyHigh;
    public Int32 YearlyHigh { get => _yearlyHigh; set => _yearlyHigh = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_YearlyLow
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _yearlyLow;
    public Int32 YearlyLow { get => _yearlyLow; set => _yearlyLow = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NoOfmoves
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _noOfMoves;
    public Int32 NoOfMoves { get => _noOfMoves; set => _noOfMoves = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MarketCapitalisation
{
    [MarshalAs(UnmanagedType.R8)]
    private double _marketCapitalisation;
    public double MarketCapitalisation { get => _marketCapitalisation; set => _marketCapitalisation = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IndustryName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
    private char[] _industryName;
    public char[] IndustryName { get => _industryName; set => _industryName = value; }
    public CTCL_IndustryName()
    {
        IndustryName = new char[15];
    }
    public CTCL_IndustryName(char[] _value)
    {
        IndustryName = new char[15];
        Array.Copy(_value, 0, IndustryName, 0, _value.Length > IndustryName.Length ? IndustryName.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Open
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _open;
    public Int32 Open { get => _open; set => _open = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MKT_High
{
    [MarshalAs(UnmanagedType.I2)]
    private short _high;
    public short High { get => _high; set => _high = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MKT_Low
{
    [MarshalAs(UnmanagedType.I2)]
    private short _low;
    public short Low { get => _low; set => _low = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NumberOfIndustryRecords
{
    [MarshalAs(UnmanagedType.I2)]
    private short _numberOfIndustryRecords;
    public short NumberOfIndustryRecords { get => _numberOfIndustryRecords; set => _numberOfIndustryRecords = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_High
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _high;
    public Int32 High { get => _high; set => _high = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Low
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _low;
    public Int32 Low { get => _low; set => _low = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Last
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _last;
    public Int32 Last { get => _last; set => _last = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Close
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _close;
    public Int32 Close { get => _close; set => _close = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MKT_Closing
{
    [MarshalAs(UnmanagedType.I2)]
    private short _closing;
    public short Closing { get => _closing; set => _closing = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MKT_Start
{
    [MarshalAs(UnmanagedType.I2)]
    private short _start;
    public short Start { get => _start; set => _start = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Start
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _start;
    public Int32 Start { get => _start; set => _start = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PrevClose
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _prevClose;
    public Int32 PrevClose { get => _prevClose; set => _prevClose = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LifeHigh
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _lifeHigh;
    public Int32 LifeHigh { get => _lifeHigh; set => _lifeHigh = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LifeLow
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _lifeLow;
    public Int32 LifeLow { get => _lifeLow; set => _lifeLow = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_INDEXDETAILSFiller
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _filler;
    public Int32 Filler { get => _filler; set => _filler = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NseSymbol
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _nseSymbol;
    public char[] NseSymbol { get => _nseSymbol; set => _nseSymbol = value; }
    public CTCL_NseSymbol()
    {
        _nseSymbol = new char[16];
    }
    public CTCL_NseSymbol(char[] _value)
    {
        _nseSymbol = new char[16];
        Array.Copy(_value, 0, _nseSymbol, 0, _value.Length > _nseSymbol.Length ? _nseSymbol.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExpMonth
{
    [MarshalAs(UnmanagedType.I2)]
    private short _expMonth;
    public short ExpMonth { get => _expMonth; set => _expMonth = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExpYear
{
    [MarshalAs(UnmanagedType.I2)]
    private short _expYear;
    public short ExpYear { get => _expYear; set => _expYear = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BidSize
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _bidSize;
    public Int64 BidSize { get => _bidSize; set => _bidSize = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AskSize
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _askSize;
    public Int64 AskSize { get => _askSize; set => _askSize = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CONTRACTS_DETAILS_Filler
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _filler;
    public Int32 Filler { get => _filler; set => _filler = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MbpSell
{
    [MarshalAs(UnmanagedType.I2)]
    private short _mbpSell;
    public short MbpSell { get => _mbpSell; set => _mbpSell = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MbpBuy
{
    [MarshalAs(UnmanagedType.I2)]
    private short _mbpBuy;
    public short MbpBuy { get => _mbpBuy; set => _mbpBuy = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Band
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _band;
    public Int32 Band { get => _band; set => _band = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MsgCount
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _msgCount;
    public Int32 MsgCount { get => _msgCount; set => _msgCount = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FirmName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _firmName;
    public char[] FirmName { get => _firmName; set => _firmName = value; }
    public CTCL_FirmName()
    {
        _firmName = new char[25];
    }
    public CTCL_FirmName(char[] _value)
    {
        _firmName = new char[25];
        Array.Copy(_value, 0, _firmName, 0, _value.Length > _firmName.Length ? _firmName.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TotalValueTraded
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _totalValueTraded;
    public Int32 TotalValueTraded { get => _totalValueTraded; set => _totalValueTraded = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Indicator
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _indicator;
    public char[] Indicator { get => _indicator; set => _indicator = value; }
    public CTCL_Indicator()
    {
        _indicator = new char[4];
    }
    public CTCL_Indicator(char[] _value)
    {
        _indicator = new char[4];
        Array.Copy(_value, 0, _indicator, 0, _value.Length > _indicator.Length ? _indicator.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MessageType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _messageType;
    public char[] MessageType { get => _messageType; set => _messageType = value; }
    public CTCL_MessageType()
    {
        _messageType = new char[1];
    }
    public CTCL_MessageType(char[] _value)
    {
        _messageType = new char[1];
        Array.Copy(_value, 0, _messageType, 0, _value.Length > _messageType.Length ? _messageType.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Opening
{
    [MarshalAs(UnmanagedType.I2)]
    private short _opening;
    public short Opening { get => _opening; set => _opening = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SectorName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
    private char[] _sectorName;
    public char[] SectorName { get => _sectorName; set => _sectorName = value; }
    public CTCL_SectorName()
    {
        _sectorName = new char[15];
    }
    public CTCL_SectorName(char[] _value)
    {
        _sectorName = new char[15];
        Array.Copy(_value, 0, _sectorName, 0, _value.Length > _sectorName.Length ? _sectorName.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NumberOfPackets
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _numberOfPackets;
    public Int32 NumberOfPackets { get => _numberOfPackets; set => _numberOfPackets = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OrgScope
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char _orgScope;
    public char OrgScope { get => _orgScope; set => _orgScope = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OPENPD
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _OPENPD;
    public Int32 OPENPD { get => _OPENPD; set => _OPENPD = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_HIPD
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _HIPD;
    public Int32 HIPD { get => _HIPD; set => _HIPD = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LOWPD
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _LOWPD;
    public Int32 LOWPD { get => _LOWPD; set => _LOWPD = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LASTTRADEDPD
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _LASTTRADEDPD;
    public Int32 LASTTRADEDPD { get => _LASTTRADEDPD; set => _LASTTRADEDPD = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NOOFCONTRACTSTRADED
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _NOOFCONTRACTSTRADED;
    public Int32 NOOFCONTRACTSTRADED { get => _NOOFCONTRACTSTRADED; set => _NOOFCONTRACTSTRADED = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PlateformIdentifier
{

    private short _plateformId;
    public short PlateformIdentifier { get => _plateformId; set => _plateformId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SettlementType
{

    private short _settlementType;
    public short SettlementType { get => _settlementType; set => _settlementType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OrderStatus
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _orderStatus;
    public CTCL_OrderStatus(char[] _value)
    {
        _orderStatus = new char[10];
        Array.Copy(_value, 0, _orderStatus, 0, _value.Length > _orderStatus.Length ? _orderStatus.Length : _value.Length);

    }
    public CTCL_OrderStatus()
    {
        _orderStatus = new char[10];
    }
    public char[] OrderStatus { get => _orderStatus; set => _orderStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OERemark
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _OERemark;
    public char[] OERemark { get => _OERemark; set => _OERemark = value; }
    public CTCL_OERemark()
    {
        OERemark = new char[5];
    }
    public CTCL_OERemark(char[] _value)
    {
        OERemark = new char[5];
        Array.Copy(_value, 0, OERemark, 0, _value.Length > OERemark.Length ? OERemark.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OmsOrderNumber
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _orderNumber;
    public Int32 OmsOrderNumber { get => _orderNumber; set => _orderNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Suspend
{
    private char _suspend;
    public CTCL_Suspend(char _value)
    {
        _suspend = _value;
    }
    public char Suspend { get => _suspend; set => _suspend = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExchangeSegmentId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _segmentId;
    public CTCL_ExchangeSegmentId(Int32 _value)
    {
        _segmentId = _value;
    }
    public Int32 SegmentId { get => _segmentId; set => _segmentId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PlatformID
{
    [MarshalAs(UnmanagedType.I2)]
    private short _platformId;

    public CTCL_PlatformID(short _value)
    {
        _platformId = _value;
    }
    public short PlatformId { get => _platformId; set => _platformId = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Short_TimeStamp
{
    [MarshalAs(UnmanagedType.I2)]
    private short _timestamp;
    public CTCL_Short_TimeStamp(short _value)
    {
        _timestamp = _value;
    }
    public short TimeStamp { get => _timestamp; set => _timestamp = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CharReserved
{

    private char _chrReserved;
    public CTCL_CharReserved(char _value)
    {
        _chrReserved = _value;
    }
    public char ChrReserved { get => _chrReserved; set => _chrReserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _reserved;
    public CTCL_Reserved(char[] _value)
    {
        _reserved = new char[1];
        Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);

    }
    public CTCL_Reserved()
    {
        _reserved = new char[1];

    }
    public char[] Reserved { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved1
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _reserved1;
    public CTCL_Reserved1(char[] _value)
    {
        _reserved1 = new char[1];
        Array.Copy(_value, 0, _reserved1, 0, _value.Length > _reserved1.Length ? _reserved1.Length : _value.Length);

    }
    public CTCL_Reserved1()
    {
        _reserved1 = new char[1];

    }
    public char[] Reserved1 { get => _reserved1; set => _reserved1 = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved2
{
    private bool _Reserved2;
    public CTCL_Reserved2(bool _value)
    {
        _Reserved2 = _value;
    }
    public bool Reserved2 { get => _Reserved2; set => _Reserved2 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved3
{
    private bool _Reserved3;
    public CTCL_Reserved3(bool _value)
    {
        _Reserved3 = _value;
    }
    public bool Reserved3 { get => _Reserved3; set => _Reserved3 = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved4
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _reserved;
    public CTCL_Reserved4(char[] _value)
    {
        _reserved = new char[4];
        Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);
    }
    public CTCL_Reserved4()
    {
        _reserved = new char[4];
    }
    public char[] Reserved4 { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved5
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _reserved5;
    public CTCL_Reserved5(char[] _value)
    {
        _reserved5 = new char[1];
        Array.Copy(_value, 0, _reserved5, 0, _value.Length > _reserved5.Length ? _reserved5.Length : _value.Length);

    }
    public CTCL_Reserved5()
    {
        _reserved5 = new char[1];

    }
    public char[] Reserved5 { get => _reserved5; set => _reserved5 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved6
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _reserved6;
    public CTCL_Reserved6(char[] _value)
    {
        _reserved6 = new char[2];
        Array.Copy(_value, 0, _reserved6, 0, _value.Length > _reserved6.Length ? _reserved6.Length : _value.Length);

    }
    public CTCL_Reserved6()
    {
        _reserved6 = new char[2];

    }
    public char[] Reserved6 { get => _reserved6; set => _reserved6 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved7
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _reserved7;
    public CTCL_Reserved7(char[] _value)
    {
        _reserved7 = new char[1];
        Array.Copy(_value, 0, _reserved7, 0, _value.Length > _reserved7.Length ? _reserved7.Length : _value.Length);

    }
    public CTCL_Reserved7()
    {
        _reserved7 = new char[1];

    }
    public char[] Reserved7 { get => _reserved7; set => _reserved7 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved8
{
    private bool _Reserved8;
    public CTCL_Reserved8(bool _value)
    {
        _Reserved8 = _value;
    }
    public bool Reserved8 { get => _Reserved8; set => _Reserved8 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved9
{
    private bool _Reserved9;
    public CTCL_Reserved9(bool _value)
    {
        _Reserved9 = _value;
    }
    public bool Reserved9 { get => _Reserved9; set => _Reserved9 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved10
{
    private bool _Reserved10;
    public CTCL_Reserved10(bool _value)
    {
        _Reserved10 = _value;
    }
    public bool Reserved10 { get => _Reserved10; set => _Reserved10 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved11
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _reserved11;
    public CTCL_Reserved11(char[] _value)
    {
        _reserved11 = new char[1];
        Array.Copy(_value, 0, _reserved11, 0, _value.Length > _reserved11.Length ? _reserved11.Length : _value.Length);

    }
    public CTCL_Reserved11()
    {
        _reserved11 = new char[1];

    }
    public char[] Reserved11 { get => _reserved11; set => _reserved11 = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved12
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 52)]
    private char[] _reserved12;
    public CTCL_Reserved12(char[] _value)
    {
        _reserved12 = new char[52];
        Array.Copy(_value, 0, _reserved12, 0, _value.Length > _reserved12.Length ? _reserved12.Length : _value.Length);
    }
    public CTCL_Reserved12()
    {
        _reserved12 = new char[52];
    }
    public char[] Reserved12 { get => _reserved12; set => _reserved12 = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Suspended
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _suspended;
    public CTCL_Suspended(char[] _value)
    {
        _suspended = new char[1];
        Array.Copy(_value, 0, _suspended, 0, _value.Length > _suspended.Length ? _suspended.Length : _value.Length);

    }
    public char[] Suspended { get => _suspended; set => _suspended = value; }
}

public struct CTCL_SettlementPeriod
{
    private short _settlementPeriod;
    public short SettlementPeriod { get => _settlementPeriod; set => _settlementPeriod = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Flag
{
    private bool _FLAG;
    public CTCL_Flag(bool _value)
    {
        _FLAG = _value;
    }
    public bool FLAG { get => _FLAG; set => _FLAG = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct Sec_Reserved
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _reserved;
    public bool Reserved { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct Sec_Eligibility
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _eligibility;
    public Sec_Eligibility(bool _value)
    {
        _eligibility = _value;
    }

    public bool Eligibility { get => _eligibility; set => _eligibility = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct Sec_Status
{
    [MarshalAs(UnmanagedType.I2)]
    private short _status;
    public Sec_Status(short _value)
    {
        _status = _value;
    }
    public short Status { get => _status; set => _status = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Percentage
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _percentage;
    public CTCL_Percentage(Int32 _value)
    {
        _percentage = _value;
    }
    public Int32 Percentage { get => _percentage; set => _percentage = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Remark
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _remark;
    public CTCL_Remark(char[] _value)
    {
        _remark = new char[32];
        //_remark = _value;
        Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

    }
    public CTCL_Remark()
    {
        _remark = new char[32];
    }
    public char[] Remark { get => _remark; set => _remark = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Remark25Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _remark;
    public CTCL_Remark25Byte(char[] _value)
    {
        _remark = new char[25];
        //_remark = _value;
        Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

    }
    public CTCL_Remark25Byte()
    {
        _remark = new char[25];
    }
    public char[] Remark { get => _remark; set => _remark = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ReservedBits
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _reserved;
    public CTCL_ReservedBits(char[] _value)
    {
        _reserved = new char[5];
        Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);

    }
    public CTCL_ReservedBits()
    {
        _reserved = new char[5];
    }
    public char[] Reservedbits { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ISINNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _isinNumber;
    public CTCL_ISINNumber(char[] _value)
    {
        _isinNumber = new char[16];
        Array.Copy(_value, 0, _isinNumber, 0, _value.Length > _isinNumber.Length ? _isinNumber.Length : _value.Length);

    }
    public CTCL_ISINNumber()
    {
        _isinNumber = new char[16];
    }
    public char[] ISINNumber { get => _isinNumber; set => _isinNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ParticipantId
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _participantId;

    public CTCL_ParticipantId(char[] _value)
    {
        _participantId = new char[32];
        Array.Copy(_value, 0, _participantId, 0, _value.Length > _participantId.Length ? _participantId.Length : _value.Length);

    }
    public CTCL_ParticipantId()
    {
        _participantId = new char[32];
    }
    public char[] ParticipantId { get => _participantId; set => _participantId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ParticipantName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _participantName;

    public CTCL_ParticipantName(char[] _value)
    {
        _participantName = new char[128];
        Array.Copy(_value, 0, _participantName, 0, _value.Length > _participantName.Length ? _participantName.Length : _value.Length);

    }
    public CTCL_ParticipantName()
    {
        _participantName = new char[128];
    }
    public char[] ParticipantName { get => _participantName; set => _participantName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Filler1
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _filler;
    public CTCL_Filler1(char[] _value)
    {
        _filler = new char[1];
        Array.Copy(_value, 0, _filler, 0, _value.Length > _filler.Length ? _filler.Length : _value.Length);

    }
    public CTCL_Filler1()
    {
        _filler = new char[1];

    }
    public char[] Filler1 { get => _filler; set => _filler = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller1
{
    private bool bitFiller;
    public CTCL_BitFiller1(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller1 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller2
{
    private bool bitFiller;
    public CTCL_BitFiller2(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller2 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller3
{
    private bool bitFiller;
    public CTCL_BitFiller3(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller3 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller4
{
    private bool bitFiller;
    public CTCL_BitFiller4(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller4 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller5
{
    private bool bitFiller;
    public CTCL_BitFiller5(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller5 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller6
{
    private bool bitFiller;
    public CTCL_BitFiller6(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller6 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller7
{
    private bool bitFiller;
    public CTCL_BitFiller7(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller7 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller8
{
    private bool bitFiller;
    public CTCL_BitFiller8(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller8 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller9
{
    private bool bitFiller;
    public CTCL_BitFiller9(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller9 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller10
{
    private bool bitFiller;
    public CTCL_BitFiller10(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller10 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller11
{
    private bool bitFiller;
    public CTCL_BitFiller11(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller11 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller12
{
    private bool bitFiller;
    public CTCL_BitFiller12(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller12 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller13
{
    private bool bitFiller;
    public CTCL_BitFiller13(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller13 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller14
{
    private bool bitFiller;
    public CTCL_BitFiller14(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller14 { get => bitFiller; set => bitFiller = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller15
{
    private bool bitFiller;
    public CTCL_BitFiller15(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller15 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller16
{
    private bool bitFiller;
    public CTCL_BitFiller16(bool _value)
    {
        bitFiller = _value;
    }
    public bool BitFiller16 { get => bitFiller; set => bitFiller = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller17
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _bitFillers;
    public CTCL_BitFiller17(char[] _value)
    {
        _bitFillers = new char[1];
        Array.Copy(_value, 0, _bitFillers, 0, _value.Length > _bitFillers.Length ? _bitFillers.Length : _value.Length);

    }
    public CTCL_BitFiller17()
    {
        _bitFillers = new char[1];
    }
    public char[] BitFiller17 { get => _bitFillers; set => _bitFillers = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitFiller18
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _bitFillers;
    public CTCL_BitFiller18(char[] _value)
    {
        _bitFillers = new char[1];
        Array.Copy(_value, 0, _bitFillers, 0, _value.Length > _bitFillers.Length ? _bitFillers.Length : _value.Length);

    }
    public CTCL_BitFiller18()
    {
        _bitFillers = new char[1];
    }
    public char[] BitFiller18 { get => _bitFillers; set => _bitFillers = value; }
}

//Login req-Auth related fields

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TerminalID // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _terminalId;

    public CTCL_TerminalID()
    {
        _terminalId = new char[16];
    }
    public CTCL_TerminalID(char[] _value)
    {
        _terminalId = new char[16];
        //_terminalId = _value;
        Array.Copy(_value, 0, _terminalId, 0, _value.Length > _terminalId.Length ? _terminalId.Length : _value.Length);

    }
    public char[] TerminalId { get => _terminalId; set => _terminalId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRTerminalID // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
    private string _terminalId;


    public CTCL_STRTerminalID(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _terminalId = new string(temparry).Replace("\0", "").Replace(" ", "");
        //_terminalId = _value;


    }
    public string TerminalId { get => _terminalId; set => _terminalId = value; }
}

//before uncmmenting do vinay/shubham know

//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_Password16 // 16 Byte
//{
//    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
//    private char[] _password;

//    public CTCL_Password16()
//    {
//        _password = new char[16];
//    }
//    public CTCL_Password16(char[] _value)
//    {
//        _password = new char[16];
//        //_password = _value;
//        Array.Copy(_value, 0, _password, 0, _value.Length > _password.Length ? _password.Length : _value.Length);

//    }
//    public char[] password { get => _password; set => _password = value; }
//}

//before uncmmenting do vinay/shubham know
//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_NewPassword // 16 Byte
//{
//    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
//    private char[] _newpassword;

//    public CTCL_NewPassword()
//    {
//        _newpassword = new char[16];
//    }
//    public CTCL_NewPassword(char[] _value)
//    {
//        _newpassword = new char[16];
//        //_newpassword = _value;
//        Array.Copy(_value, 0, _newpassword, 0, _value.Length > _newpassword.Length ? _newpassword.Length : _value.Length);

//    }
//    public char[] newpassword { get => _newpassword; set => _newpassword = value; }
//}




[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Password
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _password;
    public CTCL_Password()
    {
        _password = new char[16];
    }
    public CTCL_Password(char[] _value)
    {
        _password = new char[16];
        Array.Copy(_value, 0, _password, 0, _value.Length > _password.Length ? _password.Length : _value.Length);
    }
    public char[] password { get => _password; set => _password = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NewAuthInfo // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _newAuthInfo;

    public CTCL_NewAuthInfo()
    {
        _newAuthInfo = new char[16];
    }
    public CTCL_NewAuthInfo(char[] _value)
    {
        _newAuthInfo = new char[16];
        //_newpassword = _value;
        Array.Copy(_value, 0, _newAuthInfo, 0, _value.Length > _newAuthInfo.Length ? _newAuthInfo.Length : _value.Length);

    }
    public char[] newAuthInfo { get => _newAuthInfo; set => _newAuthInfo = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UpdateAuthStatusString // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _updateAuthStatus;

    public CTCL_UpdateAuthStatusString()
    {
        _updateAuthStatus = new char[128];
    }
    public CTCL_UpdateAuthStatusString(char[] _value)
    {
        _updateAuthStatus = new char[128];
        Array.Copy(_value, 0, _updateAuthStatus, 0, _value.Length > _updateAuthStatus.Length ? _updateAuthStatus.Length : _value.Length);

    }
    public char[] updateAuthStatus { get => _updateAuthStatus; set => _updateAuthStatus = value; }
}

//Login response
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LoginStatusString // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _loginstatus;

    public CTCL_LoginStatusString()
    {
        _loginstatus = new char[128];
    }
    public CTCL_LoginStatusString(char[] _value)
    {
        _loginstatus = new char[128];
        //_loginstatus = _value;
        Array.Copy(_value, 0, _loginstatus, 0, _value.Length > _loginstatus.Length ? _loginstatus.Length : _value.Length);

    }
    public char[] loginStatus { get => _loginstatus; set => _loginstatus = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EntityId
{
    private long _id;
    public CTCL_EntityId(long _value)
    {
        _id = _value;
    }
    public long entityId { get => _id; set => _id = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Parent
{
    private long _id;
    public CTCL_Parent(long _value)
    {
        _id = _value;
    }
    public long Id { get => _id; set => _id = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Child
{
    private long _id;
    public CTCL_Child(long _value)
    {
        _id = _value;
    }
    public long Id { get => _id; set => _id = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EntityName // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _entityname;

    public CTCL_EntityName()
    {
        _entityname = new char[128];
    }
    public CTCL_EntityName(char[] _value)
    {
        _entityname = new char[128];
        //_entityname = _value;
        Array.Copy(_value, 0, _entityname, 0, _value.Length > _entityname.Length ? _entityname.Length : _value.Length);

    }
    public char[] Entityname { get => _entityname; set => _entityname = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_APName // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _apName;

    public CTCL_APName()
    {
        _apName = new char[128];
    }
    public CTCL_APName(char[] _value)
    {
        _apName = new char[128];
        //_apName = _value;
        Array.Copy(_value, 0, _apName, 0, _value.Length > _apName.Length ? _apName.Length : _value.Length);

    }
    public char[] ApName { get => _apName; set => _apName = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FamilyName // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _familyName;

    public CTCL_FamilyName()
    {
        _familyName = new char[128];
    }
    public CTCL_FamilyName(char[] _value)
    {
        _familyName = new char[128];
        //_familyName = _value;
        Array.Copy(_value, 0, _familyName, 0, _value.Length > _familyName.Length ? _familyName.Length : _value.Length);

    }
    public char[] Familyname { get => _familyName; set => _familyName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LogoutStatusString // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _logoutStatusString;

    public CTCL_LogoutStatusString()
    {
        _logoutStatusString = new char[128];
    }
    public CTCL_LogoutStatusString(char[] _value)
    {
        _logoutStatusString = new char[128];
        //_familyName = _value;
        Array.Copy(_value, 0, _logoutStatusString, 0, _value.Length > _logoutStatusString.Length ? _logoutStatusString.Length : _value.Length);

    }
    public char[] LogoutStatusString { get => _logoutStatusString; set => _logoutStatusString = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_VersionInfo16 // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _versionInfo;

    public CTCL_VersionInfo16()
    {
        _versionInfo = new char[16];
    }
    public CTCL_VersionInfo16(char[] _value)
    {
        _versionInfo = new char[16];
        //_versionInfo = _value;
        Array.Copy(_value, 0, _versionInfo, 0, _value.Length > _versionInfo.Length ? _versionInfo.Length : _value.Length);

    }
    public char[] Versioninfo { get => _versionInfo; set => _versionInfo = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_HandshakeInfo // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private byte[] _info;

    public CTCL_HandshakeInfo()
    {
        _info = new byte[128];
    }
    public CTCL_HandshakeInfo(byte[] _value)
    {
        _info = new byte[128];
        //_versionInfo = _value;
        Array.Copy(_value, 0, _info, 0, _value.Length > _info.Length ? _info.Length : _value.Length);

    }
    public byte[] HandshakeInfo { get => _info; set => _info = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LoginStatusCode
{
    [MarshalAs(UnmanagedType.I2)]
    private short _loginstatusCode;

    public CTCL_LoginStatusCode(short _value)
    {
        _loginstatusCode = _value;
    }
    public short LoginstatusCode { get => _loginstatusCode; set => _loginstatusCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EntityCategory
{
    [MarshalAs(UnmanagedType.I2)]
    private short _entitycategory;

    public CTCL_EntityCategory(short _value)
    {
        _entitycategory = _value;
    }
    public short Entitycategory { get => _entitycategory; set => _entitycategory = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_PURPOSE_flag
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _flag;
    public CTCL_ST_PURPOSE_flag(bool _value)
    {
        _flag = _value;
    }
    public bool Flag { get => _flag; set => _flag = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RequestContext
{
    [MarshalAs(UnmanagedType.I8)]
    private long _requestContext;
    public CTCL_RequestContext(long _value)
    {
        _requestContext = _value;
    }
    public long RequestContext { get => _requestContext; set => _requestContext = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BufferSize
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _BufferSize;
    public Int32 BufferSize { get => _BufferSize; set => _BufferSize = value; }
}


#region LDB related fields



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ContextIdentifier
{
    private long _ContextIdentifier;
    public long contextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TotalNoOfRecords
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _totalNoOfRecords;
    public Int32 totalNoofRecords { get => _totalNoOfRecords; set => _totalNoOfRecords = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NoOfRecordsofSubData
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _NoOfRecordsofSubData;
    public Int32 NoOfRecordsofSubData { get => _NoOfRecordsofSubData; set => _NoOfRecordsofSubData = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TotalNoOfRecordsofSubData
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _TotalNoOfRecordsofSubData;
    public Int32 TotalNoOfRecordsofSubData { get => _TotalNoOfRecordsofSubData; set => _TotalNoOfRecordsofSubData = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LDBData
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2048)]
    private byte[] __ldbData;
    public CTCL_LDBData(byte[] _value)
    {
        __ldbData = new byte[2048];
        Array.Copy(_value, 0, __ldbData, 0, _value.Length > __ldbData.Length ? __ldbData.Length : _value.Length);
    }
    public CTCL_LDBData()
    {
        __ldbData = new byte[2048];
    }
    public byte[] LDBData { get => __ldbData; set => __ldbData = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LDBInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_LDBInformationIdentifiers _LDBInformationIdentifier;
    public CTCL_LDBInformationIdentifiers LDBInformationIdentifier { get => _LDBInformationIdentifier; set => _LDBInformationIdentifier = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AdminInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_AdminInformationIdentifiersEnum _adminInformationIdentifiersEnum;
    public CTCL_AdminInformationIdentifiersEnum AdminInformationIdentifiersEnum { get => _adminInformationIdentifiersEnum; set => _adminInformationIdentifiersEnum = value; }
}
#endregion

#region EnterpriseMasterUpdate

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EMContext
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1048)]
    private byte[] _EMcontext;
    public byte[] EMContext { get => _EMcontext; set => _EMcontext = value; }
    public CTCL_EMContext()
    {
        _EMcontext = new byte[1048];
    }
    public CTCL_EMContext(byte[] _value)
    {
        _EMcontext = new byte[1048];
        Array.Copy(_value, 0, _EMcontext, 0, _value.Length > _EMcontext.Length ? _EMcontext.Length : _value.Length);
    }
}
#endregion

#region Passwordpolicyfields

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PasswordMinlength
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _passMinLength;
    public CTCL_PasswordMinlength(Int32 _value)
    {
        _passMinLength = _value;
    }
    public Int32 MinLength { get => _passMinLength; set => _passMinLength = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PasswordMaxlength
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _passMaxLength;
    public CTCL_PasswordMaxlength(Int32 _value)
    {
        _passMaxLength = _value;
    }
    public Int32 MaxLength { get => _passMaxLength; set => _passMaxLength = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PasswordExpiry
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _PasswordExpiry;
    public CTCL_PasswordExpiry(Int32 _value)
    {
        _PasswordExpiry = _value;
    }
    public Int32 PasswordExpiry { get => _PasswordExpiry; set => _PasswordExpiry = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MinPasswordAge
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _MinPasswordAge;
    public CTCL_MinPasswordAge(Int32 _value)
    {
        _MinPasswordAge = _value;
    }
    public Int32 MinPasswordAge { get => _MinPasswordAge; set => _MinPasswordAge = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DisallowPastPassword
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _DisallowPastPassword;
    public CTCL_DisallowPastPassword(Int32 _value)
    {
        _DisallowPastPassword = _value;
    }
    public Int32 DisallowPastPassword { get => _DisallowPastPassword; set => _DisallowPastPassword = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WarnAfter
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _WarnAfter;
    public CTCL_WarnAfter(Int32 _value)
    {
        _WarnAfter = _value;
    }
    public Int32 WarnAfter { get => _WarnAfter; set => _WarnAfter = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NonNumericCharAllowed // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _NonNumericCharAllowed;
    public CTCL_NonNumericCharAllowed()
    {
        _NonNumericCharAllowed = new char[16];
    }
    public CTCL_NonNumericCharAllowed(char[] _value)
    {
        _NonNumericCharAllowed = new char[16];
        Array.Copy(_value, 0, _NonNumericCharAllowed, 0, _value.Length > _NonNumericCharAllowed.Length ? _NonNumericCharAllowed.Length : _value.Length);
    }
    public char[] NonNumericCharAllowed { get => _NonNumericCharAllowed; set => _NonNumericCharAllowed = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ST_BCAST_DESTINATION2Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private byte[] _ST_BCAST_DESTINATION;
    public byte[] ST_BCAST_DESTINATION { get => _ST_BCAST_DESTINATION; set => _ST_BCAST_DESTINATION = value; }
    public CTCL_ST_BCAST_DESTINATION2Byte()
    {
        _ST_BCAST_DESTINATION = new byte[2];
    }
    public CTCL_ST_BCAST_DESTINATION2Byte(byte[] _value)
    {
        _ST_BCAST_DESTINATION = new byte[2];
        Array.Copy(_value, 0, _ST_BCAST_DESTINATION, 0, _value.Length > _ST_BCAST_DESTINATION.Length ? _ST_BCAST_DESTINATION.Length : _ST_BCAST_DESTINATION.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OTP
{
    [MarshalAs(UnmanagedType.I8)]
    private long _otp;
    public CTCL_OTP(long _value)
    {
        _otp = _value;
    }
    public long OTP_ForgotPwd { get => _otp; set => _otp = value; }
}

#endregion

#region 2FA Fields

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct Category // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _category;
    public Category()
    {
        _category = new char[16];
    }
    public Category(char[] _value)
    {
        _category = new char[16];
        Array.Copy(_value, 0, _category, 0, _value.Length > _category.Length ? _category.Length : _value.Length);
    }
    public char[] category { get => _category; set => _category = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct TwoFAValidateAganist // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _validateAgainst;
    public TwoFAValidateAganist()
    {
        _validateAgainst = new char[16];
    }
    public TwoFAValidateAganist(char[] _value)
    {
        _validateAgainst = new char[16];
        Array.Copy(_value, 0, _validateAgainst, 0, _value.Length > _validateAgainst.Length ? _validateAgainst.Length : _value.Length);
    }
    public char[] ValidateAgainst { get => _validateAgainst; set => _validateAgainst = value; }
}

#endregion


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_StatusString // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _statusString;

    public CTCL_StatusString()
    {
        _statusString = new char[128];
    }
    public CTCL_StatusString(char[] _value)
    {
        _statusString = new char[128];
        Array.Copy(_value, 0, _statusString, 0, _value.Length > _statusString.Length ? _statusString.Length : _value.Length);

    }
    public char[] StatusString { get => _statusString; set => _statusString = value; }
}


#region "MSG Download related fields"

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MessageInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_MSGInformationIdentifiers _MessageInformationIdentifier;
    public CTCL_MSGInformationIdentifiers MessageInformationIdentifier { get => _MessageInformationIdentifier; set => _MessageInformationIdentifier = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_NoOfRecordsofSubMessages
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _NoOfRecordsofSubMessages;
    public Int32 NoOfRecordsofSubMessages { get => _NoOfRecordsofSubMessages; set => _NoOfRecordsofSubMessages = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TotalNoOfRecordsofSubMessages
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _TotalNoOfRecordsofSubMessages;
    public Int32 TotalNoOfRecordsofSubMessages { get => _TotalNoOfRecordsofSubMessages; set => _TotalNoOfRecordsofSubMessages = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MSGData
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2048)]
    private byte[] _msgData;
    public CTCL_MSGData(byte[] _value)
    {
        _msgData = new byte[2048];
        Array.Copy(_value, 0, _msgData, 0, _value.Length > _msgData.Length ? _msgData.Length : _value.Length);
    }
    public CTCL_MSGData()
    {
        _msgData = new byte[2048];
    }
    public byte[] MSGData { get => _msgData; set => _msgData = value; }
}
#endregion


//Demical locator, TradingCurrencyId, SettlementCurrencyId

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DecimalLocator
{
    [MarshalAs(UnmanagedType.I2)]
    private short _decimalLocator;

    public CTCL_DecimalLocator(short _value)
    {
        _decimalLocator = _value;
    }
    public short DecimalLocator { get => _decimalLocator; set => _decimalLocator = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TradingCurrencyId
{
    [MarshalAs(UnmanagedType.I8)]
    private long _tradingCurrencyId;
    public CTCL_TradingCurrencyId(long _value)
    {
        _tradingCurrencyId = _value;
    }
    public long TradingCurrencyId { get => _tradingCurrencyId; set => _tradingCurrencyId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SettlementCurrencyId
{
    [MarshalAs(UnmanagedType.I8)]
    private long _settlementCurrencyId;
    public CTCL_SettlementCurrencyId(long _value)
    {
        _settlementCurrencyId = _value;
    }
    public long SettlementCurrencyId { get => _settlementCurrencyId; set => _settlementCurrencyId = value; }
}

//Password Access Attempt count
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PasswordAccessAttemptCount
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _PasswordAccessAttemptCount;
    public CTCL_PasswordAccessAttemptCount(Int32 _value)
    {
        _PasswordAccessAttemptCount = _value;
    }
    public Int32 PasswordAccessAttemptCount { get => _PasswordAccessAttemptCount; set => _PasswordAccessAttemptCount = value; }
}

//User IPAddress
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UserIP
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _userIP;
    public char[] UserIP { get => _userIP; set => _userIP = value; }
    public CTCL_UserIP()
    {
        _userIP = new char[25];
    }
    public CTCL_UserIP(char[] _value)
    {
        _userIP = new char[25];
        Array.Copy(_value, 0, _userIP, 0, _value.Length > _userIP.Length ? _userIP.Length : _value.Length);
    }
}

#region FOR ENTERPRISEMASTER DOWNLOAD
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EMInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_EMInformationIdentifierEnum _EMInformationIdentifier;
    public CTCL_EMInformationIdentifierEnum EMInformationIdentifier { get => _EMInformationIdentifier; set => _EMInformationIdentifier = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EMData
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2048)]
    private byte[] _emData;
    public CTCL_EMData(byte[] _value)
    {
        _emData = new byte[2048];
        Array.Copy(_value, 0, _emData, 0, _value.Length > _emData.Length ? _emData.Length : _value.Length);
    }
    public CTCL_EMData()
    {
        _emData = new byte[2048];
    }
    public byte[] EMData { get => _emData; set => _emData = value; }
}


#endregion

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PrimaryOMS
{
    [MarshalAs(UnmanagedType.I2)]
    private short _primary;
    public CTCL_PrimaryOMS(short _value)
    {
        _primary = _value;
    }
    public short primaryoms { get => _primary; set => _primary = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EmObj_Id
{
    [MarshalAs(UnmanagedType.I8)]
    private long _id;
    public CTCL_EmObj_Id(long _value)
    {
        _id = _value;
    }
    public long Id { get => _id; set => _id = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EmObj_DisplayCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
    private char[] _displayCode;

    public char[] displayCode { get => _displayCode; set => _displayCode = value; }

    public CTCL_EmObj_DisplayCode(char[] _value)
    {
        _displayCode = new char[20];
        Array.Copy(_value, 0, _displayCode, 0, _value.Length > _displayCode.Length ? _displayCode.Length : _value.Length);
    }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PercentageDecimal
{
    [MarshalAs(UnmanagedType.R8)]
    private double _percentage;
    public CTCL_PercentageDecimal(double _value)
    {
        _percentage = _value;
    }
    public double Percentage { get => _percentage; set => _percentage = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Id
{
    [MarshalAs(UnmanagedType.I4)]
    private int _id;

    public CTCL_Id(int _value)
    {
        _id = _value;
    }
    public int id { get => _id; set => _id = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_Remark
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _remark;
    public CTCL_RMS_Remark(char[] _value)
    {
        _remark = new char[128];
        Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

    }
    public CTCL_RMS_Remark()
    {
        _remark = new char[128];
    }
    public char[] Remark { get => _remark; set => _remark = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Connectio_Log__Remark
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _remark;
    public CTCL_Connectio_Log__Remark(char[] _value)
    {
        _remark = new char[64];
        Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

    }
    public CTCL_Connectio_Log__Remark()
    {
        _remark = new char[64];
    }
    public char[] Remark { get => _remark; set => _remark = value; }
}

#region SFTP
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SFTPMaxFileSize
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _size;
    public CTCL_SFTPMaxFileSize(Int32 _value)
    {
        _size = _value;
    }
    public Int32 Size { get => _size; set => _size = value; }
}

#endregion


#region RMS LIMIT MASTER

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_TemplateName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
    private char[] _templateName;

    public CTCL_RMS_TemplateName()
    {
        _templateName = new char[15];
    }
    public CTCL_RMS_TemplateName(char[] _value)
    {
        _templateName = new char[15];
        Array.Copy(_value, 0, _templateName, 0, _value.Length > _templateName.Length ? _templateName.Length : _value.Length);

    }
    public char[] TemplateName { get => _templateName; set => _templateName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_GrossExposure
{
    [MarshalAs(UnmanagedType.R8)]
    private double _grossExposure;
    public CTCL_RMS_GrossExposure(double _value)
    {
        _grossExposure = _value;
    }
    public double GrossExposure { get => _grossExposure; set => _grossExposure = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_NetPurchase
{
    [MarshalAs(UnmanagedType.R8)]
    private double _netPurchase;
    public CTCL_RMS_NetPurchase(double _value)
    {
        _netPurchase = _value;
    }
    public double NetPurchase { get => _netPurchase; set => _netPurchase = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_NetSale
{
    [MarshalAs(UnmanagedType.R8)]
    private double _netSale;
    public CTCL_RMS_NetSale(double _value)
    {
        _netSale = _value;
    }
    public double NetSale { get => _netSale; set => _netSale = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_NetPremium
{
    [MarshalAs(UnmanagedType.R8)]
    private double _netPremium;
    public CTCL_RMS_NetPremium(double _value)
    {
        _netPremium = _value;
    }
    public double NetPremium { get => _netPremium; set => _netPremium = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_NetWrite
{
    [MarshalAs(UnmanagedType.R8)]
    private double _netWrite;
    public CTCL_RMS_NetWrite(double _value)
    {
        _netWrite = _value;
    }
    public double NetWrite { get => _netWrite; set => _netWrite = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_Turnover
{
    [MarshalAs(UnmanagedType.R8)]
    private double _netTurnover;
    public CTCL_RMS_Turnover(double _value)
    {
        _netTurnover = _value;
    }
    public double NetTurnover { get => _netTurnover; set => _netTurnover = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_MTM
{
    [MarshalAs(UnmanagedType.R8)]
    private double _mTM;
    public CTCL_RMS_MTM(double _value)
    {
        _mTM = _value;
    }
    public double MTM { get => _mTM; set => _mTM = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMS_Margin
{
    [MarshalAs(UnmanagedType.R8)]
    private double _margin;
    public CTCL_RMS_Margin(double _value)
    {
        _margin = _value;
    }
    public double Margin { get => _margin; set => _margin = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMSRequestContext
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
    private byte[] _rmscontext;
    public byte[] RMSRequestContext { get => _rmscontext; set => _rmscontext = value; }
    public CTCL_RMSRequestContext()
    {
        _rmscontext = new byte[1024];
    }
    public CTCL_RMSRequestContext(byte[] _value)
    {
        _rmscontext = new byte[1024];
        Array.Copy(_value, 0, _rmscontext, 0, _value.Length > _rmscontext.Length ? _rmscontext.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMSTemplateStatus
{
    private long _status;
    public CTCL_RMSTemplateStatus(long _value)
    {
        _status = _value;
    }

    public long status { get => _status; set => _status = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMSTemplateId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _id;
    public CTCL_RMSTemplateId(Int32 _value)
    {
        _id = _value;
    }
    public Int32 Id { get => _id; set => _id = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMSLimitMasterInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_RMSInformationIdentifiers _rmsLimitMasterInformationIdentifier;
    public CTCL_RMSInformationIdentifiers RMSLimitMasterInformationIdentifier { get => _rmsLimitMasterInformationIdentifier; set => _rmsLimitMasterInformationIdentifier = value; }
}

#endregion

#region Currency

//[StructLayout(LayoutKind.Sequential, Pack = 1)]
//public struct CTCL_CurrencyId
//{
//	[MarshalAs(UnmanagedType.I4)]
//	private Int32 _currencyId;
//	public CTCL_CurrencyId(Int32 _value)
//	{
//		_currencyId = _value;
//	}
//	public Int32 CurrencyId { get => _currencyId; set => _currencyId = value; }
//}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencyName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
    private char[] _currencyName;
    public char[] CurrencyName { get => _currencyName; set => _currencyName = value; }
    public CTCL_CurrencyName()
    {
        _currencyName = new char[100];
    }
    public CTCL_CurrencyName(char[] _value)
    {
        _currencyName = new char[100];
        Array.Copy(_value, 0, _currencyName, 0, _value.Length > _currencyName.Length ? _currencyName.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencyCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _currencyCode;
    public char[] CurrencyCode { get => _currencyCode; set => _currencyCode = value; }
    public CTCL_CurrencyCode()
    {
        _currencyCode = new char[3];
    }
    public CTCL_CurrencyCode(char[] _value)
    {
        _currencyCode = new char[3];
        Array.Copy(_value, 0, _currencyCode, 0, _value.Length > _currencyCode.Length ? _currencyCode.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencySymbol
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _currencySymbol;
    public char[] CurrencySymbol { get => _currencySymbol; set => _currencySymbol = value; }
    public CTCL_CurrencySymbol()
    {
        _currencySymbol = new char[5];
    }
    public CTCL_CurrencySymbol(char[] _value)
    {
        _currencySymbol = new char[5];
        Array.Copy(_value, 0, _currencySymbol, 0, _value.Length > _currencySymbol.Length ? _currencySymbol.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencyDepositAllowed
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _currencyDepositAllowed;
    public CTCL_CurrencyDepositAllowed(bool _value)
    {
        _currencyDepositAllowed = _value;
    }
    public bool CurrencyDepositAllowed { get => _currencyDepositAllowed; set => _currencyDepositAllowed = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencyConversionMappingId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _currencyConversionMappingId;
    public CTCL_CurrencyConversionMappingId(Int32 _value)
    {
        _currencyConversionMappingId = _value;
    }
    public Int32 CurrencyConversionMappingId { get => _currencyConversionMappingId; set => _currencyConversionMappingId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BaseCurrencyId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _baseCurrencyId;
    public CTCL_BaseCurrencyId(Int32 _value)
    {
        _baseCurrencyId = _value;
    }
    public Int32 BaseCurrencyId { get => _baseCurrencyId; set => _baseCurrencyId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ConversionCurrencyId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _conversionCurrencyId;
    public CTCL_ConversionCurrencyId(Int32 _value)
    {
        _conversionCurrencyId = _value;
    }
    public Int32 ConversionCurrencyId { get => _conversionCurrencyId; set => _conversionCurrencyId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CurrencyConversionValue
{
    [MarshalAs(UnmanagedType.R8)]
    private double _currencyConversionValue;
    public CTCL_CurrencyConversionValue(double _value)
    {
        _currencyConversionValue = _value;
    }
    public double CurrencyConversionValue { get => _currencyConversionValue; set => _currencyConversionValue = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DepositId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _depositId;
    public CTCL_DepositId(Int32 _value)
    {
        _depositId = _value;
    }
    public Int32 DepositId { get => _depositId; set => _depositId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DepositCurrencyId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _depositCurrenyId;
    public CTCL_DepositCurrencyId(Int32 _value)
    {
        _depositCurrenyId = _value;
    }
    public Int32 DepositCurrencyId { get => _depositCurrenyId; set => _depositCurrenyId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DepositAmount
{
    [MarshalAs(UnmanagedType.R8)]
    private double _despositAmount;
    public CTCL_DepositAmount(double _value)
    {
        _despositAmount = _value;
    }
    public double DepositAmount { get => _despositAmount; set => _despositAmount = value; }
}

#endregion

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Number // 20 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
    private char[] _number;
    public char[] number { get => _number; set => _number = value; }
    public CTCL_Number(char[] _value)
    {
        _number = new char[20];
        Array.Copy(_value, 0, _number, 0, _value.Length > _number.Length ? _number.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Designation // 20 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
    private char[] _designation;
    public CTCL_Designation(char[] _value)
    {
        _designation = new char[20];
        Array.Copy(_value, 0, _designation, 0, _value.Length > _designation.Length ? _designation.Length : _value.Length);
    }
    public char[] designation { get => _designation; set => _designation = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ClientId
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _clientId;
    public char[] Id { get => _clientId; set => _clientId = value; }
    public CTCL_ClientId()
    {
        _clientId = new char[16];
    }
    public CTCL_ClientId(char[] _value)
    {
        _clientId = new char[16];
        Array.Copy(_value, 0, _clientId, 0, _value.Length > _clientId.Length ? _clientId.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CompanyName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _name;
    public CTCL_CompanyName()
    {
        _name = new char[128];
    }
    public CTCL_CompanyName(char[] _value)
    {
        _name = new char[128];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public char[] CompanyName { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceStage
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _stage;
    public CTCL_SurveillanceStage()
    {
        _stage = new char[128];
    }
    public CTCL_SurveillanceStage(char[] _value)
    {
        _stage = new char[128];
        Array.Copy(_value, 0, _stage, 0, _value.Length > _stage.Length ? _stage.Length : _value.Length);
    }
    public char[] SurveillanceStage { get => _stage; set => _stage = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_GroupCode // 20 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
    private char[] _groupCode;
    public CTCL_GroupCode(char[] _value)
    {
        _groupCode = new char[20];
        Array.Copy(_value, 0, _groupCode, 0, _value.Length > _groupCode.Length ? _groupCode.Length : _value.Length);
    }
    public char[] GroupCode { get => _groupCode; set => _groupCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved_16_Char
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _reserved;
    public CTCL_Reserved_16_Char(char[] _value)
    {
        _reserved = new char[16];
        Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);

    }
    public CTCL_Reserved_16_Char()
    {
        _reserved = new char[16];

    }
    public char[] Reserved { get => _reserved; set => _reserved = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EncryptedPassword
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 2048)]
    public string encryptedPassword;
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BrokerTraderSpecificAttribute
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _specificAttribute;
    public CTCL_BrokerTraderSpecificAttribute(char[] _value)
    {
        _specificAttribute = new char[16];
        Array.Copy(_value, 0, _specificAttribute, 0, _value.Length > _specificAttribute.Length ? _specificAttribute.Length : _value.Length);
    }
    public CTCL_BrokerTraderSpecificAttribute()
    {
        _specificAttribute = new char[16];
    }
    public char[] BrokerTraderSpecificAttribute { get => _specificAttribute; set => _specificAttribute = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Quantity_Double
{
    [MarshalAs(UnmanagedType.R8)] //I4 to I8
    private double _quantity;
    public CTCL_Quantity_Double(double _value)
    {
        _quantity = _value;
    }
    public double Quantity { get => _quantity; set => _quantity = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DoublePrice
{
    [MarshalAs(UnmanagedType.R8)]
    private double _price;
    public CTCL_DoublePrice(double _value)
    {
        _price = _value;
    }
    public double Price { get => _price; set => _price = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_QVLInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_QVLInformationIdentifierEnum _QVLInformationIdentifier;
    public CTCL_QVLInformationIdentifierEnum QVLInformationIdentifier { get => _QVLInformationIdentifier; set => _QVLInformationIdentifier = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_QVLResponseBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
    private byte[] _qvlResponse;
    public byte[] QVLResponse { get => _qvlResponse; set => _qvlResponse = value; }
    public CTCL_QVLResponseBuffer()
    {
        _qvlResponse = new byte[24];
    }
    public CTCL_QVLResponseBuffer(byte[] _value)
    {
        _qvlResponse = new byte[24];
        Array.Copy(_value, 0, _qvlResponse, 0, _value.Length > _qvlResponse.Length ? _qvlResponse.Length : _value.Length);
    }
}

#region CRP

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CRP_AttributeName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _name;

    public CTCL_CRP_AttributeName()
    {
        _name = new char[50];
    }
    public CTCL_CRP_AttributeName(char[] _value)
    {
        _name = new char[50];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public char[] Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CRP_AttributeDatatype
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _datatype;

    public CTCL_CRP_AttributeDatatype()
    {
        _datatype = new char[50];
    }
    public CTCL_CRP_AttributeDatatype(char[] _value)
    {
        _datatype = new char[50];
        Array.Copy(_value, 0, _datatype, 0, _value.Length > _datatype.Length ? _datatype.Length : _value.Length);
    }
    public char[] Datatype { get => _datatype; set => _datatype = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AttributeLength
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _length;
    public CTCL_AttributeLength(Int32 _value)
    {
        _length = _value;
    }
    public Int32 Length { get => _length; set => _length = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Filler10
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _filler;
    public CTCL_Filler10(char[] _value)
    {
        _filler = new char[10];
        Array.Copy(_value, 0, _filler, 0, _value.Length > _filler.Length ? _filler.Length : _value.Length);

    }
    public CTCL_Filler10()
    {
        _filler = new char[10];

    }
    public char[] Filler1 { get => _filler; set => _filler = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CRPValue
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _crpValue;
    public CTCL_CRPValue(char[] _value)
    {
        _crpValue = new char[50];
        Array.Copy(_value, 0, _crpValue, 0, _value.Length > _crpValue.Length ? _crpValue.Length : _value.Length);
    }
    public CTCL_CRPValue()
    {
        _crpValue = new char[50];
    }
    public char[] CRPValue { get => _crpValue; set => _crpValue = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CRPInformationIdentifier
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_CRPIdentifierEnum _CRPInformationIdentifier;
    public CTCL_CRPIdentifierEnum CRPInformationIdentifier { get => _CRPInformationIdentifier; set => _CRPInformationIdentifier = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CRPResponseBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
    private byte[] _crpResponse;
    public byte[] CRPResponse { get => _crpResponse; set => _crpResponse = value; }
    public CTCL_CRPResponseBuffer()
    {
        _crpResponse = new byte[24];
    }
    public CTCL_CRPResponseBuffer(byte[] _value)
    {
        _crpResponse = new byte[24];
        Array.Copy(_value, 0, _crpResponse, 0, _value.Length > _crpResponse.Length ? _crpResponse.Length : _value.Length);
    }
}

#endregion

#region Bhavcopy CM

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MKT
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _mkt;
    public CTCL_MKT(char[] _value)
    {
        _mkt = new char[1];
        Array.Copy(_value, 0, _mkt, 0, _value.Length > _mkt.Length ? _mkt.Length : _value.Length);
    }
    public CTCL_MKT()
    {
        _mkt = new char[1];

    }
    public char[] Mkt { get => _mkt; set => _mkt = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CorpAction
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
    private char[] _corpAction;
    public CTCL_CorpAction(char[] _value)
    {
        _corpAction = new char[8];
        Array.Copy(_value, 0, _corpAction, 0, _value.Length > _corpAction.Length ? _corpAction.Length : _value.Length);
    }
    public CTCL_CorpAction()
    {
        _corpAction = new char[8];

    }
    public char[] CorpAction { get => _corpAction; set => _corpAction = value; }
}

#endregion


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RMSStatusString // 256 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
    private char[] _statusString;

    public CTCL_RMSStatusString()
    {
        _statusString = new char[256];
    }
    public CTCL_RMSStatusString(char[] _value)
    {
        _statusString = new char[256];
        Array.Copy(_value, 0, _statusString, 0, _value.Length > _statusString.Length ? _statusString.Length : _value.Length);

    }
    public char[] StatusString { get => _statusString; set => _statusString = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MessageValueString // 256 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _statusString;

    public CTCL_MessageValueString()
    {
        _statusString = new char[64];
    }
    public CTCL_MessageValueString(char[] _value)
    {
        _statusString = new char[64];
        Array.Copy(_value, 0, _statusString, 0, _value.Length > _statusString.Length ? _statusString.Length : _value.Length);

    }
    public char[] StatusString { get => _statusString; set => _statusString = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentGroup
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _instrumentGroup;
    public CTCL_InstrumentGroup(Int32 _value)
    {
        _instrumentGroup = _value;
    }
    public Int32 InstrumentGroup { get => _instrumentGroup; set => _instrumentGroup = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SegmentSpecificAttribute
{
    [MarshalAs(UnmanagedType.I4)]    //from i4 to i8 as in doc it is 8 byte
    private Int32 _segmentSpecificAttribute;
    public CTCL_SegmentSpecificAttribute(Int32 _value)
    {
        _segmentSpecificAttribute = _value;
    }
    public Int32 segmentSpecificAttribute { get => _segmentSpecificAttribute; set => _segmentSpecificAttribute = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRParticipantId // 32 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
    private string _participantId;

    public CTCL_STRParticipantId(char[] _value)
    {
        char[] temparry = new char[32];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _participantId = new string(temparry).Replace("\0", "");
    }
    public string ParticipantId { get => _participantId; set => _participantId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_EncrKey
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _key;
    public CTCL_EncrKey(char[] _value)
    {
        _key = new char[64];
        Array.Copy(_value, 0, _key, 0, _value.Length > _key.Length ? _key.Length : _value.Length);

    }
    public CTCL_EncrKey()
    {
        _key = new char[64];
    }
    public char[] Key { get => _key; set => _key = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRVersionNumber // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
    private string _version;
    public CTCL_STRVersionNumber(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _version = new string(temparry).Replace("\0", "");
    }
    public string VersionNumber { get => _version; set => _version = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SqaureOffIndicator
{
    [MarshalAs(UnmanagedType.I4)]
    private int _indicator;
    public CTCL_SqaureOffIndicator(short _value)
    {
        _indicator = _value;
    }
    public int Indicator { get => _indicator; set => _indicator = value; }

    public bool IsTimerSqOff(CTCL_ExchangeSegmentId segmentId)
    {
        return (_indicator & segmentId.SegmentId) == segmentId.SegmentId ? true : false;
    }

    public void Assign(CTCL_ExchangeSegmentId segmentId)
    {
        _indicator |= segmentId.SegmentId;
    }

    public void DeAssgin(CTCL_ExchangeSegmentId segmentId)
    {
        int inv = ~segmentId.SegmentId;
        _indicator &= inv;
    }
}

public struct CTCL_ELIGIBLITY_PERMARKET_4Bytes
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private byte[] _eligibilityPerMarket;
    public CTCL_ELIGIBLITY_PERMARKET_4Bytes(byte[] _value)
    {
        _eligibilityPerMarket = new byte[4];
        _eligibilityPerMarket = _value;

    }
    public CTCL_ELIGIBLITY_PERMARKET_4Bytes()
    {
        _eligibilityPerMarket = new byte[4];

    }
    public byte[] EligibilityPerMarket { get => _eligibilityPerMarket; set => _eligibilityPerMarket = value; }
}
public struct CTCL_PURPOSE
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private byte[] _purpose;
    public CTCL_PURPOSE(byte[] _value)
    {
        _purpose = new byte[2];
        _purpose = _value;

    }
    public CTCL_PURPOSE()
    {
        _purpose = new byte[2];

    }
    public byte[] Purpose { get => _purpose; set => _purpose = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_mktMakerSpread
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _makerSpread;

    public CTCL_mktMakerSpread(Int32 _value)
    {
        _makerSpread = _value;
    }
    public Int32 MktMakerSpread { get => _makerSpread; set => _makerSpread = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FaceValue
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _faceValue;

    public CTCL_FaceValue(Int32 _value)
    {
        _faceValue = _value;
    }
    public Int32 FaceValue { get => _faceValue; set => _faceValue = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRISINNumber // 16 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
    private string _isinNumber;
    public CTCL_STRISINNumber(char[] _value)
    {
        char[] isinNumber = new char[16];
        Array.Copy(_value, 0, isinNumber, 0, _value.Length > isinNumber.Length ? isinNumber.Length : _value.Length);
        _isinNumber = new string(isinNumber).Replace("\0", "");
    }
    public string IsinNumber { get => _isinNumber; set => _isinNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRRMSTemplateName // 15 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
    private string _templateName;
    public CTCL_STRRMSTemplateName(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _templateName = new string(temparry).Replace("\0", "");

    }
    public string TemplateName { get => _templateName; set => _templateName = value; }
}

#region FIN RMS

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Approved
{
    [MarshalAs(UnmanagedType.Bool)]
    private bool _approve;
    public CTCL_Approved(bool _value)
    {
        _approve = _value;
    }
    public bool Approve { get => _approve; set => _approve = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PartyName // 50 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 50)]
    private string _name;


    public CTCL_PartyName(char[] _value)
    {
        char[] temparry = new char[50];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _name = new string(temparry).Replace("\0", "");
    }
    public string Name { get => _name; set => _name = value; }
}

#endregion

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AttemptCount
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _attemptCount;
    public CTCL_AttemptCount(Int32 _value)
    {
        _attemptCount = _value;
    }
    public Int32 AttemptCount { get => _attemptCount; set => _attemptCount = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SubscribeName // 50 Byte
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 50)]
    private string _name;

    public CTCL_SubscribeName(char[] _value)
    {
        char[] temparry = new char[50];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _name = new string(temparry).Replace("\0", "");
    }
    public string Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SymbolName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _symbol;
    public CTCL_SymbolName(char[] _value)
    {
        _symbol = new char[50];
        Array.Copy(_value, 0, _symbol, 0, _value.Length > _symbol.Length ? _symbol.Length : _value.Length);

    }
    public CTCL_SymbolName()
    {
        _symbol = new char[50];
    }
    public char[] Symbol { get => _symbol; set => _symbol = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_StrISINNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private string _isinNumber;
    public CTCL_StrISINNumber(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _isinNumber = new string(temparry).Replace("\0", "");

    }
    public string ISINNumber { get => _isinNumber; set => _isinNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRInstrumentName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private string _instrumentName;
    public CTCL_STRInstrumentName(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _instrumentName = new string(temparry).Replace("\0", "");

    }
    public string InstrumentName { get => _instrumentName; set => _instrumentName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STROptionType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private string _optionType;
    public CTCL_STROptionType(char[] _value)
    {
        char[] temparry = new char[2];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _optionType = new string(temparry).Replace("\0", "");
    }
    public string OptionType { get => _optionType; set => _optionType = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRIndexName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private string _indexName;
    public string IndexName { get => _indexName; set => _indexName = value; }
    public CTCL_STRIndexName(char[] _value)
    {
        char[] temparry = new char[32];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _indexName = new string(temparry).Replace("\0", "");
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IssuedCapital_Double
{
    [MarshalAs(UnmanagedType.R8)]
    private double _issuedCapital;
    public CTCL_IssuedCapital_Double(double _value)
    {
        _issuedCapital = _value;
    }
    public double IssuedCapital { get => _issuedCapital; set => _issuedCapital = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WatchlistId
{
    [MarshalAs(UnmanagedType.I8)]
    private long _watchlistId;
    public CTCL_WatchlistId(long _value)
    {
        _watchlistId = _value;
    }
    public long WatchlistId { get => _watchlistId; set => _watchlistId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_StrWatchListName
{
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 30)]
    private string _watchListName;
    public CTCL_StrWatchListName(char[] _value)
    {
        char[] watchlist = new char[30];
        Array.Copy(_value, 0, watchlist, 0, _value.Length > watchlist.Length ? watchlist.Length : _value.Length);
        _watchListName = new string(watchlist).Replace("\0", "");
    }
    public string WatchListName { get => _watchListName; set => _watchListName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_WatchListName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
    private char[] _watchListName;
    public CTCL_WatchListName(char[] _value)
    {
        _watchListName = new char[30];
        Array.Copy(_value, 0, _watchListName, 0, _value.Length > _watchListName.Length ? _watchListName.Length : _value.Length);

    }
    public CTCL_WatchListName()
    {
        _watchListName = new char[30];
    }
    public char[] WatchListName { get => _watchListName; set => _watchListName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ComponentInstanceIdentifier
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _componentInstanceId;
    public CTCL_ComponentInstanceIdentifier(Int32 _value)
    {
        _componentInstanceId = _value;
    }
    public Int32 ComponentInstanceId { get => _componentInstanceId; set => _componentInstanceId = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BSMarketType
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_MarketType _MarketType;
    public CTCL_MarketType MarketType { get => _MarketType; set => _MarketType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BSMarketStatus
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_Market_Status _MarketStatus;
    public CTCL_Market_Status MarketStatus { get => _MarketStatus; set => _MarketStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRSymbol
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private string _symbol;
    public CTCL_STRSymbol(char[] _value)
    {
        char[] temparry = new char[16];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _symbol = new string(temparry).Replace("\0", "");

    }
    public string Symbol { get => _symbol; set => _symbol = value; }
}

#region IBT
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PercentageOfShares
{
    [MarshalAs(UnmanagedType.I4)]
    private int _percentageOfShares;

    public CTCL_PercentageOfShares(int _value)
    {
        _percentageOfShares = _value;
    }
    public int PercentageOfShares { get => _percentageOfShares; set => _percentageOfShares = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Age
{
    [MarshalAs(UnmanagedType.I4)]
    private int _age;

    public CTCL_Age(int _value)
    {
        _age = _value;
    }
    public int Age { get => _age; set => _age = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IFSCCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _ifscCode;
    public CTCL_IFSCCode(char[] _value)
    {
        _ifscCode = new char[16];
        Array.Copy(_value, 0, _ifscCode, 0, _value.Length > _ifscCode.Length ? _ifscCode.Length : _value.Length);
    }
    public CTCL_IFSCCode()
    {
        _ifscCode = new char[16];

    }
    public char[] IFSCCode { get => _ifscCode; set => _ifscCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MICR
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _micr;
    public CTCL_MICR(char[] _value)
    {
        _micr = new char[16];
        Array.Copy(_value, 0, _micr, 0, _value.Length > _micr.Length ? _micr.Length : _value.Length);
    }
    public CTCL_MICR()
    {
        _micr = new char[16];

    }
    public char[] MICR { get => _micr; set => _micr = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PepInformation
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _pep;
    public CTCL_PepInformation(char[] _value)
    {
        _pep = new char[50];
        Array.Copy(_value, 0, _pep, 0, _value.Length > _pep.Length ? _pep.Length : _value.Length);
    }
    public CTCL_PepInformation()
    {
        _pep = new char[50];

    }
    public char[] PepInfo { get => _pep; set => _pep = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Value
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _val;
    public CTCL_Value(char[] _value)
    {
        this._val = new char[50];
        Array.Copy(_value, 0, this._val, 0, _value.Length > this._val.Length ? this._val.Length : _value.Length);
    }
    public CTCL_Value()
    {
        _val = new char[50];

    }
    public char[] Value { get => _val; set => _val = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_StrValue
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private string _val;
    public CTCL_StrValue(char[] _value)
    {
        char[] temparry = new char[50];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        this._val = new string(temparry).Replace("\0", "");
    }
    public string Value { get => _val; set => _val = value; }
}
#endregion


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AllowedExchangeSegment
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _val;
    public CTCL_AllowedExchangeSegment(Int32 _value)
    {
        _val = _value;
    }
    public Int32 Value { get => _val; set => _val = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DisclaimerId
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _disclaimerId;
    public CTCL_DisclaimerId(Int32 _value)
    {
        _disclaimerId = _value;
    }
    public Int32 DisclaimerId { get => _disclaimerId; set => _disclaimerId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DisclaimerTitle
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _disclaimerTitle;
    public CTCL_DisclaimerTitle(char[] _value)
    {
        _disclaimerTitle = new char[128];
        Array.Copy(_value, 0, _disclaimerTitle, 0, _value.Length > _disclaimerTitle.Length ? _disclaimerTitle.Length : _value.Length);
    }
    public CTCL_DisclaimerTitle()
    {
        _disclaimerTitle = new char[128];

    }
    public char[] CorpAction { get => _disclaimerTitle; set => _disclaimerTitle = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_StatusCode
{
    [MarshalAs(UnmanagedType.I2)]
    private StatusCode _StatusCode;
    public StatusCode statusCode { get => _StatusCode; set => _StatusCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TwoFAType
{
    [MarshalAs(UnmanagedType.I2)]
    private TwoFAType _TwoFAType;
    public TwoFAType twoFAType { get => _TwoFAType; set => _TwoFAType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_AccessAllowedStruct
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_AccessAllowed _accessAllowed;
    public CTCL_AccessAllowed AccessAllowed { get => _accessAllowed; set => _accessAllowed = value; }
}

public struct CTCL_Severity
{
    private bool _Severity;
    public CTCL_Severity(bool _value)
    {
        _severity = _value;
    }
    public bool _severity { get => _severity; set => _severity = value; }
}
public struct CTCL_Frequency
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _Frequency;

    public CTCL_Frequency(Int32 _value)
    {
        _frequency = _value;
    }
    public Int32 _frequency { get => _frequency; set => _frequency = value; }
}
public struct CTCL_DisclaimerMessage // 256 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2048)]
    private char[] _Message;

    public CTCL_DisclaimerMessage()
    {
        _message = new char[2048];
    }
    public CTCL_DisclaimerMessage(char[] _value)
    {
        _message = new char[256];
        Array.Copy(_value, 0, _message, 0, _value.Length > _message.Length ? _message.Length : _value.Length);

    }
    public char[] _message { get => _message; set => _message = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_HolidayName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _name;
    public CTCL_HolidayName(char[] _value)
    {
        _name = new char[64];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public CTCL_HolidayName()
    {
        _name = new char[64];
    }
    public char[] Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UdiffCharDate
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _date;
    public char[] UdiffDate { get => _date; set => _date = value; }
    public CTCL_UdiffCharDate(char[] _value)
    {
        _date = new char[10];
        Array.Copy(_value, 0, _date, 0, _value.Length > _date.Length ? _date.Length : _value.Length);
    }
    public CTCL_UdiffCharDate()
    {
        _date = new char[10];
    }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UdiffSeries
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _series;
    public CTCL_UdiffSeries(char[] _value)
    {
        _series = new char[4];
        Array.Copy(_value, 0, _series, 0, _value.Length > _series.Length ? _series.Length : _value.Length);

    }
    public CTCL_UdiffSeries()
    {
        _series = new char[4];
    }

    public char[] Series { get => _series; set => _series = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UdiffPrice
{
    [MarshalAs(UnmanagedType.R8)]  //I4 to I8
    private double _price;
    public CTCL_UdiffPrice(long _value)
    {
        _price = _value;
    }
    public double Price { get => _price; set => _price = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UdiffInstrumentName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _instrumentName;
    public CTCL_UdiffInstrumentName(char[] _value)
    {
        _instrumentName = new char[50];
        Array.Copy(_value, 0, _instrumentName, 0, _value.Length > _instrumentName.Length ? _instrumentName.Length : _value.Length);

    }
    public CTCL_UdiffInstrumentName()
    {
        _instrumentName = new char[16];

    }
    public char[] InstrumentName { get => _instrumentName; set => _instrumentName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ChangeInOpenInterest
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _openInterestChange;
    public Int64 OpenInterestChange { get => _openInterestChange; set => _openInterestChange = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_OpenInterestLong
{
    [MarshalAs(UnmanagedType.I8)]
    private Int64 _openInterest;
    public Int64 OpenInterest { get => _openInterest; set => _openInterest = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SessionID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _sessionid;
    public CTCL_SessionID(char[] _value)
    {
        _sessionid = new char[2];
        Array.Copy(_value, 0, _sessionid, 0, _value.Length > _sessionid.Length ? _sessionid.Length : _value.Length);

    }
    public CTCL_SessionID()
    {
        _sessionid = new char[2];

    }
    public char[] SessionId { get => _sessionid; set => _sessionid = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_LotSize
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _lotSize;
    public Int32 LotSize { get => _lotSize; set => _lotSize = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Remark256
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
    private char[] _remark;
    public CTCL_Remark256(char[] _value)
    {
        _remark = new char[256];
        //_remark = _value;
        Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

    }
    public CTCL_Remark256()
    {
        _remark = new char[256];
    }
    public char[] Remark { get => _remark; set => _remark = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Reserved50
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
    private char[] _reserved;
    public CTCL_Reserved50(char[] _value)
    {
        _reserved = new char[256];
        Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);
    }
    public CTCL_Reserved50()
    {
        _reserved = new char[256];
    }
    public char[] Reserved { get => _reserved; set => _reserved = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRSeries
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private string _series;
    public CTCL_STRSeries(char[] _value)
    {
        char[] temparry = new char[2];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _series = new string(temparry).Replace("\0", "");
    }
    public string Series { get => _series; set => _series = value; }
}


#region Configuration
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ConfigName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _name;

    public CTCL_ConfigName()
    {
        _name = new char[50];
    }
    public CTCL_ConfigName(char[] _value)
    {
        _name = new char[50];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public char[] Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ConfigDataType
{
    [MarshalAs(UnmanagedType.I2)]
    private DataTypes _DataType;
    public DataTypes DataType { get => _DataType; set => _DataType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ConfigValue
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _configValue;

    public CTCL_ConfigValue()
    {
        _configValue = new char[50];
    }
    public CTCL_ConfigValue(char[] _value)
    {
        _configValue = new char[50];
        Array.Copy(_value, 0, _configValue, 0, _value.Length > _configValue.Length ? _configValue.Length : _value.Length);
    }
    public char[] Name { get => _configValue; set => _configValue = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ConfigRange
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _configRange;

    public CTCL_ConfigRange()
    {
        _configRange = new char[50];
    }
    public CTCL_ConfigRange(char[] _value)
    {
        _configRange = new char[50];
        Array.Copy(_value, 0, _configRange, 0, _value.Length > _configRange.Length ? _configRange.Length : _value.Length);
    }
    public char[] Name { get => _configRange; set => _configRange = value; }
}
#endregion


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BatchOrderBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
    private byte[] _buffer;
    public byte[] Buffer { get => _buffer; set => _buffer = value; }
    public CTCL_BatchOrderBuffer()
    {
        _buffer = new byte[1024];
    }
    public CTCL_BatchOrderBuffer(byte[] _value)
    {
        _buffer = new byte[1024];
        Array.Copy(_value, 0, _buffer, 0, _value.Length > _buffer.Length ? _buffer.Length : _value.Length);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_RecordType
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _recordType;
    public CTCL_RecordType(char[] _value)
    {
        _recordType = new char[2];
        Array.Copy(_value, 0, _recordType, 0, _value.Length > _recordType.Length ? _recordType.Length : _value.Length);
    }
    public CTCL_RecordType()
    {
        _recordType = new char[2];

    }
    public char[] RecordType { get => _recordType; set => _recordType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CertificateName // 128 Byte
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _certificateName;

    public CTCL_CertificateName()
    {
        _certificateName = new char[128];
    }
    public CTCL_CertificateName(char[] _value)
    {
        _certificateName = new char[128];
        Array.Copy(_value, 0, _certificateName, 0, _value.Length > _certificateName.Length ? _certificateName.Length : _value.Length);

    }
    public char[] CertificateName { get => _certificateName; set => _certificateName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CertificateNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
    private char[] _key;
    public CTCL_CertificateNumber(char[] _value)
    {
        _key = new char[64];
        Array.Copy(_value, 0, _key, 0, _value.Length > _key.Length ? _key.Length : _value.Length);

    }
    public CTCL_CertificateNumber()
    {
        _key = new char[64];
    }
    public char[] CertificateNumber { get => _key; set => _key = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct MCAPLimitTemplateName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _name;

    public MCAPLimitTemplateName()
    {
        _name = new char[50];
    }
    public MCAPLimitTemplateName(char[] _value)
    {
        _name = new char[50];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public char[] Name { get => _name; set => _name = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct LimitTemplateName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private char[] _name;

    public LimitTemplateName()
    {
        _name = new char[50];
    }
    public LimitTemplateName(char[] _value)
    {
        _name = new char[50];
        Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
    }
    public char[] Name { get => _name; set => _name = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_MCAPLimitResponseBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
    private byte[] _mcapResponse;
    public byte[] MCAPResponse { get => _mcapResponse; set => _mcapResponse = value; }
    public CTCL_MCAPLimitResponseBuffer()
    {
        _mcapResponse = new byte[24];
    }
    public CTCL_MCAPLimitResponseBuffer(byte[] _value)
    {
        _mcapResponse = new byte[24];
        Array.Copy(_value, 0, _mcapResponse, 0, _value.Length > _mcapResponse.Length ? _mcapResponse.Length : _value.Length);
    }
}
public struct CTCL_LimitResponseBuffer
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
    private byte[] _limitResponse;
    public byte[] Response { get => _limitResponse; set => _limitResponse = value; }
    public CTCL_LimitResponseBuffer()
    {
        _limitResponse = new byte[24];
    }
    public CTCL_LimitResponseBuffer(byte[] _value)
    {
        _limitResponse = new byte[24];
        Array.Copy(_value, 0, _limitResponse, 0, _value.Length > _limitResponse.Length ? _limitResponse.Length : _value.Length);
    }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceFiller11
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
    private char[] _Fiiler11;
    public CTCL_SurveillanceFiller11(char[] _value)
    {
        _Fiiler11 = new char[11];
        Array.Copy(_value, 0, _Fiiler11, 0, _value.Length > _Fiiler11.Length ? _Fiiler11.Length : _value.Length);

    }
    public CTCL_SurveillanceFiller11()
    {
        _Fiiler11 = new char[11];

    }
    public char[] Fiiler11 { get => _Fiiler11; set => _Fiiler11 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceIndicatorStage
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _stage;
    public CTCL_SurveillanceIndicatorStage(char[] _value)
    {
        _stage = new char[3];
        Array.Copy(_value, 0, _stage, 0, _value.Length > _stage.Length ? _stage.Length : _value.Length);

    }
    public CTCL_SurveillanceIndicatorStage()
    {
        _stage = new char[3];

    }
    public char[] Stage { get => _stage; set => _stage = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceIndicatorStatus
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _status;
    public CTCL_SurveillanceIndicatorStatus(char[] _value)
    {
        _status = new char[1];
        Array.Copy(_value, 0, _status, 0, _value.Length > _status.Length ? _status.Length : _value.Length);

    }
    public CTCL_SurveillanceIndicatorStatus()
    {
        _status = new char[1];

    }
    public char[] Status { get => _status; set => _status = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceSegmentExculsive
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _exclusive;
    public CTCL_SurveillanceSegmentExculsive(char[] _value)
    {
        _exclusive = new char[1];
        Array.Copy(_value, 0, _exclusive, 0, _value.Length > _exclusive.Length ? _exclusive.Length : _value.Length);

    }
    public CTCL_SurveillanceSegmentExculsive()
    {
        _exclusive = new char[1];

    }
    public char[] Exclusive { get => _exclusive; set => _exclusive = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceFieldName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] _fieldName;
    public CTCL_SurveillanceFieldName()
    {
        _fieldName = new char[32];
    }
    public CTCL_SurveillanceFieldName(char[] _value)
    {
        _fieldName = new char[32];
        Array.Copy(_value, 0, _fieldName, 0, _value.Length > _fieldName.Length ? _fieldName.Length : _value.Length);
    }
    public char[] FieldName { get => _fieldName; set => _fieldName = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceFieldValue
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 11)]
    private char[] _fieldValue;
    public CTCL_SurveillanceFieldValue()
    {
        _fieldValue = new char[11];
    }
    public CTCL_SurveillanceFieldValue(char[] _value)
    {
        _fieldValue = new char[11];
        Array.Copy(_value, 0, _fieldValue, 0, _value.Length > _fieldValue.Length ? _fieldValue.Length : _value.Length);
    }
    public char[] FieldValue { get => _fieldValue; set => _fieldValue = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SurveillanceFieldMessage
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
    private char[] _fieldMessage;
    public CTCL_SurveillanceFieldMessage()
    {
        _fieldMessage = new char[128];
    }
    public CTCL_SurveillanceFieldMessage(char[] _value)
    {
        _fieldMessage = new char[128];
        Array.Copy(_value, 0, _fieldMessage, 0, _value.Length > _fieldMessage.Length ? _fieldMessage.Length : _value.Length);
    }
    public char[] FieldMessage { get => _fieldMessage; set => _fieldMessage = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Numerator
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _numerator;
    public CTCL_Numerator(Int32 _value)
    {
        _numerator = _value;
    }
    public Int32 Numerator { get => _numerator; set => _numerator = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Denominator
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _denominator;
    public CTCL_Denominator(Int32 _value)
    {
        _denominator = _value;
    }
    public Int32 Denominator { get => _denominator; set => _denominator = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRCRPAttributeName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
    private string _name;
    public CTCL_STRCRPAttributeName(char[] _value)
    {
        char[] temparry = new char[50];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _name = new string(temparry).Replace("\0", "");
    }
    public string Name { get => _name; set => _name = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_DecimalPrice
{
    private decimal _price;
    public CTCL_DecimalPrice(decimal _value)
    {
        _price = _value;
    }
    public decimal Price { get => _price; set => _price = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCLEnviornment
{
    [MarshalAs(UnmanagedType.I2)]
    private CTCL_Enviornment _Enviornment;
    public CTCL_Enviornment enviornment { get => _Enviornment; set => _Enviornment = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STROrderContextIdentifier
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private string _contextIdentifier;
    public CTCL_STROrderContextIdentifier(char[] _value)
    {
        char[] temparry = new char[32];
        Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
        _contextIdentifier = new string(temparry).Replace("\0", "");
    }
    public string OrderContextIdentifier { get => _contextIdentifier; set => _contextIdentifier = value; }
}



[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentSeries
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _series;
    public CTCL_InstrumentSeries(char[] _value)
    {
        _series = new char[3];
        Array.Copy(_value, 0, _series, 0, _value.Length > _series.Length ? _series.Length : _value.Length);

    }
    public CTCL_InstrumentSeries()
    {
        _series = new char[3];
    }

    public char[] InstrumentSeries { get => _series; set => _series = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_IndexFlag
{
    private short _FLAG;
    public CTCL_IndexFlag(short _value)
    {
        _FLAG = _value;
    }
    public short FLAG { get => _FLAG; set => _FLAG = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UnderlyingAssetName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] underlyingAssetName;
    public CTCL_UnderlyingAssetName(char[] _value)
    {
        underlyingAssetName = new char[10];
        Array.Copy(_value, 0, underlyingAssetName, 0, _value.Length > underlyingAssetName.Length ? underlyingAssetName.Length : _value.Length);

    }
    public CTCL_UnderlyingAssetName()
    {
        underlyingAssetName = new char[10];

    }
    public char[] UnderlyingAssetName { get => underlyingAssetName; set => underlyingAssetName = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ProductName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] productName;
    public CTCL_ProductName(char[] _value)
    {
        productName = new char[12];
        Array.Copy(_value, 0, productName, 0, _value.Length > productName.Length ? productName.Length : _value.Length);

    }
    public CTCL_ProductName()
    {
        productName = new char[12];

    }
    public char[] ProductName { get => productName; set => productName = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_InstrumentInfo
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] _InstrumentInfo;
    public CTCL_InstrumentInfo(char[] _value)
    {
        _InstrumentInfo = new char[40];
        Array.Copy(_value, 0, _InstrumentInfo, 0, _value.Length > _InstrumentInfo.Length ? _InstrumentInfo.Length : _value.Length);

    }
    public CTCL_InstrumentInfo()
    {
        _InstrumentInfo = new char[40];

    }
    public char[] InstrumentInfo { get => _InstrumentInfo; set => _InstrumentInfo = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Range
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
    private char[] range;
    public CTCL_Range(char[] _value)
    {
        range = new char[32];
        Array.Copy(_value, 0, range, 0, _value.Length > range.Length ? range.Length : _value.Length);
    }
    public CTCL_Range()
    {
        range = new char[32];
    }
    public char[] Range { get => range; set => range = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Trade2TradeIndicator
{
    [MarshalAs(UnmanagedType.I2)]
    private short trade2TradeIndicator;
    public CTCL_Trade2TradeIndicator(short _value)
    {
        trade2TradeIndicator = _value;
    }
    public short Indicator { get => trade2TradeIndicator; set => trade2TradeIndicator = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Index
{
    private short index;
    public CTCL_Index(short _value)
    {
        index = _value;
    }
    public short Value { get => index; set => index = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Unit
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] unit;
    public CTCL_Unit(char[] _value)
    {
        unit = new char[10];
        Array.Copy(_value, 0, unit, 0, _value.Length > unit.Length ? unit.Length : _value.Length);
    }
    public CTCL_Unit()
    {
        unit = new char[10];
    }
    public char[] Unit { get => unit; set => unit = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Factor
{
    [MarshalAs(UnmanagedType.R8)]
    private double _factor;
    public CTCL_Factor(double _value)
    {
        _factor = _value;
    }
    public double Factor { get => _factor; set => _factor = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Method
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _method;
    public CTCL_Method(char[] _value)
    {
        _method = new char[1];
        Array.Copy(_value, 0, _method, 0, _value.Length > _method.Length ? _method.Length : _value.Length);
    }
    public CTCL_Method()
    {
        _method = new char[1];
    }
    public char[] Method { get => _method; set => _method = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Specification
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] specification;
    public CTCL_Specification(char[] _value)
    {
        specification = new char[40];
        Array.Copy(_value, 0, specification, 0, _value.Length > specification.Length ? specification.Length : _value.Length);
    }
    public CTCL_Specification()
    {
        specification = new char[40];
    }
    public char[] Specification { get => specification; set => specification = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Filler
{
    [MarshalAs(UnmanagedType.I4)]
    private Int32 _filler;
    public CTCL_Filler(Int32 _value)
    {
        _filler = _value;
    }
    public Int32 Filler { get => _filler; set => _filler = value; }
}

public struct CTCL_ApplMsgID
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private byte[] _val;
    public CTCL_ApplMsgID(byte[] _value)
    {
        _val = new byte[16];
        _val = _value;
    }
    public CTCL_ApplMsgID()
    {
        _val = new byte[16];
    }
    public byte[] ID { get => _val; set => _val = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ReserveLong
{
    [MarshalAs(UnmanagedType.I8)]
    private long _reserve;
    public CTCL_ReserveLong(long _value)
    {
        _reserve = _value;
    }
    public long Reserve { get => _reserve; set => _reserve = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ReserveChar16
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _reserveChar;

    public CTCL_ReserveChar16()
    {
        _reserveChar = new char[16];
    }
    public CTCL_ReserveChar16(char[] _value)
    {
        _reserveChar = new char[16];
        Array.Copy(_value, 0, _reserveChar, 0, _value.Length > _reserveChar.Length ? _reserveChar.Length : _value.Length);
    }
    public char[] ReserveChar { get => _reserveChar; set => _reserveChar = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Ip
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
    private char[] _ip;
    public CTCL_Ip(char[] _value)
    {
        _ip = new char[16];
        Array.Copy(_value, 0, _ip, 0, _value.Length > _ip.Length ? _ip.Length : _value.Length);

    }
    public CTCL_Ip()
    {
        _ip = new char[16];
    }
    public char[] Ip { get => _ip; set => _ip = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_BitCompStatus
{
    private bool bitCompStatus;
    public CTCL_BitCompStatus(bool _value)
    {
        bitCompStatus = _value;
    }
    public bool BitCompStatus { get => bitCompStatus; set => bitCompStatus = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PrevOpenInterest
{
    [MarshalAs(UnmanagedType.I8)]
    private UInt32 _openInterest;
    public CTCL_PrevOpenInterest(UInt32 _value)
    {
        _openInterest = _value;
    }   
    public UInt32 OpenInterest { get => _openInterest; set => _openInterest = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_STRSettlor
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
	private string _settlor;
	public CTCL_STRSettlor(char[] _value)
	{
		char[] temparry = new char[12];
		Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
		_settlor = new string(temparry).Replace("\0", "").Replace(" ", "");
	}
	public string Settlor { get => _settlor; set => _settlor = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_series
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _grpname;
    public CTCL_series(char[] _value)
    {
        _grpname = new char[3];
        Array.Copy(_value, 0, _grpname, 0, _value.Length > _grpname.Length ? _grpname.Length : _value.Length);

    }
    public CTCL_series()
    {
        _grpname = new char[3];
    }
    public char[] Series { get => _grpname; set => _grpname = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Instrumentname
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] _instrumentName;
    public CTCL_Instrumentname(char[] _value)
    {
        _instrumentName = new char[40];
        Array.Copy(_value, 0, _instrumentName, 0, _value.Length > _instrumentName.Length ? _instrumentName.Length : _value.Length);

    }
    public CTCL_Instrumentname()
    {
        _instrumentName = new char[40];

    }
    public char[] InstrumentName { get => _instrumentName; set => _instrumentName = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ISINnumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
    private char[] _isinNumber;
    public CTCL_ISINnumber(char[] _value)
    {
        _isinNumber = new char[19];
        Array.Copy(_value, 0, _isinNumber, 0, _value.Length > _isinNumber.Length ? _isinNumber.Length : _value.Length);

    }
    public CTCL_ISINnumber()
    {
        _isinNumber = new char[19];
    }
    public char[] ISINNumber { get => _isinNumber; set => _isinNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_SecurityTypeFlag
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _securityTypeFlag;
    public CTCL_SecurityTypeFlag(char[] _value)
    {
        _securityTypeFlag = new char[10];
        Array.Copy(_value, 0, _securityTypeFlag, 0, _value.Length > _securityTypeFlag.Length ? _securityTypeFlag.Length : _value.Length);

    }
    public CTCL_SecurityTypeFlag()
    {
        _securityTypeFlag = new char[10];
    }
    public char[] SecurityTypeFlag { get => _securityTypeFlag; set => _securityTypeFlag = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_Ticksize
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _ticksize;
    public CTCL_Ticksize(char[] _value)
    {
        _ticksize = new char[10];
        Array.Copy(_value, 0, _ticksize, 0, _value.Length > _ticksize.Length ? _ticksize.Length : _value.Length);

    }
    public CTCL_Ticksize()
    {
        _ticksize = new char[10];
    }
    public char[] TickSize { get => _ticksize; set => _ticksize = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_GSM
{
    [MarshalAs(UnmanagedType.I2)]
    private short _gsm;
    public CTCL_GSM(short _value)
    {
        _gsm = _value;
    }
    public short GSM { get => _gsm; set => _gsm = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortPrtdToTrad
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortPrtdToTrad;
    public CTCL_FillerShortPrtdToTrad(short _value)
    {
        _fillerShortPrtdToTrad = _value;
    }
    public short FillerShortPrtdToTrad { get => _fillerShortPrtdToTrad; set => _fillerShortPrtdToTrad = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharPriceRange
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
    private char[] _fillerVarcharPriceRange;
    public CTCL_FillerVarcharPriceRange(char[] _value)
    {
        _fillerVarcharPriceRange = new char[19];
        Array.Copy(_value, 0, _fillerVarcharPriceRange, 0, _value.Length > _fillerVarcharPriceRange.Length ? _fillerVarcharPriceRange.Length : _value.Length);

    }
    public CTCL_FillerVarcharPriceRange()
    {
        _fillerVarcharPriceRange = new char[19];
    }
    public char[] FillerVarcharPriceRange { get => _fillerVarcharPriceRange; set => _fillerVarcharPriceRange = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerCharMarket
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _fillerCharEligibilityNormalMarket;
    public CTCL_FillerCharMarket(char[] _value)
    {
        _fillerCharEligibilityNormalMarket = new char[1];
        Array.Copy(_value, 0, _fillerCharEligibilityNormalMarket, 0, _value.Length > _fillerCharEligibilityNormalMarket.Length ? _fillerCharEligibilityNormalMarket.Length : _value.Length);
    }
    public CTCL_FillerCharMarket()
    {
        _fillerCharEligibilityNormalMarket = new char[1];

    }
    public char[] FillerCharEligibilityNormalMarket { get => _fillerCharEligibilityNormalMarket; set => _fillerCharEligibilityNormalMarket = value; }

}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ExchangeCode
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    private char[] _exchangeCode;
    public CTCL_ExchangeCode(char[] _value)
    {
        _exchangeCode = new char[4];
        Array.Copy(_value, 0, _exchangeCode, 0, _value.Length > _exchangeCode.Length ? _exchangeCode.Length : _value.Length);

    }
    public CTCL_ExchangeCode()
    {
        _exchangeCode = new char[4];
    }
    public char[] FillerVarcharRights { get => _exchangeCode; set => _exchangeCode = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortIndex
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerindex;
    public CTCL_FillerShortIndex(short _value)
    {
        _fillerindex = _value;
    }
    public short FillerShortIndex { get => _fillerindex; set => _fillerindex = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_UniqueProductId
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 19)]
    private char[] _productId;
    public CTCL_UniqueProductId(char[] _value)
    {
        _productId = new char[19];
        Array.Copy(_value, 0, _productId, 0, _value.Length > _productId.Length ? _productId.Length : _value.Length);

    }
    public CTCL_UniqueProductId()
    {
        _productId = new char[19];
    }
    public char[] UniqueProductId { get => _productId; set => _productId = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CharBSEExclusive
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _charBSEExclusive;
    public CTCL_CharBSEExclusive(char[] _value)
    {
        _charBSEExclusive = new char[10];
        Array.Copy(_value, 0, _charBSEExclusive, 0, _value.Length > _charBSEExclusive.Length ? _charBSEExclusive.Length : _value.Length);

    }
    public CTCL_CharBSEExclusive()
    {
        _charBSEExclusive = new char[10];
    }
    public char[] CharBSEExclusive { get => _charBSEExclusive; set => _charBSEExclusive = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_TickSize1
{
    private double _tickSize1;
    public CTCL_TickSize1(double _value)
    {
        _tickSize1 = _value;
    }
    public double TickSize1 { get => _tickSize1; set => _tickSize1 = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_CharInstumentStatusFlag
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _charInstumentStatusFlag;
    public CTCL_CharInstumentStatusFlag(char[] _value)
    {
        _charInstumentStatusFlag = new char[10];
        Array.Copy(_value, 0, _charInstumentStatusFlag, 0, _value.Length > _charInstumentStatusFlag.Length ? _charInstumentStatusFlag.Length : _value.Length);

    }
    public CTCL_CharInstumentStatusFlag()
    {
        _charInstumentStatusFlag = new char[10];
    }
    public char[] CharInstumentStatusFlag { get => _charInstumentStatusFlag; set => _charInstumentStatusFlag = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerChar
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
    private char[] _fillerCharTradgPrtd;
    public CTCL_FillerChar(char[] _value)
    {
        _fillerCharTradgPrtd = new char[1];
        Array.Copy(_value, 0, _fillerCharTradgPrtd, 0, _value.Length > _fillerCharTradgPrtd.Length ? _fillerCharTradgPrtd.Length : _value.Length);

    }
    public CTCL_FillerChar()
    {
        _fillerCharTradgPrtd = new char[1];

    }
    public char[] FillerCharTradgPrtd { get => _fillerCharTradgPrtd; set => _fillerCharTradgPrtd = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharInstrumentAttributs
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    private char[] _fillerVarcharInstrumentAttributs;
    public CTCL_FillerVarcharInstrumentAttributs(char[] _value)
    {
        _fillerVarcharInstrumentAttributs = new char[40];
        Array.Copy(_value, 0, _fillerVarcharInstrumentAttributs, 0, _value.Length > _fillerVarcharInstrumentAttributs.Length ? _fillerVarcharInstrumentAttributs.Length : _value.Length);

    }
    public CTCL_FillerVarcharInstrumentAttributs()
    {
        _fillerVarcharInstrumentAttributs = new char[40];

    }
    public char[] FillerVarcharInstrumentAttributs { get => _fillerVarcharInstrumentAttributs; set => _fillerVarcharInstrumentAttributs = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortMinLot
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortMinLot;
    public CTCL_FillerShortMinLot(short _value)
    {
        _fillerShortMinLot = _value;
    }
    public short FillerShortMinLot { get => _fillerShortMinLot; set => _fillerShortMinLot = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharUnderlyingInstrumentAssetClass
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
    private char[] _fillerVarcharUnderlyingInstrumentAssetClass;
    public CTCL_FillerVarcharUnderlyingInstrumentAssetClass(char[] _value)
    {
        _fillerVarcharUnderlyingInstrumentAssetClass = new char[25];
        Array.Copy(_value, 0, _fillerVarcharUnderlyingInstrumentAssetClass, 0, _value.Length > _fillerVarcharUnderlyingInstrumentAssetClass.Length ? _fillerVarcharUnderlyingInstrumentAssetClass.Length : _value.Length);

    }
    public CTCL_FillerVarcharUnderlyingInstrumentAssetClass()
    {
        _fillerVarcharUnderlyingInstrumentAssetClass = new char[25];

    }
    public char[] FillerVarcharUnderlyingInstrumentAssetClass { get => _fillerVarcharUnderlyingInstrumentAssetClass; set => _fillerVarcharUnderlyingInstrumentAssetClass = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharUnderlyingInstrument
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
    private char[] _fillerVarcharUnderlyingInstrument;
    public CTCL_FillerVarcharUnderlyingInstrument(char[] _value)
    {
        _fillerVarcharUnderlyingInstrument = new char[10];
        Array.Copy(_value, 0, _fillerVarcharUnderlyingInstrument, 0, _value.Length > _fillerVarcharUnderlyingInstrument.Length ? _fillerVarcharUnderlyingInstrument.Length : _value.Length);

    }
    public CTCL_FillerVarcharUnderlyingInstrument()
    {
        _fillerVarcharUnderlyingInstrument = new char[10];

    }
    public char[] FillerVarcharUnderlyingInstrument { get => _fillerVarcharUnderlyingInstrument; set => _fillerVarcharUnderlyingInstrument = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerLongUnderlyingFinInstrumentId
{
    [MarshalAs(UnmanagedType.I8)]
    private long _fillerLongUnderlyingFinInstrumentId;
    public CTCL_FillerLongUnderlyingFinInstrumentId(long _value)
    {
        _fillerLongUnderlyingFinInstrumentId = _value;
    }
    public long FillerLongUnderlyingFinInstrumentIden { get => _fillerLongUnderlyingFinInstrumentId; set => _fillerLongUnderlyingFinInstrumentId = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharInstrumentName
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
    private char[] _fillerVarcharInstrumentName;
    public CTCL_FillerVarcharInstrumentName(char[] _value)
    {
        _fillerVarcharInstrumentName = new char[6];
        Array.Copy(_value, 0, _fillerVarcharInstrumentName, 0, _value.Length > _fillerVarcharInstrumentName.Length ? _fillerVarcharInstrumentName.Length : _value.Length);

    }
    public CTCL_FillerVarcharInstrumentName()
    {
        _fillerVarcharInstrumentName = new char[6];
    }
    public char[] FillerVarcharInstrumentName { get => _fillerVarcharInstrumentName; set => _fillerVarcharInstrumentName = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortMktTpAndId
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortMktTpAndId;

    public CTCL_FillerShortMktTpAndId(short _value)
    {
        _fillerShortMktTpAndId = _value;
    }
    public short FillerShortMktTpAndId { get => _fillerShortMktTpAndId; set => _fillerShortMktTpAndId = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharUnitOfMeasure
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
    private char[] _fillerVarcharUnitOfMeasure;
    public CTCL_FillerVarcharUnitOfMeasure(char[] _value)
    {
        _fillerVarcharUnitOfMeasure = new char[5];
        Array.Copy(_value, 0, _fillerVarcharUnitOfMeasure, 0, _value.Length > _fillerVarcharUnitOfMeasure.Length ? _fillerVarcharUnitOfMeasure.Length : _value.Length);

    }
    public CTCL_FillerVarcharUnitOfMeasure()
    {
        _fillerVarcharUnitOfMeasure = new char[5];
    }
    public char[] FillerVarcharUnitOfMeasure { get => _fillerVarcharUnitOfMeasure; set => _fillerVarcharUnitOfMeasure = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortPriceQtQty
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortPriceQtQty;
    public CTCL_FillerShortPriceQtQty(short _value)
    {
        _fillerShortPriceQtQty = _value;
    }
    public short FillerShortPriceQtQty { get => _fillerShortPriceQtQty; set => _fillerShortPriceQtQty = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortPriceRangeType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortPriceRangeType;
    public CTCL_FillerShortPriceRangeType(short _value)
    {
        _fillerShortPriceRangeType = _value;
    }
    public short FillerShortPriceRangeType { get => _fillerShortPriceRangeType; set => _fillerShortPriceRangeType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerdoublePrice
{
    private double _fillerNumericMaxPrice;
    public CTCL_FillerdoublePrice(double _value)
    {
        _fillerNumericMaxPrice = _value;
    }
    public double FillerNumericMaxPrice { get => _fillerNumericMaxPrice; set => _fillerNumericMaxPrice = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortSttlmMtd
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortSttlmMtd;
    public CTCL_FillerShortSttlmMtd(short _value)
    {
        _fillerShortSttlmMtd = _value;
    }
    public short FillerShortSttlmMtd { get => _fillerShortSttlmMtd; set => _fillerShortSttlmMtd = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortInitialMarginType
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortInitialMarginType;
    public CTCL_FillerShortInitialMarginType(short _value)
    {
        _fillerShortInitialMarginType = _value;
    }
    public short FillerShortInitialMarginType { get => _fillerShortInitialMarginType; set => _fillerShortInitialMarginType = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerDoubleInitialMarginRate
{
    private double _fillerNumericBuyInitialMarginRate;
    public CTCL_FillerDoubleInitialMarginRate(double _value)
    {
        _fillerNumericBuyInitialMarginRate = _value;
    }
    public double FillerNumericBuyInitialMarginRate { get => _fillerNumericBuyInitialMarginRate; set => _fillerNumericBuyInitialMarginRate = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortAssetClass
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortAssetClass;
    public CTCL_FillerShortAssetClass(short _value)
    {
        _fillerShortAssetClass = _value;
    }
    public short FillerShortAssetClass { get => _fillerShortAssetClass; set => _fillerShortAssetClass = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharSpecialfunctionNumber
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
    private char[] _fillerVarcharSpecialfunctionNumber;
    public CTCL_FillerVarcharSpecialfunctionNumber(char[] _value)
    {
        _fillerVarcharSpecialfunctionNumber = new char[100];
        Array.Copy(_value, 0, _fillerVarcharSpecialfunctionNumber, 0, _value.Length > _fillerVarcharSpecialfunctionNumber.Length ? _fillerVarcharSpecialfunctionNumber.Length : _value.Length);

    }
    public CTCL_FillerVarcharSpecialfunctionNumber()
    {
        _fillerVarcharSpecialfunctionNumber = new char[100];
    }
    public char[] FillerVarcharSpecialfunctionNumber { get => _fillerVarcharSpecialfunctionNumber; set => _fillerVarcharSpecialfunctionNumber = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharSrsSttlmTp
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    private char[] _fillerVarcharSrsSttlmTp;
    public CTCL_FillerVarcharSrsSttlmTp(char[] _value)
    {
        _fillerVarcharSrsSttlmTp = new char[2];
        Array.Copy(_value, 0, _fillerVarcharSrsSttlmTp, 0, _value.Length > _fillerVarcharSrsSttlmTp.Length ? _fillerVarcharSrsSttlmTp.Length : _value.Length);

    }
    public CTCL_FillerVarcharSrsSttlmTp()
    {
        _fillerVarcharSrsSttlmTp = new char[2];
    }
    public char[] FillerVarcharSrsSttlmTp { get => _fillerVarcharSrsSttlmTp; set => _fillerVarcharSrsSttlmTp = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharRatgDtls
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
    private char[] _fillerVarcharRatgDtls;
    public CTCL_FillerVarcharRatgDtls(char[] _value)
    {
        _fillerVarcharRatgDtls = new char[12];
        Array.Copy(_value, 0, _fillerVarcharRatgDtls, 0, _value.Length > _fillerVarcharRatgDtls.Length ? _fillerVarcharRatgDtls.Length : _value.Length);

    }
    public CTCL_FillerVarcharRatgDtls()
    {
        _fillerVarcharRatgDtls = new char[12];
    }
    public char[] FillerVarcharRatgDtls { get => _fillerVarcharRatgDtls; set => _fillerVarcharRatgDtls = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortInstrumentClssfctn
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortInstrumentClssfctn;

    public CTCL_FillerShortInstrumentClssfctn(short _value)
    {
        _fillerShortInstrumentClssfctn = _value;
    }
    public short FillerShortInstrumentClssfctn { get => _fillerShortInstrumentClssfctn; set => _fillerShortInstrumentClssfctn = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShortPreOpenAllowedFlag
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortPreOpenAllowedFlag;
    public CTCL_FillerShortPreOpenAllowedFlag(short _value)
    {
        _fillerShortPreOpenAllowedFlag = _value;
    }
    public short FillerShortPreOpenAllowedFlag { get => _fillerShortPreOpenAllowedFlag; set => _fillerShortPreOpenAllowedFlag = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerShort
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillerShortClssfctnTp;
    public CTCL_FillerShort(short _value)
    {
        _fillerShortClssfctnTp = _value;
    }
    public short FillerShortClssfctnTp { get => _fillerShortClssfctnTp; set => _fillerShortClssfctnTp = value; }
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharCcy
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _fillerVarcharCcy;
    public CTCL_FillerVarcharCcy(char[] _value)
    {
        _fillerVarcharCcy = new char[3];
        Array.Copy(_value, 0, _fillerVarcharCcy, 0, _value.Length > _fillerVarcharCcy.Length ? _fillerVarcharCcy.Length : _value.Length);

    }
    public CTCL_FillerVarcharCcy()
    {
        _fillerVarcharCcy = new char[3];
    }
    public char[] FillerVarcharCcy { get => _fillerVarcharCcy; set => _fillerVarcharCcy = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillerVarcharSttlmCcy
{
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
    private char[] _fillerVarcharSttlmCcy;
    public CTCL_FillerVarcharSttlmCcy(char[] _value)
    {
        _fillerVarcharSttlmCcy = new char[3];
        Array.Copy(_value, 0, _fillerVarcharSttlmCcy, 0, _value.Length > _fillerVarcharSttlmCcy.Length ? _fillerVarcharSttlmCcy.Length : _value.Length);

    }
    public CTCL_FillerVarcharSttlmCcy()
    {
        _fillerVarcharSttlmCcy = new char[3];
    }
    public char[] FillerVarcharCcy { get => _fillerVarcharSttlmCcy; set => _fillerVarcharSttlmCcy = value; }
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_FillershortRsvd
{
    [MarshalAs(UnmanagedType.I2)]
    private short _fillershortRsvd;
    public CTCL_FillershortRsvd(short _value)
    {
        _fillershortRsvd = _value;
    }

    public short FillershortRsvd { get => _fillershortRsvd; set => _fillershortRsvd = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_PartitionID
{
    [MarshalAs(UnmanagedType.I2)]
    private short _partitionID;
    public CTCL_PartitionID(short _value)
    {
        _partitionID = _value;
    }
    public short PartitionID { get => _partitionID; set => _partitionID = value; }
}


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public struct CTCL_ISDefault
{
	[MarshalAs(UnmanagedType.Bool)]
	private bool _default;
	public CTCL_ISDefault(bool _value)
	{
		_default = _value;
	}
	public bool Default { get => _default; set => _default = value; }
}
