﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DematHolding
	{
		public CTCL_ExchangeSegmentId ExchangeId;
		public CTCL_ExchangeSegmentId SegmentId;
		public CTCL_Token TokenNo;
		public CTCL_ISINNumber ISIN;
		public CTCL_Symbol Symbol;
		public CTCL_Series Series;
		public CTCL_ClientIndicator ProClient;
		public CTCL_AccountNumber AccountNumber;
		public CTCL_Settlor Participant;
		public CTCL_TerminalID Dealer;
		public CTCL_TimeStamp LastTradeDate;
		public CTCL_TimeStamp SettlementDate;
		//public CTCL_DateTime EarlyPayIn;
		public CTCL_TimeStamp LastUpdateTime;
		public CTCL_EntityId LastUpdatedBy;
		public CTCL_Quantity ClearedHolding;
		public CTCL_Price ClearedHoldingAveragePrice;
		public CTCL_Quantity LastUnsettledHolding;
		public CTCL_Price UnsettledHoldingAveragePrice;
	}
}
