﻿using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MarshalConnectionMode
{
	[MarshalAs(UnmanagedType.I2)]
	public CTCL_ConnectionMode ConnectionMode;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MarshalTradingStatus
{
	[MarshalAs(UnmanagedType.I2)]
	public CTCL_TradingStatus TradeStatus;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MarshalOperationStatus
{
	[MarshalAs(UnmanagedType.I2)]
	public CTCL_OperationStatus OperationStatus;
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MarshalAcessAllowed 
{
    [MarshalAs(UnmanagedType.I2)]
    public CTCL_AccessAllowed AccessAllowed;
}