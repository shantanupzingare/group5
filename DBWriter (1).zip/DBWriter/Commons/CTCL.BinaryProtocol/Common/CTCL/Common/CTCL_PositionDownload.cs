﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    //[StructLayout(LayoutKind.Sequential, Pack = 1)]
    //public class CTCL_START_POSITION_DOWNLOAD
    //{
    //    public CTCL_MessageHeader messageHeader;
    //    public CTCL_ContextIdentifier contextIdentifier;
    //}

    //[StructLayout(LayoutKind.Sequential, Pack = 1)]
    //public class CTCL_START_SUB_POSITON_DOWNLOAD
    //{
    //    public CTCL_MessageHeader messageHeader;
    //    public CTCL_ContextIdentifier contextIdentifier;
    //    public CTCL_ExchangeSegmentId exchangeSegmentId;
    //}

    //[StructLayout(LayoutKind.Sequential, Pack = 1)]
    //public class CTCL_Position_UPDATE
    //{
    //    public CTCL_MessageHeader messageHeader;
    //    public CTCL_ContextIdentifier contextIdentifier;
    //    public CTCL_Token TokenIdentifier;
    //    public CTCL_MessageLength MessageLength;
    //    public CTCL_LDBData LDBData;
    //}

    //[StructLayout(LayoutKind.Sequential, Pack = 1)]
    //public class CTCL_END_SUB_POSITON_DOWNLOAD
    //{
    //    public CTCL_MessageHeader messageHeader;
    //    public CTCL_ContextIdentifier contextIdentifier;
    //    public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    //}

    //[StructLayout(LayoutKind.Sequential, Pack = 1)]
    //public class CTCL_END_POSITION_DOWNLOAD
    //{
    //    public CTCL_MessageHeader messageHeader;
    //    public CTCL_ContextIdentifier contextIdentifier;
    //    public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    //}

}
