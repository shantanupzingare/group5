﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_COMMON_MASTER_ATTRIBUTE
	{
		public CTCL_EntityId LastUpdatedBy;
		public CTCL_TimeStamp LastUpdatedTime;
		[Validator(validationType.alpha_numeric, "Special characters not allowed in Entity Remark")]
		public CTCL_Remark Remarks;
		public CTCL_RMSTemplateStatus Status;
	}
}
