﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Indexes
    {
       public CTCL_IndexName IndexName;
       public CTCL_IndexValue IndexValue;
       public CTCL_IndexValue HighIndexValue;
       public CTCL_IndexValue LowIndexValue;
       public CTCL_IndexValue OpeningIndex;
       public CTCL_IndexValue CloseingIndex;
       public CTCL_Percentage PercentChange;
       public CTCL_IndexValue YearlyHigh;
       public CTCL_IndexValue YearlyLow;
       public CTCL_NoOfmoves UpMoves;
       public CTCL_NoOfmoves DownMoves;
       public CTCL_MarketCapitalisation Capitalisation;
       public CTCL_NetChangeIndicator NetChangeIndicator;
       public CTCL_Filler1 Filler1;

    }
}
