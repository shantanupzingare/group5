﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public  class CTCL_AccountInformation
{
    public CTCL_ClientIndicator ProClientIndicator;
    public CTCL_AccountNumber ClientAccountCode;
}
