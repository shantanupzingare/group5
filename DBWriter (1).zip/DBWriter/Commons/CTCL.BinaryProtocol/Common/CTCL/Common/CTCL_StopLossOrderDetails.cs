﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_StopLossOrderDetails
{
	public CTCL_OrderContextIdentifier OrderContextIdentifier;
	public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
	public CTCL_OrderContextIdentifier GatewayOrderNumber;
	public CTCL_BrokerID BrokerID;
	public CTCL_TraderId TraderId;
	public CTCL_AccountInformation AccountInformation;
	public CTCL_Buy_SellIndicator Buy_SellIndicator;
	public CTCL_Quantity OriginalVolume;
	public CTCL_Quantity DisclosedVolume;
	public CTCL_Quantity RemainingVolume;
	public CTCL_Quantity DisclosedVolumeRemaining;
	public CTCL_Price OrderPrice;
	public CTCL_Price TradePrice;
	public CTCL_FillNumber FillNumber;
	public CTCL_Quantity FillQtyy;
	public CTCL_Price FillPrice;
	public CTCL_Quantity VolumeFilledToday;
	public CTCL_ActivityType ActivityType;
	public CTCL_ST_Order_Flag STOrderFlag;
	public CTCL_Quantity GoodTillDate;
	public CTCL_TimeStamp ActivityTime;
	public CTCL_Contract_Desc Contract_Desc;
	public CTCL_ExchangeOrderNumber CPOrderNumber;
	public CTCL_BrokerID CPBrokerId;
	public CTCL_Participant ParticipantCode;
	public CTCL_AccountSpecificAttribute AccountSpecificAttribute;
	public CTCL_TimeStamp FillTime;
	public CTCL_Algo_ID AlgoID;
	public CTCL_TradeNumber TradeNumber;
	public CTCL_TimeStamp LastActivityReference;
    public CTCL_BrokerTraderSpecificAttribute BrokerTraderSpecificAttribute;
}
