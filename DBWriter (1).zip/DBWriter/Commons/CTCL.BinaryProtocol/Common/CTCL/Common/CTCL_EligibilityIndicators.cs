﻿using CTCL.BinaryProtocol.Common.NSE_FO.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_EligibilityIndicators
    {
        public bool IndexParticipant;
        public bool AON;
        public bool MinimumFill;
        public CTCL_ReservedBits Reserved;
        public CTCL_Reserved Reserved_1Byte;
    }
}
