﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class DeliveryObligationMaster
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_InstrumentId Instrument;
        public CTCL_InstrumentId SubInstrument;
        public CTCL_InstrumentId SubAsset;
        public CTCL_DateTime DeliveryObligationDays;
    }
}
