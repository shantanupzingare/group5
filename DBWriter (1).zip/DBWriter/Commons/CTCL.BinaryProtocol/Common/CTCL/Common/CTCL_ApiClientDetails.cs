﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ApiClientDetails
    {
        public CTCL_MessageHeader Header;
        public CTCL_TerminalID TerminalID;
        public CTCL_LoginStatusString AppKey;
        public CTCL_LoginStatusString SecretKey;
    }
}
