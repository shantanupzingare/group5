﻿using CTCL.BinaryProtocol.Common.NSE_FO.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_SecEligibility
    {
        public Sec_Reserved Reserved;
        public Sec_Eligibility Eligibility;
        public Sec_Status Status;
    }
}
