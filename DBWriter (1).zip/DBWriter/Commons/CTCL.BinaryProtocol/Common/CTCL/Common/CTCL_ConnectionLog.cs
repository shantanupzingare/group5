﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_ConnectionLog
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_EntityId EntityId;
    public CTCL_ConnectionStatus ConnectionStatus; // LogIn - 1 , LogOut - 2, Locked - 3
    public CTCL_UserIP TrackAddress;
    public CTCL_TimeStamp EventTimeStamp;
    public CTCL_Connectio_Log__Remark Remark;


}
