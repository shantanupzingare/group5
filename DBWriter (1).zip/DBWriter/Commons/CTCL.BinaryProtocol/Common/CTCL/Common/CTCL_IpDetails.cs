﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_IpDetails
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_Ip IP;
        public CTCL_TimeStamp LastRequestReceivedTime;
        public CTCL_MsgCount Count;
        public CTCL_Flag Flag;
    }
}
