﻿using CTCL.BinaryProtocol.Common.NSE_FO.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_System_Information_Data
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ST_MARKET_STATUS ST_MARKET_STATUS;
        public CTCL_ST_MARKET_STATUS ST_EX_MARKET_STATUS;
        public CTCL_ST_MARKET_STATUS ST_PL_MARKET_STATUS;
        public CTCL_Remark Remark;
    }
}
