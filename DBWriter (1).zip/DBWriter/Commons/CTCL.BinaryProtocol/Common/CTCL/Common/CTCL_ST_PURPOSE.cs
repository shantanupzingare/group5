﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ST_PURPOSE
    {
        public CTCL_ST_PURPOSE_flag ExerciseStyle;
        public CTCL_ST_PURPOSE_flag Reserved;
        public CTCL_ST_PURPOSE_flag EGM;
        public CTCL_ST_PURPOSE_flag AGM;
        public CTCL_ST_PURPOSE_flag Interest;
        public CTCL_ST_PURPOSE_flag Bonus;
        public CTCL_ST_PURPOSE_flag Rights;
        public CTCL_ST_PURPOSE_flag Dividend;
        public CTCL_ST_PURPOSE_flag Reserved1;
        public CTCL_ST_PURPOSE_flag IsCorporateAdjusted;
        public CTCL_ST_PURPOSE_flag IsAsset;
        public CTCL_ST_PURPOSE_flag PlAllowed;
        public CTCL_ST_PURPOSE_flag ExRejectionAllowed;
        public CTCL_ST_PURPOSE_flag ExAllowed;
    }
}
