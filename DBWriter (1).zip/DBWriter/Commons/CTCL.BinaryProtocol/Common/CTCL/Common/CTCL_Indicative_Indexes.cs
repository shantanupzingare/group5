﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Indicative_Indexes
    {
        public CTCL_IndexName IndexName;
        public CTCL_IndexValue IndicativeCloseValue;
        public CTCL_IndexValue Reserved;
        public CTCL_IndexValue Reserved1;
        public CTCL_IndexValue Reserved2;
        public CTCL_IndexValue ClosingIndex;
        public CTCL_Percentage PercentChange;
        public CTCL_IndexValue Reserved3;
        public CTCL_IndexValue Reserved4;
        public CTCL_NoOfmoves Change;
        public CTCL_NoOfmoves Reserved5;
        public CTCL_MarketCapitalisation MarketCapitalisation;
        public CTCL_NetChangeIndicator NetChangeIndicator;
        public CTCL_Filler1 Filler1;
    }
}
