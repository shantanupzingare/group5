﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;
[StructLayout(LayoutKind.Sequential, Pack = 1)]

public class CTCL_TradedDetails
{
    public CTCL_OrderContextIdentifier OrderContextIdentifier;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber; // need to change int64 to char16 as per doc, also not present in db
    public CTCL_OrderContextIdentifier GatewayOrderNumber;
    public CTCL_BrokerID BrokerID;
    public CTCL_TraderId TraderId; // need to confirm size- int in db, size not define in doc
    public CTCL_AccountInformation AccountInformation;
    public CTCL_Buy_SellIndicator Buy_SellIndicator;
    public CTCL_Quantity OriginalVolume;
    public CTCL_Quantity DisclosedVolume;
    public CTCL_Quantity RemainingVolume;
    public CTCL_Quantity DisclosedVolumeRemaining;
    public CTCL_Price OrderPrice;
    public CTCL_Price TradePrice;
    public CTCL_FillNumber FillNumber;
    public CTCL_Quantity FillQtyy;
    public CTCL_Price FillPrice;
    public CTCL_TimeStamp FillTime; //added 6623

    public CTCL_Quantity VolumeFilledToday;
    public CTCL_ActivityType ActivityType;
    public CTCL_ST_Order_Flag sTOrderFlag;
    public CTCL_Quantity GoodTillDate;
    public CTCL_TimeStamp ActivityTime;
    public CTCL_Contract_Desc Contract_Desc;
    public CTCL_ExchangeOrderNumber CPOrderNumber;
    public CTCL_BrokerID CPBrokerId;
    public CTCL_Participant ParticipantCode;
    public CTCL_AccountSpecificAttribute AccountSpecificAttribute;
    
    public CTCL_Algo_ID AlgoID;
    public CTCL_TradeNumber TradeNumber;   //new added- not exist in doc.
	public CTCL_TimeStamp LastActivityReference;

    public CTCL_ProductType ProductType;
    public CTCL_TradeStatus TradeStatus;
    public CTCL_CoverUnCover CoverUnCover;
    public CTCL_BranchID BranchID;
    public CTCL_BrokerTraderSpecificAttribute BrokerTraderSpecificAttribute;
}
