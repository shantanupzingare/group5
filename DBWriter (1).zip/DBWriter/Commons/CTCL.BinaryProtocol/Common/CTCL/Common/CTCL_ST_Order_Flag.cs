﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_ST_Order_Flag
{
    public CTCL_ST_Order_Flag_bool AON; 
    public CTCL_ST_Order_Flag_bool IOC;
    public CTCL_ST_Order_Flag_bool GTC;
    public CTCL_ST_Order_Flag_bool Day;
    public CTCL_ST_Order_Flag_bool MIT;
    public CTCL_ST_Order_Flag_bool SL;
    public CTCL_ST_Order_Flag_bool Market;
    public CTCL_ST_Order_Flag_bool ATO;
    public CTCL_ST_Order_Flag_bool Frozen;
    public CTCL_ST_Order_Flag_bool Modified;
    public CTCL_ST_Order_Flag_bool Traded;
    public CTCL_ST_Order_Flag_bool MatchedInd;
    public CTCL_ST_Order_Flag_bool MF;
    public CTCL_ST_Order_Flag_bool GTD;
    public CTCL_ST_Order_Flag_bool EOS;
   // public CTCL_ST_Order_Flag_bool Preopen; //not in doc- new added
   // public CTCL_ST_Order_Flag_bool OnStop; //not in doc- new added
}

