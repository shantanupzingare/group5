﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_User_Throtlling_Info
    {
        public CTCL_TimeStamp Timestamp { get; set; }
        public CTCL_MsgCount Count { get; set; }
    }
}
