﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_OrderDetails
{

    public CTCL_OrderContextIdentifier OrderContextIdentifier;
    public CTCL_OrderContextIdentifier GatewayOrderNumber;
    public CTCL_Contract_Desc contract_Desc;
    public CTCL_ParticipantType ParticipantType;
    public CTCL_CounterPartyBrokerId CounterPartyBrokerId;
    public CTCL_OrderType OrderType;
    public CTCL_AccountInformation AccountInformation;

    public CTCL_ModifiedBy Modified_CancelBy;
    public CTCL_BookType BookType;
    public CTCL_BuySellIndicator Buy_SellIndicator;
    public CTCL_OpenClose OpenOrClose;

    public CTCL_Quantity DisclosedVolume;
    public CTCL_Quantity DisclosedVolumeRemaining;
    public CTCL_Quantity TotalVolumeRemaining;
    public CTCL_Quantity TotalVolume;
    public CTCL_Quantity VolumeFilledToday;
    public CTCL_Quantity MinimumFill;

    public CTCL_Price Price;
    public CTCL_Percent Percent;
    public CTCL_Price TriggerPrice;
    public CTCL_Quantity GoodTillDate;
    public CTCL_TimeStamp LastModifiedTime;
    public CTCL_TimeStamp LastActivityReference;
    public CTCL_ST_Order_Flag STOrderFlag;
    public CTCL_BranchID BranchID;
    public CTCL_TraderId TraderID;
    public CTCL_BrokerID BrokerID;
    public CTCL_Algo_ID Algo_ID;
    public CTCL_Symbol Symbol;


    public CTCL_Settlor Settlor;
    public CTCL_AccountSpecificAttribute AccountSpecificAttribute;
    public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;

    public CTCL_Participant ParticipantCode;
    public CTCL_ProductType ProductType;
    public CTCL_CoverUnCover CoverUnCover;
    public CTCL_BrokerTraderSpecificAttribute BrokerTraderSpecificAttribute;
	public CTCL_TerminalID Initiator;
	[Validator(validationType.alpha_numeric, "Special characters not allowed in User Remarks")]
	public CTCL_Remark UserRemarks;
	public CTCL_OrderContextIdentifier OrderUniqueIdentifier;
    public CTCL_TimeStamp DeliveryObligationTime;
    public CTCL_TimeStamp GTDExpiryDate;
    public CTCL_TimeStamp OrderPunchInTime;
    //------Datatype need to confirm with sameer sir for this newly added fields

    //PartType
    //ServerEntryTime
    //AMOOrderId
    //OMSID
    //DealingInstruction
    //InitiatedFrom
    //ModifiedFrom

}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Error_OrderDetail
{
	public CTCL_Quantity DisclosedVolume;
	public CTCL_Quantity DisclosedVolumeRemaining;
	public CTCL_Quantity TotalVolumeRemaining;
	public CTCL_Quantity TotalVolume;
	public CTCL_Quantity VolumeFilledToday;
	public CTCL_Price Price;
    public CTCL_AccountInformation AccountInformation;
}
