﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Contract_Desc
{
    //public CTCL_InstrumentName InstrumentName;
    //public CTCL_Symbol Symbol;
    //public CTCL_DateTime ExpiryDate;
    //public CTCL_Price StrikePrice;
    //public CTCL_OptionType OptionType;
    //public CTCL_CALevel CALevel;
    public CTCL_Token MappingTokenId;
}

