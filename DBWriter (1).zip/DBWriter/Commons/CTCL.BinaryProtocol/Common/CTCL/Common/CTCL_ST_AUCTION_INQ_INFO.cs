﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ST_AUCTION_INQ_INFO
    {
        public CTCL_Token Token;
        public CTCL_AuctionNumber AuctionNumber;
        public CTCL_Auction_Status AuctionStatus;
        public CTCL_InitiatorType InitiatorType;
        public CTCL_Quantity TotalBuyQuantity;
        public CTCL_Price BestBuyPrice;
        public CTCL_Quantity TotalSellQuantity;
        public CTCL_Price BestSellPrice;
        public CTCL_Price AuctionPrice;
        public CTCL_Quantity AuctionQuantity;
        public CTCL_SettlementPeriod SettlementPeriod;
    }
}
