﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMSCommonMasterAttributes
	{
		public CTCL_TimeStamp IntCreatedOn;
		public CTCL_TimeStamp IntModifiedOn;
		public CTCL_EntityId IntCreatedBy;
		public CTCL_EntityId IntModifiedBy;
		public CTCL_RMSTemplateStatus IntStatus;
	}
}
