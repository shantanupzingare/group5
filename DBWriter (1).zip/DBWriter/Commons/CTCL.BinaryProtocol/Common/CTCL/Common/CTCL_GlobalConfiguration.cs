﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Common
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_GlobalConfiguration
    {
        public CTCL_NoOfRecords NoOfRecords;
        public CTCL_Configuration[] Configuration;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Configuration
    {
        public CTCL_Id ConfigId;
        public CTCL_ComponentInstanceIdentifier ConfigComponent;
        public CTCL_ComponentInstanceIdentifier ConfigInstance;
        public CTCL_ConfigDataType ConfigDataType;
        public CTCL_ConfigValue ConfigValue;
        public CTCL_ConfigName ConfigDisplayName;
        public CTCL_Remark ConfigRemarks;
        public CTCL_ConfigRange ConfigRange;
        public CTCL_TimeStamp LastUpdatedTime;
    }
}
