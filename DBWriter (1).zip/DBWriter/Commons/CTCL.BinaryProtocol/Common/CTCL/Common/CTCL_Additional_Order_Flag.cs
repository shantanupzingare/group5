﻿namespace CTCL.BinaryProtocol.Common.CTCL.Common;

public class CTCL_Additional_Order_Flag
{
    public bool BOC;
    public bool COL;   
    public bool STPC;    
}

