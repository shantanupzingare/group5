﻿using System.ComponentModel;

namespace CTCL.BinaryProtocol.Common.CTCL.Enum;

public enum CTCL_Exchange : short
{
    NSE = 1,
    MCX = 2,
    BSE = 3
}

[Flags]
public enum CTCL_ExchangeIdentifier : short
{
    NSE_FO = 1,
    NSE_CM = 2,
    MCX_FO = 4,
    BSE_CM = 8,
    BSE_FO = 16
}

public enum CTCL_Instrument : short
{
    DERIVATIVE = 1,
    SPOT = 2

}

public enum CTCL_SubInstrument : short
{
    NA = -1,
    F = 1,
    O = 2
}

public enum CTCL_Asset : short
{
    Equity = 1,
    Commodity = 2
}
public enum CTCL_SUBAsset : short
{
    Individual = 1,
    Index = 2
}



[Flags]
public enum CTCL_BuySellIndicator : short
{
    Buy = 1,
    Sell = 2
}

public enum CTCL_OpenClose
{
    Open = 'O',
    Closed = 'C',
}

public enum CTCL_Status : short //as VK sir said
{
    INVALIDAUTHDETAIL = 1000,
    PASSWORDEXISTS = 2000
}

public enum CTCL_AuthType : short
{
    PASSWORD = 1,
    //2FA = 2,
}


public enum CTCL_ModifiedBy
{
    Trader = 'T',
    BranchManager = 'B',
    CorporateManager = 'M',
    Exchange = 'C'
}

public enum CTCL_BookType : short
{
    Regularlotorder = 1,
    Specialtermsorder = 2,
    StoplossORMITorder = 3,
    Negotiatedorder = 4,
    Oddlotorder = 5,
    Spotorder = 6,
    Auctionorder = 7,
    CallAuction1 = 11,
    CallAuction2 = 12
}

public enum CTCL_SegmentSpecificAttribute : short
{
    Best5 = 1,
    LTP = 2,
    TouchLine = 4,
    OptionChain =8
}

public enum UnsubscribeSegmentAttribute : short
{
    NotBest5 =0XFE ,
    NotLTP = 0XFD,
    NotTouchLine = 0XFB,
    NotOptionChain = 0XF7
}

public enum CTCL_MarketType : short
{
    Normal_Market = 1,
    Odd_Lot_Market = 2,
    Spot_Market = 3,
    Auction_Market = 4,
    Call_Auction1_Market = 5,
    Call_Auction2_Market = 6
}

[Flags]
public enum CTCL_OrderType : short
{
    //[Description("Limit")]
    //Limit = 1,
    //[Description("Market")]
    //Market = 2,
    [Description("SL")]
    Stoploss = 4,
    [Description("RL")]
    Regular = 8,

}

public enum Filetype : short
{
    NSE_FO_SECURITY = 1,
    NSE_FO_PARTICIPANT = 2,
    NSE_CM_SECURITY = 3,
    NSE_CM_PARTICIPANT = 4,
    NSE_CM_BhavCopy = 5,
    NSE_CM_ExtremeLossMargin = 6,
    NSE_FO_BhavCopy = 7,
	GradedSurveillanceMeasure = 8,
	AdditionalSurveillanceMeasure = 9,
	NSE_FO_SecuritiesBanForTrade = 10,
    MCX_InstrumentMaster = 12,
    NSE_FO_Span = 13,
	Exchange_Contract_Master = 14,
	NSE_FO_ExposureLimit = 15,
    NSE_CM_Udiff_BhavCopy=16,
    NSE_FO_Udiff_BhavCopy=17,
    MCX_Udiff_Bhavcopy=18,
	NSE_SURVEILLANCE_INDICATOR = 19,
	MARKET_CAPITALISATION = 20,
    MCX_PARTICIPANT =  22,
    BSECM_PARTICIPANT=23,
    BSE_CM_UDIFF_BHAVCOPY = 24,
    BSEFO_PARTICIPANTMASTER=25,
    BSE_CM_SECURITY = 26,
    BSE_SURVEILLANCE_INDICATOR = 27,
    BSE_FO_UDIFF_BHAVCOPY = 28,
    NSE_INTEROP = 30,
}

//values will be changed for usertype
public enum UserType : short
{
    Admin = 1,
    ReservedUser = 2,
    Client = 3,
    Dealer = 4,
    Normaluser = 5
}

public enum TwoFAType : short
{

    PAN = 1,
    AADHAR_NUMBER = 2,
    GOOGLE_AUTH = 3,
    MOBILE = 4
}

[Flags]
public enum CTCL_OperationType : short
{
    OE = 1,
    OM = 2,
    OC = 4,
    TM = 8
}

public enum CTCL_TransactionValidity : short
{
    Day = 1,
    GTC = 2,
    IOC = 4,
    GTD = 8,
    EOS = 16
}

public enum CTCL_AccountType : short
{
	CLI = 1,
	PRO = 2,
	INST = 4
}

public enum CTCL_ProductType : short
{
    MIS=1,
    CNC=2
}

public enum CTCL_TradeStatus : short
{
    Original  = 11,
    Modified  = 12,
    Cancelled =13,
    Rejected = 14,   
    ModificationRejected=15,
    CancellationRejected=16,
    GiveupTradeApproved=17,
    GiveupTradeRejected=18
}
public enum CTCL_CoverUnCover : short
{
    Cover = 1, 
    UnCover=2
}

public enum CTCL_ConnectionMode : short
{
    LAN = 1,
    WAN = 2
}

public enum CTCL_ConnectionStatus : short
{

    LogIn = 1,
    LogOut = 2,
    locked = 3
}

public enum CTCL_LDBInformationIdentifiers : short
{
    NSE_FO_SECURITY_MASTER = 1,
    NSE_FO_PARTICIPANT_MASTER=2,
    NSE_CM_SECURITY_MASTER=3,
    NSE_CM_PARTICIPANT_MASTER=4,
    CURRENCY_MASTER=5,
    CURRENCY_CONVERSION_MAPPING_MASTER=6,
    NSE_CM_BhavData=7,
    NSE_GatewayConfigurationData=8,
    NSE_FO_BhavData = 9,
    MARKET_ORDER_PRICE_PROTECTION_CONFIG = 10,
    CRP_ATTRIBUTE = 11,
    NSE_FO_BANNED_LIST = 12,
    FO_LIMIT_PRICE_PROTECTION_RANGE = 13,
    FO_ST_TICKER_INDEX = 14,
	MARKET_WIDE_POSITION_LIMIT = 15,
    UDIFF_BhavCopy=16,
	SPAN_FILE_PATH_UPDATE = 17,
	NSE_FO_EXPOSURE_LIMIT = 18,
	DELIVERY_OBLIGATION = 19,
	HOLIDAY_LIST = 20,
	ALLOWED_QUANTITY_MASTER = 21,
	MARGIN_FILE_PATH_UPDATE = 22,
	SURVEILLANCE_INDICATOR_MASTER = 23,
	SURVEILLANCE_INDICATOR_MESSAGE_MASTER = 24,
	PHYSICAL_MARGIN_CONFIGURATION = 25,
	BROKERAGE_CHARGES_MASTER = 26,
	MARKET_CAPITALISATION_MASTER = 27,
	MCX_SECURITY_MASTER = 28,
    MCX_FO_PARTICIPANT_MASTER = 29,
    BSE_CM_SECURITY_MASTER = 30,
    BSE_CM_PARTICIPANT_MASTER = 31,
    BSE_FO_PARTICIPANT_MASTER = 32,
    INTEROP_MASTER = 33
}

public enum CTCL_EMInformationIdentifierEnum : short
{
    ENTITY_CATEGORY_MASTER = 1,
    ENTITY_TYPE_MASTER = 2,
    ENTITY_MASTER = 3,
    ENTITY_CONTACT_DETAIL_MASTER = 4,
    ENTITY_KYC_DETAILS_MASTER = 5,
    ENTITY_CONTACT_TO_ENTITY_MAPPING_MASTER = 6,
    EXCHANGE_SEGMENT_INFO_DB = 7,
    SECURITY_INFO_DB = 8,
    PRIVILEGE_TEMPLATE_DB = 9,
    PRIVILGE_ATTRIBUTE_DB = 10,
    ENTITY_PRIVILEGE_TEMPLATE_MAPPING = 11,
    CONNECTION_LOG = 12,
    INSTRUMENT_ATTRIBUTE_DB = 13,
    INSTRUMENT_BASKET_ENTITY_MAPPING = 14,
    LOCK_USER_INFO_DB =15,

	RMS_LIMIT_TEMPLATE = 16,
	RMS_LIMIT_TEMPLATE_ATTRIBUTE = 17,
	USER_TO_RMS_MAPPING = 18,
	RMS_USER_DEPOSIT = 19,

	QVL_TEMPLATE_MASTER = 20,
	QVL_ATTRIBUTE_MASTER = 21,
	QVL_MAPPING_MASTER = 22,

	CRP_TEMPLATE_ATTRIBUTE_MAPPING = 23,
	CRP_TEMPLATE_USER_MAPPING = 24,

	DEALER_CLIENT_MAPPING = 25,
    CLIENT_RISK_PROFILE_MAPPING = 26,
    CLIENT_PARTICIPANT_MAPPING = 27,
    LICENSE_VALIDATION_MESSAGE=28,
	DPR_MASTER = 29,
    ConfigurationMaster = 30,
	RMS_TRANSACTION_TEMPLATE = 31,
	RMS_TRANSACTION_MAPPING = 32
}


public enum CTCL_AvailabilityStatus : short
{

    Connected = 1,
    Disconnected = 2,   
}

public enum CTCL_ControlLevel : short
{
	[Description("Exchange")]
	Exchange = 1,
	[Description("Asset")]
	Asset = 2,
	[Description("SubAsset")]
	SubAsset = 3,
	[Description("Instrument")]
	Instrument = 4,
	[Description("Sub Instrument")]
	SubInstrument = 5,
	[Description("Segment")]
	Segment = 6,
	[Description("Instrument Asset Mapping")]
	InstrumentAssetMapping = 7,
	[Description("Individual Exchange Defined Token")]
	IndividualExchangeDefinedToken = 8,
}

public enum CTCL_PermissionType : short
{
	Allowed = 1,
	DisAllowed = -1
}

public enum CTCL_InstrumentAssetMapping : short 
{ 
    EQ_DERIVATIVE = 1,
    EQ_SPOT = 2,
    COMMODITY_DERIVATIVE = 4,
    COMMODITY_SPOT = 8
}

public enum CTCL_OperationMode
{
    ADD = 1,
    REMOVE = 2,
	UPDATE = 3
}

public enum CTCL_EventType 
{ 
    ORDER_ENTRY_TRANSACTION_VALIDATION_FAIL = 1
}

public enum CTCL_SeverityCode 
{ 
    INFO = 1,
    WARNING = 2,
    ERROR = 3,
    FATAL_ERROR = 4
}

public enum CTCL_EventStatusCode 
{ 
    SUCCESS = 1,
    ERROR = 2,
    WARNING = 3
}


public enum CTCL_StrikePriceType
{
	ATM = 1,
	OTM = 2,
	ITM = 3
}

public enum CTCL_ExpiryType
{
	CURRENT = -1,
	NEAR = -2,
	FAR = -3,
	OTHERS = -4
}

public enum CTCL_QVLInformationIdentifierEnum : short
{
	QVL_TEMPLATE_MASTER = 1,
    QVL_ATTRIBUTE_MASTER = 2,
    QVL_MAPPING_MASTER = 3
}

public enum CTCL_CRPIdentifierEnum : short
{
	CRP_TEMPLATE_ATTRIBUTE_MAPPING = 1,
    CRP_TEMPLATE_USER_MAPPING = 2
}

public enum CTCL_CRPDataType
{
    TEXT = 1,
    INTEGER = 2,
    BOOLEAN = 3
}

public enum CTCL_MSGInformationIdentifiers : short
{
	TRADE_BOOK = 1,
	ORDER_BOOK = 2,
	SURVEILLANCE_ORDER_BOOK = 3,
    DEMAT_HOLDING = 4,
	PARTICIPANT_TRADE_ACKNOWLEDGEMENT = 5,
	RMS_POSITION = 6,
}

public enum CTCL_RMSInformationIdentifiers : short
{
	RMS_LIMIT_TEMPLATE = 1,
	RMS_LIMIT_TEMPLATE_ATTRIBUTE = 2,
	USER_TO_RMS_MAPPING = 3,
    RMS_USER_DEPOSIT = 4,

}
public enum CTCL_Auction_Status : short
{
    AUCTION_PENDING_APPROVAL = 1,
    AUCTION_PENDING = 2,
    OPEN_COMPETITIOR_PERIOD = 3,
    OPEN_SOLICITOR_PERIOD = 4,
    AUCTION_MATCHING = 5,
    AUCTION_FINISHED = 6,
    AUCTION_CXLED = 7
}

public enum CTCL_Market_Status : short
{
    Undefined,
    PreOpen_Started,
    PreOpen_Closed,
    NormalOpen_Started,
    NormalOpen_Closed,
    PostClose_Started,
    PostClose_Closed
}
public enum FinRMSSubscriptionTypes
{
	Consolidated = 1,
	DetailedTokenWise = 2,
    ConsolidatedScriptWise = 3,
	DetailedDataScriptWise = 4
}
public enum FinRMSSubscription
{
	SUBSCRIBE = 1,
	UNSUBSCRIBE = 2
}

public enum CTCL_SourceType : short
{
    ThickClient = 1,
    TradingApi = 2,
    IBTInteractiveApi = 3,
    MarketApi = 4,
    IBTMarketApi = 5,
    GatewayApi = 6,
	AdminAPI = 7,
}

public enum CTCL_ApiType
{
    PlaceOrder = 1,
    ModifyOrder = 2,
    CancelOrder = 3,
    CancelAllOrder = 4,
    GetOrderBook = 5,
    GetOrderHistory = 6,
    GetTradeBook = 7,
    GetHoldings = 8,
    GetPositions = 9,
    GetBalance = 10,
}

public enum CTCL_ThrottlingTemplate
{
    NORMAL = 1,
    PREMIUM = 2,
    GLOBAL = -1,
}

public enum CTCL_AccessAllowed : short
{ 
    IBT = 1,
    MOBILE = 2
}

public enum CTCL_DisclaimerSeverity : short
{
	Warning = 1,
	Strict = 2
}

public enum CTCL_DisclaimerFrequency : short
{
	Recurring = 1,
	NonRecurring = 2
}

[Flags]
public enum CTCL_SpecialPrivilege : short
{
    [Description("Before Pre order")]
    BeforePreOrder = 1,
    [Description("Pre market order")]
    PreMarketOrder = 2,
    [Description("Post market order")]
    PostMarketOrder = 4
}

public enum LicenseValidationType
{
    ValidateMacAddress,
    ValidateExpirayDate,
    ValidateExchangeSegment,
    ValidateBrokerID,
    ValidateTraderID,
    ValidateUserCategory,
    ValidateMaxConcurrentUserAllowed,
    ValidateMaxTransactionAllowed,
    ValidateFrontEndType
}

public enum CTCL_IndexToken : short
{
    NIFTY50 = 1,
    NIFTY100 = 2,
    NIFTY200 = 3,
    BANKNIFTY = 4,
    MID_CAP_NIFTY = 5,
    BANKEX = 6,
    SENSEX = 7,
}

public enum CTCL_ExchangeSource : short
{
    BSE,
    NSE,
    MSE,
    NCD,
    MCX,
    NCL,
    NCCL,
    BCC,
    ICCL,
    CTC,
}
public enum CTCL_ExchangeSegment
{
    FO,
CM,
CD,
CO

}
public enum CTCL_Instrument_Type
{
    COM,
    STK,
    CUR,
    COF,
    COO,
    STF,
    STO,
    FUO,
    IDF,
    IDO,
    CDF,
    CDO,
    IRF,
    IRO,
    IRT

}
public enum CTCL_Option_Type
{
 XX
,CE
,PE
,CA
,PA
}


public enum CTCL_OrderParticipantMakerCheckerStatus : short
{
	AWAITED,
	APPROVE,
	REJECT,
	AUTOAPPROVE,
	AUTOREJECT,
}
public enum CTCL_BrokerageType : short
{
	PercentAge = 1,
	Flat = 2
}
public enum CTCL_DeliveryObligationFlag : short
{
	NotApplicable = -1,
	NotAccepted = 0,
}
public enum ComponentHandshakeStatus
{
	START = 1,
	INIT_START = 2,
	INIT_COMPLETE = 3,
	READY_TO_ROUTE = 4,
	INACTIVE = 5,
}

public enum CTCL_CertificateAplicability : short
{
	NON_MANDATORY = 0,
	MANDATORY = 1
}

public enum CTCL_CertificateStatus : short
{
	EXPIRED = 0,
	ACTIVE = 1
}

public enum CTCL_UploadFileType : short
{
	KYC = 1,
	CERTIFICATE = 2
}

public enum CTCL_AdjustmentAttributeType : short 
{ 
    QUANTITY = 1,
    PRICE = 2 
}

public enum CTCL_CorporateActionType : short
{ 
    BONUS = 1,
    RIGHTS = 2,
    MERGER = 3,
    DEMERGER = 4,
   // AMALGAMATION  = 5,
    SPLITS = 6,
   // CONSOLIDATIONS = 7,
  //  HIVEOFF = 8,
  //  WARRANTS = 9,
  //  SPNs = 10

}

public enum CTCL_Enviornment :short
{
    Live=1,
    Test=2,
    Mock=3,
    Dev=4,
    Sim=5
}

public enum CTCL_EntityCategoryEnum : short
{
    CategoryAdmin = 1,
    CategoryGrpAdmin = 2,
    CategoryDMAUser = 4,
    CategoryDealer = 8,
    CategoryClient = 16,
    CategoryProDealer = 32,
    CategorySuperDealer = 64,
    CategoryAPIDealer = 128,
    CategoryIBTDealer = 254,
    CategoryShadowAdmin = 512,
    CategoryShadowGroupAdmin = 1024
}

public enum CTCL_EquitySegment : short 
{ 
    NSE_CM = 2,
    BSE_CM = 8,
}

public enum CTCL_DerivativeSegment : short
{
    NSE_FO = 1,
    MCX_FO = 4,
}

public enum CTCL_SquareOffType
{
    MTMSquareOff = 1,
    TimerSquareOff = 2
}


public enum CTCL_AdminInformationIdentifiersEnum : short
{
	INTERACTIVE_GATEWAY_STATUS = 1,

}

public enum PositionType
{
    Day,
    Expiry
}

[Flags]
public enum CTCL_LimitIndicator : short
{
	Buy = 1,
	Sell = 2,
    Turnover = 3
}