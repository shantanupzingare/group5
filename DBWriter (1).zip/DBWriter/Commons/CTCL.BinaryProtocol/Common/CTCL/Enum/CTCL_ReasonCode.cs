﻿namespace CTCL.BinaryProtocol.Common.CTCL.Enum;

public enum CTCL_ReasonCode : short
{
    Exercise = 2,
    Positionliquidation = 3,
    Security = 5,
    Broker = 6,
    Branch = 7,
    User = 8,
    Participant = 9,
    CounterParty = 10,
    OrderNumber = 11,
    AuctionNumber = 15,
    OrderType = 16,
    PriceFreeze = 17,
    QuantityFreeze = 18,
    Contract = 20,
    ExerciseModeMismatch = 30
}
