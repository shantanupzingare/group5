﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Enum
{
	public class EntityCategoryConst
	{
		public const string CategoryAdmin = "ADMIN";
		public const string CategoryGrpAdmin = "GRPADMIN";
		public const string CategoryDMAUser = "DMAUSER";
		public const string CategoryDealer = "DEALER";
		public const string CategoryClient = "CLIENT";
		public const string CategoryProDealer = "PRODEALER";
		public const string CategorySuperDealer = "SUPERDEALER";
		public const string CategoryAPIDealer = "APIDEALER";
		public const string CategoryIBTDealer = "IBTDEALER";
		public const string CategoryShadowAdmin = "SHADOWADMIN";
		public const string CategoryShadowGroupAdmin = "SHADOWGROUPADMIN";
	}

	public class DefaultTemplate
	{
		public const string ContractTemplate = "DTDEFAULT";
		public const string QVLDefaultTemplate = "QVLDEFAULT";
		public const string TERDefaultTemplate = "TERDEFAULT";
		public const string MCAPDefaultTemplate = "MCAPDEFAULT";
	}
    public class ParticipantStatusConst
    {
        public const string Active = "A";
        public const string VoluntaryCloseOut  = "V";
        public const string Suspended = "S";
    }
    public class DeleteFlagConst
    {
        public const string YES = "Y";
        public const string NO = "N";
    }
	public class CRPAttributeNameConst
	{
		public const string CARRY_FORWARD_POSITION = "CARRY_FORWARD_POSITION";
		public const string CNC_SELL_BYPASS = "CNC_SELL_BYPASS";
		public const string IS_GROSSING_ALLOWED = "IS_GROSSING_ALLOWED";
		public const string CFS_PERCENTAGE = "CFS_PERCENTAGE";
		public const string FO_RELEASED_PERCENTAGE = "FO_RELEASED_PERCENTAGE";
		public const string IS_UCC_HOLDING = "IS_UCC_HOLDING";
	}
	public class PhysicalMarginAppliedFiledConst
	{
		public const string VarElmAdhoc = "VAR_ELM_ADHOC";
		public const string ContractValue = "CONTRACT_VALUE";
	}
}