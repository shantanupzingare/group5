﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.CRP.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CRP_MASTER_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_StatusString StatusString;
		public CTCL_CRPResponseBuffer ResponseBuffer;
	}
}
