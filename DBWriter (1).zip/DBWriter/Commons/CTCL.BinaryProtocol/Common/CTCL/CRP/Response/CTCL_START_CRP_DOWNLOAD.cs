﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.CRP.CRPModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.CRP.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_CRP_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_CRP_MAPPING_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EMInformationIdentifier EMIdentifier;
		public CRPTemplate Template;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
		//public CTCL_Id CRPTemplateId;
		//public CTCL_CRP_AttributeName CRPAttributeName;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CRP_MAPPING_UPDATE_DOWNLAOD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EMInformationIdentifier EMIdentifier;
		public CTCL_MessageLength MessageLength;
		public CTCL_Id CRPTemplateId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofMapping;
		public CTCL_EMData CRPMappingData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_CRP_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EMInformationIdentifier EMIdentifier;
		public CTCL_Id CRPTemplateId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_CRP_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}
}
