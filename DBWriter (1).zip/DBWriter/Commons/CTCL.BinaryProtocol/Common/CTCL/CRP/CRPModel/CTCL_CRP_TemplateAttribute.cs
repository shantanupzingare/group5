﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.CRP.CRPModel
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CRP_ATTRIBUTE : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id CRPAttributeId;
		public CTCL_CRP_AttributeName CRPAttributeName;
		public CTCL_CRPDataType AttributeDatatype;
		public CTCL_AttributeLength AttributeLength;
		public CTCL_Filler10 Filler;
		public CTCL_ProductType ProductType;
		public CTCL_ExchangeSegmentId SegmentId;
	}
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CRPTemplate : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id CRPTemplateId;
		[Validator(validationType.alpha_numeric, "Please enter valid template name")]
		public CTCL_CRP_AttributeName CRPTemplateName;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CRP_TemplateAttribute : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id CRPTemplateId;
		public CTCL_Id CRPAttributeId;
		public CTCL_CRPValue CRPValue;
	}
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CRP_TemplateUser : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_STRTerminalID TerminalID;
		public CTCL_OperationMode OperationMode;
	}
}
