﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Response.EnterpriseMaster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Admin
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Enterprise_Master_Response
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_RequestContext ContextIdentifier;
        public StatusCode statusCode;
        public CTCL_StatusString StatusString;
        public CTCL_EMContext Data;
    }

}
