﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ADMIN_LDB_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecords TotalNoOfRecords;
        public List<AdminIncrementalUpdateInfo>  UpdateInfo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class AdminIncrementalUpdateInfo 
    {
        public CTCL_AdminInformationIdentifier  AdminInformationIdentifier;
        public CTCL_TimeStamp LastUpdateTimestamp;
    }

}
