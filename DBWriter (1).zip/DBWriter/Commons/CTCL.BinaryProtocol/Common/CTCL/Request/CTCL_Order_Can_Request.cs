﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Can_Request
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_OrderDetails OrderDetails;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
    public CTCL_DateTime_OMS OrderEntryTime;    
}
