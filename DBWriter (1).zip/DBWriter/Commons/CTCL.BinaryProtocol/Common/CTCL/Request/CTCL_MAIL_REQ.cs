﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Licensing.DataType;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MAIL_REQ
{
	public CTCL_MessageHeader MessageHeader;
	public CTCL_TerminalID TerminalID;
	//public List<CTCL_Email> Email;
	public CTCL_TotalNoOfRecords totalEmailIdCount;
	public CTCL_Email[] Email= new CTCL_Email[20];
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_LICENSE_EXPIRY_EMAIL
{
    public CTCL_MessageHeader MessageHeader;    
    public CTCL_Email Email;
	public CTCL_TimeStamp ExpiryDate;
	public LicenseStr ClientName;
}
