﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_API_CLIENT_CREDENTIALS_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_API_CLIENT_CREDENTIALS
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_SUB_API_CLIENT_CREDENTIALS
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_API_CLIENT_CREDENTIALS_UPDATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofParticipant;
        public CTCL_ApiClientDetails ApiClientDetails;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_SUB_API_CLIENT_CREDENTIALS
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_API_CLIENT_CREDENTIALS
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    }
}
