﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Entry_Request
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_OrderDetails OrderDetails;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Xmitted_Cancel_Request
{
	public CTCL_MessageHeader MessageHeader;
	public CTCL_OrderDetails OrderDetails;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Xmitted_Cancel_Reject
{
	public CTCL_MessageHeader MessageHeader;
	public CTCL_OrderDetails OrderDetails;
	public CTCL_Message ErrorMessage;
}
