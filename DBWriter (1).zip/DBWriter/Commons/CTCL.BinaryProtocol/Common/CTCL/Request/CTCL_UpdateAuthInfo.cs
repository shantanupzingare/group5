﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UpdateAuthInfo
    {
        public CTCL_TerminalID TerminalID;
        public CTCL_Password OldAuthInfo;
        public CTCL_Password NewAuthInfo;
    }
}
