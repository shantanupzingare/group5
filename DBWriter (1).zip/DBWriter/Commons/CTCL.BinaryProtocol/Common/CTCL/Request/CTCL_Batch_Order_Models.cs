﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Start_Batch_Order_Entry_Request
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData; //10
		public CTCL_Quantity TotalQuantity;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Batch_Order_Entry_Request
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_Order_Entry_Request OrderEntryRequest; //byte records of order entry
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_End_Batch_Order_Entry_Request
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Batch_Order_Entry_Response 
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_Message Message;
	}
}
