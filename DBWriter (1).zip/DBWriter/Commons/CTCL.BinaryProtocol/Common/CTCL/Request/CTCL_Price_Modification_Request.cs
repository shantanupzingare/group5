﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request;


[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Price_Modification_Request
{    
    public CTCL_Token TokenNo;
    public CTCL_TraderId TraderID;
    public CTCL_OrderNumber OrderNumber;
    public CTCL_BuySellIndicator BuySell;
    public CTCL_Price Price;
    public CTCL_Volume Volume;
    public CTCL_DateTime LastModified;
    public CTCL_Reference Reference;
    public CTCL_LastActivityReference LastActivityReference;    
}
