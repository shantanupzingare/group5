﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_User_Disclaimer_Log
    {
        public CTCL_ExchangeSegmentId ExchangeSegmentId;
        public CTCL_Flag IsUserAccept;
        public CTCL_TimeStamp TimeStamp;
    }
}
