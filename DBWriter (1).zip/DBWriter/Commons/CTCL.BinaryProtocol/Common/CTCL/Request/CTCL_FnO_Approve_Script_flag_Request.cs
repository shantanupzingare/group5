﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_FnO_Approve_Script_flag_Request
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_Flag IsCheckApproveScript;
	}
}
