﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Version_Handshake_Request
    {
        public CTCL_MessageHeader messageHeader;
        public DeviceType sourceType;
        public CTCL_VersionInfo16 versionNumber;
        public CTCL_EncrKey encrKey;
    }
}
