﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Forgot_Pwd_REQ
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_RequestContext ContextIdentifier;
        public CTCL_TerminalID TerminalID;
    }
}
