﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_EventLogRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EventType EventType;
		public CTCL_SeverityCode SeverityCode;
		public CTCL_EventStatusCode StatusCode;
		public CTCL_LDBData EventData;
	}
}
