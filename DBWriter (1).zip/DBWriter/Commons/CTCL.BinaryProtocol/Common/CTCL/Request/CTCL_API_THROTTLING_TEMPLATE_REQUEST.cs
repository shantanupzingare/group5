﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_API_THROTTLING_TEMPLATE_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_API_THROTTLING_TEMPLATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_SUB_API_THROTTLING_TEMPLATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_API_THROTTLING_TEMPLATE_UPDATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofParticipant;
        public CTCL_ThrottlingTemplate ThrottlingTemplate;
        public CTCL_ApiType ApiType;
        public CTCL_User_Throtlling_Info ThrottlingInfo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_SUB_API_THROTTLING_TEMPLATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_API_THROTTLING_TEMPLATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    }
}
