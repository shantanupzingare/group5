﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_TEMPORARY_PASSWORD_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_TerminalID TerminalID;
		public CTCL_Password TemporaryPassword;
		public CTCL_TotalNoOfRecords totalEmailIdCount;
		public CTCL_Email[] Email = new CTCL_Email[20];
	}
}
