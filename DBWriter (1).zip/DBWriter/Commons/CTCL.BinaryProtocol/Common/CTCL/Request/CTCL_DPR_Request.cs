﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DPR_Request
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_TotalNoOfRecords NoOfRecords;
		public List<CTCL_DPR> DPRs;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_DPR_BYPASS_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData NoOfRecords;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DPR_BYPASS_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_NoOfRecordsofSubData NoOfRecords;
		public CTCL_EMData EMData; // List<CTCL_DPR>
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_DPR_BYPASS_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData NoOfRecords;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DPR_BYPASS_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public StatusCode statusCode;
		public CTCL_StatusString StatusString;
	}
}
