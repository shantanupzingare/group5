﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.Broadcast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_LOCAL_DB_DOWNLOAD_REQ
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_TotalNoOfRecords totalNoOfRecords;
        public List<LDBIncrementalUpdateInfo> LDBContext;

    }
}
