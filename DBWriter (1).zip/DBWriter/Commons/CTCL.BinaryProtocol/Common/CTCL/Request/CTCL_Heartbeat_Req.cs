﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_Heartbeat_Req
    {
        public CTCL_MessageHeader MessageHeader;
        public ComponentHandshakeStatus ComponentHandshakeStatus;

    }
}
