﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ExtendedApproveBasket
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ExtendedApproveBasketTemplateAttribute : CTCL_RMSCommonMasterAttributes 
	{
		public CTCL_Id TemplateId;
		public CTCL_ISINNumber ISINNumber;
		public CTCL_Symbol Symbol;
		public CTCL_BuySellIndicator OperationFlag;
	}
}
