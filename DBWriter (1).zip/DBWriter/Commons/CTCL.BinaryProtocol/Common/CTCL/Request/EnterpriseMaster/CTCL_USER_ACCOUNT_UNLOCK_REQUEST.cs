﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_USER_ACCOUNT_UNLOCK_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId EntityId;
		public CTCL_COMMON_MASTER_ATTRIBUTE CommonMasterAttribute;
	}
}
