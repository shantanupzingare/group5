﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CTCL.Common.CTCL_UserIP;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EMIncrementalUpdateInfo
    {
        public CTCL_EMInformationIdentifier EMDInformationIdentifier;
        public CTCL_TimeStamp lastUpdateTimestamp;
    }
}
