﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ClientParticipant
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CLIENT_PARTICIPANT_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_CLIENT_PARTICIPANT_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_CLIENT_PARTICIPANT_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TerminalID ClientId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_CLIENT_PARTICIPANT_SEGMENTWISE_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_ExchangeSegmentId  ExchangeSegmentId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CLIENT_PARTICIPANT_MASTER_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofParticipant;
		public CTCL_TerminalID ClientId;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public DBWrite.EntityModels.CTCL_CommonMasterAttributes CommonMasterAttributes;
		public CTCL_EMData EMData;
	}


	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_CLIENT_PARTICIPANT_SEGMENTWISE_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_CLIENT_PARTICIPANT_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TerminalID ClientId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_CLIENT_PARTICIPANT_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CLIENT_PARTICIPANT_MAPPING
	{
		public CTCL_OperationMode OperationMode;
		public CTCL_ParticipantId ParticipantId;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CLIENT_PARTICIPANT_MASTER_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_StatusString StatusString;
	}


}
