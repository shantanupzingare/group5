﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.QVL.QVLModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class ENTERPRISE_QuantityValuedLimitRequest 
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_QuantityValuedLimitTemplate QVLTemplate;
	}
	
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_QVLAttribute 
	{
		public CTCL_OperationMode OperationMode;
		public CTCL_QuantityValuedLimitAttribute valuedLimitAttribute;
	}
}
