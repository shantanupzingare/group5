﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;


namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ExtendedApproveBasket.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public  class CTCL_FnoApproveScriptsFlagRequest
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_FnoApproveScriptsFlag FnoApproveScriptsFlag;
    }
}
