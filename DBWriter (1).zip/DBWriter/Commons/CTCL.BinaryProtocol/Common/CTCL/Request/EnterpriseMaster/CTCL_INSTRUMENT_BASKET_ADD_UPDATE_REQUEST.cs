﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_INSTRUMENT_BASKET_ADD_UPDATE_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public CTCL_EntityId CurrentEntityId;
		public CTCL_Name TemplateName;
		public CTCL_Id TemplateId;
		public DBWrite.EntityModels.CTCL_CommonMasterAttributes CommonMasterAttributes;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public List<CTCL_INSTRUMENT_BASKET_ATTRIBUTE> ListOfInstrumentBasketAttribute;
	}
}
