﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_PRIVILEGE_ASSET_INFO
	{
		public CTCL_Exchange Exchange;
		public CTCL_Asset Assets;
		public CTCL_SUBAsset SubAssets;
		public CTCL_Instrument Instrument;
		public CTCL_SubInstrument SubInstrument;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_Id MappingId;
	}
}
