﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ENTERPRISE_MASTER_ADD_UPDATE_REQ
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_MessageLength MessageLength; //for update(length), not sync(no of recored)
        public CTCL_EMContext EMContext; //byte[1024]
        // EmiInformantionIdentier  field need to add after D1
    }
}
