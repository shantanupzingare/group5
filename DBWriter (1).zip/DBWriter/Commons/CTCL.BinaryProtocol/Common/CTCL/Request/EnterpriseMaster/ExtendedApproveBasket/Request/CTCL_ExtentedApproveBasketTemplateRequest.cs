﻿
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ExtendedApproveBasket.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ExtentedApproveBasketTemplateRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ExtendedApproveBasketTemplate ExtendedApproveBasketTemplate;
	}
}
