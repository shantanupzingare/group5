﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_PRIVILEGE_MAPPING
	{
		public CTCL_Id TemplateId;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public CTCL_COMMON_MASTER_ATTRIBUTE CommonMasterAttributes;
		public List<CTCL_EntityId> ListOfEntity;
	}
}
