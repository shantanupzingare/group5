﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_PRIVILEGE_MASTER_ADD_UPDATE_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public CTCL_EntityId CurrentEntityId;
		public CTCL_Name TemplateName;
		public CTCL_Id TemplateId;
		public CTCL_PRIVILEGE_ITEM PrivilegeItem;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public CTCL_Remark Remark;
		public List<CTCL_PRIVILEGE_ASSET_INFO> ExchangeSegmentMaster;
	}
}
