﻿
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_CONTRACT_MASTER_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_Name FileName;
		public CTCL_TimeStamp LastTimeUpdateTime;
		public CTCL_Id TemplateId;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CONTRACT_MASTER_DATA_DOWNLOAD_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_MessageLength MessageLength;
		public CTCL_EMData ContractMasterData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_CONTRACT_MASTER_DATA_DOWNLOAD
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}
}
