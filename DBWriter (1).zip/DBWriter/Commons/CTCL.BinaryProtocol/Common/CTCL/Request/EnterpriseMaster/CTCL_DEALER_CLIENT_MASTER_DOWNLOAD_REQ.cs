﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DEALER_CLIENT_MASTER_DOWNLOAD_REQ
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_DEALER_CLIENT_MASTER_DOWNLOAD
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_START_SUB_DEALER_CLIENT_MASTER_DOWNLOAD
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TerminalID DealerId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DEALER_CLIENT_MASTER_UPDATE
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofClient;
		public CTCL_TerminalID DealerId;
		public CTCL_EMData EMData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_DEALER_CLIENT_MASTER_DOWNLOAD
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TerminalID DealerId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_DEALER_CLIENT_MASTER_DOWNLOAD
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DEALER_CLIENT_ClientInfo
	{
		public CTCL_TerminalID ClientId;
		public CTCL_OperationMode OperationMode;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DEALER_CLIENT_MASTER_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public StatusCode statusCode;
		public CTCL_StatusString StatusString;
	}
}
