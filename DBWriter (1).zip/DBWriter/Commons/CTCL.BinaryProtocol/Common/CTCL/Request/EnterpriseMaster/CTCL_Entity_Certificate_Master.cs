﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_CERTIFICATE_UPDATE_START_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_CERTIFICATE_UPDATE_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EntityId EntityId;
		public CTCL_Entity_Certificate_Info EntityCertificateInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_CERTIFICATE_UPDATE_END_REQUEST
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public CTCL_EntityId EntityId;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_CERTIFICATE_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_StatusString StatusString;
	}
}
