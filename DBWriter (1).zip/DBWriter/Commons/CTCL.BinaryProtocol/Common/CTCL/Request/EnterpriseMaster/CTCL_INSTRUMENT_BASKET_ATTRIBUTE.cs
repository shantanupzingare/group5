﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_INSTRUMENT_BASKET_ATTRIBUTE
	{
		public CTCL_ControlLevel ControlLevel;
		public CTCL_Token UniqueIdentifer;
		public CTCL_PermissionType PermissionType;

	}
}
