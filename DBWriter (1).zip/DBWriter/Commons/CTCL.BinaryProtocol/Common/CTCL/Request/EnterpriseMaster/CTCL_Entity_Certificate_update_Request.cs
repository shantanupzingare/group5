﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Entity_Certificate_Info : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_Id MasterCertificateId;
		public CTCL_Id AttributeId;
		public CTCL_CertificateNumber CertificateNumber;
		public CTCL_TimeStamp CertificateExpriyTimeStamp;
		public DBWrite.EntityModels.CTCL_FilePath UploadPath;
		public CTCL_Remark Remarks;
		public CTCL_OperationMode OperationMode;
	}
}
