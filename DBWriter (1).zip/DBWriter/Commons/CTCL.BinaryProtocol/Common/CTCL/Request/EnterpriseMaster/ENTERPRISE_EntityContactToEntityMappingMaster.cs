﻿using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class ENTERPRISE_EntityContactToEntityMappingMaster
    {
        public CTCL_MessageHeader MessageHeader;
        public EntityContactToEntityMappingMaster entityContactToEntityMapping;
    }

}
