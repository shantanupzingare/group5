﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ExtendedApproveBasket
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ExtendedApproveBasketUserMapping : CTCL_RMSCommonMasterAttributes
	{
		public CTCL_Id TemplateId;
		public CTCL_TerminalID TerminalId;
	}
}
