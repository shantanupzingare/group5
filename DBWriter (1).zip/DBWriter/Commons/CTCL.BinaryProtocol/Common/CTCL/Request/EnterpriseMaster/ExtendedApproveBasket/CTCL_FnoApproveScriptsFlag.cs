﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;


namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster.ExtendedApproveBasket
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_FnoApproveScriptsFlag : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Symbol symbol;
    }
}
