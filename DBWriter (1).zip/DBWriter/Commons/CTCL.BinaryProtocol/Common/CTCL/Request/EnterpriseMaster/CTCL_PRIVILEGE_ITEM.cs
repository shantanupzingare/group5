﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_PRIVILEGE_ITEM
	{
		public CTCL_OperationType OperationType;
		public CTCL_OrderType OrderType;
		public CTCL_BuySellIndicator BuySellIndicator;
		public CTCL_TransactionValidity ValidityType;
		public CTCL_AccountType ClientType;
		public CTCL_SpecialPrivilege SpecialPrivilege;
		public CTCL_ProductType ProductType;
	}
}
