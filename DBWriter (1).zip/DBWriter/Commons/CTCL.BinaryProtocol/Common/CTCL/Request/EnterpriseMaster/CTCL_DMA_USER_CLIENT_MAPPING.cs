﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Request.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DMA_USER_CLIENT_MAPPING
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_TerminalID DMAUser;
		public CTCL_TerminalID DMAUccClient;
	}
}
