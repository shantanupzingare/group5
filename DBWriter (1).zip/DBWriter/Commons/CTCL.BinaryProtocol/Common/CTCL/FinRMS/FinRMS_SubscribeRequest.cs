﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.FinRMS;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class FinRMS_SubscribeRequest
{
	public CTCL_MessageHeader MessageHeader;
	public FinRMSSubscriptionTypes SubscriptionType;
	public FinRMSSubscription Subscription;
	public CTCL_SubscribeName SubscribeName;
}
