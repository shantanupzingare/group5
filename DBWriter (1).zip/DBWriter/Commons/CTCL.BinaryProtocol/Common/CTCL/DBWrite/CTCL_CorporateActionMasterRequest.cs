﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CorporateActionMasterRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_CorporateActionMaster CorporateActionMaster;

	}
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CorporateActionMaster 
	{
		public CTCL_Id Id;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_ISINNumber ISINNumber;
		public CTCL_CorporateActionType  CorporateActionType;
		public CTCL_AdjustmentAttributeType AdjustmentAttributeType;
		public CTCL_ISINNumber TargetISINNumber;
		public CTCL_TimeStamp RecordDate;
		public CTCL_Numerator Numerator;
		public CTCL_Denominator Denominator;
		public CTCL_Id Priority;
		public CTCL_TimeStamp LastUpdatedOn;
		public CTCL_EntityId LastUpdatedBy;
		public CTCL_ReserveLong Reserve1;
		public CTCL_ReserveLong Reserve2;
		public CTCL_ReserveChar16 Reserve3;
		public CTCL_ReserveChar16 Reserve4;
    }

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_CorporateActionMasterRemoveRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_Id Id;
		public CTCL_TimeStamp LastUpdatedOn;
		public CTCL_EntityId LastUpdatedBy;
	}
}
