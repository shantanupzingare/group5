﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class Segment_Wise_GetwayConfiguration 
    {
        public CTCL_ExchangeIdentifier exchangeIdentifier;
        public CTCL_BrokerID brokerID;
        public CTCL_TraderId traderId;
        public CTCL_AvailabilityStatus availabilityStatus;
        public CTCL_BrokerName brokerName;
        //public Int32 InstanceID;
    }
}
