﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_LIMIT_TEMPLATE_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RMSTemplateId RmsLimitTemplateMasterId;
		[Validator(validationType.alpha_numeric, "Special characters not allowed in Entity name.")]
		public CTCL_RMS_TemplateName RMS_TemplateName;
		[Validator(validationType.alpha_numeric, "Template Owner is required")]
		public CTCL_TerminalID TemplateOwner;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
	}
}
