﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_EquityPositionInfoRequest 
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EquityPositionInfo  EquityPositionInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DerivativePositionInfoRequest 
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_DerivativePositionInfo  DerivativePositionInfo;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_BasePositionInfo
	{
		public CTCL_TerminalID DealerId;
		public CTCL_TerminalID ClientId;
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_AccountType AccountType;
		public CTCL_Token Token;
		public CTCL_Symbol Symbol;
		public CTCL_TimeStamp RecordDate;
		public CTCL_Remark Remark;
		public CTCL_StatusCode Status;
		public CTCL_TimeStamp LastUpdateTime;
		public CTCL_EntityId LastUpdateBy;

		public virtual Responses Update(CTCL_EquityPositionInfo equityPositionInfo)
		{
			return new Responses();
		}

		public virtual Responses Update(CTCL_DerivativePositionInfo  derivativePositionInfo)
		{
			return new Responses();
		}
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_EquityPositionInfo : CTCL_BasePositionInfo
	{
		public CTCL_Series Series;
		public CTCL_ISINNumber ISINNumber;
		public CTCL_Quantity BuyQuantity;
		public CTCL_Price BuyAverage;

		public override Responses Update(CTCL_EquityPositionInfo target)
		{
			Responses response = new();
			try
			{
				DealerId = target.DealerId;
				ClientId = target.ClientId;
				ExchangeSegmentId = target.ExchangeSegmentId;
				AccountType = target.AccountType;
				Token = target.Token;
				Symbol = target.Symbol;
				RecordDate = target.RecordDate;
				Remark = target.Remark;
				Status = target.Status;
				Series = target.Series;
				ISINNumber = target.ISINNumber;
				BuyQuantity = target.BuyQuantity;
				BuyAverage = target.BuyAverage;
				LastUpdateTime = target.LastUpdateTime;
				LastUpdateBy = target.LastUpdateBy;

				response.Set(StatusCode.Success, "Equity position info is updated");
			}
			catch (Exception ex)
			{
				response.Set(StatusCode.Failure, $"Exception occured while updating equity position info | {ex}");
			}
			return response;
		}

	}
	
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_DerivativePositionInfo : CTCL_BasePositionInfo
	{
		public CTCL_Quantity BuyQuantity;
		public CTCL_Price BuyAverage;
		public CTCL_Quantity SellQuantity;
		public CTCL_Price SellAverage;
		public CTCL_BuySellIndicator BuySellIndicator;
        public CTCL_Settlor Settlor;
        public override Responses Update(CTCL_DerivativePositionInfo target) 
		{
			Responses response = new();
			try
			{
				DealerId = target.DealerId;
				ClientId = target.ClientId;
				ExchangeSegmentId = target.ExchangeSegmentId;
				AccountType = target.AccountType;
				Token = target.Token;
				Settlor = target.Settlor;
				Symbol = target.Symbol;
				RecordDate = target.RecordDate;
				Remark = target.Remark;
				Status = target.Status;
				BuyQuantity = target.BuyQuantity;
				BuyAverage = target.BuyAverage;
				SellQuantity = target.SellQuantity;
				SellAverage = target.SellAverage;
				BuySellIndicator = target.BuySellIndicator;
				LastUpdateTime = target.LastUpdateTime;
				LastUpdateBy = target.LastUpdateBy;

				response.Set(StatusCode.Success, "Derivative position info is updated");
			}
			catch (Exception ex)
			{
				response.Set(StatusCode.Failure, $"Exception occured while updating derivative position info | {ex}");
			}
			return response;
		}
	}
}
