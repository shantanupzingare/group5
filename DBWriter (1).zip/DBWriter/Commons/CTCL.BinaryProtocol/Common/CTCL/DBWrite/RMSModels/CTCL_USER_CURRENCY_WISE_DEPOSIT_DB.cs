﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_USER_CURRENCY_WISE_DEPOSIT_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_PrimaryId DepositId;
		public CTCL_TerminalID TerminalId;
		public CTCL_CurrencyId DepositCurrencyId;
		public CTCL_DepositAmount DepositCurrencyAmount;
		public CTCL_TimeStamp DepositDate;
		public CTCL_TimeStamp CreatedOn;
		public CTCL_TimeStamp ModifiedOn;
		public CTCL_EntityId CreatedBy;
		public CTCL_EntityId ModifiedBy;
	}
}
