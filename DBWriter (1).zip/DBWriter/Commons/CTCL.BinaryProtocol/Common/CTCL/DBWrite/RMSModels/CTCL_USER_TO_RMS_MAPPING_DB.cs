﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_USER_TO_RMS_MAPPING_DB
	{
		public CTCL_MessageHeader MessageHeader;
		[Validator(validationType.alpha_numeric, "Please enter a valid Terminal id")]
		public CTCL_TerminalID TerminalId;
		[Validator(validationType.numericRequired, "Please enter a valid Template master id")]
		public CTCL_RMSTemplateId RmsLimitTemplateMasterId;
		public CTCL_RMS_Remark Remark;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
	}
}
