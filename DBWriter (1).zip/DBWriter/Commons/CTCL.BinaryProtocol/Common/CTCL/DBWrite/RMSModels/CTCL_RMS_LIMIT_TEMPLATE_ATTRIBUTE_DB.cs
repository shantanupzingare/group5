﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.RMS.RmsLimitMaster;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.RMSModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_RMS_LIMIT_TEMPLATE_ATTRIBUTE_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RMSTemplateId RmsLimitTemplateAttributeId;
		public CTCL_RMSTemplateId RmsLimitTemplateMasterId;
		[NestedValidator]
		public CTCL_RMS_LIMIT_TYPES RmsLimitTemplateAttribute;
		public CTCL_RMSCommonMasterAttributes CommonMasterAttributes;
		public CTCL_ExchangeIdentifier Periodicity;
		[Validator(validationType.alpha_numeric, "Template Owner is required")]
		public CTCL_TerminalID TemplateOwner;
	}
}
