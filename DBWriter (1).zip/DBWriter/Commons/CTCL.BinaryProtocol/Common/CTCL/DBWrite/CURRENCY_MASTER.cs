﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CURRENCY_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_CurrencyId CurrencyId;
		public CTCL_CurrencyName CurrencyName;
		public CTCL_CurrencyCode CurrencyCode;
		public CTCL_CurrencySymbol CurrencySymbol;
		public CTCL_CurrencyDepositAllowed IsCurrencyDepositAllowed;
		public CTCL_TimeStamp LastUpdateTimeStamp;
	}
}
