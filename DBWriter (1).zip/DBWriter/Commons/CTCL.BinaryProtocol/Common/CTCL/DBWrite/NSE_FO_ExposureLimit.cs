﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class NSE_FO_ExposureLimit
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		//public CTCL_Token TokenNo;
		//public CTCL_ISINNumber ISIN;
		public CTCL_TimeStamp LocalUpdateDateTime;
		public CTCL_Symbol Symbol;
		public CTCL_InstrumentName InstrumentType;
		public CTCL_PercentageDecimal NormalELMMargin;
		public CTCL_PercentageDecimal AdditionalELMForTrade;
		public CTCL_PercentageDecimal TotalApplicableELM;
	}
}
