﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CURRENCY_CONVERSION_MAPPING_MASTER
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_PrimaryId CurrencyConversionMappingId;
		public CTCL_CurrencyId BaseCurrencyId;
		public CTCL_CurrencyId ConversionCurrencyId;
		public CTCL_CurrencyConversionValue CurrencyConversionValue;
		public CTCL_TimeStamp CurrencyConversionDate;
		public CTCL_TimeStamp CreatedOn;
		public CTCL_TimeStamp ModifiedOn;
		public CTCL_EntityId CreatedBy;
		public CTCL_EntityId ModifiedBy;
	}
}
