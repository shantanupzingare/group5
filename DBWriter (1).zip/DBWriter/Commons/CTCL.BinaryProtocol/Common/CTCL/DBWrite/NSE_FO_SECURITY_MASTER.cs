﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;
using System.Security.AccessControl;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class NSE_FO_SECURITY_MASTER
    {
        public CTCL_MessageHeader Headers;
        public CTCL_Token Token;
        public CTCL_SEC_INFO SecurityInfo;
        public CTCL_IssuedCapital IssuedCapital;
        public CTCL_Quantity WarningQty;
        public CTCL_Quantity FreezeQty;
        public CTCL_CreditRating CreditRating;
        public CTCL_SecEligibility NormalMktEligibility;
        public CTCL_SecEligibility OddLotMktEligibility;
        public CTCL_SecEligibility SpotMktEligibility;
        public CTCL_SecEligibility AuctionMktEligibility; 
		public CTCL_Price IssueRate;
        public CTCL_TimeStamp IssueStartDate;
        public CTCL_TimeStamp InterestPaymentDate;
        public CTCL_TimeStamp IssueMaturityDate;
        public CTCL_Percentage MarginPercentage;
        public CTCL_Quantity MinLot; 
		public CTCL_Quantity BoardLot;
        public CTCL_Price TickSize;
        public CTCL_Name Name;
        public CTCL_TimeStamp ListingDate;
        public CTCL_TimeStamp ExpulsionDate;
        public CTCL_TimeStamp ReadmissionDate;
        public CTCL_TimeStamp RecordDate;
        public CTCL_Price LowPriceRange;
        public CTCL_Price HighPriceRange;
        public CTCL_TimeStamp ExpiryDate;
        public CTCL_TimeStamp NDStartDate;
        public CTCL_TimeStamp NDEndDate;
        public CTCL_EligibilityIndicators EligibilityIndicators; 
        public CTCL_TimeStamp BCStartDate;
        public CTCL_TimeStamp BCEndDate;
        public CTCL_TimeStamp ExStartDate;
        public CTCL_TimeStamp ExEndDate;
        public CTCL_Token OldToken;
        public CTCL_InstrumentName ULInstrument;
        public CTCL_Token ULToken;
        public CTCL_Price IntrinsicValue;
        public CTCL_Price ExtrinsicValue;
        public CTCL_ST_PURPOSE STPurpose;
        public CTCL_TimeStamp LocalUpdateDateTime;
        public CTCL_DeleteFlag DeletedFlag;
        public CTCL_Remark Remark;
        public CTCL_Price BasePrice;
        public CTCL_DecimalLocator DecimalLocator;
        public CTCL_TradingCurrencyId TradingCurrencyId;
        public CTCL_SettlementCurrencyId SettlementCurrencyId;


        public Responses Update(NSE_FO_SECURITY_MASTER target)
        {
            Responses response = new();

            try
            {
                Headers = target.Headers;
                SecurityInfo = target.SecurityInfo;
                NormalMktEligibility = target.NormalMktEligibility;
                OddLotMktEligibility = target.OddLotMktEligibility;
                SpotMktEligibility = target.SpotMktEligibility;
                AuctionMktEligibility = target.AuctionMktEligibility;
                EligibilityIndicators = target.EligibilityIndicators;
                STPurpose = target.STPurpose;

                //Headers.OpCode = target.Headers.OpCode;
                //Headers.TimeStamp = target.Headers.TimeStamp;
                //Headers.MessageLength = target.Headers.MessageLength;
                //Headers.SourceComponentIdentifier = target.Headers.SourceComponentIdentifier;
                //Headers.DestinationComponentIdentifier = target.Headers.DestinationComponentIdentifier;
                //Headers.ExchangeSegmentId = target.Headers.ExchangeSegmentId;

                Token = target.Token;
                //SecurityInfo.InstrumentName = target.SecurityInfo.InstrumentName;
                //SecurityInfo.Symbol = target.SecurityInfo.Symbol;
                //SecurityInfo.Series = target.SecurityInfo.Series;
                //SecurityInfo.ExpiryDate = target.SecurityInfo.ExpiryDate;
                //SecurityInfo.StrikePrice = target.SecurityInfo.StrikePrice;
                //SecurityInfo.CALevel = target.SecurityInfo.CALevel;
                IssuedCapital = target.IssuedCapital;
                WarningQty = target.WarningQty;
                FreezeQty = target.FreezeQty;
                CreditRating = target.CreditRating;
                //NormalMktEligibility.Eligibility = target.NormalMktEligibility.Eligibility;
                //NormalMktEligibility.Status = target.NormalMktEligibility.Status;
                //OddLotMktEligibility.Eligibility = target.OddLotMktEligibility.Eligibility;
                //OddLotMktEligibility.Status = target.OddLotMktEligibility.Status;
                //SpotMktEligibility.Eligibility = target.SpotMktEligibility.Eligibility;
                //SpotMktEligibility.Status = target.SpotMktEligibility.Status;
                //AuctionMktEligibility.Eligibility = target.AuctionMktEligibility.Eligibility;
                //AuctionMktEligibility.Status = target.AuctionMktEligibility.Status;
                IssueRate = target.IssueRate;
                IssueStartDate = target.IssueStartDate;
                InterestPaymentDate = target.InterestPaymentDate;
                IssueMaturityDate = target.IssueMaturityDate;
                MarginPercentage = target.MarginPercentage;
                MinLot = target.MinLot;
                BoardLot = target.BoardLot;
                TickSize = target.TickSize;
                Name = target.Name;
                ListingDate = target.ListingDate;
                ExpulsionDate = target.ExpulsionDate;
                ReadmissionDate = target.ReadmissionDate;
                RecordDate = target.RecordDate;
                LowPriceRange = target.LowPriceRange;
                HighPriceRange = target.HighPriceRange;
                NDStartDate = target.NDStartDate;
                NDEndDate = target.NDEndDate;
                BCStartDate = target.BCStartDate;
                BCEndDate = target.BCEndDate;
                ExStartDate = target.ExStartDate;
                ExEndDate = target.ExEndDate;
                OldToken = target.OldToken;
                //EligibilityIndicators.AON = target.EligibilityIndicators.AON;
                //EligibilityIndicators.MinimumFill = target.EligibilityIndicators.MinimumFill;
                //EligibilityIndicators.IndexParticipant = target.EligibilityIndicators.IndexParticipant;
                ULInstrument = target.ULInstrument;
                ULToken = target.ULToken;
                IntrinsicValue = target.IntrinsicValue;
                ExtrinsicValue = target.ExtrinsicValue;
                //STPurpose.Bonus = target.STPurpose.Bonus;
                //STPurpose.Dividend = target.STPurpose.Dividend;
                //STPurpose.Rights = target.STPurpose.Rights;
                //STPurpose.Interest = target.STPurpose.Interest;
                //STPurpose.AGM = target.STPurpose.AGM;
                //STPurpose.EGM = target.STPurpose.EGM;
                //STPurpose.ExerciseStyle = target.STPurpose.ExerciseStyle;
                //STPurpose.ExAllowed = target.STPurpose.ExAllowed;
                //STPurpose.ExRejectionAllowed = target.STPurpose.ExRejectionAllowed;
                //STPurpose.PlAllowed = target.STPurpose.PlAllowed;
                //STPurpose.IsAsset = target.STPurpose.IsAsset;
                //STPurpose.IsCorporateAdjusted = target.STPurpose.IsCorporateAdjusted;
                DeletedFlag = target.DeletedFlag;
                LocalUpdateDateTime = target.LocalUpdateDateTime;
                Remark = target.Remark;
                BasePrice = target.BasePrice;
                DecimalLocator = target.DecimalLocator;
                TradingCurrencyId = target.TradingCurrencyId;
                SettlementCurrencyId = target.SettlementCurrencyId;

                response.Set(StatusCode.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, "", ex.Message);
            }
            return response;
        }
    }
}


