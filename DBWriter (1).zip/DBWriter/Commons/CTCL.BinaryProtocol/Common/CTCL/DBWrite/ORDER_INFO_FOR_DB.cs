﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Request;
using CTCL.BinaryProtocol.Common.CTCL.Response;
using CTCL.BinaryProtocol.Common.NSE_CM.Request;
using CTCL.BinaryProtocol.Common.NSE_CM.Response;
using CTCL.BinaryProtocol.Common.NSE_FO.Request;
using CTCL.BinaryProtocol.Common.NSE_FO.Response;
using CTCL.Broadcast;
using System.Runtime.InteropServices;
using CTCL_OpCode = CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode;
using Responses = BinaryProtocol.Common.Response;
using StatusCodes = BinaryProtocol.Common.StatusCode;

namespace CTCL.BinaryProtocol.Common.CTCL.DB
{

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class ORDER_INFO_FOR_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_PlatformID PlatformId;
		public CTCL_VersionInfo VersionInfo;
		public CTCL_OpCode OrderOpCode;
		public CTCL_AlphaChar AlphaChar;
		public CTCL_OrderDetails OrderDetails;
		public OrderStatus OrderStatus;  //verified by vk sir 23-5-23
		public CTCL_Status StatusCode;   //added empty enum- vk sir
		public CTCL_TimeStamp TimeStamp1;
		public CTCL_TimeStamp TimeStamp2;
		public CTCL_Period CompetitorPeriod;
		public CTCL_Period SolicitorPeriod;
		public CTCL_Filler1 Filler1;
		public CTCL_SEC_INFO SecurityInformaion;
		public CTCL_AuctionNumber AuctionNumber;
		public CTCL_Suspended Suspended;
		public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
		public CTCL_TimeStamp OrderEntryTime;
		public CTCL_OE_cOrdFiller COrdFiller;
		public CTCL_Settlor SettlorCode;
		public CTCL_SettlementType SettlementType;
		public CTCL_SettlementPeriod SettlementPeriod;
		public CTCL_Flag BOCFlag;
		public CTCL_Flag COLFlag;
		public CTCL_MktReplay MktReplay;
		public CTCL_Message ErrorMessage;
		public CTCL_ApplMsgID ApplMsgID;
        public CTCL_PartitionID PartitionID;

        public CTCL_Reserved1 Reserved1; //CA1
		public CTCL_Reserved2 Reserved2; //bool
		public CTCL_Reserved3 Reserved3; //bool
		public CTCL_Reserved4 Reserved4; //string 4
		public CTCL_Reserved5 Reserved5; //CA1
		public CTCL_Reserved6 Reserved6; //CA2
		public CTCL_Reserved7 Reserved7; //CA1
		public CTCL_Reserved8 Reserved8; //bool
		public CTCL_Reserved9 Reserved9; //bool
		public CTCL_Reserved10 Reserved10; //bool
		public CTCL_Reserved11 Reserved11; //CA1
		public CTCL_Reserved12 Reserved12; //string 52

		public CTCL_BitFiller1 bitFiller1;      //bool
		public CTCL_BitFiller2 bitFiller2;      //bool
		public CTCL_BitFiller3 bitFiller3;      //bool
		public CTCL_BitFiller4 bitFiller4;      //bool
		public CTCL_BitFiller5 bitFiller5;      //bool
		public CTCL_BitFiller6 bitFiller6;      //bool
		public CTCL_BitFiller7 bitFiller7;      //bool
		public CTCL_BitFiller8 bitFiller8;      //bool
		public CTCL_BitFiller9 bitFiller9;      //bool
		public CTCL_BitFiller10 bitFiller10;    //bool
		public CTCL_BitFiller11 bitFiller11;    //bool
		public CTCL_BitFiller12 bitFiller12;    //bool
		public CTCL_BitFiller13 bitFiller13;    //bool
		public CTCL_BitFiller14 bitFiller14;    //bool
		public CTCL_BitFiller15 bitFiller15;    //bool
		public CTCL_BitFiller16 bitFiller16;    //bool
		public CTCL_BitFiller17 bitFiller17;    //CA1
		public CTCL_BitFiller18 bitFiller18;    //CA1
		public ORDER_INFO_FOR_DB()
		{			
		}

		public ORDER_INFO_FOR_DB(ORDER_INFO_FOR_DB orderInfo)
		{
			MessageHeader = orderInfo.MessageHeader;
			OrderDetails = orderInfo.OrderDetails;
			SecurityInformaion = orderInfo.SecurityInformaion;
			PlatformId = orderInfo.PlatformId;
			VersionInfo = orderInfo.VersionInfo;
			OrderOpCode = orderInfo.OrderOpCode;
			AlphaChar = orderInfo.AlphaChar;
			TimeStamp1 = orderInfo.TimeStamp1;
			TimeStamp2 = orderInfo.TimeStamp2;
			OrderStatus = orderInfo.OrderStatus;
			CompetitorPeriod = orderInfo.CompetitorPeriod;
			SolicitorPeriod = orderInfo.SolicitorPeriod;
			AuctionNumber = orderInfo.AuctionNumber;
			Suspended = orderInfo.Suspended;
			ExchangeOrderNumber = orderInfo.ExchangeOrderNumber;
			OrderEntryTime = orderInfo.OrderEntryTime;
			COrdFiller = orderInfo.COrdFiller;
			SettlorCode = orderInfo.SettlorCode;
			SettlementType = orderInfo.SettlementType;
			BOCFlag = orderInfo.BOCFlag;
			COLFlag = orderInfo.COLFlag;
			MktReplay = orderInfo.MktReplay;
			ErrorMessage = orderInfo.ErrorMessage;
		}

		public Responses Update(ORDER_INFO_FOR_DB target)
		{
			Responses response = new();

			try
			{

				MessageHeader = target.MessageHeader;
				OrderDetails = target.OrderDetails;				
				SecurityInformaion = target.SecurityInformaion;
				PlatformId = target.PlatformId;
				VersionInfo = target.VersionInfo;
				OrderOpCode = target.OrderOpCode;
				AlphaChar = target.AlphaChar;			
				TimeStamp1 = target.TimeStamp1;
				TimeStamp2 = target.TimeStamp2;
				OrderStatus = target.OrderStatus;
				CompetitorPeriod = target.CompetitorPeriod;
				SolicitorPeriod = target.SolicitorPeriod;				
				AuctionNumber = target.AuctionNumber;
				Suspended = target.Suspended;
				ExchangeOrderNumber = target.ExchangeOrderNumber;
				OrderEntryTime = target.OrderEntryTime;
				COrdFiller = target.COrdFiller;
				SettlorCode = target.SettlorCode;
				SettlementType = target.SettlementType;
				BOCFlag = target.BOCFlag;
				COLFlag = target.COLFlag;
				MktReplay = target.MktReplay;
				ErrorMessage = target.ErrorMessage;
				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}
		public Responses Update(CTCL_Order_Entry_Request target)
		{
			Responses response = new();

			try
			{

				MessageHeader = target.MessageHeader;
				OrderDetails = target.OrderDetails;

				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}
		public Responses Update(CTCL_Order_Entry_Confirm target)
		{
			Responses response = new();

			try
			{

				MessageHeader = target.MessageHeader;
				OrderDetails = target.OrderDetails;
				ExchangeOrderNumber = target.ExchangeOrderNumber;
				OrderEntryTime.TimeStamp = target.OrderEntryTime.DateTime;

				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}
		public Responses Update(NSE_FO_MS_OE_RESPONSE_TR exchnageResponse)
		{
			Responses response = new();

			try
			{

				ExchangeOrderNumber = new CTCL_ExchangeOrderNumber((long)exchnageResponse.OrderNumber.OrderNumber);


				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}
		public Responses Update(NSE_FO_MS_OE_REQUEST exchnageResponse)
		{
			Responses response = new();
			try
			{
				
				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}

		public Responses Update(NSE_CM_ORDER_OM_RESPONSE_TR exchnageResponse)
		{
			Responses response = new();

			try
			{

				ExchangeOrderNumber = new CTCL_ExchangeOrderNumber((long)exchnageResponse.OrderNumber.OrderNumber);


				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}

		public Responses Update(NSE_CM_MS_TRADE_CONFIRM exchnageResponse)
		{
			Responses response = new();

			try
			{

				ExchangeOrderNumber = new CTCL_ExchangeOrderNumber((long)exchnageResponse.OpOrderNumber.OpOrderNumber);


				response.Set(StatusCodes.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCodes.Failure, "", ex.Message);
			}
			return response;
		}

        public Responses Update(NSE_CM_ORDER_ENTRY_REQUEST exchnageResponse)
        {
            Responses response = new();
            try
            {

                response.Set(StatusCodes.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCodes.Failure, "", ex.Message);
            }
            return response;
        }


        #region OrderModify/CancelReq
        public Responses Update(CTCL_Order_Modify_Request target)
        {
            Responses response = new();

            try
            {

                MessageHeader = target.MessageHeader;
                OrderDetails = target.OrderDetails;
				ExchangeOrderNumber= target.ExchangeOrderNumber;
				OrderEntryTime = new(target.OrderEntryTime.DateTime);

				response.Set(StatusCodes.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCodes.Failure, "", ex.Message);
            }
            return response;
        }

        public Responses Update(CTCL_Order_Can_Request target)
        {
            Responses response = new();

            try
            {

                MessageHeader = target.MessageHeader;
                OrderDetails = target.OrderDetails;
				ExchangeOrderNumber= target.ExchangeOrderNumber;
				OrderEntryTime = new(target.OrderEntryTime.DateTime);

                response.Set(StatusCodes.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCodes.Failure, "", ex.Message);
            }
            return response;
        }
        #endregion

    }
}
