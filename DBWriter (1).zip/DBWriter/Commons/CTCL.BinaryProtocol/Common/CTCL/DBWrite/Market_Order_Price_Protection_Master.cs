﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class Market_Order_Price_Protection_Master
	{
		public CTCL_PrimaryId intId;
		public CTCL_ExchangeSegmentId exchangeSegmentId;
		public CTCL_PercentageDecimal MarketPriceProtectionPCT;
		public CTCL_TimeStamp LastUpdateTimeStamp;
	}
}
