﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.MCAPL
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MCAP_LIMIT_USER_TEMPLATE_MAPPING_DB
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_Id MCAPTemplateID;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofMapping;
        public CTCL_EMData MCAPLimitUserTemplateMappingData; //list of users
    }
}
