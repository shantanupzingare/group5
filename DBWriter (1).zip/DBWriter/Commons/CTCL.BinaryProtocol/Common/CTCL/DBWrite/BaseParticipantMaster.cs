﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class BaseParticipantMaster
    {
        public CTCL_MessageHeader Headers;
        public CTCL_ParticipantId ParticipantID;
        public CTCL_ParticipantName ParticipantName;
        public CTCL_ParticipantStatus ParticipantStatus;
        public CTCL_TimeStamp ParticipantUpdateTime;
        public CTCL_DeleteFlag DeletedFlag;

        public virtual Responses Update(NSE_CM_PARTICIPANT_MASTER_NEW target)
        {
            return new Responses();
        }
        public virtual Responses Update(NSE_FO_PARTICIPANT_MASTER_NEW target)
        {
            return new Responses();
        }

        public virtual Responses Update(MCX_FO_PARTICIPANT_MASTER target)
        {
            return new Responses();
        }
    }
}
