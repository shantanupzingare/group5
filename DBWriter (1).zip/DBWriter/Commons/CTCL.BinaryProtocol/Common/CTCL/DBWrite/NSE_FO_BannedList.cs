﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class NSE_FO_BannedList
    {
        public CTCL_Symbol Symbol;
        public CTCL_TimeStamp LastUpdatedOn;
        public CTCL_Name Name;

        public Responses Update(NSE_FO_BannedList target)
        {
            Responses response = new();

            if(target != null)
            {
                Symbol = target.Symbol;
                LastUpdatedOn = target.LastUpdatedOn;
                Name = target.Name;
                return response.Set(StatusCode.Success, "");
            }
            return response.Set(StatusCode.Failure, "");
        }
    }
}
