﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MARKET_CAPITALISATION
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_TimeStamp TradeDate;
        public CTCL_Symbol Symbol;
        public CTCL_Series Series;
        public CTCL_Name SecurityName;
        //public int Category;
        public CTCL_TimeStamp LastTradedDate;
        public CTCL_DecimalPrice FaceValue;
        public CTCL_IssuedCapital IssueSize;
        public CTCL_DecimalPrice ClosePrice;
        public CTCL_DecimalPrice MarketCap;
        public CTCL_DoublePrice MarketCapPerOneThousandCrore;
    }
}

