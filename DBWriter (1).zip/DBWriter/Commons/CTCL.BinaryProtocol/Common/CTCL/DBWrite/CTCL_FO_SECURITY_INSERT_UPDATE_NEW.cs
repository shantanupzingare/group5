﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_FO_SECURITY_INSERT_UPDATE_NEW
    {
 
            public CTCL_MessageHeader messageHeader;

            public NSE_FO_SECURITY_MASTER_NEW NewSecurity;
    }
}
