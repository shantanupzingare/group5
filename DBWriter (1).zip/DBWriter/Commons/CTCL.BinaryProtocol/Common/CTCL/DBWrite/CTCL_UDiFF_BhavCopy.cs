﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UDiFF_BhavCopy
    {
        public CTCL_ExchangeSegmentId ExchangeSegmentId;
        public CTCL_TimeStamp tradeDate;
        public CTCL_TimeStamp businessDate;
        public CTCL_ExchangeSegment exchangeSegment;
        public CTCL_ExchangeSource exchangeSource;
        public CTCL_Instrument_Type InstrumentType;
        public CTCL_Token InstrumentId;
        public CTCL_ISINNumber ISINNumber;
        public CTCL_Symbol symbol;
        public CTCL_UdiffSeries series;
        public CTCL_TimeStamp Og_ExpiryDate;
        public CTCL_TimeStamp Act_Expiry_Date;
        public CTCL_Price strikePrice;
        public CTCL_Option_Type OptionType;
        public CTCL_UdiffInstrumentName InstrumentName;
        public CTCL_Price OpenPrice;
        public CTCL_Price HighPrice;
        public CTCL_Price LowPrice;
        public CTCL_Price ClosePrice;
        public CTCL_Price LTP;
        public CTCL_Price Previous_Close;
        public CTCL_Price Underlying_Asset_price;
        public CTCL_Price SettlementPrice;
        public CTCL_OpenInterestLong OpenInterest;
        public CTCL_ChangeInOpenInterest changeInOpenInterest;
        public CTCL_Quantity TotalTradedQuantity;
        public CTCL_Price TotalTradedValue;
        public CTCL_NoOfOrders TotalNumberoofTrades;
        public CTCL_SessionID sessionID;
        public CTCL_LotSize lotSize;
        public CTCL_Remark256 Remark;
        public CTCL_Price High52Week;
        public CTCL_Price Low52Week;
        public CTCL_Reserved50 Reservred1;
        public CTCL_Reserved50 Reservred2;
        public CTCL_Reserved50 Reservred3;
        public CTCL_Reserved50 Reservred4;
        public CTCL_TimeStamp  LastUpdateDateTime;

        public Responses Update(CTCL_UDiFF_BhavCopy target)
        {
            Responses response = new();

            try
            {
                ExchangeSegmentId = target.ExchangeSegmentId;
                tradeDate = target.tradeDate;
                businessDate = target.businessDate;
                exchangeSegment = target.exchangeSegment;
                exchangeSource = target.exchangeSource;
                InstrumentType = target.InstrumentType;
                InstrumentId = target.InstrumentId;
                ISINNumber = target.ISINNumber;
                symbol = target.symbol;
                series = target.series;
                Og_ExpiryDate = target.Og_ExpiryDate;
                Act_Expiry_Date = target.Act_Expiry_Date;
                strikePrice = target.strikePrice;
                OptionType = target.OptionType;
                InstrumentName = target.InstrumentName;
                OpenPrice = target.OpenPrice;
                HighPrice = target.HighPrice;
                LowPrice = target.LowPrice;
                ClosePrice = target.ClosePrice;
                LTP = target.LTP;
                Previous_Close = target.Previous_Close;
                Underlying_Asset_price = target.Underlying_Asset_price;
                SettlementPrice = target.SettlementPrice;
                OpenInterest = target.OpenInterest;
                changeInOpenInterest = target.changeInOpenInterest;
                TotalTradedQuantity = target.TotalTradedQuantity;
                TotalTradedValue = target.TotalTradedValue;
                TotalNumberoofTrades = target.TotalNumberoofTrades;
                sessionID = target.sessionID;
                lotSize = target.lotSize;
                Remark = target.Remark;
                High52Week = target.High52Week;
                Low52Week = target.Low52Week;
                Reservred1 = target.Reservred1;
                Reservred2 = target.Reservred2;
                Reservred3 = target.Reservred3;
                Reservred4 = target.Reservred4;
                LastUpdateDateTime = target.LastUpdateDateTime;
                response.Set(StatusCode.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, "", ex.Message);
            }
            return response;
        }


    }
}
