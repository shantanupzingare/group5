﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class DEMAT_HOLDING_DB
	{
		public CTCL_Token Token;
		public CTCL_GroupCode GroupCode;
		public CTCL_TerminalID TerminalId;
		public CTCL_ISINNumber ISIN;
		public CTCL_Quantity Quantity;
		public CTCL_PercentageDecimal HairCutPercent;
		public CTCL_Price Price;
		public CTCL_Quantity CollateralQuantity;
	}

}
