﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]

	public class ADDITIONAL_SURVEILLANCE_MEASURE_MASTER
	{
		public CTCL_Symbol Symbol;
		public CTCL_CompanyName CompanyName;
		public CTCL_ISINNumber ISIN;
		public CTCL_SurveillanceStage AddtionalSurveillanceStage;
		public CTCL_TimeStamp LastUpdateTimeStamp;
	}
}
