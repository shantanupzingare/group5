﻿using BinaryProtocol.Common;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]

    public class NSE_FO_PARTICIPANT_MASTER_NEW:BaseParticipantMaster
    {

    }
}