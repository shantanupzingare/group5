﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Introp
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ISINNumber ISINNumber;
		public CTCL_Symbol BSESymbol;
		public CTCL_Symbol NSESymbol;
		public CTCL_Symbol MESISymbol;
		public CTCL_Symbol ApplicableSymbol;
		public CTCL_Name Description;
		public CTCL_Flag SettlementFlag;
	}
}
