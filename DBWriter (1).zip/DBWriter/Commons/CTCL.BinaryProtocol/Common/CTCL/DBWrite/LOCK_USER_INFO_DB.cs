﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class LOCK_USER_INFO_DB
	{
		public CTCL_EntityId EntityId;
		public CTCL_TerminalID TerminalId;
		public CTCL_TimeStamp LastLoginTime;
	}
}
