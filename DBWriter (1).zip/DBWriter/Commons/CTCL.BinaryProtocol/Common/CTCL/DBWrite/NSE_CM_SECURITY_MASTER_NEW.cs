﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;
using System;
using System.Reflection.PortableExecutable;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class NSE_CM_SECURITY_MASTER_NEW : CM_SECURITY_MASTER
	{
		public CTCL_InstrumentType InstrumentType;
		public CTCL_PermittedToTrade PermittedToTrade;
		public CTCL_IssuedCapital IssuedCapital;
		public CTCL_Percent WarningPercent;
		public CTCL_Percent FreezePercent;
		public CTCL_SecEligibility CallAuc1;
		public CTCL_SecEligibility CallAuc2;
		public CTCL_SurvIndicator SurvInd;
		public CTCL_Reserved Reserved_1Byte;
		public CTCL_Price FaceValue;
		public CTCL_Price MktMakerSpread;
		public CTCL_Quantity MktMakerMinQty;
		public CTCL_CallAuc1Flag CallAuction1Flag; 
		public NSE_CM_ExtremeLossMargin ELM;
		public CTCL_Price DPRLow;
        public CTCL_Price DPRHigh;
		public CTCL_Quantity FreezeQuantity;
		public CTCL_Price PriceTick;

        public override Responses Update(NSE_CM_SECURITY_MASTER_NEW target)
		{
			Responses response = new();
			try
			{
				Headers = target.Headers;
				SecurityInfo = target.SecurityInfo;
				NormalMktEligibility = target.NormalMktEligibility;
				OddLotMktEligibility = target.OddLotMktEligibility;
				SpotMktEligibility = target.SpotMktEligibility;
				AuctionMktEligibility = target.AuctionMktEligibility;
				EligibilityIndicators = target.EligibilityIndicators;
				STPurpose = target.STPurpose;
				InstrumentType = target.InstrumentType;
				PermittedToTrade = target.PermittedToTrade;
				Reserved_1Byte = target.Reserved_1Byte;
				FaceValue = target.FaceValue;
				MktMakerSpread = target.MktMakerSpread;
				MktMakerMinQty = target.MktMakerMinQty;
				//Headers.OpCode = target.Headers.OpCode;
				//Headers.TimeStamp = target.Headers.TimeStamp;
				//Headers.MessageLength = target.Headers.MessageLength;
				//Headers.SourceComponentIdentifier = target.Headers.SourceComponentIdentifier;
				//Headers.DestinationComponentIdentifier = target.Headers.DestinationComponentIdentifier;
				//Headers.ExchangeSegmentId = target.Headers.ExchangeSegmentId;

				Token = target.Token;
				//SecurityInfo.InstrumentName = target.SecurityInfo.InstrumentName;
				//SecurityInfo.Symbol = target.SecurityInfo.Symbol;
				//SecurityInfo.Series = target.SecurityInfo.Series;
				//SecurityInfo.ExpiryDate = target.SecurityInfo.ExpiryDate;
				//SecurityInfo.StrikePrice = target.SecurityInfo.StrikePrice;
				//SecurityInfo.CALevel = target.SecurityInfo.CALevel;
				IssuedCapital = target.IssuedCapital;
                WarningPercent = target.WarningPercent;
                FreezePercent = target.FreezePercent;
				CreditRating = target.CreditRating;
				//NormalMktEligibility.Eligibility = target.NormalMktEligibility.Eligibility;
				NormalMktEligibility.Status = target.NormalMktEligibility.Status;
				//OddLotMktEligibility.Eligibility = target.OddLotMktEligibility.Eligibility;
				OddLotMktEligibility.Status = target.OddLotMktEligibility.Status;
				//SpotMktEligibility.Eligibility = target.SpotMktEligibility.Eligibility;
				SpotMktEligibility.Status = target.SpotMktEligibility.Status;
				//AuctionMktEligibility.Eligibility = target.AuctionMktEligibility.Eligibility;
				AuctionMktEligibility.Status = target.AuctionMktEligibility.Status;
				//IssueRate = target.IssueRate;
				IssueStartDate = target.IssueStartDate;
				InterestPaymentDate = target.InterestPaymentDate;
				IssueMaturityDate = target.IssueMaturityDate;
				//MarginPercentage = target.MarginPercentage;
				//MinLot = target.MinLot;
				BoardLot = target.BoardLot;
				TickSize = target.TickSize;
				Name = target.Name;
				ListingDate = target.ListingDate;
				ExpulsionDate = target.ExpulsionDate;
				ReadmissionDate = target.ReadmissionDate;
				RecordDate = target.RecordDate;
				ExpiryDate = target.ExpiryDate;
				//LowPriceRange = target.LowPriceRange;
				//HighPriceRange = target.HighPriceRange;
				NDStartDate = target.NDStartDate;
				NDEndDate = target.NDEndDate;
				BCStartDate = target.BCStartDate;
				BCEndDate = target.BCEndDate;
				//ExStartDate = target.ExStartDate;
				//ExEndDate = target.ExEndDate;
				//OldToken = target.OldToken;
				//EligibilityIndicators.AON = target.EligibilityIndicators.AON;
				//EligibilityIndicators.MinimumFill = target.EligibilityIndicators.MinimumFill;
				//EligibilityIndicators.IndexParticipant = target.EligibilityIndicators.IndexParticipant;
				//ULInstrument = target.ULInstrument;
				//IntrinsicValue = target.IntrinsicValue;
				//ExtrinsicValue = target.ExtrinsicValue;
				//STPurpose.Bonus = target.STPurpose.Bonus;
				//STPurpose.Dividend = target.STPurpose.Dividend;
				//STPurpose.Rights = target.STPurpose.Rights;
				//STPurpose.Interest = target.STPurpose.Interest;
				//STPurpose.AGM = target.STPurpose.AGM;
				//STPurpose.EGM = target.STPurpose.EGM;
				//STPurpose.ExerciseStyle = target.STPurpose.ExerciseStyle;
				//STPurpose.ExAllowed = target.STPurpose.ExAllowed;
				//STPurpose.ExRejectionAllowed = target.STPurpose.ExRejectionAllowed;
				//STPurpose.PlAllowed = target.STPurpose.PlAllowed;
				//STPurpose.IsAsset = target.STPurpose.IsAsset;
				//STPurpose.IsCorporateAdjusted = target.STPurpose.IsCorporateAdjusted;
				DeletedFlag = target.DeletedFlag;
				LocalUpdateDateTime = target.LocalUpdateDateTime;
				Remark = target.Remark;
				DecimalLocator = target.DecimalLocator;
				ISINNumber = target.ISINNumber;
				SurvInd = target.SurvInd;
				var creditRatingString = new string(target.CreditRating.CreditRating);
				if (creditRatingString.Contains('-'))
				{
					var dpr = creditRatingString.Split("-");
					DPRLow = new CTCL_Price(Convert.ToInt64(Convert.ToDouble(dpr[0]) * 100));
					DPRHigh = new CTCL_Price(Convert.ToInt64(Convert.ToDouble(dpr[1]) * 100));
				}
				FreezePercent.Percent = target.FreezePercent.Percent;
				var freezeQty = Convert.ToInt64(Math.Floor((double)(IssuedCapital.IssuedCapital) * FreezePercent.Percent / 1000000));
				FreezeQuantity = new(freezeQty);
				PriceTick = new(TickSize.Price);
				TradingCurrencyId = target.TradingCurrencyId;
				SettlementCurrencyId = target.SettlementCurrencyId;
				//BasePrice = target.BasePrice;

				response.Set(StatusCode.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCode.Failure, "", ex.Message);
			}
			return response;
		}
		public override Responses Update(NSE_CM_ExtremeLossMargin extremeLossMargin)
		{
			ELM = new NSE_CM_ExtremeLossMargin();
			return ELM.Update(extremeLossMargin);
		}

		public NSE_CM_SECURITY_MASTER_NEW()
		{

		}

		public NSE_CM_SECURITY_MASTER_NEW(NSE_CM_SECURITY_MASTER nseSecurity)
		{
			Headers = nseSecurity.Headers;
			Token = nseSecurity.Token;
			SecurityInfo = nseSecurity.SecurityInfo;
			CreditRating = nseSecurity.CreditRating;
			NormalMktEligibility = nseSecurity.NormalMktEligibility;
			OddLotMktEligibility = nseSecurity.OddLotMktEligibility;
			SpotMktEligibility = nseSecurity.SpotMktEligibility;
			AuctionMktEligibility = nseSecurity.AuctionMktEligibility;
			IssueStartDate = nseSecurity.IssueStartDate;
			InterestPaymentDate = nseSecurity.InterestPaymentDate;
			IssueMaturityDate = nseSecurity.IssueMaturityDate;
			BoardLot = nseSecurity.BoardLot;
			TickSize = nseSecurity.TickSize;
			Name = nseSecurity.Name;
			ListingDate = nseSecurity.ListingDate;
			ExpulsionDate = nseSecurity.ExpulsionDate;
			ReadmissionDate = nseSecurity.ReadmissionDate;
			RecordDate = nseSecurity.RecordDate;
			ExpiryDate = nseSecurity.ExpiryDate;
			NDStartDate = nseSecurity.NDStartDate;
			NDEndDate = nseSecurity.NDEndDate;
			EligibilityIndicators = nseSecurity.EligibilityIndicators;
			BCStartDate = nseSecurity.BCStartDate;
			BCEndDate = nseSecurity.BCEndDate;
			STPurpose = nseSecurity.STPurpose;
			LocalUpdateDateTime = nseSecurity.LocalUpdateDateTime;
			DeletedFlag = nseSecurity.DeletedFlag;
			Remark = nseSecurity.Remark;
			DecimalLocator = nseSecurity.DecimalLocator;
			TradingCurrencyId = nseSecurity.TradingCurrencyId;
			SettlementCurrencyId = nseSecurity.SettlementCurrencyId;
			InstrumentType = nseSecurity.InstrumentType;
			PermittedToTrade = nseSecurity.PermittedToTrade;
			IssuedCapital = nseSecurity.IssuedCapital;
			WarningPercent = nseSecurity.WarningPercent;
			FreezePercent = nseSecurity.FreezePercent;
			CallAuc1 = nseSecurity.CallAuc1;
			CallAuc2 = nseSecurity.CallAuc2;
			SurvInd = nseSecurity.SurvInd;
			Reserved_1Byte = nseSecurity.Reserved_1Byte;
			FaceValue = nseSecurity.FaceValue;
			ISINNumber = nseSecurity.ISINNumber;
			MktMakerSpread = nseSecurity.MktMakerSpread;
			MktMakerMinQty = nseSecurity.MktMakerMinQty;
			CallAuction1Flag = nseSecurity.CallAuction1Flag;
			ELM = new NSE_CM_ExtremeLossMargin();
			//ELM = nseSecurity.ELM;
			//DPRLow = nseSecurity.DPRLow;
			//DPRHigh = nseSecurity.DPRHigh;
			//FreezeQuantity = nseSecurity.FreezeQuantity;
			//PriceTick = nseSecurity.PriceTick;
		}
	}
}
