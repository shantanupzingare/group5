﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;
using System.Runtime.InteropServices;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.BSE;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class BaseSecurityMaster
	{
		public CTCL_MessageHeader Headers;
		public CTCL_Token Token;
		public CTCL_SEC_INFO SecurityInfo;
		public CTCL_CreditRating CreditRating;
		public CTCL_SecEligibility NormalMktEligibility;
		public CTCL_SecEligibility OddLotMktEligibility;
		public CTCL_SecEligibility SpotMktEligibility;
		public CTCL_SecEligibility AuctionMktEligibility;
		public CTCL_TimeStamp IssueStartDate;
		public CTCL_TimeStamp InterestPaymentDate;
		public CTCL_TimeStamp IssueMaturityDate;
		public CTCL_Quantity BoardLot;
		public CTCL_Price TickSize;
		public CTCL_Name Name;
		public CTCL_TimeStamp ListingDate;
		public CTCL_TimeStamp ExpulsionDate;
		public CTCL_TimeStamp ReadmissionDate;
		public CTCL_TimeStamp RecordDate;
		public CTCL_TimeStamp ExpiryDate;
		public CTCL_TimeStamp NDStartDate;
		public CTCL_TimeStamp NDEndDate;
		public CTCL_EligibilityIndicators EligibilityIndicators;
		public CTCL_TimeStamp BCStartDate;
		public CTCL_TimeStamp BCEndDate;
		public CTCL_ST_PURPOSE STPurpose;
		public CTCL_TimeStamp LocalUpdateDateTime;
		public CTCL_DeleteFlag DeletedFlag;
		public CTCL_Remark Remark;
		public CTCL_DecimalLocator DecimalLocator;
		public CTCL_TradingCurrencyId TradingCurrencyId;
		public CTCL_SettlementCurrencyId SettlementCurrencyId;
		public virtual Responses Update(NSE_FO_SECURITY_MASTER_NEW target)
		{
			return new Responses();
		}
		public virtual Responses Update(NSE_CM_SECURITY_MASTER_NEW target)
		{
			return new Responses();
		}
		public virtual Responses Update(NSE_CM_ExtremeLossMargin extremeLossMargin)
		{
			return new Responses();
		}
		public virtual Responses Update(MCX_SECURITY_MASTER mcxSecurity)
		{
			return new Responses();
		}
        public virtual Responses Update(BSE_CM_SECURITY_MASTER target)
        {
            return new Responses();
        }
    }


	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CM_SECURITY_MASTER : BaseSecurityMaster
	{
		public CTCL_ISINNumber ISINNumber;
	}
}
