﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.Watchlist
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UserWatchlist
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_TerminalID TerminalID;
        public CTCL_WatchlistId WatchListId;
        public CTCL_WatchListName WatchListName;
    }
}
