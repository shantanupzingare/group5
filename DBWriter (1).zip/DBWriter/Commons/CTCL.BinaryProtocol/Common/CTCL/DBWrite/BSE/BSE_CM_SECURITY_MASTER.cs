﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.BSE
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class BSE_CM_SECURITY_MASTER : CM_SECURITY_MASTER
	{
        public CTCL_Series CharGroupName;
        public CTCL_Instrumentname CharInstrumentName;
        public CTCL_Ticksize newTickSize;
		public CTCL_Price FaceValue;
		public CTCL_GSM ShortGradedSurveillanceMeasure;
        public CTCL_Auction ShortCallAuctionIndicator;
		public CTCL_IssuedCapital IssuedCapital;
		public CTCL_FillerShortPrtdToTrad FillerShortPrtdToTrad;
		public CTCL_Percent FreezePercent;
		public CTCL_TimeStamp FillerLongRmvlDt;
        public CTCL_FillerCharMarket FillerCharIndxPrtcptnInd;
        public CTCL_FillerCharMarket FillerCharAllOrNn;
        public CTCL_FillerCharMarket FillerCharMinFill;
        public CTCL_Oddlot ShortSettlementType;
		public CTCL_SecEligibility AddtionalMkt1Eligibility;
		public CTCL_SecEligibility AddtionalMkt2Eligibility;
		public CTCL_Value FillerVarcharAdditionalInfo;
        public CTCL_Price FillerLongMktMakerSpread;
        public CTCL_ExchangeCode VarcharExchangeCode;
        public CTCL_UniqueProductId VarcharUniqueProductId;
        public CTCL_OptionType CharScriptType;
        public CTCL_TickSize1 NumericTickSize1;
        public CTCL_CharBSEExclusive CharBSEExclusive;
        public CTCL_CharInstumentStatusFlag CharInstumentStatusFlag;
        public CTCL_TimeStamp VarcharExDivDate;
        public CTCL_TimeStamp  VarcharExRightsDate;
        public CTCL_OptionType VarcharInstrumentType;
        public CTCL_InstrumentType FillerShortInstrumentType;
        public CTCL_FillerChar FillerCharTradgPrtd;
        public CTCL_FillerChar FillerCharBuyBckInd;
        public CTCL_FillerChar FillerCharTradToTradInd;
        public CTCL_FillerShortIndex FillerShortIndex;
        public CTCL_FillerShortIndex FillerShortIndexInstrument;
        public CTCL_FillerVarcharInstrumentAttributs FillerVarcharInstrumentAttributs;
        public CTCL_FillerShortMinLot FillerShortMinLot;
        public CTCL_FillerVarcharUnderlyingInstrumentAssetClass FillerVarcharUnderlyingInstrumentAssetClass;
        public CTCL_FillerVarcharUnderlyingInstrument FillerVarcharUnderlyingInstrument;
        public CTCL_FillerLongUnderlyingFinInstrumentId FillerLongUnderlyingFinInstrumentId;
        public CTCL_FillerChar FillerCharBlockDealAllowedFlg;
        public CTCL_FillerVarcharInstrumentName FillerVarcharInstrumentName;
        public CTCL_FillerShortMktTpAndId FillerShortMktTpAndId;
        public CTCL_FillerVarcharUnitOfMeasure FillerVarcharUnitOfMeasure;
        public CTCL_FillerShortPriceQtQty FillerShortPriceQtQty;
        public CTCL_FillerShortPriceRangeType FillerShortPriceRangeType;
        public CTCL_FillerdoublePrice FillerNumericMaxPrice;
        public CTCL_FillerdoublePrice FillerNumericMinPrice;
        public CTCL_FillerShortSttlmMtd FillerShortSttlmMtd;
        public CTCL_FillerShortInitialMarginType FillerShortInitialMarginType;
        public CTCL_FillerDoubleInitialMarginRate FillerNumericBuyInitialMarginRate;
        public CTCL_Price FillerLongIssuePrice;
        public CTCL_Quantity FillerLongMaxSnglTxnQty;
        public CTCL_FillerdoublePrice FillerNumericMaxSnglTxnVal;
        public CTCL_FillerShortAssetClass FillerShortAssetClass;
        public CTCL_FillerdoublePrice FillerNumericPricNmrtr;
        public CTCL_FillerVarcharSpecialfunctionNumber FillerVarcharSpecialfunctionNumber;
        public CTCL_FillerdoublePrice FillerNumericPricDnmtr;
        public CTCL_FillerdoublePrice FillerNumericGnlNmrtr;
        public CTCL_FillerdoublePrice FillerNumericGnlDnmtr;
        public CTCL_FillerdoublePrice FillerNumericLotNmrtr;
        public CTCL_FillerdoublePrice FillerNumericLotDnmtr;
        public CTCL_FillerdoublePrice FillerNumericDcmlstnPric;
        public CTCL_FillerVarcharSrsSttlmTp FillerVarcharSrsSttlmTp;
        public CTCL_FillerDoubleInitialMarginRate FillerNumericSellInitialMarginRate;
        public CTCL_FillerVarcharRatgDtls FillerVarcharRatgDtls;
        public CTCL_FillerShortInstrumentClssfctn FillerShortInstrumentClssfctn;
        public CTCL_FillerShortInitialMarginType FillerShortSpecialMarginType;
        public CTCL_FillerDoubleInitialMarginRate FillerNumericBuySpecialMarginRate;
        public CTCL_FillerDoubleInitialMarginRate FillerNumericSellSpecialMarginRate;
        public CTCL_FillerShortPreOpenAllowedFlag FillerShortPreOpenAllowedFlag;
        public CTCL_FillerShort FillerShortClssfctnTp;
        public CTCL_FillerShort FillerShortMtchgCrit;
        public CTCL_FillerChar FillerCharValMtd;
        public CTCL_FillerChar FillerCharSLBMElgblty;
        public CTCL_FillerDoubleInitialMarginRate FillerNumericSegment;
        public CTCL_FillerVarcharCcy FillerVarcharCcy;
        public CTCL_FillerVarcharSttlmCcy FillerVarcharSttlmCcy;
        public CTCL_FillershortRsvd FillershortRsvd02;
        public CTCL_FillershortRsvd FillershortRsvd03;
        public CTCL_FillershortRsvd FillershortRsvd04;
        public CTCL_FillershortRsvd FillershortRsvd05;
        public CTCL_FillershortRsvd FillershortRsvd06;
        public CTCL_FillershortRsvd FillershortRsvd07;
		public CTCL_Quantity FreezeQuantity;

		public override Responses Update(BSE_CM_SECURITY_MASTER target)
        {
            Responses response = new();

            try
            {
                Headers = target.Headers;
                Token = target.Token;
                BCStartDate = target.BCStartDate;
                ISINNumber = target.ISINNumber;
                SecurityInfo = target.SecurityInfo;
                CharGroupName = target.CharGroupName;
                CharInstrumentName = target.CharInstrumentName;
                ShortGradedSurveillanceMeasure = target.ShortGradedSurveillanceMeasure;
                ShortCallAuctionIndicator = target.ShortCallAuctionIndicator;
                FillerShortPrtdToTrad = target.FillerShortPrtdToTrad;
                FillerLongRmvlDt = target.FillerLongRmvlDt;
                FillerCharIndxPrtcptnInd = target.FillerCharIndxPrtcptnInd;
                FillerCharAllOrNn = target.FillerCharAllOrNn;
                FillerCharMinFill = target.FillerCharMinFill;
                ShortSettlementType = target.ShortSettlementType;
                FillerVarcharAdditionalInfo = target.FillerVarcharAdditionalInfo;
                VarcharExchangeCode = target.VarcharExchangeCode;
                VarcharUniqueProductId = target.VarcharUniqueProductId;
                CharScriptType = target.CharScriptType;
                NumericTickSize1 = target.NumericTickSize1;
                CharBSEExclusive = target.CharBSEExclusive;
                CharInstumentStatusFlag = target.CharInstumentStatusFlag;
                VarcharInstrumentType = target.VarcharInstrumentType;
                FillerShortInstrumentType = target.FillerShortInstrumentType;
                FillerCharTradgPrtd = target.FillerCharTradgPrtd;
                FillerCharBuyBckInd = target.FillerCharBuyBckInd;
                FillerCharTradToTradInd = target.FillerCharTradToTradInd;
                FillerShortIndex = target.FillerShortIndex;
                FillerShortIndexInstrument = target.FillerShortIndexInstrument;
                FillerVarcharInstrumentAttributs = target.FillerVarcharInstrumentAttributs;
                FillerShortMinLot = target.FillerShortMinLot;
                FillerVarcharUnderlyingInstrumentAssetClass = target.FillerVarcharUnderlyingInstrumentAssetClass;
                FillerVarcharUnderlyingInstrument = target.FillerVarcharUnderlyingInstrument;
                FillerLongUnderlyingFinInstrumentId = target.FillerLongUnderlyingFinInstrumentId;
                FillerCharBlockDealAllowedFlg = target.FillerCharBlockDealAllowedFlg;
                FillerVarcharInstrumentName = target.FillerVarcharInstrumentName;
                FillerShortMktTpAndId = target.FillerShortMktTpAndId;
                FillerVarcharUnitOfMeasure = target.FillerVarcharUnitOfMeasure;
                FillerShortPriceQtQty = target.FillerShortPriceQtQty;
                FillerShortPriceRangeType = target.FillerShortPriceRangeType;
                FillerNumericMaxPrice = target.FillerNumericMaxPrice;
                FillerNumericMinPrice = target.FillerNumericMinPrice;
                FillerShortSttlmMtd = target.FillerShortSttlmMtd;
                FillerShortInitialMarginType = target.FillerShortInitialMarginType;
                FillerNumericBuyInitialMarginRate = target.FillerNumericBuyInitialMarginRate;
                FillerLongMaxSnglTxnQty = target.FillerLongMaxSnglTxnQty;
                FillerNumericMaxSnglTxnVal = target.FillerNumericMaxSnglTxnVal;
                FillerShortAssetClass = target.FillerShortAssetClass;
                FillerNumericPricNmrtr = target.FillerNumericPricNmrtr;
                FillerVarcharSpecialfunctionNumber = target.FillerVarcharSpecialfunctionNumber;
                FillerNumericPricDnmtr = target.FillerNumericPricDnmtr;
                FillerNumericGnlNmrtr = target.FillerNumericGnlNmrtr;
                FillerNumericGnlDnmtr = target.FillerNumericGnlDnmtr;
                FillerNumericLotNmrtr = target.FillerNumericLotNmrtr;
                FillerNumericLotDnmtr = target.FillerNumericLotDnmtr;
                FillerNumericDcmlstnPric = target.FillerNumericDcmlstnPric;
                FillerVarcharSrsSttlmTp = target.FillerVarcharSrsSttlmTp;
                FillerNumericSellInitialMarginRate = target.FillerNumericSellInitialMarginRate;
                FillerVarcharRatgDtls = target.FillerVarcharRatgDtls;
                FillerShortInstrumentClssfctn = target.FillerShortInstrumentClssfctn;
                FillerShortSpecialMarginType = target.FillerShortSpecialMarginType;
                FillerNumericBuySpecialMarginRate = target.FillerNumericBuySpecialMarginRate;
                FillerNumericSellSpecialMarginRate = target.FillerNumericSellSpecialMarginRate;
                FillerShortPreOpenAllowedFlag = target.FillerShortPreOpenAllowedFlag;
                FillerShortClssfctnTp = target.FillerShortClssfctnTp;
                FillerShortMtchgCrit = target.FillerShortMtchgCrit;
                FillerCharValMtd = target.FillerCharValMtd;
                FillerCharSLBMElgblty = target.FillerCharSLBMElgblty;
                FillerNumericSegment = target.FillerNumericSegment;
                FillerVarcharCcy = target.FillerVarcharCcy;
                FillerVarcharSttlmCcy = target.FillerVarcharSttlmCcy;
                FillershortRsvd02 = target.FillershortRsvd02;
                FillershortRsvd03 = target.FillershortRsvd03;
                FillershortRsvd04 = target.FillershortRsvd04;
                FillershortRsvd05 = target.FillershortRsvd05;
                FillershortRsvd06 = target.FillershortRsvd06;
                FillershortRsvd07 = target.FillershortRsvd07;
				DecimalLocator = target.DecimalLocator;
				SettlementCurrencyId = target.SettlementCurrencyId;
				TradingCurrencyId = target.TradingCurrencyId;
				LocalUpdateDateTime = target.LocalUpdateDateTime;
                CreditRating = target.CreditRating;
                NormalMktEligibility = target.NormalMktEligibility;
                OddLotMktEligibility = target.OddLotMktEligibility;
                SpotMktEligibility = target.SpotMktEligibility;
                AuctionMktEligibility = target.AuctionMktEligibility;
                AddtionalMkt1Eligibility = target.AddtionalMkt1Eligibility;
                AddtionalMkt2Eligibility = target.AddtionalMkt2Eligibility;
                IssueStartDate = target.IssueStartDate;
                InterestPaymentDate = target.InterestPaymentDate;
                IssueMaturityDate = target.IssueMaturityDate;
                BoardLot = target.BoardLot;
                TickSize = target.TickSize;
                Name = target.Name;
                ListingDate = target.ListingDate;
                ExpulsionDate = target.ExpulsionDate;
                ReadmissionDate = target.ReadmissionDate;
                RecordDate = target.RecordDate;
                ExpiryDate = target.ExpiryDate;
                NDStartDate = target.NDStartDate;
                NDEndDate = target.NDEndDate;
                EligibilityIndicators = target.EligibilityIndicators;
                BCEndDate = target.BCEndDate;
                STPurpose = target.STPurpose;
                DeletedFlag = target.DeletedFlag;
                Remark = target.Remark;

				FreezePercent.Percent = target.FreezePercent.Percent;
				var freezeQty = Convert.ToInt64(Math.Floor((double)(IssuedCapital.IssuedCapital) * FreezePercent.Percent / 1000000));
				FreezeQuantity = new(freezeQty);

				response.Set(StatusCode.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, "", ex.Message);

            }
            return response;
        }

    }
}
