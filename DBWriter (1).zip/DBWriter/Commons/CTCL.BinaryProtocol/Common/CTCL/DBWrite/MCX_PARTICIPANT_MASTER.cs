﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using Responses = BinaryProtocol.Common.Response;


namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public  class MCX_PARTICIPANT_MASTER
    {
        public CTCL_MessageHeader Headers;
        public CTCL_ParticipantId ParticipantID;
        public CTCL_ParticipantName ParticipantName;
        public CTCL_ParticipantStatus ParticipantStatus;
        public CTCL_TimeStamp ParticipantUpdateTime;
        public CTCL_DeleteFlag DeletedFlag ;

        public Responses Update(MCX_PARTICIPANT_MASTER target)
        {
            Responses response = new();

            try
            {
                Headers = new();

                Headers.OpCode = target.Headers.OpCode;
                Headers.TimeStamp = target.Headers.TimeStamp;
                Headers.MessageLength = target.Headers.MessageLength;
                Headers.SourceComponentIdentifier = target.Headers.SourceComponentIdentifier;
                Headers.DestinationComponentIdentifier = target.Headers.DestinationComponentIdentifier;
                Headers.ExchangeSegmentId = target.Headers.ExchangeSegmentId;

                ParticipantName = target.ParticipantName;
                ParticipantStatus = target.ParticipantStatus;
                ParticipantUpdateTime = target.ParticipantUpdateTime;
                DeletedFlag = target.DeletedFlag;


                response.Set(StatusCode.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, "", ex.Message);
            }
            return response;
        }

    }
}
