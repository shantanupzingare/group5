﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class SURVEILLANCE_INDICATOR_MASTER
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_Token Token;
		public CTCL_Symbol Symbol;
		public CTCL_SurveillanceSegmentExculsive SegmentExclusive;
		public CTCL_SurveillanceIndicatorStatus Status;
		public CTCL_Series Series;
		public CTCL_SurveillanceIndicatorStage TradeToTrade;
		public CTCL_SurveillanceIndicatorStage GSM;
		public CTCL_SurveillanceIndicatorStage LongTermASM;
		public CTCL_SurveillanceIndicatorStage Unsolicited_SMS;
		public CTCL_SurveillanceIndicatorStage Insolvency_Resolution_Process;
		public CTCL_SurveillanceIndicatorStage ShortTermASM;
		public CTCL_SurveillanceIndicatorStage Default;
		public CTCL_SurveillanceIndicatorStage ICA;
		public CTCL_SurveillanceFiller11 Filler4;
		public CTCL_SurveillanceFiller11 Filler5;
		public CTCL_SurveillanceIndicatorStage Pledge;
		public CTCL_SurveillanceIndicatorStage Add_on_PB;
		public CTCL_SurveillanceIndicatorStage TotalPledge;
		public CTCL_SurveillanceIndicatorStage ISSocialMediaPlatforms;
		public CTCL_SurveillanceIndicatorStage ESM;
		public CTCL_SurveillanceIndicatorStage LossMaking;
		public CTCL_SurveillanceIndicatorStage ISEncumberedShare50Percent;
		public CTCL_SurveillanceIndicatorStage IsUnderBZ_SZ_Series;
		public CTCL_SurveillanceIndicatorStage IsAnnualFeeFailed;
		public CTCL_SurveillanceFiller11 Filler12;
		public CTCL_SurveillanceIndicatorStage IsMovedOutFromFnO;
		public CTCL_SurveillanceIndicatorStage ScripPEIsGreaterThan50;
		public CTCL_SurveillanceIndicatorStage EPSInTheScripIsZero;
		public CTCL_SurveillanceIndicatorStage LessThan100UniquePAN;
		public CTCL_SurveillanceIndicatorStage MandatoryMarketMaking;
		public CTCL_SurveillanceIndicatorStage SMEScripIsNotRegularlyTraded;
		public CTCL_SurveillanceIndicatorStage CloseToClose1;
		public CTCL_SurveillanceIndicatorStage CloseToClose2;
		public CTCL_SurveillanceIndicatorStage CloseToClose3;
		public CTCL_SurveillanceIndicatorStage CloseToClose4;
		public CTCL_SurveillanceIndicatorStage CloseToClose5;
		public CTCL_SurveillanceIndicatorStage CloseToClose6;
		public CTCL_SurveillanceIndicatorStage CloseToClose7;
		public CTCL_SurveillanceIndicatorStage CloseToClose8;
		public CTCL_SurveillanceIndicatorStage CloseToClose9;
		public CTCL_SurveillanceIndicatorStage CloseToClose10;
		public CTCL_SurveillanceIndicatorStage CloseToClose11;
		public CTCL_SurveillanceIndicatorStage HighLowPrice1;
		public CTCL_SurveillanceIndicatorStage HighLowPrice2;
		public CTCL_SurveillanceIndicatorStage HighLowPrice3;
		public CTCL_SurveillanceIndicatorStage HighLowPrice4;
		public CTCL_SurveillanceIndicatorStage HighLowPrice5;
		public CTCL_SurveillanceIndicatorStage HighLowPrice6;
		public CTCL_SurveillanceIndicatorStage HighLowPrice7;
        public CTCL_SurveillanceFiller11 Filler17;
		public CTCL_SurveillanceFiller11 Filler18;
		public CTCL_SurveillanceFiller11 Filler19;
		public CTCL_SurveillanceFiller11 Filler20;
		public CTCL_SurveillanceFiller11 Filler21;
		public CTCL_SurveillanceFiller11 Filler22;
		public CTCL_SurveillanceFiller11 Filler23;
		public CTCL_SurveillanceFiller11 Filler24;
		public CTCL_SurveillanceFiller11 Filler25;
		public CTCL_SurveillanceFiller11 Filler26;
		public CTCL_SurveillanceFiller11 Filler27;
		public CTCL_SurveillanceFiller11 Filler28;
		public CTCL_SurveillanceFiller11 Filler29;
		public CTCL_SurveillanceFiller11 Filler30;
		public CTCL_SurveillanceFiller11 Filler31;
		public CTCL_TimeStamp LastUpdateTImeStamp;
	}
}
