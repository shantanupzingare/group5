﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Response;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ParticipantMakerChecker : CTCL_Participant_Trade_Acknowledgement_Response
	{
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_OrderParticipantMakerCheckerStatus Action;
		public CTCL_TimeStamp LastUpdateTimeStamp;
		public CTCL_TimeStamp1 smtTimeStamp1;
	}
}
