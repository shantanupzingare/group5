﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class UserDisclaimerLog
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ExchangeSegmentId ExchangeSegmentId;
        public CTCL_TerminalID TerminalID;
        public CTCL_Flag IsUserAccept;
        public CTCL_TimeStamp TimeStamp;
    }
}
