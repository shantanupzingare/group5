﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class EntityBranchDetailsDB
	{
		public CTCL_Id PrimaryId;
		[Validator(validationType.numericRequired, "Segment Id is required")]
		public CTCL_ExchangeSegmentId SegmentId;
		[Validator(validationType.numericRequired, "Branch Id is required")]
		public CTCL_ClientId BranchId;
		[Validator(validationType.numericRequired, "CTCL Client Id is required")]
		public CTCL_ClientId Ctcl_ClientId;
	}
}
