﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_CommonMasterAttributes
    {
        public CTCL_EntityID LastUpdatedBy;
        public CTCL_TimeStamp LastUpdatedTime;

        [Validator(validationType.alpha_numeric, "Special characters not allowed in Entity Remark")]
        public CTCL_Remarks Remarks;
        public CTCL_RMSTemplateStatus Status;
    }
}
