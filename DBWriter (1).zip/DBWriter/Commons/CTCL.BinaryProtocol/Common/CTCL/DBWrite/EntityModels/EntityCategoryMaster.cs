﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityCategoryMaster
    {

        //Header
        public CTCL_MessageHeader MessageHeader;
        public CTCL_CategoryId CategoryId;

        [Validator(validationType.alpha_numeric, "Special characters not allowed in Category DisplayShortName")]
        public CTCL_CategoryDisplayShortName CategoryDisplayShortName;

        public CTCL_HierarchyLevel HierarchyLevel;
        public CTCL_HierarchyLevel ParentHierarchyLevel;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
