﻿
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class SecurityInfoDB
    {
        public CTCL_Id Id;
        public CTCL_Id ExchangeSegmentID;
        public CTCL_Id SubAssetId;
        public CTCL_Id SubInstrumentId;
        public CTCL_DisplayShortName DisplayShortName;
        public CTCL_Name DisplayLongName;
        public CharFlag TradingAllowed;
        public CharFlag FeedReceived;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
