﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class SegmentInstrumentAssetMapping
    {
       // public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        public ExchangeSegmentInfo ExchangeSegmentInfo;
        public SubAssetInfo SubAssetInfo;
        public SubInstrumentInfo SubInstrumentInfo;
        public CTCL_DisplayShortName DisplayShortName;
        public CTCL_Name DisplayLongName;
        public CharFlag TradingAllowed;
        public CharFlag FeedReceived;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
