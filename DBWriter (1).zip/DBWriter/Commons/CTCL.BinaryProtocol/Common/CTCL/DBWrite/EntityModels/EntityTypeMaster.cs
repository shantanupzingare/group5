﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityTypeMaster
    {
        //Header
        public CTCL_MessageHeader MessageHeader;
        public CTCL_TypeId TypeId;

        [Validator(validationType.alpha_numeric, "Special characters not allowed in EntityType DisplayShortName")]
        public CTCL_EntityTypeDisplayShortName EntityTypeDisplayShortName;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
