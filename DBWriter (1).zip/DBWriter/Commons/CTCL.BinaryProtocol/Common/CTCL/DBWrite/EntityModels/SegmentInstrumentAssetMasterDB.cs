﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class SegmentInstrumentAssetMasterDB
    {
        public CTCL_Id Id;
        public CTCL_Id intExchangeSegmentId;
        public CTCL_Id intSubAssetId;
        public CTCL_Id intSubInstrumentId;
        public CTCL_CommonMasterAttributes CTCL_CommonMasterAttributes;
    }
}
