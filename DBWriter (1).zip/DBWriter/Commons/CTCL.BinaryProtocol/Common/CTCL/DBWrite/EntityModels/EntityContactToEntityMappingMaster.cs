﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityContactToEntityMappingMaster
    {
		
		public CTCL_MessageHeader MessageHeader;
		public CTCL_Id Id;
        [Validator(validationType.numericRequired, "EntityContactId required")]
        public CTCL_EntityContactID EntityContactId;
        [Validator(validationType.numericRequired, "EntityId required")]
        public CTCL_EntityID EntityId;
        public CTCL_ContactLevel ContactLevel;
        [Validator(validationType.numericRequired, "DesignationID required")]
        public CTCL_Id DesignationID;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }

}
