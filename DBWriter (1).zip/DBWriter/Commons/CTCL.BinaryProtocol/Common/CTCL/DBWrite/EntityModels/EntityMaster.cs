﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityMaster
    {
        //Header
      //  public CTCL_MessageHeader MessageHeader;
        public CTCL_EntityID EntityID;

        [Validator(validationType.alpha_numeric, "Special characters not allowed in Entity Display Code.")]
        public CTCL_EntityDisplayCode EntityDisplayCode;
       
        public CTCL_CategoryId EntityCategory; 
        public CTCL_TypeId EntityType;
        public CTCL_EntityID ParentEntityId; 
        public CTCL_OperationStatus OperationStatus;
        public CTCL_TradingStatus TradingStatus;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
        public CTCL_ConnectionMode ConnectionMode;
		[Validator(validationType.alpha_numeric, "Pancard number is required")]
		public CTCL_PAN PancardNumber;
		public CTCL_Flag DMAFlag;
		public CTCL_AccessAllowed AccessAllowed;
		public CTCL_TotalNoOfRecords NumberOfSegmentWiseClient;
		public List<SegmentWiseDMAUccClient> SegmentWiseDMAUccClient;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public List<EntityBranchDetailsDB> CTCLBranchDetails;
    }

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class SegmentWiseDMAUccClient 
    {
        public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_OperationMode OperationMode;
		public CTCL_TerminalID DMAUccClient;
    }

}
