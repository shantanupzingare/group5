﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.Broadcast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityAuthInfoMaster
    {
        public CTCL_EntityID EntityId;
        public CTCL_TerminalID terminalID;
        public CTCL_Password Password;
       // public List<OldPassword> OldPasswords;
        public CTCL_TimeStamp LastPasswordChangeTime;
        public CTCL_TimeStamp Last2FAChangeTime;
        public CTCL_TimeStamp LastLoginTime;
        public CTCL_AccessAttemptCount AccessAttemptCount;
        public AuthStage AuthStage;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;

    }
}
