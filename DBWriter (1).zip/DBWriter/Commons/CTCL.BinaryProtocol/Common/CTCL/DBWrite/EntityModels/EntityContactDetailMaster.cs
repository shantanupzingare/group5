﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityContactDetailMaster
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_EntityContactID EntityContactID;

        [Validator(validationType.alpha_numeric, "Special characters not allowed in firstname.")]
        public CTCL_Name FirstName;
        [Validator(validationType.alpha_numeric, "Special characters not allowed in middlename.")]
        public CTCL_Name MiddleName;
        [Validator(validationType.alpha_numeric, "Special characters not allowed in surname.")]
        public CTCL_Name Surname;
        [Validator(validationType.numeric, "Please enter a valid phone number")]
        public CTCL_Phone Phone;
        [Validator(validationType.mail, "Please enter a valid email")]
        public CTCL_Email email;
        public CTCL_Address Address1;
        public CTCL_Address Address2;
        [Validator(validationType.numericRequired, "CountryID required")]
        public CTCL_Id CountryID;
        [Validator(validationType.numericRequired, "StateID required")]
        public CTCL_Id StateID;
        [Validator(validationType.numericRequired, "CityID required")]
        public CTCL_Id CityID;
        [Validator(validationType.numericRequired, "Please enter a valid Zip Code")]
        public CTCL_Id ZipCode;
		[Validator(validationType.numeric, "Please enter a valid phone number")]
		public CTCL_Phone MobileNumber1;
		[Validator(validationType.mail, "Please enter a valid corporate email")]
		public CTCL_Email CorporateEmailId;
		[Validator(validationType.numeric, "Please enter a valid fax number")]
		public CTCL_Number FaxNumber;
		[Validator(validationType.numeric, "Please enter a valid telephone number")]
		public CTCL_Number TelePhoneNumber;
		public CTCL_CommonMasterAttributes CommonMasterAttributes;

    }

}