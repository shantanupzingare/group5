﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_ENTITY_PRIVILEGE_MAPPING_OBJECT
	{
		public CTCL_Id MappingId;
		public CTCL_EntityId EntityId;
	}
}
