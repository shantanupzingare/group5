﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.InstrumentBasket
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class InstrumentBasketEntityMappingDB
	{
		public CTCL_Id TemplateId;
		public CTCL_CommonMasterAttributes CommonMasterAttributes;
		public CTCL_TotalNoOfRecords NumberOfRecords;
		public List<CTCL_EntityId> ListOfEntityId;
	}
}
