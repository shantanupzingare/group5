﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityUserCredentialsMaster
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_EntityID EntityId;
        public CTCL_TerminalID terminalID;
        public CTCL_Password Password;
		public CTCL_TimeStamp LastPasswordChangeTime;
		public CTCL_IsActive IsActive;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;

    }
}
