﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityPrivelegeTemplateMappingDB
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        public CTCL_Id TemplateId;
        public CTCL_EntityID EntityId;
       // public PrivelegesTemplateDB PrivelegesTemplate;
       // public PrivelegesAttributesDB privelegesAttributes; 
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
