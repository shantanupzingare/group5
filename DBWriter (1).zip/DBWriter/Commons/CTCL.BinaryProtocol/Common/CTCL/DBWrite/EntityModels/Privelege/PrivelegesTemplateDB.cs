﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class PrivelegesTemplateDB
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        public CTCL_EntityID TemplateOwner;
        public CTCL_TemplateName Name;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
