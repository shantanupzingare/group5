﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class ExchangeSegmentMasterDB
    {
        public CTCL_Id Id;
        public CTCL_Id intExchangeId;
        public CTCL_Id intAssetId;
        public CTCL_Id intInstrumentId;
        public CTCL_CommonMasterAttributes CTCL_CommonMasterAttributes;
    }
}
