﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EntityKYCDetailsMaster
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        [Validator(validationType.numericRequired, "EntityTypeId required")]
        public CTCL_TypeId EntityTypeId;
        [Validator(validationType.numericRequired, "EntityUID required")]
        public CTCL_EntityUID EntityUID;
        [Validator(validationType.numericRequired, "ProofType required")]
        public CTCL_ProofType ProofType;
        [Validator(validationType.numericRequired, "DocumentType required")]
        public CTCL_DocumentType DocumentType;
        public CTCL_FilePath FilePath;
        [Validator(validationType.numericRequired, "KYCApprovalStatus required")]
        public CTCL_KYCApprovalStatus KYCApprovalStatus;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
	}

}
