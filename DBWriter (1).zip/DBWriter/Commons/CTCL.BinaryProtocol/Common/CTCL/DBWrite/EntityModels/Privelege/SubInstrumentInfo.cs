﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class SubInstrumentInfo 
    {
        //public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        public CTCL_DisplayShortName DisplayShortName;
        public CTCL_Name DisplayLongName;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;
    }
}
