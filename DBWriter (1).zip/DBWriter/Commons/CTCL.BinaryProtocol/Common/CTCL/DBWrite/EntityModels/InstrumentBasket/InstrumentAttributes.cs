﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.InstrumentBasket
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class InstrumentAttributes
	{
		public CTCL_ControlLevel ControlLevel;
		public CTCL_Token UniqueIdentifier;
		public CTCL_PermissionType PermissionType;
	}
}
