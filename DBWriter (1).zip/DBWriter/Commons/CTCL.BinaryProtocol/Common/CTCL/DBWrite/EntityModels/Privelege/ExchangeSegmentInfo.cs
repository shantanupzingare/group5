﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.Privelege
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class ExchangeSegmentInfo
    {
        //public CTCL_MessageHeader MessageHeader;
        public CTCL_Id Id;
        public ExchangeInfo ExchangeInfo;
        public AssetInfo AssetInfo;
        //public SubAssetInfo SubAssetInfo;
        public InstrumentInfo InstrumentInfo;
        public CTCL_DisplayShortName DisplayShortName;
        public CTCL_Name DisplayLongName;
        public CTCL_CommonMasterAttributes CommonMasterAttributes;

    }
}
