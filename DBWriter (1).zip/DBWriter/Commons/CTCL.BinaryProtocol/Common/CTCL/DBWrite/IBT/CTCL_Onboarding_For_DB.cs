﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.IBT.Common;
using System.Runtime.InteropServices;
using CTCL_Name = CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.CTCL_Name;
using CTCL_Id = CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.CTCL_Id;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite.IBT
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Onboarding_For_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId ID;
		public IBTOnboardingStages Stage;
		public CTCL_Phone Mobile;
		public CTCL_Email EmailId;
		public CTCL_DateTime_OMS DOB;
		public CTCL_Name Name;
		public CTCL_EntityDisplayCode ClientId;
		public CTCL_EntityId CustId;
		public CTCL_PAN Pan;
		public CTCL_Name FatherName;
		public CTCL_Name MotherName;
		public CTCL_Value AnnualIncome;
		public CTCL_Value TradingExp;
		public CTCL_Value PoliticallyExposed;
		public CTCL_Value Occupation;
		public CTCL_Value SettlementPreference;
		public CTCL_Value MaritalStatus;
		public CTCL_PepInformation PepInformation;
		public CTCL_Name MotherFirstName;
		public CTCL_Name MotherLastName;
		public CTCL_Name FatherFirstName;
		public CTCL_Name FatherLastName;
		public CTCL_AccountNumber BankAccount;
		public CTCL_IFSCCode BankIfsc;
		public CTCL_MICR BankMicr;
		public CTCL_Flag IsMobileNumberVerified;
        public CTCL_Flag IsEmailVerified;
        public CTCL_Flag IsAddharVerified;
        public CTCL_Flag IsPANVerified;
        public CTCL_Flag IsBankAccountVerified;
		public CTCL_Flag IsIPVVerified;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Onboarding_DocumentUpload_For_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId ID;
		public DocumentFileType TypeOfDocument;
		public CTCL_FileInfo Document;
	}
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Onboarding_DocumentDelete_For_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId ID;
		public DocumentFileType TypeOfDocument;
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Onboarding_Nominee_For_DB
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId ID;
		public NomineeType TypeOfNominee;
		public CTCL_Nominee Nominee;
	}

}
