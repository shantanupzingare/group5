﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class SURVEILLANCE_INDICATOR_MESSAGE_MASTER
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_SurveillanceFieldName Name;
		public CTCL_SurveillanceFieldValue Value;
		public CTCL_SurveillanceFieldMessage Message;
		public CTCL_TimeStamp LastUpdateTimeStamp;
	}
}
