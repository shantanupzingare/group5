﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;
using CTCL_OpCode = CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;
using CTCL.Broadcast;
using CTCL.BinaryProtocol.Common.CTCL.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class TRADE_INFO_FOR_DB
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_PlatformID PlatformId;
        public CTCL_VersionInfo VersionInfo;
        public CTCL_OpCode TradeOpCode;
        public CTCL_AlphaChar AlphaChar;
        public CTCL_TradedDetails TradeDetails;  
        public CTCL_Status TradeStatusCode;   //new empty ENUM added as vinay sir said.
        public CTCL_TimeStamp TimeStamp1;
        public CTCL_TimeStamp TimeStamp2;
        public CTCL_Reserved Reserved;
        //public CTCL_Reserved1 Reserved1;
        //public CTCL_Reserved2 Reserved2;
        //public CTCL_Reserved3 Reserved3;
        //public CTCL_Reserved4 Reserved4;
        public CTCL_Reserved5 Reserved5;
        public CTCL_SEC_INFO SecurityInformaion;
        public CTCL_TimeStamp LastModifiedtime;
        public CTCL_Token Token;

        public Responses Update(TRADE_INFO_FOR_DB target)
        {
            Responses response = new();

            try
            {

                MessageHeader = target.MessageHeader;
                SecurityInformaion = target.SecurityInformaion;
                TradeDetails =target.TradeDetails;
                //TradeDetails.Contract_Desc = new();
                //TradeDetails.sTOrderFlag = new();
                //TradeDetails.AccountInformation = new();

                //MessageHeader.OpCode = target.MessageHeader.OpCode;
                //MessageHeader.TimeStamp = target.MessageHeader.TimeStamp;
                //MessageHeader.MessageLength = target.MessageHeader.MessageLength;
                //MessageHeader.SourceComponentIdentifier = target.MessageHeader.SourceComponentIdentifier;
                //MessageHeader.DestinationComponentIdentifier = target.MessageHeader.DestinationComponentIdentifier;
                //MessageHeader.ExchangeSegmentId = target.MessageHeader.ExchangeSegmentId;

                PlatformId = target.PlatformId;
                VersionInfo = target.VersionInfo;
                TradeOpCode = target.TradeOpCode;
                AlphaChar = target.AlphaChar;

                //TradeDetails.OrderContextIdentifier = target.TradeDetails.OrderContextIdentifier;
                //TradeDetails.ExchangeOrderNumber = target.TradeDetails.ExchangeOrderNumber;
                //TradeDetails.TraderId = target.TradeDetails.TraderId;
                //TradeDetails.BrokerID = target.TradeDetails.BrokerID;
                //TradeDetails.AccountInformation.ClientAccountCode = target.TradeDetails.AccountInformation.ClientAccountCode;
                //TradeDetails.AccountInformation.ProClientIndicator = target.TradeDetails.AccountInformation.ProClientIndicator;
                //TradeDetails.Buy_SellIndicator = target.TradeDetails.Buy_SellIndicator;
                //TradeDetails.OriginalVolume = target.TradeDetails.OriginalVolume;
                //TradeDetails.DisclosedVolumeRemaining = target.TradeDetails.DisclosedVolumeRemaining;
                //TradeDetails.RemainingVolume = target.TradeDetails.RemainingVolume;
                //TradeDetails.OrderPrice = target.TradeDetails.OrderPrice;
                //TradeDetails.sTOrderFlag.ATO = target.TradeDetails.sTOrderFlag.ATO;
                //TradeDetails.sTOrderFlag.Market = target.TradeDetails.sTOrderFlag.Market;
                //TradeDetails.sTOrderFlag.GTC = target.TradeDetails.sTOrderFlag.GTC;
                //TradeDetails.sTOrderFlag.IOC = target.TradeDetails.sTOrderFlag.IOC;
                //TradeDetails.sTOrderFlag.AON = target.TradeDetails.sTOrderFlag.AON;
                //TradeDetails.sTOrderFlag.MF = target.TradeDetails.sTOrderFlag.MF;
                //TradeDetails.sTOrderFlag.MatchedInd = target.TradeDetails.sTOrderFlag.MatchedInd;
                //TradeDetails.sTOrderFlag.Traded = target.TradeDetails.sTOrderFlag.Traded;
                //TradeDetails.sTOrderFlag.Modified = target.TradeDetails.sTOrderFlag.Modified;
                //TradeDetails.sTOrderFlag.Frozen = target.TradeDetails.sTOrderFlag.Frozen;
                //TradeDetails.sTOrderFlag.Day = target.TradeDetails.sTOrderFlag.Day;
                LastModifiedtime = target.LastModifiedtime;
                TimeStamp1 = target.TimeStamp1;
                TimeStamp2 = target.TimeStamp2;
                //SecurityInformaion.InstrumentName = target.SecurityInformaion.InstrumentName;
                //SecurityInformaion.Symbol = target.SecurityInformaion.Symbol;
                //SecurityInformaion.ExpiryDate = target.SecurityInformaion.ExpiryDate;
                //SecurityInformaion.StrikePrice = target.SecurityInformaion.StrikePrice;
                //SecurityInformaion.OptionType = target.SecurityInformaion.OptionType;
                //SecurityInformaion.CALevel = target.SecurityInformaion.CALevel;
                Token = target.Token;


                response.Set(StatusCode.Success, "");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, "", ex.Message);
            }
            return response;
        }
		public Responses Update(CTCL_TradeConfirm target)
		{
			Responses response = new();

			try
			{

				MessageHeader = target.MessageHeader;				
				TradeDetails = target.TradedDetails;
                PlatformId = new CTCL_PlatformID(1);
				TradeOpCode = CTCL_OpCode.Trade_Confirm;
				Token = target.TradedDetails.Contract_Desc.MappingTokenId;

				response.Set(StatusCode.Success, "");
			}
			catch (Exception ex)
			{
				response.Set(StatusCode.Failure, "", ex.Message);
			}
			return response;
		}
	}
}
