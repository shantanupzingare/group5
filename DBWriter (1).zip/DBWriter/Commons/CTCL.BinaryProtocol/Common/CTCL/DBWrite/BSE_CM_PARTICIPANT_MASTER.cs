﻿using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class BSE_CM_PARTICIPANT_MASTER : BaseParticipantMaster
	{
	}
}
