﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class NSE_FO_MarketStatistics : BaseBhavCopy
{
    public CTCL_InstrumentName Instrument;
    public CTCL_TimeStamp ExpiryDate;
    public CTCL_OptionType OptionType;
    public CTCL_Price StrikePrice;
    public CTCL_Price SettlePrice;   
    public CTCL_Quantity Contracts;
    public CTCL_Quantity ValInLacs;
    public CTCL_Quantity OpenInterest;
    public CTCL_Quantity ChangeInOI;
    public CTCL_TimeStamp TimeStamp; 
    public CTCL_TimeStamp LastUpdateTime;
}
