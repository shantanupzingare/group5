﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class DisclaimerTemplate
    {
        public CTCL_DisclaimerId DisclaimerId;
        public CTCL_ExchangeSegmentId ExchangeSegmentId;
        public string DisclaimerMessage;
        public CTCL_DisclaimerFrequency Frequency;
        public CTCL_DisclaimerTitle DisclaimerTitle;
        public CTCL_DisclaimerSeverity Severity;
        public CTCL_RMS_Remark Remark;
        public CTCL_Flag IsDisabled;
    }
}
