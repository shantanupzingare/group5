﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Responses = BinaryProtocol.Common.Response;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class NSE_CM_ExtremeLossMargin
	{
		public CTCL_ExchangeSegmentId ExchangeSegmentId;
		public CTCL_Token TokenNo;
		public CTCL_ISINNumber ISIN;
		public CTCL_TimeStamp LocalUpdateDateTime;
		public CTCL_Symbol Symbol;
		public CTCL_Series chrSeries;
		public CTCL_PercentageDecimal ExtremeLossMargin;

		public Responses Update(NSE_CM_ExtremeLossMargin extremeLossMargin)
		{
			Responses response = new();
			ExchangeSegmentId.SegmentId = extremeLossMargin.ExchangeSegmentId.SegmentId;
			TokenNo.Token = extremeLossMargin.TokenNo.Token;
			ISIN = new CTCL_ISINNumber(extremeLossMargin.ISIN.ISINNumber);
			LocalUpdateDateTime.TimeStamp = LocalUpdateDateTime.TimeStamp;
			Symbol = new CTCL_Symbol(extremeLossMargin.Symbol.Symbol);
			chrSeries = new CTCL_Series(extremeLossMargin.chrSeries.Series);
			ExtremeLossMargin.Percentage = extremeLossMargin.ExtremeLossMargin.Percentage;

			response.Set(StatusCode.Success, "");
			return response;
		}
	}

}
