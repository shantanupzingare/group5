﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.DBWrite
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class NSE_CM_MarketStatistics : BaseBhavCopy
	{
		public CTCL_ISINNumber ISIN;
		public CTCL_TimeStamp Date;
		public CTCL_Price AvgPrice;

		public CTCL_MKT MKT;
		public CTCL_Series chrSeries;
		public CTCL_CompanyName Security;
		public CTCL_MKT INDSec;
		public CTCL_CorpAction CorpAction;

		public CTCL_Price PrevClose;
		public CTCL_Price NetTradeValue;
		public CTCL_Price High52Week;
		public CTCL_Price Low52Week;

		public CTCL_Quantity NetTradeQuantity;
		public CTCL_Quantity NoOfTrades;
		public CTCL_TimeStamp LocalUpdateDateTime;
	}
}
