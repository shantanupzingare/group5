﻿using BinaryProtocol.TCP;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.IG
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_IG_ENTITY_CACHE_UPDATE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId EntityID;
		public AliasName EntityDisplayCode;
		public CTCL_EntityId ParentEntityId;
		public CTCL_CategoryId EntityCategory;
		public CTCL_Flag DMAFlag;
	}

}
