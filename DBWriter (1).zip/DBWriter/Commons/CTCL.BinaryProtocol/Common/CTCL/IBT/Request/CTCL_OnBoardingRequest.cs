﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.IBT.Request
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_OnBoardingRequest
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityID IBTEntityId;
		public CTCL_EntityID EntityID;
		public CTCL_EntityDisplayCode EntityDisplayCode;
		public CTCL_CategoryId EntityCategory;
		public CTCL_TypeId EntityType;
		public CTCL_EntityID ParentEntityId;
		public CTCL_OperationStatus OperationStatus;
		public CTCL_PAN PancardNumber;
		public CTCL_AccessAllowed AccessAllowed;
		public CTCL_EntityContactID EntityContactID;
		public DBWrite.EntityModels.CTCL_Name FirstName;
		public DBWrite.EntityModels.CTCL_Name MiddleName;
		public DBWrite.EntityModels.CTCL_Name Surname;
		public CTCL_Phone Phone;
		public CTCL_Email email;
		public CTCL_Address Address1;
		public CTCL_Address Address2;
		public DBWrite.EntityModels.CTCL_Id CountryID;
		public DBWrite.EntityModels.CTCL_Id StateID;
		public DBWrite.EntityModels.CTCL_Id CityID;
		public DBWrite.EntityModels.CTCL_Id ZipCode;
		public CTCL_Phone MobileNumber1;
		public CTCL_Email CorporateEmailId;
		public CTCL_Number FaxNumber;
		public CTCL_Number TelePhoneNumber;
		public CTCL_CommonMasterAttributes CommonMasterAttributes;
	}

}
