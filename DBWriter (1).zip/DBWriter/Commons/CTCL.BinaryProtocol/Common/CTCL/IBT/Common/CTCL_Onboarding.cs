﻿
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL_Name = CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.CTCL_Name;
using CTCL_Id = CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels.CTCL_Id;
using System.Globalization;
using System;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.IBT.Common;

public class CTCL_Onboarding
{
	public IBTOnboardingStages Stage;
	public CTCL_PrefillData PrefillData;
	public CTCL_Onboarding()
	{
		Stage = IBTOnboardingStages.validate_mobile;
		PrefillData = new CTCL_PrefillData();
	}
}


public class CTCL_PrefillData
{
	public CTCL_EntityId ID;
	public CTCL_Phone Mobile;
	public CTCL_Email EmailId; 
	public CTCL_DateTime_OMS DOB;
	public CTCL_Name Name;
	public CTCL_EntityDisplayCode ClientId;
	public CTCL_EntityId CustId;
	public CTCL_PAN Pan;
	public CTCL_Name FatherName;
	public CTCL_Name MotherName;
	public CTCL_Value AnnualIncome;
	public CTCL_Value TradingExp;
	public CTCL_Value PoliticallyExposed;
	public CTCL_Value Occupation;
	public CTCL_Value SettlementPreference;
	public CTCL_Value MaritalStatus;
	public CTCL_PepInformation PepInformation;
	public CTCL_Name MotherFirstName;
	public CTCL_Name MotherLastName;
	public CTCL_Name FatherFirstName;
	public CTCL_Name FatherLastName;
	public CTCL_AccountNumber BankAccount;
	public CTCL_IFSCCode BankIfsc;
	public CTCL_MICR BankMicr;
	public CTCL_Uploads Uploads;
	public CTCL_Nominees Nominee;
	public OTPWrapper MobileOTP;
	public OTPWrapper EmailOTP;
	public OTPWrapper IPV;
	public List<CTCL_FileInfo> IPVImages;
	public CTCL_PrefillData()
	{
		Uploads = new CTCL_Uploads();
		Nominee = new CTCL_Nominees();
		MobileOTP = new OTPWrapper();
		EmailOTP = new OTPWrapper();
		IPV = new OTPWrapper(false);
		IPVImages = new List<CTCL_FileInfo>();
	}
	public void UpdateMobile(string mobileNumber)
	{
		Mobile = new CTCL_Phone(mobileNumber.ToCharArray());
	}
	public void UpdateEmail(string email)
	{
		EmailId = new CTCL_Email(email.ToCharArray());
	}
	public void UpdatePan(string pan, long dob)
	{
		Pan = new CTCL_PAN(pan.ToCharArray());
		DOB = new CTCL_DateTime_OMS(dob);
	}
	public void UpdateContact(string annualIncome, string tradingExp, string politicallyExposed, string pepInformation, string occupation, string settlementPreference, string maritalStatus, string motherName, string fatherName)
	{
		AnnualIncome = new CTCL_Value(annualIncome.ToCharArray());
		TradingExp = new CTCL_Value(tradingExp.ToCharArray());
		PoliticallyExposed = new CTCL_Value(politicallyExposed.ToCharArray());
		Occupation = new CTCL_Value(occupation.ToCharArray());
		SettlementPreference = new CTCL_Value(settlementPreference.ToCharArray());
		PepInformation = new CTCL_PepInformation(pepInformation.ToCharArray());
		MotherName = new CTCL_Name(motherName.ToCharArray());
		FatherName = new CTCL_Name(fatherName.ToCharArray());
		MaritalStatus = new CTCL_Value(maritalStatus.ToCharArray());
	}
	public void UpdateBank(string bankAccount, string bankIfsc, string bankMicr)
	{
		BankAccount = new CTCL_AccountNumber(bankAccount.ToCharArray());
		BankIfsc = new CTCL_IFSCCode(bankIfsc.ToCharArray());
		BankMicr = new CTCL_MICR(bankMicr.ToCharArray());
	}
	public CTCL_FileInfo UpdateIPVPath(string filename, string imagePath)
	{
		var fileInfo = new CTCL_FileInfo();
		fileInfo.Filename = new CTCL_Name(filename?.ToCharArray() ?? Array.Empty<char>());
		fileInfo.FileUrl = new CTCL_Address(imagePath?.ToCharArray() ?? Array.Empty<char>());
		IPVImages.Add(fileInfo);
		return fileInfo;
	}
}
public class OTPWrapper
{
	public CTCL_OTP OTP;
	CTCL_TimeStamp TimeStamp;
	public CTCL_Flag IsVerified;
	bool IsToCheckExperied;
	bool IsExperied 
	{ 
		get 
		{ 
			if(!IsToCheckExperied)
				return false;
			return  DateTime.Now.Ticks - TimeStamp.TimeStamp > TimeSpan.FromSeconds(5 * 60).Ticks; 
		} 
	}
	public OTPWrapper(bool isToCheckExperied = true)
	{
		IsToCheckExperied = isToCheckExperied;
	}
	public CTCL_OTP GenerateOTP()
	{
		var otp = Random.Shared.Next(100000, 999999);
		OTP = new CTCL_OTP(otp);
		TimeStamp = new CTCL_TimeStamp(DateTime.Now.Ticks);
		return this.OTP;
	}

	public bool Verify(string otp)
	{
		if (otp == OTP.OTP_ForgotPwd.ToString() && !IsExperied)
		{
			IsVerified = new CTCL_Flag(true);
			return true;
		}
		return false;
	}
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Nominees
{
	public CTCL_Nominee PrimaryNominee;
	public CTCL_Nominee SecondaryNominee;
	public CTCL_Nominee TertiaryNominee;
	public CTCL_Nominee PrimaryNomineeGuardian;
	public CTCL_Nominee SecondaryNomineeGuardian;
	public CTCL_Nominee TertiaryNomineeGuardian;
	public CTCL_Nominees()
	{

	}
	public void Update(NomineeType nomineeType, CTCL_Nominee nominee)
	{
		switch (nomineeType)
		{
			case NomineeType.PrimaryNominee:
				PrimaryNominee = nominee; 
				break;
			case NomineeType.SecondaryNominee:
				SecondaryNominee = nominee;
				break;
			case NomineeType.TertiaryNominee:
				TertiaryNominee = nominee;
				break;
			case NomineeType.PrimaryNomineeGuardian:
				PrimaryNomineeGuardian = nominee;
				break;
			case NomineeType.SecondaryNomineeGuardian:
				SecondaryNomineeGuardian = nominee;
				break;
			case NomineeType.TertiaryNomineeGuardian:
				TertiaryNomineeGuardian = nominee;
				break;
			default:
				break;
		}
	}
	public void Update(NomineeType nomineeType, CTCL_PercentageOfShares percentageOfShare)
	{
		switch (nomineeType)
		{
			case NomineeType.PrimaryNominee:
				PrimaryNominee.PercentageOfShares = percentageOfShare; 
				break;
			case NomineeType.SecondaryNominee:
				SecondaryNominee.PercentageOfShares = percentageOfShare;
				break;
			case NomineeType.TertiaryNominee:
				TertiaryNominee.PercentageOfShares = percentageOfShare;
				break;
			case NomineeType.PrimaryNomineeGuardian:
				PrimaryNomineeGuardian.PercentageOfShares = percentageOfShare;
				break;
			case NomineeType.SecondaryNomineeGuardian:
				SecondaryNomineeGuardian.PercentageOfShares = percentageOfShare;
				break;
			case NomineeType.TertiaryNomineeGuardian:
				TertiaryNomineeGuardian.PercentageOfShares = percentageOfShare;
				break;
			default:
				break;
		}
	}
}
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Nominee
{
	public CTCL_Id UserNomineeDetailId;
	public CTCL_Age Age;
	public CTCL_DateTime_OMS Dob;
	public CTCL_Phone Mobile;
	public CTCL_Id Pin;
	public CTCL_Id City;
	public CTCL_Email Email;
	public CTCL_Id State;
	public CTCL_Id Country;
	public CTCL_Name FullName;
	public CTCL_Name LastName;
	public CTCL_Name FirstName;
	public CTCL_Name MiddleName;
	public CTCL_Value Relationship;
	public CTCL_Address AddressLine1;
	public CTCL_Address AddressLine2;
	public CTCL_Address AddressLine3;
	public CTCL_PercentageOfShares PercentageOfShares;

	public CTCL_Nominee Update(string? fullName, DateTime dob, string? email, string? mobile, int? percentageOfShares, string? relationship, string? addressLine1, string? addressLine2, string? addressLine3, string? pin, string? city, string? state, string? country)
	{
		Age = new CTCL_Age();
		Dob = new CTCL_DateTime_OMS(dob.Ticks);
		Mobile = new CTCL_Phone(mobile?.ToCharArray() ?? Array.Empty<char>());
		Email = new CTCL_Email(email?.ToCharArray() ?? Array.Empty<char>());
		FullName = new CTCL_Name(fullName?.ToCharArray() ?? Array.Empty<char>());
		Relationship = new CTCL_Value(relationship?.ToCharArray() ?? Array.Empty<char>());
		AddressLine1 = new CTCL_Address(addressLine1?.ToCharArray() ?? Array.Empty<char>());
		AddressLine2 = new CTCL_Address(addressLine2?.ToCharArray() ?? Array.Empty<char>());
		AddressLine3 = new CTCL_Address(addressLine3?.ToCharArray() ?? Array.Empty<char>());
		PercentageOfShares = new CTCL_PercentageOfShares(percentageOfShares ?? 0);
		Pin = new CTCL_Id();
		City = new CTCL_Id();
		State = new CTCL_Id();
		Country = new CTCL_Id();
		return this;
	}
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Uploads
{
	public CTCL_FileInfo IncomeProof;
	public CTCL_FileInfo BankProof;
	public CTCL_FileInfo Pan;
	public CTCL_FileInfo Signature;
	public CTCL_FileInfo PrimaryNomineePoi;
	public CTCL_FileInfo SecondaryNomineePoi;
	public CTCL_FileInfo TertiaryNomineePoi;
	public CTCL_FileInfo PrimaryNomineeGuardianPoi;
	public CTCL_FileInfo SecondaryNomineeGuardianPoi;
	public CTCL_FileInfo TertiaryNomineeGuardianPoi;
	public bool IsRequiredFileUploaded()
	{
		if (IncomeProof == null ||
			//BankProof == null || //optional
			Pan == null ||
			Signature == null //||
			//PrimaryNomineePoi == null ||
			//SecondaryNomineePoi == null ||
			//TertiaryNomineePoi == null ||
			//PrimaryNomineeGuardianPoi == null ||
			//SecondaryNomineeGuardianPoi == null ||
			//TertiaryNomineeGuardianPoi == null
		)
		{
			return false;
		}
		return true;
	}
	public CTCL_FileInfo Update(DocumentFileType fileType, string filename, string fileurl)
	{
		var fileInfo = new CTCL_FileInfo();
		fileInfo.Filename = new CTCL_Name(filename?.ToCharArray() ?? Array.Empty<char>());
		fileInfo.FileUrl = new CTCL_Address(fileurl?.ToCharArray() ?? Array.Empty<char>());
		switch (fileType)
		{
			case DocumentFileType.IncomeProof:
				IncomeProof = fileInfo;
				break;
			case DocumentFileType.BankProof:
				BankProof = fileInfo;
				break;
			case DocumentFileType.Pan:
				Pan = fileInfo;
				break;
			case DocumentFileType.Signature:
				Signature = fileInfo;
				break;
			case DocumentFileType.PrimaryNomineePoi:
				PrimaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.SecondaryNomineePoi:
				SecondaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.TertiaryNomineePoi:
				TertiaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.PrimaryNomineeGuardianPoi:
				PrimaryNomineeGuardianPoi = fileInfo;
				break;
			case DocumentFileType.SecondaryNomineeGuardianPoi:
				SecondaryNomineeGuardianPoi = fileInfo;
				break;
			case DocumentFileType.TertiaryNomineeGuardianPoi:
				TertiaryNomineeGuardianPoi = fileInfo;
				break;
			default:
				break;
		}
		return fileInfo;
	}
	public void Update(DocumentFileType fileType, CTCL_FileInfo fileInfo)
	{
		switch (fileType)
		{
			case DocumentFileType.IncomeProof:
				IncomeProof = fileInfo;
				break;
			case DocumentFileType.BankProof:
				BankProof = fileInfo;
				break;
			case DocumentFileType.Pan:
				Pan = fileInfo;
				break;
			case DocumentFileType.Signature:
				Signature = fileInfo;
				break;
			case DocumentFileType.PrimaryNomineePoi:
				PrimaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.SecondaryNomineePoi:
				SecondaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.TertiaryNomineePoi:
				TertiaryNomineePoi = fileInfo;
				break;
			case DocumentFileType.PrimaryNomineeGuardianPoi:
				PrimaryNomineeGuardianPoi = fileInfo;
				break;
			case DocumentFileType.SecondaryNomineeGuardianPoi:
				SecondaryNomineeGuardianPoi = fileInfo;
				break;
			case DocumentFileType.TertiaryNomineeGuardianPoi:
				TertiaryNomineeGuardianPoi = fileInfo;
				break;
			default:
				break;
		}
	}
	public void Remove(DocumentFileType fileType)
	{
		var fileInfo = new CTCL_FileInfo();
		switch (fileType)
		{
			case DocumentFileType.IncomeProof:
				IncomeProof = null;
				break;
			case DocumentFileType.BankProof:
				BankProof = null;
				break;
			case DocumentFileType.Pan:
				Pan = null;
				break;
			case DocumentFileType.Signature:
				Signature = null;
				break;
			case DocumentFileType.PrimaryNomineePoi:
				PrimaryNomineePoi = null;
				break;
			case DocumentFileType.SecondaryNomineePoi:
				SecondaryNomineePoi = null;
				break;
			case DocumentFileType.TertiaryNomineePoi:
				TertiaryNomineePoi = null;
				break;
			case DocumentFileType.PrimaryNomineeGuardianPoi:
				PrimaryNomineeGuardianPoi = null;
				break;
			case DocumentFileType.SecondaryNomineeGuardianPoi:
				SecondaryNomineeGuardianPoi = null;
				break;
			case DocumentFileType.TertiaryNomineeGuardianPoi:
				TertiaryNomineeGuardianPoi = null;
				break;
			default:
				break;
		}
	}
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_FileInfo
{
	public CTCL_Name Filename;
	public CTCL_Address FileUrl;
}

public enum IBTOnboardingStages : short
{
	validate_mobile = 1,
	verify_email = 2,
	verify_email_otp = 4,
	pan = 8,
	payment = 16,
	aadhaar = 32,
	contact_form = 64,
	bank_form = 128,
	ipv = 256,
	upload = 512,
	nominee = 1024,
	esign_aadhaar = 2048,
	esign_finish = 4096,
	account_opened = 8192
}

public enum IBTSTAGESALL
{
	validate_mobile = 1,
	verify_email,
	verify_email_otp,
	non_individual_pan,
	pan,
	payment,
	kra_consent,
	aadhaar,
	contact_form,
	bank_form,
	idfc_option,
	ipv,
	upload,
	nominee,
	esign_aadhaar,
	esign_finish,
	account_opened,

	login_minor,
	guardian_consent_minor,
	loading_minor,
	verify_mobile_minor,
	verify_mobile_otp_minor,
	verify_email_minor,
	verify_email_otp_minor,
	pan_minor,
	aadhaar_minor,
	contact_form_minor,
	bank_form_minor,
	ipv_minor,
	upload_minor,
	nominee_minor,
	esign_aadhaar_minor,
	esign_finish_minor
}

public enum RelationShipChoice
{
	Spouse = 1,
	Son,
	Daughter,
	Father,
	Mother,
	Brother,
	Sister,
	GrandSon,
	GrandDaughter,
	GrandFather,
	GrandMother,
	NotProvided,
	Others
}

public enum TradingExperience
{
	ZeroOrNew,
	OneToFive,
	FiveToTen,
	TenToFifteen,
	MoreThanFifteen
}

public enum Occupation
{
	Bussiness,
	Housewife,
	Student,
	Professional,
	PrivateSector,
	GovermentService,
	PublicSector,
	Retried,
	ForexDealer,
	Other
}

public enum IncomeSlab
{
	LessThenOneLakh,
	OneToFiveLakh,
	FiveToTenLakh,
	TenToTwentyFiveLakh,
	TwentyFiveLakhToOneCrore,
	MoreThenOneCrore
}

public enum MaritalStatus
{
	Single,
	Married
}

public enum PoliticallyExposed
{
	Yes,
	No,
	RelatedToOne
}

public enum DocumentFileType
{
	IncomeProof = 1,
	BankProof,
	Pan,
	Signature,
	PrimaryNomineePoi,
	SecondaryNomineePoi,
	TertiaryNomineePoi,
	PrimaryNomineeGuardianPoi,
	SecondaryNomineeGuardianPoi,
	TertiaryNomineeGuardianPoi,
	IPVImage
}

public enum NomineeType
{
	PrimaryNominee,
	SecondaryNominee,
	TertiaryNominee,
	PrimaryNomineeGuardian,
	SecondaryNomineeGuardian,
	TertiaryNomineeGuardian
}
