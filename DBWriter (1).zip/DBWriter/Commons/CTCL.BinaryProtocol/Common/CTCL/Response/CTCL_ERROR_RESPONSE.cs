﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ERROR_RESPONSE : CTCL_BASE_RESPONSE //for generic response
    {
        public StatusCode StatusCode;
    }
}
