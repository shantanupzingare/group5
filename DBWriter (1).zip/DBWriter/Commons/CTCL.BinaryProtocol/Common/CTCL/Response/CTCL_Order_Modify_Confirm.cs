﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public  class CTCL_Order_Modify_Confirm
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_OrderDetails OrderDetails;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
    public CTCL_DateTime_OMS OrderEntryTime;
}
