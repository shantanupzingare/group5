﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_SftpCertificateUploadResponse
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_EntityId EntityId;
		public CTCL_ExchangeSegmentId SegmentId;
		public CTCL_Id MasterId;
		public DBWrite.EntityModels.CTCL_FilePath FilePath;
		public CTCL_Id AttributeId;
	}
}
