﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_SFTPFileUploadDetail
{
	public CTCL_MessageHeader MessageHeader;
	public CTCL_EntityCategory EntityCategory;
	public CTCL_EntityId EntityId;
	public CTCL_ProofType ProofType;
	public CTCL_DocumentType DocumentType;
	public CTCL_FilePath FilePath;
}
