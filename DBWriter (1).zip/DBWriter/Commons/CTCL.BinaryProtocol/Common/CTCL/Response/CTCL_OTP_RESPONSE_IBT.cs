﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_OTP_RESPONSE_IBT
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_OTP Otp;
        public CTCL_TerminalID TerminalID;
        public CTCL_Connectio_Log__Remark Id;
        public CTCL_PasswordExpiry ExpiryTimeInMinutes;
    }
}
