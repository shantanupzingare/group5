﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_BASE_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_RequestContext RequestContext;
        public CTCL_Message Message;
    }
}
