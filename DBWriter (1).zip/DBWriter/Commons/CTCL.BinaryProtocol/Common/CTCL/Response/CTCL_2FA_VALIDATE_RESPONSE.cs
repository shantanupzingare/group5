﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_2FA_VALIDATE_RESPONSE 
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_RequestContext ContextIdentifier;
        public StatusCode statusCode;
        public CTCL_StatusString TwoFAValidateStatusString;
    }
}
