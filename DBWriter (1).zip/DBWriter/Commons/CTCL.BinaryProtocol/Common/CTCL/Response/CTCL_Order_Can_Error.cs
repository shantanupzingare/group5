﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Can_Error
{
    public CTCL_MessageHeader messageHeader;
    public CTCL_Code ExchangeReasonCode;
    public CTCL_DateTime_OMS OrderEntryTime;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
    public CTCL_OrderContextIdentifier OrderContextIdentifier;
    public CTCL_Message ErrorMessage;
	public CTCL_Token MappingTokenId;
	public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
	public CTCL_TerminalID Initiator;
	public CTCL_TimeStamp LastModifiedTime;
}
