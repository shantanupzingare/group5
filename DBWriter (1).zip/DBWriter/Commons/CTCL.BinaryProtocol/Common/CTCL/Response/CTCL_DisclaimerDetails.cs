﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_DisclaimerDetails
    {
        public CTCL_DisclaimerId DisclaimerId;
        public CTCL_ExchangeSegmentId SegmentId;
        public CTCL_DisclaimerTitle DisclaimerTitle;
    }
}
