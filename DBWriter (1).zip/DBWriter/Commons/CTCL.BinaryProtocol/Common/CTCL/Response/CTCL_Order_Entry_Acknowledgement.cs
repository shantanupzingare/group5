﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Entry_Acknowledgement
{
	public CTCL_MessageHeader MessageHeader;
	public CTCL_OrderContextIdentifier OrderContextIdentifier;
	public CTCL_OrderContextIdentifier GatewayOrderNumber;
	public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
	public CTCL_TraderId TraderId;
	public CTCL_TerminalID Initiator;
	public CTCL_Token MappingTokenId;
}
