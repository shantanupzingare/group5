﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_INSTRUMENT_BASKET_ADD_UPDATE_RESPONSE
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_RequestContext ContextIdentifier;
		public StatusCode StatusCode;
		public CTCL_StatusString StatusString;
		public CTCL_Id TemplateId;
	}
}
