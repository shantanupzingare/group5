﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response.EnterpriseMaster
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_END_SUB_TEMPLATE_WISE_ENTERPRISE_MASTER_DOWNLOAD
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_EMInformationIdentifier msgInformationIdentifier;
		public CTCL_Id instrumentBasketTemplateID;
		public CTCL_TotalNoOfRecordsofSubData NumberOfRecords;
	}
}
