﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CTCL.Common.CTCL_UserIP;

namespace CTCL.BinaryProtocol.Common.CTCL.Response.EnterpriseMaster
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_SUB_ENTERPRISE_MASTER_DOWNLOAD
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_EMInformationIdentifier msgInformationIdentifier;
		public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
	}
}
