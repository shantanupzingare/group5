﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_MSG_DOWNLOAD_UPDATE
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier contextIdentifier;
		public CTCL_MessageInformationIdentifier msgInformationIdentifier;
		public CTCL_MessageLength MessageLength;
		public CTCL_MSGData MSGData;
	}
}
