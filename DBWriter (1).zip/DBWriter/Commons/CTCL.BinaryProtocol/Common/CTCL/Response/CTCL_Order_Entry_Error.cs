﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Entry_Error
{
    public CTCL_MessageHeader messageHeader;
    public CTCL_Code ExchangeReasonCode;
    public CTCL_DateTime OrderEntryTime;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
    public CTCL_OrderContextIdentifier OrderContextIdentifier;
    public CTCL_Message ErrorMessage;
    public CTCL_Token MappingTokenId;
	public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
    public CTCL_BrokerTraderSpecificAttribute BrokerTraderSpecificAttribute;
	public CTCL_TerminalID Initiator;
	public CTCL_TimeStamp LastModifiedTime;
}

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_Order_Entry_Error_Internal
{
	public CTCL_MessageHeader messageHeader;
	public CTCL_Code ExchangeReasonCode;
	public CTCL_DateTime OrderEntryTime;
	public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
	public CTCL_OrderContextIdentifier OrderContextIdentifier;
	public CTCL_Message ErrorMessage;
	public CTCL_Token MappingTokenId;
	public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
    public CTCL_BrokerTraderSpecificAttribute BrokerTraderSpecificAttribute;
	public CTCL_TerminalID Initiator;
	public CTCL_TimeStamp LastModifiedTime;
	public CTCL_BuySellIndicator BuySellIndicator;
	public CTCL_ProductType ProductType;
	public CTCL_Settlor Participant;
	public CTCL_Error_OrderDetail OrderDetail;
}