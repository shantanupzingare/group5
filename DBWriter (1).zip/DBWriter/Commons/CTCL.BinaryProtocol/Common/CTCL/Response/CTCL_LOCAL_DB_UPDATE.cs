﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_LOCAL_DB_UPDATE
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        //public LDBInformationIdentifier ldBInformationIdentifier; Sameer sir suggested, as of now change enum to int due to marshalling issue.
        public CTCL_LDBInformationIdentifier ldBInformationIdentifier;
        public CTCL_MessageLength MessageLength;
        public CTCL_LDBData LDBData;
    }
}
