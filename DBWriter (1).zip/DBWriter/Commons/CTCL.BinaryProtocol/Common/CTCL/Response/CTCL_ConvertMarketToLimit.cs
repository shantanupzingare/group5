﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_ConvertMarketToLimit
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_OrderContextIdentifier OrderContextIdentifier;
    public CTCL_OrderContextIdentifier GatewayOrderNumber;
    public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
    public CTCL_Price Price;
    public CTCL_Contract_Desc Contract_Desc;
    public CTCL_LastActivityReference LastActivityReference;
    public CTCL_TimeStamp LastModifiedTime;
	public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
	public CTCL_TerminalID Initiator;
	public CTCL_Quantity DisclosedVolume;
	public CTCL_Quantity DisclosedVolumeRemaining;
	public CTCL_Quantity TotalVolumeRemaining;
	public CTCL_Quantity TotalVolume;
	public CTCL_Quantity VolumeFilledToday;
	public CTCL_AccountInformation AccountInformation;
	public CTCL_Settlor Participant;
	public CTCL_BuySellIndicator BuySellIndicator;
	public CTCL_ProductType ProductType;
}
