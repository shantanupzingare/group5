﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_LOGIN_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_StatusCode LoginStatusCode;
        public CTCL_EntityCategory EntityCategory;
        public CTCL_StatusString LoginStatusString;
        public CTCL_EntityName EntityName;
        public CTCL_APName APName;
        public CTCL_FamilyName FamilyName;
        public CTCL_TimeStamp LastLoginDateTime;
        public CTCL_TimeStamp LastPwdChangeDateTime;
        public CTCL_VersionInfo16 VersionInfo;
        public CTCL_PrimaryOMS PrimaryOMS;
		public CTCL_EntityId EntityId;
        public CTCL_SFTPUserCread sftpUserCred;
        public CTCL_TwoFAType TwoFAValidationType;
        public CTCL_PercentageDecimal SystemELM;
        public CTCL_MessageValueString BrokerName;
        public CTCL_TimeStamp ServerTimeOffset;
        public CTCL_AccessAllowedStruct AccessAllowed;
		public ComponentIdentifier AutoUpdaterComponentId;
        public CTCL_TimeStamp MTMRecalculateTime;
        public CTCL_AllowedExchangeSegment AllowedExchangeSegment;
        public CTCLEnviornment enviornment;
        public CTCL_Flag IsCNCSellAllowed;
        public CTCL_Flag IsGrossingAllowed;
		public CTCL_TotalNoOfRecords TotalNoOfRecords;
		public CTCL_EMData DisclaimerData;
       
	}
}
