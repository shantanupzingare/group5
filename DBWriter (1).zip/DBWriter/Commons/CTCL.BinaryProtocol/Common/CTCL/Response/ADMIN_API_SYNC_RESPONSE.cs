﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_ADMIN_API_LDB_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecords TotalNoOfRecords;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_SUB_ADMIN_API_LDB_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_AdminInformationIdentifier AdminInformationIdentifier;
        public CTCL_TotalNoOfRecordsofSubMessages TotalNoOfRecordsofSubMessages;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_ADMIN_API_LDB_UPDATE_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_AdminInformationIdentifier AdminInformationIdentifier;
        public CTCL_MessageLength MessageLength;
        public CTCL_LDBData LDBData;
    }
    
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_SUB_ADMIN_API_LDB_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_AdminInformationIdentifier AdminInformationIdentifier;
        public CTCL_TotalNoOfRecordsofSubMessages TotalNoOfRecordsofSubMessages;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_ADMIN_API_LDB_RESPONSE
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_TotalNoOfRecords TotalNoOfRecords;
    }
}
