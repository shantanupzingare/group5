﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_TrackResponse
{
    public CTCL_MessageHeader MessageHeader;
    public CTCL_UserIP TrackOne;
    public CTCL_UserIP TrackTwo;
}
