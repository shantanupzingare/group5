﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_AllowedQuantityMaster
    {
        public CTCL_ISINNumber ISINNumber;
        public CTCL_Symbol Symbol;
        public CTCL_Quantity PermittedQtyCMSegment;
        public CTCL_Quantity PermittedQtyAcrossAllSegment;
        public CTCL_TimeStamp CreatedOn;
        public CTCL_Remark NVCRemarks;
    }
}
