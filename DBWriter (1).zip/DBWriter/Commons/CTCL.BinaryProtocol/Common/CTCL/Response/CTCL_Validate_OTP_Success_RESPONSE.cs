﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
    public class CTCL_Validate_OTP_Success_RESPONSE : CTCL_BASE_RESPONSE
    {
    }
}
