﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.CTCL.Response
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_Participant_Trade_Acknowledgement_Response
	{
		public CTCL_MessageHeader MessageHeader;
		public CTCL_ExchangeOrderNumber ExchangeOrderNumber;
		public CTCL_FillNumber TradeNumber;
		public CTCL_AccountInformation AccountInformation;
		public CTCL_Participant ParticipantCode;
		public CTCL_BuySellIndicator Buy_SellIndicator;
		public CTCL_ProductType ProductType;
		public CTCL_Quantity TotalVolume;
		public CTCL_Price Price;
		public CTCL_Quantity ApprovedQuantity;
		public CTCL_Quantity TradedQuantity;
		public CTCL_Remarks UserRemarks;
		public CTCL_Token Token;
		public CTCL_ExchangeSpecificAttributeComposition ExchangeSpecificAttributeComposition;
	}
}
