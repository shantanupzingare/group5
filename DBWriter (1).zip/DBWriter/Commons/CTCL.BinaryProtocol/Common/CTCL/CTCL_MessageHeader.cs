﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using CTCL_OpCode = CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode;

namespace CTCL.BinaryProtocol.Common.CTCL;

[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class CTCL_MessageHeader
{   
    public CTCL_OpCode OpCode;  
    public CTCL_TimeStamp TimeStamp; 
    public CTCL_MessageLength MessageLength;  
    public ComponentIdentifier SourceComponentIdentifier; 
    public ComponentIdentifier DestinationComponentIdentifier;  
    public CTCL_ExchangeSegmentId ExchangeSegmentId;
    public CTCL_ComponentInstanceIdentifier SourceComponentInstance;
    public CTCL_ComponentInstanceIdentifier DestComponentInstance;
}