﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.FileUpload
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_START_UPLOAD_FILE_INFO
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_TotalNoOfRecords NumberOfRecords;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UPDATE_FILE_INFO
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_Name fileName;
        public CTCL_TotalNoOfRecords NoOfRecords;
        public CTCL_EMData fileInfoData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_END_UPLOAD_FILE_INFO
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_TotalNoOfRecords NumberOfRecords;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UPLOAD_FILE_DATA
    {
        public CTCL_ClientId clientCode;
        public CTCL_ClientId groupCode;
        public CTCL_ReserveLong reserve;
        public CTCL_Price limit;
        public CTCL_ConversionCurrencyId currencyId;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_UPDATE_FILE_INFO_RESPONSE
    {
        public CTCL_MessageHeader messageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public StatusCode statusCode;
        public CTCL_StatusString StatusString;
    }

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CTCL_LIMIT_FILE_UPLOAD_RESPONSE
	{
		public CTCL_MessageHeader messageHeader;
		public CTCL_ContextIdentifier ContextIdentifier;
		public StatusCode statusCode;
		public CTCL_StatusString StatusString;
        public CTCL_TerminalID TerminalID;
	}
}
