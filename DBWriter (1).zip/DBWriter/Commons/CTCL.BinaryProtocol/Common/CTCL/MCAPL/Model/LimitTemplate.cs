﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.MCAPL.Model
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class LimitTemplate : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Id LimitTemplateId;
        [Validator(validationType.alpha_numeric, "Please enter valid template name")]
        public LimitTemplateName TemplateName;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class LimitTemplateAttribute : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Id TemplateId;
        public CTCL_Id AttributeId;
        public CTCL_Price Limit;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class LimitTemplateUser : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_STRTerminalID TerminalID;
        public CTCL_OperationMode OperationMode;
    }
}
