﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.MCAPL.Model
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class McapAttributeResonseData
    {
        public CTCL_Id AttributeId;
        public CTCL_ISINNumber ISINNumber;
    }
}
