﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.MCAPL.Model
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MarketCapitalisationLimitTemplate : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Id MCAPTemplateId;
        [Validator(validationType.alpha_numeric, "Please enter valid template name")]
        public MCAPLimitTemplateName TemplateName;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MCAP_Limit_TemplateAttribute : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_Id AttributeId;
        public CTCL_ISINNumber ISINNumber;
        public CTCL_Price Limit;
        public CTCL_Price MaximumUpperLimit;
        public CTCL_OperationMode OperationMode;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class MCAP_Limit_TemplateUser : CTCL_RMSCommonMasterAttributes
    {
        public CTCL_STRTerminalID TerminalID;
        public CTCL_OperationMode OperationMode;
    }

}
