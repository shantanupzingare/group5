﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CTCL.MCAPL.Response
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MCAP_ATTRIBUTE_RESPONSE_START_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MCAP_ATTRIBUTE_RESPONSE_START_SUB_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier contextIdentifier;
        public CTCL_Id TemplateId;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MCAP_ATTRIBUTE_RESPONSE_UPDATE_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_Id LimitTemplateId;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofMapping;
        public CTCL_EMData AttributeResponseData; //McapAttributeResonseData
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MCAP_ATTRIBUTE_RESPONSE_END_SUB_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public CTCL_Id LimitTemplateId;
        public CTCL_NoOfRecordsofSubData NoOfRecordsofSubData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CTCL_MCAP_ATTRIBUTE_RESPONSE_END_REQUEST
    {
        public CTCL_MessageHeader MessageHeader;
        public CTCL_ContextIdentifier ContextIdentifier;
        public StatusCode StatusCode;
        public CTCL_StatusString StatusString;
        public CTCL_TotalNoOfRecordsofSubData TotalNoOfRecordsofSubData;
    }
}
