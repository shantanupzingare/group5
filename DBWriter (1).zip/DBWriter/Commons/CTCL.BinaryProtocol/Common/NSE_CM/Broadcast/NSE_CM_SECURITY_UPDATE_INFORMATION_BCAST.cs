﻿using CTCL.BinaryProtocol.Common.NSE_CM.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.NSE_CM.Broadcast
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class NSE_CM_SECURITY_UPDATE_INFORMATION_BCAST
    {
        public NSE_CM_BCAST_HEADER MESSAGE_HEADER;
#if VER_5_7
        public NSE_CM_Token_TNDTC Token;
#else
    public NSE_CM_Token_2Byte Token;
#endif
        public NSE_CM_SEC_INFO SEC_INFO;
        public NSE_CM_InstrumentType InstrumentType;
        public NSE_CM_PermittedToTrade PermittedToTrade;
        public NSE_CM_IssuedCapital IssuedCapital;
        public NSE_CM_SettlementType SettlementType;
        public NSE_CM_FreezePercent FreezePercent;
        public NSE_CM_CreditRating CreditRating;
        public NSE_CM_Reserved_1Byte Reserved1;
       // public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes[] SECURITY_ELIGIBILITY_PER_MARKET = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes[6];
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET1 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET2 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET3 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET4 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET5 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_ELIGIBLITY_PERMARKET_4Bytes SECURITY_ELIGIBILITY_PER_MARKET6 = new NSE_CM_ELIGIBLITY_PERMARKET_4Bytes();
        public NSE_CM_SurvInd SurvInd;
        public NSE_CM_IssueStartDate IssueStartDate;
        public NSE_CM_InterestPaymentDate InterestPaymentDate;
        public NSE_CM_IssueMaturityDate IssueMaturityDate;
        public NSE_CM_BoardLotQuantity BoardLotQuantity;
        public NSE_CM_TickSize TickSize;
        public NSE_CM_Name Name;
        public NSE_CM_Reserved_1Byte Reserved2;
        public NSE_CM_ListingDate ListingDate;
        public NSE_CM_ExpulsionDate ExpulsionDate;
        public NSE_CM_ReAdmissionDate ReAdmissionDate;
        public NSE_CM_RecordDate RecordDate;
        public NSE_CM_ExpiryDate ExpiryDate;
        public NSE_CM_NoDeliveryStartDate NoDeliveryStartDate;
        public NSE_CM_NoDeliveryEndDate NoDeliveryEndDate;
        //public NSE_CM_ELIGIBLITY_INDICATORS ELIGIBLITY_INDICATORS;
        public NSE_CM_ELIGIBLITY_INDICATOR_2Bytes ELIGIBLITY_INDICATORS;
        public NSE_CM_BookClosureStartDate BookClosureStartDate;
        public NSE_CM_BookClosureEndDate BookClosureEndDate;
        //public NSE_CM_PURPOSE PURPOSE_structures;
        public NSE_CM_PURPOSE_2Bytes PURPOSE_structures;
        public NSE_CM_LocalUpdateDateTime LocalUpdateDateTime;
        public NSE_CM_DeleteFlag DeleteFlag;
        public NSE_CM_Remark Remark;
        public NSE_CM_FaceValue FaceValue;
        public NSE_CM_ISINNumber ISINNumber;
        public NSE_CM_MktMakerSpread MktMakerSpread;
        public NSE_CM_MktMakerMinQty MktMakerMinQty;
        public NSE_FO_CallAuctionFalg CallAuction1Flag;
    }
}
