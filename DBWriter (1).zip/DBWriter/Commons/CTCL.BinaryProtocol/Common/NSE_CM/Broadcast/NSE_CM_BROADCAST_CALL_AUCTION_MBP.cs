﻿using CTCL.BinaryProtocol.Common.NSE_CM.Common;
using System.Runtime.InteropServices;

namespace CTCL.BinaryProtocol.Common.NSE_CM.Broadcast;
[StructLayout(LayoutKind.Sequential, Pack = 1)]
public class NSE_CM_BROADCAST_CALL_AUCTION_MBP
{
    public NSE_CM_BCAST_HEADER BCAST_HEADER;
	public NSE_CM_NoOfRecords NoOfRecords;
    public NSE_CM_INTERACTIVE_CALL_AUCTION_MBP_DATA[] INTERACTIVE_CALL_AUCTION_MBP_DATA = new NSE_CM_INTERACTIVE_CALL_AUCTION_MBP_DATA[2];
}