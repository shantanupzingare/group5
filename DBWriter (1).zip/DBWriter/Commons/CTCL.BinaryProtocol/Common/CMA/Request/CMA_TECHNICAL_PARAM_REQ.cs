﻿using CTCL.BinaryProtocol.Common.CMA.Commons;
using CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Request
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_TECHNICAL_PARAM_REQ
    {
        public CMA_MessageHeader MessageHeader;
        public CMA_RequestId RequestID;
        public InfoMaster InfoMaster;
        public InfoStatistics InfoStatistics;
        // public  CMA_CommonMasterAttributes CommonMasterAttributes;
        public CMA_Timer CMA_Timer;
    }
}
