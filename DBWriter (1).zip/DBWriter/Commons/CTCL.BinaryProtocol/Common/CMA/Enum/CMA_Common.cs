﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.Enum
{

    public enum CMA_OpenClose
    {
        Open = 'O',
        Closed = 'C',
    }

    public enum CMA_Status : short
    {
        INVALIDAUTHDETAIL = 1000,
        PASSWORDEXISTS = 2000
    }

    public enum CMA_AuthType : short
    {
        PASSWORD = 1,
        //2FA = 2,
    }


    public enum CMA_ModifiedBy
    {
        Trader = 'T',
        BranchManager = 'B',
        CorporateManager = 'M',
        Exchange = 'C'
    }

    public enum UserType : short
    {
        Admin = 1,
        ReservedUser = 2,
        Client = 3,
        Dealer = 4,
        Normaluser = 5
    }
    public class ComponenetAgentConst
    {
        public const string ConnectedUser = "ConnectedUser";
        public const string OrderCount = "OrderCount";
        public const string TradeCount = "TradeCount";
        public const string frequency = "frequency";
        public const string breach = "breach";
    }
}
