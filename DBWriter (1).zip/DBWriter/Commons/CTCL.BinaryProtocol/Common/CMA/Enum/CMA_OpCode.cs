﻿namespace CTCL.BinaryProtocol.Common.CMA.Enum
{
    public enum CMA_OpCode : short
    {
        LOGIN_REQ = 101,
        LOGIN_RESPONSE = 102,

        FILE_INFO_REQ = 103,
        FILE_INFO_RES = 104,
        END_FILE_UPLOAD = 105,
        COMPONENT_INFO_REQ = 106,
        COMPONENT_INFO_RES = 107,
        COMPONENT_STATE_UPDATE = 108,

        START_FILE_UPLOAD = 109,
        COMPONENT_START = 110,

        FILE_UPLOAD_CONFIRMATION = 111,

        AGENT_HANDSHAKE_REQ = 112,
        AGENT_HANDSHAKE_RES = 113,
        CMA_TECHNICAL_PARAM_REQ = 114,
        INFO_MASTER_FOR_DB = 115,
        INFO_STATISTICS_FOR_DB = 116,
		COMPONENT_STOP = 117,

        END_MSG_DOWNLOAD = 118,

        START_AFTER_BOD_FILE_UPLOAD = 119,
    }
    public enum CMA_StatusCode
    {
        Stopped = 0,
        Started = 1,
        Completed = 2,
    }
}
