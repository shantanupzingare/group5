﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
    public class InstanceMaster
    {
        public int IntInstanceId { get; set; }

        public int IntComponentId { get; set; }

        public string? NvcInstanceName { get; set; }
        public string? NvcInstanceIp { get; set; }
        public string? IntPort { get; set; }

        public DateTime DtmCreatedOn { get; set; }

        public int? IntCreatedBy { get; set; }

        public DateTime? DtmUpdatedOn { get; set; }

        public int? IntUpdatedBy { get; set; }

        public int BitIsActive { get; set; }

        public int BitIsDelete { get; set; }

        public DateTime DtmStartDate { get; set; }

        public DateTime? DtmEndDate { get; set; }

        public int? VersionNo { get; set; }

        public int? CapacityWeightage { get; set; }

        public string NvcBrokerSiteId { get; set; }
    }
}
