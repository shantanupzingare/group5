﻿using CTCL.BinaryProtocol.Common.CMA.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
    public class CMACommons
    {
        #region DateTime

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_DateTime
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _dateTime;

            public CMA_DateTime(int _value)
            {
                _dateTime = _value;
            }
            public int DateTime { get => _dateTime; set => _dateTime = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_DateTime_OMS
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _dateTime;

            public CMA_DateTime_OMS(long _value)
            {
                _dateTime = _value;
            }
            public long DateTime { get => _dateTime; set => _dateTime = value; }
        }

        #endregion

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct ComponentIdentifier
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _componentId;
            public ComponentIdentifier(short _value)
            {
                _componentId = _value;
            }
            public short ComponentId { get => _componentId; set => _componentId = value; }

            public static explicit operator ComponentIdentifier(short v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MarketStatus
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _marketStatus;
            public CMA_MarketStatus(short _value)
            {
                _marketStatus = _value;
            }
            public short MarketStatus { get => _marketStatus; set => _marketStatus = value; }
        }

        //[StructLayout(LayoutKind.Sequential, Pack = 1)]
        //public struct CMA_OpCode
        //{
        //    [MarshalAs(UnmanagedType.I4)]
        //    private int _opCode;

        //    public CMA_OpCode(int _value)
        //    {
        //        _opCode = _value;
        //    }
        //    public int OpCode { get => _opCode; set => _opCode = value; }
        //}


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Transaction_Code
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _transactionCode;

            public CMA_Transaction_Code(short _value)
            {
                _transactionCode = _value;
            }
            public short TransactionCode { get => _transactionCode; set => _transactionCode = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AlphaChar
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _alphachar;
            public CMA_AlphaChar(char[] _value)
            {
                _alphachar = new char[2];
                Array.Copy(_value, 0, _alphachar, 0, _value.Length > _alphachar.Length ? _alphachar.Length : _value.Length);
            }
            public CMA_AlphaChar()
            {
                _alphachar = new char[2];

            }
            public char[] Alphachar { get => _alphachar; set => _alphachar = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TraderId
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _traderid;
            public CMA_TraderId(int _value)
            {
                _traderid = _value;
            }
            public int Traderid { get => _traderid; set => _traderid = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TimeStamp
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _timestamp;
            public CMA_TimeStamp(long _value)
            {
                _timestamp = _value;
            }
            public long TimeStamp { get => _timestamp; set => _timestamp = value; }

            public static explicit operator CMA_TimeStamp(string v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MessageLength
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _messagelength;
            public CMA_MessageLength(int _value)
            {
                _messagelength = _value;
            }
            public int Messagelength { get => _messagelength; set => _messagelength = value; }

            public static explicit operator CMA_MessageLength(int v)
            {
                throw new NotImplementedException();
            }
        }



        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TimeStamp1 // 8 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            private char[] _timestamp1;
            public CMA_TimeStamp1(char[] _value)
            {
                _timestamp1 = new char[8];
                Array.Copy(_value, 0, _timestamp1, 0, _value.Length > _timestamp1.Length ? _timestamp1.Length : _value.Length);
            }
            public CMA_TimeStamp1()
            {
                _timestamp1 = new char[8];

            }
            public char[] TimeStamp { get => _timestamp1; set => _timestamp1 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_VersionInfo
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _versionInfo;
            public CMA_VersionInfo(char[] _value)
            {
                _versionInfo = new char[16];
                Array.Copy(_value, 0, _versionInfo, 0, _value.Length > _versionInfo.Length ? _versionInfo.Length : _value.Length);
            }
            public CMA_VersionInfo()
            {
                _versionInfo = new char[16];
            }
            public char[] VersionInfo { get => _versionInfo; set => _versionInfo = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OrderContextIdentifier
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _contextIdentifier;
            public CMA_OrderContextIdentifier(char[] _value)
            {
                _contextIdentifier = new char[32];
                Array.Copy(_value, 0, _contextIdentifier, 0, _value.Length > _contextIdentifier.Length ? _contextIdentifier.Length : _value.Length);
            }
            public CMA_OrderContextIdentifier()
            {
                _contextIdentifier = new char[32];
            }
            public char[] OrderContextIdentifier { get => _contextIdentifier; set => _contextIdentifier = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_UserID
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _userID;
            public CMA_UserID(long _value)
            {
                _userID = _value;
            }
            public long UserID { get => _userID; set => _userID = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TraderName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26)]
            private char[] _traderName;
            public CMA_TraderName(char[] _value)
            {
                _traderName = new char[26];
                Array.Copy(_value, 0, _traderName, 0, _value.Length > _traderName.Length ? _traderName.Length : _value.Length);

            }
            public CMA_TraderName()
            {
                _traderName = new char[26];

            }
            public char[] TraderName { get => _traderName; set => _traderName = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InfoID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _infoId;
            public CMA_InfoID(short _value)
            {
                _infoId = _value;
            }
            public short InfoID { get => _infoId; set => _infoId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Port
        {
            [MarshalAs(UnmanagedType.I2)]
            private int _port;
            public CMA_Port(int _value)
            {
                _port = _value;
            }
            public int Port { get => _port; set => _port = value; }

            public static explicit operator CMA_Port(int v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InstanceID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _instanceId;
            public CMA_InstanceID(short _value)
            {
                _instanceId = _value;
            }
            public short InstanceID { get => _instanceId; set => _instanceId = value; }

            public static explicit operator CMA_InstanceID(short v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParamID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _paramId;
            public CMA_ParamID(short _value)
            {
                _paramId = _value;
            }
            public short ParamID { get => _paramId; set => _paramId = value; }

            public static explicit operator CMA_ParamID(short v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParamAttribute
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _paramAttribute;
            public CMA_ParamAttribute(short _value)
            {
                _paramAttribute = _value;
            }
            public short ParamAttribute { get => _paramAttribute; set => _paramAttribute = value; }

            public static explicit operator CMA_ParamAttribute(short v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BrokerSiteInstanceID
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
            private char[] _brokerSiteInstance;
            public CMA_BrokerSiteInstanceID(char[] _value)
            {
                _brokerSiteInstance = _value;
                Array.Copy(_value, 0, _brokerSiteInstance, 0, _value.Length > _brokerSiteInstance.Length ? _brokerSiteInstance.Length : _value.Length);
            }
            public char[] BrokerSiteInstanceID { get => _brokerSiteInstance; set => _brokerSiteInstance = value; }

        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BrokerID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _brokerId;
            public CMA_BrokerID(short _value)
            {
                _brokerId = _value;
            }
            public short BrokerID { get => _brokerId; set => _brokerId = value; }

            public static implicit operator CMA_BrokerID(short _value) => new CMA_BrokerID(_value);
            //public static implicit operator CMA_BrokerID(int v)
            //{
            //    //throw new NotImplementedException();
            //}
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SiteID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _siteId;
            public CMA_SiteID(short _value)
            {
                _siteId = _value;
            }
            public short SiteId { get => _siteId; set => _siteId = value; }

            public static explicit operator CMA_SiteID(short v)
            {
                throw new NotImplementedException();
            }
        }

        //[StructLayout(LayoutKind.Sequential, Pack = 1)]
        //public struct CMA_References
        //{
        //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
        //    private char[] _creference;
        //    public char[] Reference { get => _creference; set => _creference = value; }
        //    public CMA_References()
        //    {
        //        _creference = new char[25];
        //    }
        //    public CMA_References(char[] _value)
        //    {
        //        _creference = new char[25];
        //        //Array.Copy(_value, 0, _creference, 0, _value.Length > _creference.Length ? _creference.Length : _value.Length);
        //    }

        //    public static explicit operator CMA_References(string v)
        //    {
        //        throw new NotImplementedException();
        //    }
        //}

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_References
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _references;
            public char[] References { get => _references; set => _references = value; }
            public CMA_References(char[] _value)
            {
                _references = new char[16];
                Array.Copy(_value, 0, _references, 0, _value.Length > _references.Length ? _references.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Value
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
            private char[] _cvalue;
            public char[] Value { get => _cvalue; set => _cvalue = value; }
            public CMA_Value()
            {
                _cvalue = new char[24];
            }
            public CMA_Value(char[] _value)
            {
                _cvalue = new char[24];
                Array.Copy(_value, 0, _cvalue, 0, _value.Length > _cvalue.Length ? _cvalue.Length : _value.Length);
            }

            public static explicit operator CMA_Value(string v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BranchID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _branchId;
            public CMA_BranchID(short _value)
            {
                _branchId = _value;
            }
            public short BranchID { get => _branchId; set => _branchId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_VersionNumber
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _versionNumber;
            public int VersionNumber { get => _versionNumber; set => _versionNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_HostSwitchContext
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _hostsWwitchContext;
            public char HostSwitchContext { get => _hostsWwitchContext; set => _hostsWwitchContext = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Colour
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 50)]
            private char[] _colour;
            public CMA_Colour(char[] _value)
            {
                _colour = new char[50];
                Array.Copy(_value, 0, _colour, 0, _value.Length > _colour.Length ? _colour.Length : _value.Length);

            }
            public CMA_Colour()
            {
                _colour = new char[50];
            }
            public char[] Colour { get => _colour; set => _colour = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_UserType
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _userType;
            public short UserType { get => _userType; set => _userType = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SequenceNumber
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _sequenceNumber;
            public CMA_SequenceNumber(long _value)
            {
                _sequenceNumber = _value;
            }
            public long SequenceNumber { get => _sequenceNumber; set => _sequenceNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_WsClassName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
            private char[] _wsClassName;
            public char[] WsClassName { get => _wsClassName; set => _wsClassName = value; }
            public CMA_WsClassName()
            {
                _wsClassName = new char[14];
            }
            public CMA_WsClassName(char[] _value)
            {
                _wsClassName = new char[14];
                Array.Copy(_value, 0, _wsClassName, 0, _value.Length > _wsClassName.Length ? _wsClassName.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BrokerStatus
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _brokerStatus;
            public char BrokerStatus { get => _brokerStatus; set => _brokerStatus = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ShowIndex
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _showIndex;
            public char ShowIndex { get => _showIndex; set => _showIndex = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ClearingStatus
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _clearingStatus;
            public char ClearingStatus { get => _clearingStatus; set => _clearingStatus = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MemberType
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _memberType;
            public CMA_MemberType(short _value)
            {
                _memberType = _value;
            }
            public short MemberType { get => _memberType; set => _memberType = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BrokerName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
            private char[] _brokerName;
            public char[] BrokerName { get => _brokerName; set => _brokerName = value; }
            public CMA_BrokerName()
            {
                _brokerName = new char[25];
            }
            public CMA_BrokerName(char[] _value)
            {
                _brokerName = new char[25];
                Array.Copy(_value, 0, _brokerName, 0, _value.Length > _brokerName.Length ? _brokerName.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_UpdatePortfolio
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _updatePortfolio;
            public char UpdatePortfolio { get => _updatePortfolio; set => _updatePortfolio = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MarketIndex
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _marketIndex;
            public int MarketIndex { get => _marketIndex; set => _marketIndex = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AuctionMarket
        {

            private bool _auctionMarket;
            public bool AuctionMarket { get => _auctionMarket; set => _auctionMarket = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SpotMarket
        {

            private bool _spotMarket;
            public bool SpotMarket { get => _spotMarket; set => _spotMarket = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OddlotMarket
        {

            private bool _oddlotMarket;
            public bool OddlotMarket { get => _oddlotMarket; set => _oddlotMarket = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NormalMarket
        {

            private bool _normalMarket;
            public bool NormalMarket { get => _normalMarket; set => _normalMarket = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Key
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
            private char[] _key;
            public char[] Key { get => _key; set => _key = value; }
            public CMA_Key()
            {
                _key = new char[14];
            }
            public CMA_Key(char[] _value)
            {
                _key = new char[14];
                Array.Copy(_value, 0, _key, 0, _value.Length > _key.Length ? _key.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ErrorMessage
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _errorMessage;
            public CMA_ErrorMessage()
            {
                _errorMessage = new char[128];
            }
            public CMA_ErrorMessage(char[] _value)
            {
                _errorMessage = new char[128];
                Array.Copy(_value, 0, _errorMessage, 0, _value.Length > _errorMessage.Length ? _errorMessage.Length : _value.Length);
            }
            public char[] ErrorMessage { get => _errorMessage; set => _errorMessage = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Period
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _period;
            public CMA_Period(int _value)
            {
                _period = _value;
            }
            public int Period { get => _period; set => _period = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ErrorCode
        {
            [MarshalAs(UnmanagedType.I4)]
            private long _errorCode;
            public CMA_ErrorCode(long _value)
            {
                _errorCode = _value;
            }
            public long ErrorCode { get => _errorCode; set => _errorCode = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Percent
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _percent;
            public short Percent { get => _percent; set => _percent = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Quantity
        {
            [MarshalAs(UnmanagedType.I8)] //I4 to I8
            private long _quantity;
            public CMA_Quantity(long _value)
            {
                _quantity = _value;
            }
            public long Quantity { get => _quantity; set => _quantity = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TickSize
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _tickSize;
            public int TickSize { get => _tickSize; set => _tickSize = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InterestRate
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _interestRate;
            public int InterestRate { get => _interestRate; set => _interestRate = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParticipantType
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _participantType;
            public CMA_ParticipantType(char[] _value)
            {
                _participantType = new char[1];
                Array.Copy(_value, 0, _participantType, 0, _value.Length > _participantType.Length ? _participantType.Length : _value.Length);
            }
            public CMA_ParticipantType()
            {
                _participantType = new char[1];
            }
            public char[] ParticipantType { get => _participantType; set => _participantType = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Modified
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _modified;
            public CMA_Modified(char _value)
            {
                _modified = _value;
            }
            public char Modified { get => _modified; set => _modified = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Code
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _code;
            public CMA_Code(short _value)
            {
                _code = _value;
            }
            public int Code { get => _code; set => _code = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Normal
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _normal;
            public short Normal { get => _normal; set => _normal = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Oddlot
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _oddlot;
            public short Oddlot { get => _oddlot; set => _oddlot = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Spot
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _spot;
            public short Spot { get => _spot; set => _spot = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Auction
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _auction;
            public short Auction { get => _auction; set => _auction = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BooksMerged
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _booksMerged;
            public bool BooksMerged { get => _booksMerged; set => _booksMerged = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MinimumFill
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _minimumFill;
            public bool MinimumFill { get => _minimumFill; set => _minimumFill = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AON
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _aon;
            public CMA_AON(bool _value)
            {
                _aon = _value;
            }
            public bool AON { get => _aon; set => _aon = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_RequestForOpenOrders
        {
            private char _requestForOpenOrders;
            public char RequestForOpenOrders { get => _requestForOpenOrders; set => _requestForOpenOrders = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NoOfRecords
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _noOfRecords;
            public short NoOfRecords { get => _noOfRecords; set => _noOfRecords = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MaximumGtcDays
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _maximumGtcDays;
            public short MaximumGtcDays { get => _maximumGtcDays; set => _maximumGtcDays = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IndexName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _indexName;
            public char[] IndexName { get => _indexName; set => _indexName = value; }
            public CMA_IndexName(char[] _value)
            {
                _indexName = new char[16];
                Array.Copy(_value, 0, _indexName, 0, _value.Length > _indexName.Length ? _indexName.Length : _value.Length);
            }
            public CMA_IndexName()
            {
                _indexName = new char[16];
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExchangeSpecificAttributeComposition
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _exchangeSpecificAttributeComposition;
            public CMA_ExchangeSpecificAttributeComposition(char[] _value)
            {
                _exchangeSpecificAttributeComposition = new char[16];
                Array.Copy(_value, 0, _exchangeSpecificAttributeComposition, 0, _value.Length > _exchangeSpecificAttributeComposition.Length ? _exchangeSpecificAttributeComposition.Length : _value.Length);
            }
            public CMA_ExchangeSpecificAttributeComposition()
            {
                _exchangeSpecificAttributeComposition = new char[16];
            }
            public char[] ExchangeSpecificAttributeComposition { get => _exchangeSpecificAttributeComposition; set => _exchangeSpecificAttributeComposition = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Token
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _token;
            public CMA_Token(long _value)
            {
                _token = _value;
            }
            public long Token { get => _token; set => _token = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CurrentOI
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _currentOI;
            public int CurrentOI { get => _currentOI; set => _currentOI = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BcastName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 26)]
            private char[] _bcastName;
            public char[] BcastName { get => _bcastName; set => _bcastName = value; }
            public CMA_BcastName(char[] _value)
            {
                _bcastName = new char[26];
                Array.Copy(_value, 0, _bcastName, 0, _value.Length > _bcastName.Length ? _bcastName.Length : _value.Length);
            }
            public CMA_BcastName()
            {
                _bcastName = new char[26];
            }

        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ChangedName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _changedName;
            public char[] ChangedName { get => _changedName; set => _changedName = value; }
            public CMA_ChangedName(char[] _value)
            {
                _changedName = new char[10];
                Array.Copy(_value, 0, _changedName, 0, _value.Length > _changedName.Length ? _changedName.Length : _value.Length);
            }
            public CMA_ChangedName()
            {
                _changedName = new char[10];
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_DeleteFlag
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _deleteFlag;
            public CMA_DeleteFlag(char[] _value)
            {
                _deleteFlag = new char[1];
                Array.Copy(_value, 0, _deleteFlag, 0, _value.Length > _deleteFlag.Length ? _deleteFlag.Length : _value.Length);
            }
            public CMA_DeleteFlag()
            {
                _deleteFlag = new char[1];
            }
            public char[] DeleteFlag { get => _deleteFlag; set => _deleteFlag = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Portfolio
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _portfolio;
            public char[] Portfolio { get => _portfolio; set => _portfolio = value; }
            public CMA_Portfolio()
            {
                _portfolio = new char[10];
            }
            public CMA_Portfolio(char[] _value)
            {
                _portfolio = new char[10];
                Array.Copy(_value, 0, _portfolio, 0, _value.Length > _portfolio.Length ? _portfolio.Length : _value.Length);
            }

        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InstrumentName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _instrumentName;
            public CMA_InstrumentName(char[] _value)
            {
                _instrumentName = new char[16];
                Array.Copy(_value, 0, _instrumentName, 0, _value.Length > _instrumentName.Length ? _instrumentName.Length : _value.Length);

            }
            public CMA_InstrumentName()
            {
                _instrumentName = new char[16];

            }
            public char[] InstrumentName { get => _instrumentName; set => _instrumentName = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Symbol
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _symbol;
            public CMA_Symbol(char[] _value)
            {
                _symbol = new char[16];
                Array.Copy(_value, 0, _symbol, 0, _value.Length > _symbol.Length ? _symbol.Length : _value.Length);

            }
            public CMA_Symbol()
            {
                _symbol = new char[16];
            }
            public char[] Symbol { get => _symbol; set => _symbol = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Price
        {
            [MarshalAs(UnmanagedType.I8)]  //I4 to I8
            private long _price;
            public CMA_Price(long _value)
            {
                _price = _value;
            }
            public long Price { get => _price; set => _price = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OptionType
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _optionType;
            public CMA_OptionType(char[] _value)
            {
                _optionType = new char[2];
                Array.Copy(_value, 0, _optionType, 0, _value.Length > _optionType.Length ? _optionType.Length : _value.Length);
            }
            public CMA_OptionType()
            {
                _optionType = new char[2];
            }
            public char[] OptionType { get => _optionType; set => _optionType = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CALevel
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _caLevel;
            public CMA_CALevel(short _value)
            {
                _caLevel = _value;
            }
            public short CALevel { get => _caLevel; set => _caLevel = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CounterPartyBrokerId
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _counterPartyBrokerId;
            public CMA_CounterPartyBrokerId(char[] _value)
            {
                _counterPartyBrokerId = new char[16];
                Array.Copy(_value, 0, _counterPartyBrokerId, 0, _value.Length > _counterPartyBrokerId.Length ? _counterPartyBrokerId.Length : _value.Length);
            }
            public CMA_CounterPartyBrokerId()
            {
                _counterPartyBrokerId = new char[16];
            }
            public char[] CounterPartyBrokerId { get => _counterPartyBrokerId; set => _counterPartyBrokerId = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CloseoutFlag
        {
            [MarshalAs(UnmanagedType.I1)]
            private char _closeoutFlag;
            public CMA_CloseoutFlag(char _value)
            {
                _closeoutFlag = _value;
            }
            public char CloseoutFlag { get => _closeoutFlag; set => _closeoutFlag = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OrderNumber
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _orderNumber;
            public CMA_OrderNumber(long _value)
            {
                _orderNumber = _value;
            }
            public long OrderNumber { get => _orderNumber; set => _orderNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExchangeOrderNumber
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _orderNumber;
            public CMA_ExchangeOrderNumber(long _value)
            {
                _orderNumber = _value;
            }
            public long OrderNumber { get => _orderNumber; set => _orderNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AccountNumber
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _accountNumber;
            public char[] AccountNumber { get => _accountNumber; set => _accountNumber = value; }
            public CMA_AccountNumber(char[] _value)
            {
                _accountNumber = new char[10];
                Array.Copy(_value, 0, _accountNumber, 0, _value.Length > _accountNumber.Length ? _accountNumber.Length : _value.Length);
            }
            public CMA_AccountNumber()
            {
                _accountNumber = new char[10];
            }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Buy_SellIndicator
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _buy_SellIndicator;
            public CMA_Buy_SellIndicator(short _value)
            {
                _buy_SellIndicator = _value;
            }
            public short Buy_SellIndicator { get => _buy_SellIndicator; set => _buy_SellIndicator = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Volume
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _volume;
            public CMA_Volume(long _value)
            {
                _volume = _value;
            }
            public long Volume { get => _volume; set => _volume = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IOC
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _IOC;
            public CMA_IOC(bool _value)
            {
                _IOC = _value;
            }
            public bool IOC { get => _IOC; set => _IOC = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_GTC
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _GTC;
            public CMA_GTC(bool _value)
            {
                _GTC = _value;
            }
            public bool GTC { get => _GTC; set => _GTC = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Day
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _day;
            public CMA_Day(bool _value)
            {
                _day = _value;
            }
            public bool Day { get => _day; set => _day = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MIT
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _MIT;
            public CMA_MIT(bool _value)
            {
                _MIT = _value;
            }
            public bool MIT { get => _MIT; set => _MIT = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SL
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _SL;
            public CMA_SL(bool _value)
            {
                _SL = _value;
            }
            public bool SL { get => _SL; set => _SL = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Market
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _market;
            public CMA_Market(bool _value)
            {
                _market = _value;
            }
            public bool Market { get => _market; set => _market = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ATO
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _ATO;
            public CMA_ATO(bool _value)
            {
                _ATO = _value;
            }
            public bool ATO { get => _ATO; set => _ATO = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Frozen
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _frozen;
            public CMA_Frozen(bool _value)
            {
                _frozen = _value;
            }
            public bool Frozen { get => _frozen; set => _frozen = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Traded
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _traded;
            public CMA_Traded(bool _value)
            {
                _traded = _value;
            }
            public bool Traded { get => _traded; set => _traded = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MatchedInd
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _matchedInd;
            public CMA_MatchedInd(bool _value)
            {
                _matchedInd = _value;
            }
            public bool MatchedInd { get => _matchedInd; set => _matchedInd = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MF
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _MF;
            public CMA_MF(bool _value)
            {
                _MF = _value;
            }
            public bool MF { get => _MF; set => _MF = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_cOrdFiller
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _cOrdFiller;
            public CMA_cOrdFiller(bool _value)
            {
                _cOrdFiller = _value;
            }
            public bool COrdFiller { get => _cOrdFiller; set => _cOrdFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OE_cOrdFiller
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24)]
            private char[] _cOrdFiller;
            public char[] COrdFiller { get => _cOrdFiller; set => _cOrdFiller = value; }
            public CMA_OE_cOrdFiller()
            {
                _cOrdFiller = new char[24];
            }
            public CMA_OE_cOrdFiller(char[] _value)
            {
                _cOrdFiller = new char[24];
                Array.Copy(_value, 0, _cOrdFiller, 0, _value.Length > _cOrdFiller.Length ? _cOrdFiller.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Open_Close
        {
            private char _open_Close;
            public CMA_Open_Close(char _value)
            {
                _open_Close = _value;
            }
            public char Open_Close { get => _open_Close; set => _open_Close = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PreOpen
        {
            private bool _open;
            public CMA_PreOpen(bool _value)
            {
                _open = _value;
            }
            public bool PreOpen { get => _open; set => _open = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OnStop
        {
            private bool _stop;
            public CMA_OnStop(bool _value)
            {
                _stop = _value;
            }
            public bool OnStopp { get => _stop; set => _stop = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Settlor
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            private char[] _settlor;
            public CMA_Settlor(char[] _value)
            {
                _settlor = new char[12];
                Array.Copy(_value, 0, _settlor, 0, _value.Length > _settlor.Length ? _settlor.Length : _value.Length);

            }
            public CMA_Settlor()
            {
                _settlor = new char[12];

            }
            public char[] Settlor { get => _settlor; set => _settlor = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ClientIndicator
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _clientIndicator;
            public CMA_ClientIndicator(short _value)
            {
                _clientIndicator = _value;
            }
            public short ClientIndicator { get => _clientIndicator; set => _clientIndicator = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BOC
        {

            private bool _BOC;
            public CMA_BOC(bool _value)
            {
                _BOC = _value;
            }
            public bool BOC { get => _BOC; set => _BOC = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_COL
        {

            private bool _COL;
            public CMA_COL(bool _value)
            {
                _COL = _value;
            }
            public bool COL { get => _COL; set => _COL = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_Order_Flag_bool
        {
            [MarshalAs(UnmanagedType.I1)]
            private bool _storderbool;
            public CMA_ST_Order_Flag_bool(bool _value)
            {
                _storderbool = _value;
            }
            public bool Storderbool { get => _storderbool; set => _storderbool = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_STPC
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _STPC;
            public CMA_STPC(bool _value)
            {
                _STPC = _value;
            }
            public bool STPC { get => _STPC; set => _STPC = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NnfField
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _nnfField;
            public CMA_NnfField(long _value)
            {
                _nnfField = _value;
            }
            public long NnfField { get => _nnfField; set => _nnfField = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MktReplay
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _mktReplay;
            public CMA_MktReplay(long _value)
            {
                _mktReplay = _value;
            }
            public long MktReplay { get => _mktReplay; set => _mktReplay = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PAN
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _PAN;
            public CMA_PAN(char[] _value)
            {
                _PAN = new char[10];
                Array.Copy(_value, 0, _PAN, 0, _value.Length > _PAN.Length ? _PAN.Length : _value.Length);

            }
            public char[] PAN { get => _PAN; set => _PAN = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AccountSpecificAttribute
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _accountSpecificAttribute;
            public CMA_AccountSpecificAttribute(char[] _value)
            {
                _accountSpecificAttribute = new char[32];
                Array.Copy(_value, 0, _accountSpecificAttribute, 0, _value.Length > _accountSpecificAttribute.Length ? _accountSpecificAttribute.Length : _value.Length);

            }
            public CMA_AccountSpecificAttribute()
            {
                _accountSpecificAttribute = new char[32];
            }
            public char[] AccountSpecificAttribute { get => _accountSpecificAttribute; set => _accountSpecificAttribute = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Algo_ID
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _algo_ID;
            public CMA_Algo_ID(int _value)
            {
                _algo_ID = _value;
            }
            public int Algo_ID { get => _algo_ID; set => _algo_ID = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LastActivityReference
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _lastActivityReference;
            public CMA_LastActivityReference(long _value)
            {
                _lastActivityReference = _value;
            }
            public long LastActivityReference { get => _lastActivityReference; set => _lastActivityReference = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reference
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            private char[] _reference;
            public char[] Reference { get => _reference; set => _reference = value; }
            public CMA_Reference()
            {
                _reference = new char[4];
            }
            public CMA_Reference(char[] _value)
            {
                _reference = new char[4];
                Array.Copy(_value, 0, _reference, 0, _value.Length > _reference.Length ? _reference.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TraderNumber
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _traderNumber;
            public int TraderNumber { get => _traderNumber; set => _traderNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TradeNumber
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _traderNumber;
            public CMA_TradeNumber(char[] _value)
            {
                _traderNumber = new char[16];
                Array.Copy(_value, 0, _traderNumber, 0, _value.Length > _traderNumber.Length ? _traderNumber.Length : _value.Length);

            }
            public CMA_TradeNumber()
            {
                _traderNumber = new char[16];
            }
            public char[] TradeNumber { get => _traderNumber; set => _traderNumber = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_FillNumber
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _fillNumber;
            public CMA_FillNumber(int _value)
            {
                _fillNumber = _value;
            }
            public int FillNumber { get => _fillNumber; set => _fillNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ActivityType
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _activityType;
            public char[] ActivityType { get => _activityType; set => _activityType = value; }

            public CMA_ActivityType()
            {
                _activityType = new char[2];
            }
            public CMA_ActivityType(char[] _value)
            {
                _activityType = new char[2];
                Array.Copy(_value, 0, _activityType, 0, _value.Length > _activityType.Length ? _activityType.Length : _value.Length);
            }

        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CounterBrokerId
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
            private char[] _counterBrokerId;
            public char[] CounterBrokerId { get => _counterBrokerId; set => _counterBrokerId = value; }
            public CMA_CounterBrokerId()
            {
                _counterBrokerId = new char[5];
            }
            public CMA_CounterBrokerId(char[] _value)
            {
                _counterBrokerId = new char[5];
                Array.Copy(_value, 0, _counterBrokerId, 0, _value.Length > _counterBrokerId.Length ? _counterBrokerId.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Participant
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _participant;

            public CMA_Participant(char[] _value)
            {
                _participant = new char[16];
                Array.Copy(_value, 0, _participant, 0, _value.Length > _participant.Length ? _participant.Length : _value.Length);

            }
            public CMA_Participant()
            {
                _participant = new char[16];
            }
            public char[] Participant { get => _participant; set => _participant = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ReservedFiller
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _reservedFiller;
            public char[] ReservedFiller { get => _reservedFiller; set => _reservedFiller = value; }

            public CMA_ReservedFiller()
            {
                _reservedFiller = new char[2];
            }
            public CMA_ReservedFiller(char[] _value)
            {
                _reservedFiller = new char[2];
                Array.Copy(_value, 0, _reservedFiller, 0, _value.Length > _reservedFiller.Length ? _reservedFiller.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BCSeqNo
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _BCSeqNo;
            public long BCSeqNo { get => _BCSeqNo; set => _BCSeqNo = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ComponentName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _componentName;
            public char[] ComponentName { get => _componentName; set => _componentName = value; }
            public CMA_ComponentName(char[] _value)
            {
                _componentName = new char[16];
                Array.Copy(_value, 0, _componentName, 0, _value.Length > _componentName.Length ? _componentName.Length : _value.Length);

            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ActionCode
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _actionCode;
            public char[] ActionCode { get => _actionCode; set => _actionCode = value; }
            public CMA_ActionCode(char[] _value)
            {
                _actionCode = new char[16];
                Array.Copy(_value, 0, _actionCode, 0, _value.Length > _actionCode.Length ? _actionCode.Length : _value.Length);

            }

        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_JournalingRequired
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _journalingRequired;
            public bool JournalingRequired { get => _journalingRequired; set => _journalingRequired = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Tandem
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _tandem;
            public bool Tandem { get => _tandem; set => _tandem = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ControlWorkstation
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _controlWorkstation;
            public bool ControlWorkstation { get => _controlWorkstation; set => _controlWorkstation = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TraderWorkstation
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _traderWorkstation;
            public bool TraderWorkstation { get => _traderWorkstation; set => _traderWorkstation = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BroadcastMessageLength
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _broadcastMessageLength;
            public short BroadcastMessageLength { get => _broadcastMessageLength; set => _broadcastMessageLength = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BroadcastMessage
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            private char[] _broadcastMessage;
            public char[] BroadcastMessage { get => _broadcastMessage; set => _broadcastMessage = value; }
            public CMA_BroadcastMessage()
            {
                _broadcastMessage = new char[256];
            }
            public CMA_BroadcastMessage(char[] _value)
            {
                _broadcastMessage = new char[256];
                Array.Copy(_value, 0, _broadcastMessage, 0, _value.Length > _broadcastMessage.Length ? _broadcastMessage.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Series
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _series;
            public CMA_Series(char[] _value)
            {
                _series = new char[2];
                Array.Copy(_value, 0, _series, 0, _value.Length > _series.Length ? _series.Length : _value.Length);

            }
            public CMA_Series()
            {
                _series = new char[2];
            }

            public char[] Series { get => _series; set => _series = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CALevel_Short
        {
            private short _caLevel;
            public short CALevel { get => _caLevel; set => _caLevel = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PermittedToTrade
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _permittedToTrade;
            public short PermittedToTrade { get => _permittedToTrade; set => _permittedToTrade = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InstrumentType
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _instrumenttype;
            public short Instrumenttype { get => _instrumenttype; set => _instrumenttype = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CallAuc1Flag
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _callAucFlag1;
            public short CallAugFlag { get => _callAucFlag1; set => _callAucFlag1 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SurvIndicator
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _survInd;
            public short SurvInd { get => _survInd; set => _survInd = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IssuedCapital
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _issuedCapital;
            public CMA_IssuedCapital(long _value)
            {
                _issuedCapital = _value;
            }
            public long IssuedCapital { get => _issuedCapital; set => _issuedCapital = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CreditRating
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
            private char[] _creditRating;
            public CMA_CreditRating(char[] _value)
            {
                _creditRating = new char[12];
                Array.Copy(_value, 0, _creditRating, 0, _value.Length > _creditRating.Length ? _creditRating.Length : _value.Length);

            }
            public CMA_CreditRating()
            {
                _creditRating = new char[12];

            }
            public char[] CreditRating { get => _creditRating; set => _creditRating = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_SEC_ELIGIBILITY_PER_MARKET_Reserved
        {
            private bool[] _reserved;
            public bool[] Reserved { get => _reserved; set => _reserved = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Eligibility
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _eligibility;
            public bool Eligibility { get => _eligibility; set => _eligibility = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IssueRate
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _issueRate;
            public short IssueRate { get => _issueRate; set => _issueRate = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Name
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _name;
            public CMA_Name(char[] _value)
            {
                _name = new char[32];
                Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
            }
            public CMA_Name()
            {
                _name = new char[32];
            }
            public char[] Name { get => _name; set => _name = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_ELIGIBLITY_INDICATORS_Reserved
        {
            private bool[] _reserved;
            public bool[] Reserved { get => _reserved; set => _reserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IntrinsicValue
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _intrinsicValue;
            public int IntrinsicValue { get => _intrinsicValue; set => _intrinsicValue = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AssetInstrument
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
            private char[] _assetInstrument;
            public char[] AssetInstrument { get => _assetInstrument; set => _assetInstrument = value; }
            public CMA_AssetInstrument()
            {
                _assetInstrument = new char[6];
            }
            public CMA_AssetInstrument(char[] _value)
            {
                _assetInstrument = new char[6];
                Array.Copy(_value, 0, _assetInstrument, 0, _value.Length > _assetInstrument.Length ? _assetInstrument.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AssetName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _assetName;
            public char[] AssetName { get => _assetName; set => _assetName = value; }
            public CMA_AssetName()
            {
                _assetName = new char[10];
            }
            public CMA_AssetName(char[] _value)
            {
                _assetName = new char[10];
                Array.Copy(_value, 0, _assetName, 0, _value.Length > _assetName.Length ? _assetName.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParticipateInMarketIndex
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _participateInMarketIndex;
            public bool ParticipateInMarketIndex { get => _participateInMarketIndex; set => _participateInMarketIndex = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExerciseStyle
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _exerciseStyle;
            public bool ExerciseStyle { get => _exerciseStyle; set => _exerciseStyle = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_EGM
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _EGM;
            public bool EGM { get => _EGM; set => _EGM = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AGM
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _AGM;
            public bool AGM { get => _AGM; set => _AGM = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Interest
        {
            private bool _interest;
            public bool Interest { get => _interest; set => _interest = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Bonus
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _bonus;
            public bool Bonus { get => _bonus; set => _bonus = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Rights
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _rights;
            public bool Rights { get => _rights; set => _rights = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Dividend
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _dividend;
            public bool Dividend { get => _dividend; set => _dividend = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_Purpose_Reserved
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool[] _reserved;
            public bool[] Reserved { get => _reserved; set => _reserved = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IsCorporateAdjusted
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _isCorporateAdjusted;
            public bool IsCorporateAdjusted { get => _isCorporateAdjusted; set => _isCorporateAdjusted = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IsThisAsse
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _isThisAsse;
            public bool IsThisAsse { get => _isThisAsse; set => _isThisAsse = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PlAllowed
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _plAllowed;
            public bool PlAllowed { get => _plAllowed; set => _plAllowed = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExRejectionAllowed
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _exRejectionAllowed;
            public bool ExRejectionAllowed { get => _exRejectionAllowed; set => _exRejectionAllowed = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExAllowed
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _exAllowed;
            public bool ExAllowed { get => _exAllowed; set => _exAllowed = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InstrumentId
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _instrumentId;
            public short InstrumentId { get => _instrumentId; set => _instrumentId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InstrumentDescription
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
            private char[] _instrumentDescription;
            public char[] InstrumentDescription { get => _instrumentDescription; set => _instrumentDescription = value; }
            public CMA_InstrumentDescription()
            {
                _instrumentDescription = new char[5];
            }
            public CMA_InstrumentDescription(char[] _value)
            {
                _instrumentDescription = new char[5];
                Array.Copy(_value, 0, _instrumentDescription, 0, _value.Length > _instrumentDescription.Length ? _instrumentDescription.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParticipantStatus
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _participantStatus;
            public CMA_ParticipantStatus(char[] _value)
            {
                _participantStatus = new char[1];
                Array.Copy(_value, 0, _participantStatus, 0, _value.Length > _participantStatus.Length ? _participantStatus.Length : _value.Length);

            }
            public CMA_ParticipantStatus()
            {
                _participantStatus = new char[1];

            }
            public char[] ParticipantStatus { get => _participantStatus; set => _participantStatus = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_WarningType
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _warningType;
            public short WarningType { get => _warningType; set => _warningType = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Final
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char _final;
            public char Final { get => _final; set => _final = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OpenInterest
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _openInterest;
            public int OpenInterest { get => _openInterest; set => _openInterest = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_DayOI
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _dayOI;
            public int DayOI { get => _dayOI; set => _dayOI = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NetChangeIndicator
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _netChangeIndicator;

            public CMA_NetChangeIndicator(char[] _value)
            {
                _netChangeIndicator = new char[1];
                Array.Copy(_value, 0, _netChangeIndicator, 0, _value.Length > _netChangeIndicator.Length ? _netChangeIndicator.Length : _value.Length);

            }
            public char[] NetChangeIndicator { get => _netChangeIndicator; set => _netChangeIndicator = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AuctionNumber
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _auctionNumber;
            public short AuctionNumber { get => _auctionNumber; set => _auctionNumber = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AuctionStatus
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _auctionStatus;
            public short AuctionStatus { get => _auctionStatus; set => _auctionStatus = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_InitiatorType
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _initiatorType;
            public short InitiatorType { get => _initiatorType; set => _initiatorType = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_RecordBuffer
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char _recordBuffer;
            public char RecordBuffer { get => _recordBuffer; set => _recordBuffer = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Buy
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _buy;
            public bool Buy { get => _buy; set => _buy = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Sell
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _sell;
            public bool Sell { get => _sell; set => _sell = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LastTradeLess
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _lastTradeLess;
            public bool LastTradeLess { get => _lastTradeLess; set => _lastTradeLess = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LastTradeMore
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _lastTradeMore;
            public bool LastTradeMore { get => _lastTradeMore; set => _lastTradeMore = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NoOfOrders
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _noOfOrders;
            public int NoOfOrders { get => _noOfOrders; set => _noOfOrders = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BbTotalBuySellFlag
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _BbTotalBuyFlag;
            public short BbTotalBuyFlag { get => _BbTotalBuyFlag; set => _BbTotalBuyFlag = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IndexValue
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _indexValue;
            public int IndexValue { get => _indexValue; set => _indexValue = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_HighIndexValue
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _highIndexValue;
            public int HighIndexValue { get => _highIndexValue; set => _highIndexValue = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LowIndexValue
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _lowIndexValue;
            public int LowIndexValue { get => _lowIndexValue; set => _lowIndexValue = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_YearlyHigh
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _yearlyHigh;
            public int YearlyHigh { get => _yearlyHigh; set => _yearlyHigh = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_YearlyLow
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _yearlyLow;
            public int YearlyLow { get => _yearlyLow; set => _yearlyLow = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NoOfmoves
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _noOfMoves;
            public int NoOfMoves { get => _noOfMoves; set => _noOfMoves = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MarketCapitalisation
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _marketCapitalisation;
            public int MarketCapitalisation { get => _marketCapitalisation; set => _marketCapitalisation = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_IndustryName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
            private char[] _industryName;
            public char[] IndustryName { get => _industryName; set => _industryName = value; }
            public CMA_IndustryName()
            {
                IndustryName = new char[15];
            }
            public CMA_IndustryName(char[] _value)
            {
                IndustryName = new char[15];
                Array.Copy(_value, 0, IndustryName, 0, _value.Length > IndustryName.Length ? IndustryName.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Open
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _open;
            public int Open { get => _open; set => _open = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MKT_High
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _high;
            public short High { get => _high; set => _high = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MKT_Low
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _low;
            public short Low { get => _low; set => _low = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NumberOfIndustryRecords
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _numberOfIndustryRecords;
            public short NumberOfIndustryRecords { get => _numberOfIndustryRecords; set => _numberOfIndustryRecords = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_High
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _high;
            public int High { get => _high; set => _high = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Low
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _low;
            public int Low { get => _low; set => _low = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Last
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _last;
            public int Last { get => _last; set => _last = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Close
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _close;
            public int Close { get => _close; set => _close = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MKT_Closing
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _closing;
            public short Closing { get => _closing; set => _closing = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MKT_Start
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _start;
            public short Start { get => _start; set => _start = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Start
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _start;
            public int Start { get => _start; set => _start = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PrevClose
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _prevClose;
            public int PrevClose { get => _prevClose; set => _prevClose = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LifeHigh
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _lifeHigh;
            public int LifeHigh { get => _lifeHigh; set => _lifeHigh = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LifeLow
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _lifeLow;
            public int LifeLow { get => _lifeLow; set => _lifeLow = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_INDEXDETAILSFiller
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _filler;
            public int Filler { get => _filler; set => _filler = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NseSymbol
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _nseSymbol;
            public char[] NseSymbol { get => _nseSymbol; set => _nseSymbol = value; }
            public CMA_NseSymbol()
            {
                _nseSymbol = new char[16];
            }
            public CMA_NseSymbol(char[] _value)
            {
                _nseSymbol = new char[16];
                Array.Copy(_value, 0, _nseSymbol, 0, _value.Length > _nseSymbol.Length ? _nseSymbol.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExpMonth
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _expMonth;
            public short ExpMonth { get => _expMonth; set => _expMonth = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExpYear
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _expYear;
            public short ExpYear { get => _expYear; set => _expYear = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BidSize
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _bidSize;
            public long BidSize { get => _bidSize; set => _bidSize = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_AskSize
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _askSize;
            public long AskSize { get => _askSize; set => _askSize = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CONTRACTS_DETAILS_Filler
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _filler;
            public int Filler { get => _filler; set => _filler = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MbpSell
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _mbpSell;
            public short MbpSell { get => _mbpSell; set => _mbpSell = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MbpBuy
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _mbpBuy;
            public short MbpBuy { get => _mbpBuy; set => _mbpBuy = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Band
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _band;
            public int Band { get => _band; set => _band = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MsgCount
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _msgCount;
            public int MsgCount { get => _msgCount; set => _msgCount = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_FirmName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)]
            private char[] _firmName;
            public char[] FirmName { get => _firmName; set => _firmName = value; }
            public CMA_FirmName()
            {
                _firmName = new char[25];
            }
            public CMA_FirmName(char[] _value)
            {
                _firmName = new char[25];
                Array.Copy(_value, 0, _firmName, 0, _value.Length > _firmName.Length ? _firmName.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TotalValueTraded
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _totalValueTraded;
            public int TotalValueTraded { get => _totalValueTraded; set => _totalValueTraded = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Indicator
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            private char[] _indicator;
            public char[] Indicator { get => _indicator; set => _indicator = value; }
            public CMA_Indicator()
            {
                _indicator = new char[4];
            }
            public CMA_Indicator(char[] _value)
            {
                _indicator = new char[4];
                Array.Copy(_value, 0, _indicator, 0, _value.Length > _indicator.Length ? _indicator.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MessageType
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _messageType;
            public char[] MessageType { get => _messageType; set => _messageType = value; }
            public CMA_MessageType()
            {
                _messageType = new char[1];
            }
            public CMA_MessageType(char[] _value)
            {
                _messageType = new char[1];
                Array.Copy(_value, 0, _messageType, 0, _value.Length > _messageType.Length ? _messageType.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Opening
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _opening;
            public short Opening { get => _opening; set => _opening = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SectorName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
            private char[] _sectorName;
            public char[] SectorName { get => _sectorName; set => _sectorName = value; }
            public CMA_SectorName()
            {
                _sectorName = new char[15];
            }
            public CMA_SectorName(char[] _value)
            {
                _sectorName = new char[15];
                Array.Copy(_value, 0, _sectorName, 0, _value.Length > _sectorName.Length ? _sectorName.Length : _value.Length);
            }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NumberOfPackets
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _numberOfPackets;
            public int NumberOfPackets { get => _numberOfPackets; set => _numberOfPackets = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OrgScope
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char _orgScope;
            public char OrgScope { get => _orgScope; set => _orgScope = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OPENPD
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _OPENPD;
            public int OPENPD { get => _OPENPD; set => _OPENPD = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_HIPD
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _HIPD;
            public int HIPD { get => _HIPD; set => _HIPD = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LOWPD
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _LOWPD;
            public int LOWPD { get => _LOWPD; set => _LOWPD = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LASTTRADEDPD
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _LASTTRADEDPD;
            public int LASTTRADEDPD { get => _LASTTRADEDPD; set => _LASTTRADEDPD = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NOOFCONTRACTSTRADED
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _NOOFCONTRACTSTRADED;
            public int NOOFCONTRACTSTRADED { get => _NOOFCONTRACTSTRADED; set => _NOOFCONTRACTSTRADED = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PlateformIdentifier
        {

            private short _plateformId;
            public short PlateformIdentifier { get => _plateformId; set => _plateformId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_SettlementType
        {

            private short _settlementType;
            public short SettlementType { get => _settlementType; set => _settlementType = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OrderStatus
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            private char[] _orderStatus;
            public CMA_OrderStatus(char[] _value)
            {
                _orderStatus = new char[10];
                Array.Copy(_value, 0, _orderStatus, 0, _value.Length > _orderStatus.Length ? _orderStatus.Length : _value.Length);

            }
            public CMA_OrderStatus()
            {
                _orderStatus = new char[10];
            }
            public char[] OrderStatus { get => _orderStatus; set => _orderStatus = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OERemark
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
            private char[] _OERemark;
            public char[] OERemark { get => _OERemark; set => _OERemark = value; }
            public CMA_OERemark()
            {
                OERemark = new char[5];
            }
            public CMA_OERemark(char[] _value)
            {
                OERemark = new char[5];
                Array.Copy(_value, 0, OERemark, 0, _value.Length > OERemark.Length ? OERemark.Length : _value.Length);
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_OmsOrderNumber
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _orderNumber;
            public int OmsOrderNumber { get => _orderNumber; set => _orderNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Suspend
        {
            private char _suspend;
            public CMA_Suspend(char _value)
            {
                _suspend = _value;
            }
            public char Suspend { get => _suspend; set => _suspend = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ExchangeSegmentId
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _segmentId;
            public CMA_ExchangeSegmentId(int _value)
            {
                _segmentId = _value;
            }
            public int SegmentId { get => _segmentId; set => _segmentId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PlatformID
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _platformId;

            public CMA_PlatformID(short _value)
            {
                _platformId = _value;
            }
            public short PlatformId { get => _platformId; set => _platformId = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Short_TimeStamp
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _timestamp;
            public CMA_Short_TimeStamp(short _value)
            {
                _timestamp = _value;
            }
            public int TimeStamp { get => _timestamp; set => _timestamp = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_CharReserved
        {

            private char _chrReserved;
            public CMA_CharReserved(char _value)
            {
                _chrReserved = _value;
            }
            public char ChrReserved { get => _chrReserved; set => _chrReserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _reserved;
            public CMA_Reserved(char[] _value)
            {
                _reserved = new char[1];
                Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);

            }
            public CMA_Reserved()
            {
                _reserved = new char[1];

            }
            public char[] Reserved { get => _reserved; set => _reserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved1
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _reserved1;
            public CMA_Reserved1(char[] _value)
            {
                _reserved1 = new char[1];
                Array.Copy(_value, 0, _reserved1, 0, _value.Length > _reserved1.Length ? _reserved1.Length : _value.Length);

            }
            public CMA_Reserved1()
            {
                _reserved1 = new char[1];

            }
            public char[] Reserved1 { get => _reserved1; set => _reserved1 = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved2
        {
            private bool _Reserved2;
            public CMA_Reserved2(bool _value)
            {
                _Reserved2 = _value;
            }
            public bool Reserved2 { get => _Reserved2; set => _Reserved2 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved3
        {
            private bool _Reserved3;
            public CMA_Reserved3(bool _value)
            {
                _Reserved3 = _value;
            }
            public bool Reserved3 { get => _Reserved3; set => _Reserved3 = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved4
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            private char[] _reserved;
            public CMA_Reserved4(char[] _value)
            {
                _reserved = new char[4];
                Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);
            }
            public CMA_Reserved4()
            {
                _reserved = new char[4];
            }
            public char[] Reserved4 { get => _reserved; set => _reserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved5
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _reserved5;
            public CMA_Reserved5(char[] _value)
            {
                _reserved5 = new char[1];
                Array.Copy(_value, 0, _reserved5, 0, _value.Length > _reserved5.Length ? _reserved5.Length : _value.Length);

            }
            public CMA_Reserved5()
            {
                _reserved5 = new char[1];

            }
            public char[] Reserved5 { get => _reserved5; set => _reserved5 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved6
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private char[] _reserved6;
            public CMA_Reserved6(char[] _value)
            {
                _reserved6 = new char[2];
                Array.Copy(_value, 0, _reserved6, 0, _value.Length > _reserved6.Length ? _reserved6.Length : _value.Length);

            }
            public CMA_Reserved6()
            {
                _reserved6 = new char[2];

            }
            public char[] Reserved6 { get => _reserved6; set => _reserved6 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved7
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _reserved7;
            public CMA_Reserved7(char[] _value)
            {
                _reserved7 = new char[1];
                Array.Copy(_value, 0, _reserved7, 0, _value.Length > _reserved7.Length ? _reserved7.Length : _value.Length);

            }
            public CMA_Reserved7()
            {
                _reserved7 = new char[1];

            }
            public char[] Reserved7 { get => _reserved7; set => _reserved7 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved8
        {
            private bool _Reserved8;
            public CMA_Reserved8(bool _value)
            {
                _Reserved8 = _value;
            }
            public bool Reserved8 { get => _Reserved8; set => _Reserved8 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved9
        {
            private bool _Reserved9;
            public CMA_Reserved9(bool _value)
            {
                _Reserved9 = _value;
            }
            public bool Reserved9 { get => _Reserved9; set => _Reserved9 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved10
        {
            private bool _Reserved10;
            public CMA_Reserved10(bool _value)
            {
                _Reserved10 = _value;
            }
            public bool Reserved10 { get => _Reserved10; set => _Reserved10 = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved11
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _reserved11;
            public CMA_Reserved11(char[] _value)
            {
                _reserved11 = new char[1];
                Array.Copy(_value, 0, _reserved11, 0, _value.Length > _reserved11.Length ? _reserved11.Length : _value.Length);

            }
            public CMA_Reserved11()
            {
                _reserved11 = new char[1];

            }
            public char[] Reserved11 { get => _reserved11; set => _reserved11 = value; }
        }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Reserved12
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 52)]
            private char[] _reserved12;
            public CMA_Reserved12(char[] _value)
            {
                _reserved12 = new char[52];
                Array.Copy(_value, 0, _reserved12, 0, _value.Length > _reserved12.Length ? _reserved12.Length : _value.Length);
            }
            public CMA_Reserved12()
            {
                _reserved12 = new char[52];
            }
            public char[] Reserved12 { get => _reserved12; set => _reserved12 = value; }
        }



        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Suspended
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _suspended;
            public CMA_Suspended(char[] _value)
            {
                _suspended = new char[1];
                Array.Copy(_value, 0, _suspended, 0, _value.Length > _suspended.Length ? _suspended.Length : _value.Length);

            }
            public char[] Suspended { get => _suspended; set => _suspended = value; }
        }

        public struct CMA_SettlementPeriod
        {
            private short _settlementPeriod;
            public short SettlementPeriod { get => _settlementPeriod; set => _settlementPeriod = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Flag
        {
            private bool _FLAG;
            public CMA_Flag(bool _value)
            {
                _FLAG = _value;
            }
            public bool FLAG { get => _FLAG; set => _FLAG = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Sec_Reserved
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _reserved;
            public bool Reserved { get => _reserved; set => _reserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Sec_Eligibility
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _eligibility;
            public Sec_Eligibility(bool _value)
            {
                _eligibility = _value;
            }

            public bool Eligibility { get => _eligibility; set => _eligibility = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct Sec_Status
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _status;
            public Sec_Status(short _value)
            {
                _status = _value;
            }
            public short Status { get => _status; set => _status = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Percentage
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _percentage;
            public CMA_Percentage(int _value)
            {
                _percentage = _value;
            }
            public int Percentage { get => _percentage; set => _percentage = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Remark
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _remark;
            public CMA_Remark(char[] _value)
            {
                _remark = new char[32];
                //_remark = _value;
                Array.Copy(_value, 0, _remark, 0, _value.Length > _remark.Length ? _remark.Length : _value.Length);

            }
            public CMA_Remark()
            {
                _remark = new char[32];
            }
            public char[] Remark { get => _remark; set => _remark = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ReservedBits
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
            private char[] _reserved;
            public CMA_ReservedBits(char[] _value)
            {
                _reserved = new char[5];
                Array.Copy(_value, 0, _reserved, 0, _value.Length > _reserved.Length ? _reserved.Length : _value.Length);

            }
            public CMA_ReservedBits()
            {
                _reserved = new char[5];
            }
            public char[] Reservedbits { get => _reserved; set => _reserved = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ISINNumber
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _isinNumber;
            public CMA_ISINNumber(char[] _value)
            {
                _isinNumber = new char[16];
                Array.Copy(_value, 0, _isinNumber, 0, _value.Length > _isinNumber.Length ? _isinNumber.Length : _value.Length);

            }
            public CMA_ISINNumber()
            {
                _isinNumber = new char[16];
            }
            public char[] ISINNumber { get => _isinNumber; set => _isinNumber = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParticipantId
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _participantId;

            public CMA_ParticipantId(char[] _value)
            {
                _participantId = new char[32];
                Array.Copy(_value, 0, _participantId, 0, _value.Length > _participantId.Length ? _participantId.Length : _value.Length);

            }
            public CMA_ParticipantId()
            {
                _participantId = new char[32];
            }
            public char[] ParticipantId { get => _participantId; set => _participantId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ParticipantName
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _participantName;

            public CMA_ParticipantName(char[] _value)
            {
                _participantName = new char[32];
                Array.Copy(_value, 0, _participantName, 0, _value.Length > _participantName.Length ? _participantName.Length : _value.Length);

            }
            public CMA_ParticipantName()
            {
                _participantName = new char[32];
            }
            public char[] ParticipantName { get => _participantName; set => _participantName = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Filler1
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _filler;
            public CMA_Filler1(char[] _value)
            {
                _filler = new char[1];
                Array.Copy(_value, 0, _filler, 0, _value.Length > _filler.Length ? _filler.Length : _value.Length);

            }
            public CMA_Filler1()
            {
                _filler = new char[1];

            }
            public char[] Filler1 { get => _filler; set => _filler = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller1
        {
            private bool bitFiller;
            public CMA_BitFiller1(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller1 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller2
        {
            private bool bitFiller;
            public CMA_BitFiller2(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller2 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller3
        {
            private bool bitFiller;
            public CMA_BitFiller3(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller3 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller4
        {
            private bool bitFiller;
            public CMA_BitFiller4(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller4 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller5
        {
            private bool bitFiller;
            public CMA_BitFiller5(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller5 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller6
        {
            private bool bitFiller;
            public CMA_BitFiller6(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller6 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller7
        {
            private bool bitFiller;
            public CMA_BitFiller7(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller7 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller8
        {
            private bool bitFiller;
            public CMA_BitFiller8(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller8 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller9
        {
            private bool bitFiller;
            public CMA_BitFiller9(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller9 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller10
        {
            private bool bitFiller;
            public CMA_BitFiller10(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller10 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller11
        {
            private bool bitFiller;
            public CMA_BitFiller11(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller11 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller12
        {
            private bool bitFiller;
            public CMA_BitFiller12(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller12 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller13
        {
            private bool bitFiller;
            public CMA_BitFiller13(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller13 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller14
        {
            private bool bitFiller;
            public CMA_BitFiller14(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller14 { get => bitFiller; set => bitFiller = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller15
        {
            private bool bitFiller;
            public CMA_BitFiller15(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller15 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller16
        {
            private bool bitFiller;
            public CMA_BitFiller16(bool _value)
            {
                bitFiller = _value;
            }
            public bool BitFiller16 { get => bitFiller; set => bitFiller = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller17
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _bitFillers;
            public CMA_BitFiller17(char[] _value)
            {
                _bitFillers = new char[1];
                Array.Copy(_value, 0, _bitFillers, 0, _value.Length > _bitFillers.Length ? _bitFillers.Length : _value.Length);

            }
            public CMA_BitFiller17()
            {
                _bitFillers = new char[1];
            }
            public char[] BitFiller17 { get => _bitFillers; set => _bitFillers = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BitFiller18
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            private char[] _bitFillers;
            public CMA_BitFiller18(char[] _value)
            {
                _bitFillers = new char[1];
                Array.Copy(_value, 0, _bitFillers, 0, _value.Length > _bitFillers.Length ? _bitFillers.Length : _value.Length);

            }
            public CMA_BitFiller18()
            {
                _bitFillers = new char[1];
            }
            public char[] BitFiller18 { get => _bitFillers; set => _bitFillers = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TerminalID
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _terminalId;

            public CMA_TerminalID()
            {
                _terminalId = new char[16];
            }
            public CMA_TerminalID(char[] _value)
            {
                _terminalId = new char[16];
                //_terminalId = _value;
                Array.Copy(_value, 0, _terminalId, 0, _value.Length > _terminalId.Length ? _terminalId.Length : _value.Length);

            }
            public char[] TerminalId { get => _terminalId; set => _terminalId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_STRTerminalID
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
            private string _terminalId;


            public CMA_STRTerminalID(char[] _value)
            {
                char[] temparry = new char[16];
                Array.Copy(_value, 0, temparry, 0, _value.Length > temparry.Length ? temparry.Length : _value.Length);
                _terminalId = new string(temparry);
                //_terminalId = _value;


            }
            public string TerminalId { get => _terminalId; set => _terminalId = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_Password
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _password;
            public CMA_Password()
            {
                _password = new char[16];
            }
            public CMA_Password(char[] _value)
            {
                _password = new char[16];
                Array.Copy(_value, 0, _password, 0, _value.Length > _password.Length ? _password.Length : _value.Length);
            }
            public char[] password { get => _password; set => _password = value; }
        }



        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NewAuthInfo // 16 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _newAuthInfo;

            public CMA_NewAuthInfo()
            {
                _newAuthInfo = new char[16];
            }
            public CMA_NewAuthInfo(char[] _value)
            {
                _newAuthInfo = new char[16];
                //_newpassword = _value;
                Array.Copy(_value, 0, _newAuthInfo, 0, _value.Length > _newAuthInfo.Length ? _newAuthInfo.Length : _value.Length);

            }
            public char[] newAuthInfo { get => _newAuthInfo; set => _newAuthInfo = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_UpdateAuthStatusString // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _updateAuthStatus;

            public CMA_UpdateAuthStatusString()
            {
                _updateAuthStatus = new char[128];
            }
            public CMA_UpdateAuthStatusString(char[] _value)
            {
                _updateAuthStatus = new char[128];
                Array.Copy(_value, 0, _updateAuthStatus, 0, _value.Length > _updateAuthStatus.Length ? _updateAuthStatus.Length : _value.Length);

            }
            public char[] updateAuthStatus { get => _updateAuthStatus; set => _updateAuthStatus = value; }
        }

        //Login response
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LoginStatusString // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _loginstatus;

            public CMA_LoginStatusString()
            {
                _loginstatus = new char[128];
            }
            public CMA_LoginStatusString(char[] _value)
            {
                _loginstatus = new char[128];
                //_loginstatus = _value;
                Array.Copy(_value, 0, _loginstatus, 0, _value.Length > _loginstatus.Length ? _loginstatus.Length : _value.Length);

            }
            public char[] loginStatus { get => _loginstatus; set => _loginstatus = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_EntityId
        {
            private long _id;
            public CMA_EntityId(long _value)
            {
                _id = _value;
            }
            public long entityId { get => _id; set => _id = value; }

            public static explicit operator CMA_EntityId(int v)
            {
                throw new NotImplementedException();
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_EntityName // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _entityname;

            public CMA_EntityName()
            {
                _entityname = new char[128];
            }
            public CMA_EntityName(char[] _value)
            {
                _entityname = new char[128];
                //_entityname = _value;
                Array.Copy(_value, 0, _entityname, 0, _value.Length > _entityname.Length ? _entityname.Length : _value.Length);

            }
            public char[] Entityname { get => _entityname; set => _entityname = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_APName // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _apName;

            public CMA_APName()
            {
                _apName = new char[128];
            }
            public CMA_APName(char[] _value)
            {
                _apName = new char[128];
                //_apName = _value;
                Array.Copy(_value, 0, _apName, 0, _value.Length > _apName.Length ? _apName.Length : _value.Length);

            }
            public char[] ApName { get => _apName; set => _apName = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_FamilyName // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _familyName;

            public CMA_FamilyName()
            {
                _familyName = new char[128];
            }
            public CMA_FamilyName(char[] _value)
            {
                _familyName = new char[128];
                //_familyName = _value;
                Array.Copy(_value, 0, _familyName, 0, _value.Length > _familyName.Length ? _familyName.Length : _value.Length);

            }
            public char[] Familyname { get => _familyName; set => _familyName = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LogoutStatusString // 128 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            private char[] _logoutStatusString;

            public CMA_LogoutStatusString()
            {
                _logoutStatusString = new char[128];
            }
            public CMA_LogoutStatusString(char[] _value)
            {
                _logoutStatusString = new char[128];
                Array.Copy(_value, 0, _logoutStatusString, 0, _value.Length > _logoutStatusString.Length ? _logoutStatusString.Length : _value.Length);

            }
            public char[] LogoutStatusString { get => _logoutStatusString; set => _logoutStatusString = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_VersionInfo16 // 16 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _versionInfo;

            public CMA_VersionInfo16()
            {
                _versionInfo = new char[16];
            }
            public CMA_VersionInfo16(char[] _value)
            {
                _versionInfo = new char[16];
                Array.Copy(_value, 0, _versionInfo, 0, _value.Length > _versionInfo.Length ? _versionInfo.Length : _value.Length);

            }
            public char[] Versioninfo { get => _versionInfo; set => _versionInfo = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LoginStatusCode
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _loginstatusCode;

            public CMA_LoginStatusCode(short _value)
            {
                _loginstatusCode = _value;
            }
            public short LoginstatusCode { get => _loginstatusCode; set => _loginstatusCode = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_EntityCategory
        {
            [MarshalAs(UnmanagedType.I2)]
            private short _entitycategory;

            public CMA_EntityCategory(short _value)
            {
                _entitycategory = _value;
            }
            public short Entitycategory { get => _entitycategory; set => _entitycategory = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_PURPOSE_flag
        {
            [MarshalAs(UnmanagedType.Bool)]
            private bool _flag;
            public CMA_ST_PURPOSE_flag(bool _value)
            {
                _flag = _value;
            }
            public bool Flag { get => _flag; set => _flag = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_RequestContext
        {
            [MarshalAs(UnmanagedType.I8)]
            private long _requestContext;
            public CMA_RequestContext(long _value)
            {
                _requestContext = _value;
            }
            public long RequestContext { get => _requestContext; set => _requestContext = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_BufferSize
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _BufferSize;
            public int BufferSize { get => _BufferSize; set => _BufferSize = value; }
        }


        #region LDB related fields



        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ContextIdentifier
        {
            private long _ContextIdentifier;
            public long contextIdentifier { get => _ContextIdentifier; set => _ContextIdentifier = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TotalNoOfRecords
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _totalNoOfRecords;
            public int totalNoofRecords { get => _totalNoOfRecords; set => _totalNoOfRecords = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NoOfRecordsofSubData
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _NoOfRecordsofSubData;
            public int NoOfRecordsofSubData { get => _NoOfRecordsofSubData; set => _NoOfRecordsofSubData = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_TotalNoOfRecordsofSubData
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _TotalNoOfRecordsofSubData;
            public int TotalNoOfRecordsofSubData { get => _TotalNoOfRecordsofSubData; set => _TotalNoOfRecordsofSubData = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LDBData
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2048)]
            private byte[] __ldbData;
            public CMA_LDBData(byte[] _value)
            {
                __ldbData = new byte[2048];
                Array.Copy(_value, 0, __ldbData, 0, _value.Length > __ldbData.Length ? __ldbData.Length : _value.Length);
            }
            public CMA_LDBData()
            {
                __ldbData = new byte[2048];
            }
            public byte[] LDBData { get => __ldbData; set => __ldbData = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_LDBInformationIdentifier
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _LDBInformationIdentifier;
            public int LDBInformationIdentifier { get => _LDBInformationIdentifier; set => _LDBInformationIdentifier = value; }
        }

        #endregion

        #region EnterpriseMasterUpdate

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_EMContext
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
            private byte[] _EMcontext;
            public byte[] EMContext { get => _EMcontext; set => _EMcontext = value; }
            public CMA_EMContext()
            {
                _EMcontext = new byte[1024];
            }
            public CMA_EMContext(byte[] _value)
            {
                _EMcontext = new byte[1024];
                Array.Copy(_value, 0, _EMcontext, 0, _value.Length > _EMcontext.Length ? _EMcontext.Length : _value.Length);
            }
        }
        #endregion

        #region Passwordpolicyfields

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PasswordMinlength
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _passMinLength;
            public CMA_PasswordMinlength(int _value)
            {
                _passMinLength = _value;
            }
            public int MinLength { get => _passMinLength; set => _passMinLength = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PasswordMaxlength
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _passMaxLength;
            public CMA_PasswordMaxlength(int _value)
            {
                _passMaxLength = _value;
            }
            public int MaxLength { get => _passMaxLength; set => _passMaxLength = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_PasswordExpiry
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _PasswordExpiry;
            public CMA_PasswordExpiry(int _value)
            {
                _PasswordExpiry = _value;
            }
            public int PasswordExpiry { get => _PasswordExpiry; set => _PasswordExpiry = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_MinPasswordAge
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _MinPasswordAge;
            public CMA_MinPasswordAge(int _value)
            {
                _MinPasswordAge = _value;
            }
            public int MinPasswordAge { get => _MinPasswordAge; set => _MinPasswordAge = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_DisallowPastPassword
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _DisallowPastPassword;
            public CMA_DisallowPastPassword(int _value)
            {
                _DisallowPastPassword = _value;
            }
            public int DisallowPastPassword { get => _DisallowPastPassword; set => _DisallowPastPassword = value; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_WarnAfter
        {
            [MarshalAs(UnmanagedType.I4)]
            private int _WarnAfter;
            public CMA_WarnAfter(int _value)
            {
                _WarnAfter = _value;
            }
            public int WarnAfter { get => _WarnAfter; set => _WarnAfter = value; }
        }


        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_NonNumericCharAllowed // 16 Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            private char[] _NonNumericCharAllowed;
            public CMA_NonNumericCharAllowed()
            {
                _NonNumericCharAllowed = new char[16];
            }
            public CMA_NonNumericCharAllowed(char[] _value)
            {
                _NonNumericCharAllowed = new char[16];
                Array.Copy(_value, 0, _NonNumericCharAllowed, 0, _value.Length > _NonNumericCharAllowed.Length ? _NonNumericCharAllowed.Length : _value.Length);
            }
            public char[] NonNumericCharAllowed { get => _NonNumericCharAllowed; set => _NonNumericCharAllowed = value; }
        }

        #endregion

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_ST_BCAST_DESTINATION2Byte
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private byte[] _ST_BCAST_DESTINATION;
            public byte[] ST_BCAST_DESTINATION { get => _ST_BCAST_DESTINATION; set => _ST_BCAST_DESTINATION = value; }
            public CMA_ST_BCAST_DESTINATION2Byte()
            {
                _ST_BCAST_DESTINATION = new byte[2];
            }
            public CMA_ST_BCAST_DESTINATION2Byte(byte[] _value)
            {
                _ST_BCAST_DESTINATION = new byte[2];
                Array.Copy(_value, 0, _ST_BCAST_DESTINATION, 0, _value.Length > _ST_BCAST_DESTINATION.Length ? _ST_BCAST_DESTINATION.Length : _ST_BCAST_DESTINATION.Length);
            }
        }

        public struct CMA_OpCodeStruct
        {
            [MarshalAs(UnmanagedType.I2)]
            private CMA_OpCode _OpCode;
            public CMA_OpCode OpCode { get => _OpCode; set => _OpCode = value; }
            //public CMA_OpCodeStruct()
            //{
            //    _OpCode = new CMA_OpCode();
            //}
            //public CMA_OpCodeStruct(CMA_OpCode _value)
            //{
            //    _OpCode = new CMA_OpCode();
            //    Array.Copy(_value, 0, _OpCode, 0, _value.Length > _OpCode.Length ? _OpCode.Length : _ST_BCAST_DESTINATION.Length);
            //}
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct CMA_RequestId
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            private char[] _requestId;         

            public CMA_RequestId(char[] _value)
            {
                _requestId = new char[32];
                Array.Copy(_value, 0, _requestId, 0, _value.Length > _requestId.Length ? _requestId.Length : _value.Length);
            }
            public CMA_RequestId()
            {
                _requestId = new char[32];

            }
            public char[] RequestId { get => _requestId; set => _requestId = value; }
        }


    }
}
