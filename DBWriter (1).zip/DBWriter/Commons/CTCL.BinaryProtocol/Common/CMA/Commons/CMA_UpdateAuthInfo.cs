﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_UpdateAuthInfo
    {
        public CMA_EntityId EntityId;
        public CMA_TerminalID TerminalID;
        public CMA_Password OldAuthInfo;
        public CMA_Password NewAuthInfo;
    }
}
