﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_AuthDetails
    {
        public CTCL_TerminalID TerminalID;
        public CTCL_Password Password;
        public CTCL_Password NewPassword;
    }

}
