﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_MessageHeader
    {
        public CMA_OpCodeStruct OpCode;
        //public CMA_TimeStamp TimeStamp; 
        //public CMA_MessageLength MessageLength;
        //public ComponentIdentifier SourceComponentIdentifier; 
        //public ComponentIdentifier DestinationComponentIdentifier;  
        public CMA_ComponentName CMA_ComponentName;
        public CMA_ActionCode CMA_ActionCode;
    }
}
