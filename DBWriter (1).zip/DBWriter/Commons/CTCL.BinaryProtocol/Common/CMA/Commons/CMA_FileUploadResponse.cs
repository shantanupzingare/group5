﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using System.Runtime.InteropServices;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Commons
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CMA_FileUploadResponse
	{
		public CTCL_MessageHeader MessageHeader;
        public CMA_RequestId RequestID;
        public CTCL_ExchangeSegmentId SegmentId;
		public CTCL_Id FileType;
		public StatusCode StatusCode;
		public CTCL_Message StatusMessage;
		public CTCL_TimeStamp TimeStamp;
	}
}
