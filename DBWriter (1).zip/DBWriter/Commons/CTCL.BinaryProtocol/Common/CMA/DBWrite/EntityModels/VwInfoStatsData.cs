﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;
using ComponentIdentifier = CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons.ComponentIdentifier;

namespace CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class VwInfoStatsData
    {
        public CMA_InfoID InfoId;
        public CMA_BrokerID BrokerId;
        public CMA_SiteID SiteId;
        public ComponentIdentifier ComponentId;
        public CMA_InstanceID InstanceId;
        public CMA_ParamID ParamId;
        public CMA_References Reference;// RAM/ OMS/ CTCL.OMS/RAM
        public CMA_Value nvcValue;
        public CTCL_UserIP nvcInstanceIp;
        public CMA_Port intPort;
        public CMA_TimeStamp dtmTimeStamp;
    }
}
