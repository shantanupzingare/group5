﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Remarks
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private char[] _remarks;
        public char[] remarks { get => _remarks; set => _remarks = value; }
        public CMA_Remarks()
        {
            _remarks = new char[32];
        }
        public CMA_Remarks(char[] _value)
        {
            _remarks = new char[32];
            Array.Copy(_value, 0, _remarks, 0, _value.Length > _remarks.Length ? _remarks.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_EntityDisplayCode
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        private char[] _displayCode;

        public char[] displayCode { get => _displayCode; set => _displayCode = value; }
        public CMA_EntityDisplayCode()
        {
            _displayCode = new char[16];
        }
        public CMA_EntityDisplayCode(char[] _value)
        {
            _displayCode = new char[16];
            Array.Copy(_value, 0, _displayCode, 0, _value.Length > _displayCode.Length ? _displayCode.Length : _value.Length);
        }

    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_CategoryDisplayShortName
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        private char[] _displayShortName;

        public char[] displayShortName { get => _displayShortName; set => _displayShortName = value; }
        public CMA_CategoryDisplayShortName()
        {
            _displayShortName = new char[8];
        }
        public CMA_CategoryDisplayShortName(char[] _value)
        {
            _displayShortName = new char[8];
            Array.Copy(_value, 0, _displayShortName, 0, _value.Length > _displayShortName.Length ? _displayShortName.Length : _value.Length);
        }
    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_EntityTypeDisplayShortName
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        private char[] _displayShortName;

        public char[] displayShortName { get => _displayShortName; set => _displayShortName = value; }

        public CMA_EntityTypeDisplayShortName()
        {
            _displayShortName = new char[8];
        }
        public CMA_EntityTypeDisplayShortName(char[] _value)
        {
            _displayShortName = new char[8];
            Array.Copy(_value, 0, _displayShortName, 0, _value.Length > _displayShortName.Length ? _displayShortName.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_CategoryId
    {
        [MarshalAs(UnmanagedType.I2)]
        private short _id;

        public short id { get => _id; set => _id = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_TypeId
    {
        [MarshalAs(UnmanagedType.I2)]
        private short _id;

        public short id { get => _id; set => _id = value; }
    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_EntityID
    {
        [MarshalAs(UnmanagedType.I8)]
        private long _id;

        public long id { get => _id; set => _id = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_HierarchyLevel
    {
        [MarshalAs(UnmanagedType.I2)]
        private short _level;

        public short level { get => _level; set => _level = value; }
    }

    #region Contact details

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_EntityContactID
    {
        private int _id;

        public int id { get => _id; set => _id = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Timer
    {
        [MarshalAs(UnmanagedType.I2)]
        private short _timer;
        public CMA_Timer(short _value)
        {
            _timer = _value;
        }
        public short Timer { get => _timer; set => _timer = value; }

        public static implicit operator CMA_Timer(short _value) => new CMA_Timer(_value);
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Name
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
        private char[] _name;

        public char[] name { get => _name; set => _name = value; }
        public CMA_Name(char[] _value)
        {
            _name = new char[64];
            Array.Copy(_value, 0, _name, 0, _value.Length > _name.Length ? _name.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    public struct CMA_Phone
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        private char[] _phone;

        public char[] phone { get => _phone; set => _phone = value; }

        public CMA_Phone(char[] _value)
        {
            _phone = new char[16];
            Array.Copy(_value, 0, _phone, 0, _value.Length > _phone.Length ? _phone.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Email
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
        private char[] _email;

        public char[] email { get => _email; set => _email = value; }
        public CMA_Email(char[] _value)
        {
            _email = new char[64];
            Array.Copy(_value, 0, _email, 0, _value.Length > _email.Length ? _email.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Address
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        private char[] _address;

        public char[] address { get => _address; set => _address = value; }
        public CMA_Address(char[] _value)
        {
            _address = new char[128];
            Array.Copy(_value, 0, _address, 0, _value.Length > _address.Length ? _address.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_Id
    {
        private int _id;
        public int id { get => _id; set => _id = value; }
    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_EntityUID
    {
        [MarshalAs(UnmanagedType.I8)]
        private long _id;

        public long id { get => _id; set => _id = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_DocumentType
    {
        [MarshalAs(UnmanagedType.I2)]
        private short _level;

        public short level { get => _level; set => _level = value; }
    }
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_FilePath
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
        private char[] _filePath;

        public char[] filepath { get => _filePath; set => _filePath = value; }
        public CMA_FilePath(char[] _value)
        {
            _filePath = new char[128];
            Array.Copy(_value, 0, _filePath, 0, _value.Length > _filePath.Length ? _filePath.Length : _value.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_KYCApprovalStatus

    {
        [MarshalAs(UnmanagedType.I2)]
        private short _level;
        public short level { get => _level; set => _level = value; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_AccessAttemptCount
    {
        private int _accessAttemptCount;

        public int accessAttemptCount { get => _accessAttemptCount; set => _accessAttemptCount = value; }
    }


    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CMA_IsActive
    {
        [MarshalAs(UnmanagedType.Bool)]
        private bool _IsActive;
        public bool IsActive { get => _IsActive; set => _IsActive = value; }
    }

    #endregion


    public enum StatusCode : short
    {
        //OMS 100
        #region OMS (-199 to -100 and  100 t0 199)
        OMS_Success = 100,//success
        OMS_Error = 101,
        OMS_UserSessionUpdated = 102,
        OMS_KeyNotFound = -102,
        OMS_Failure = -103,
        OMS_InvalidInput = -104,
        OMS_InvalidSessionToken = -105,
        OMS_InvalidUser = -106,
        OMS_ExchangeOrderLimitExceeded = -107,
        OMS_UserAuthorizationFailed = -108,
        OMS_NoOrderPresentForCancel = -109,
        OMS_TechnicalError = -110,
        OMS_InvalidLastUpdateTime = -111,
        OMS_ModifyIsInProgress = -112,
        OMS_Warning = -113,
        OMS_BreakConnection = -114,
        OMS_OrderLimitExceed = -115,
        OMS_NoDeviceExistInCounter = -116,
        OMS_RedisKeyNotFound = -117,
        OMS_OrderCannotBeModify = -118,
        OMS_OrderAlreadyCompleted = -119,
        OMS_RedisSessionExpired = -120,
        OMS_TcpHeartBeatNotMatched = -121,
        OMS_TcpClientDisconnect = -122,
        #endregion

        //RMS 200
        #region RMS (-299 to -200 and 200 to 299)
        RMS_Success = 200,//success
        RMS_Error = 201,
        RMS_KeyNotFound = -202,
        RMS_Failure = -203,
        RMS_InvalidInput = -204,
        RMS_QuantityMoreThanBalance = -205,
        RMS_InsufficientBalance = -206,
        RMS_DepositBalanceRejected = -207,
        RMS_DepositBalanceError = -208,
        RMS_WithDrawBalanceRejected = -209,
        RMS_WithDrawBalanceError = -210,
        #endregion

        //Feed 300
        #region FEED (-399 to -300  and 300 to 399)
        Feed_Success = 300,
        Feed_Error = 301,
        Feed_Failure = 303,
        Feed_KeyNotFound = 302,
        Feed_OrderAdded = -301,
        Feed_orderCancelled = -302,
        Feed_orderCancelledAll = -304,
        Feed_tradeOrder = -305,
        Feed_IsQuantityZero = 304,
        Feed_OrderBookNotFound = 305,
        Feed_OrderEntryRequestPriceOrQuantityNull = 306,
        Feed_KeyAlreadyPresent = 307,
        Feed_VolumeChanged = 308,
        Feed_OrderBookUpdated = 309,
        #endregion
        //ME 400
        #region ME (-499 to -400 and 400 to 499)
        ME_OrderExecutedCompletely = -407,
        ME_TradeAddedToTAS = -406,
        ME_OrderModifiedPartially = -405,
        ME_OrderModified = -404,
        ME_OrderCancelledAll = -403,
        ME_OrderCancelled = -402,
        ME_OrderAdded = -401,
        ME_Success = 400,
        ME_Error = 401,
        ME_OrderAlreadyPresent = 402,
        ME_NoOrderPresentForCancel = 403,
        ME_NoOrderPresentForModify = 404,
        ME_ModifyOrderSimilarToOrder = 405,
        ME_SyncRequestIncorrectSourceComponent = 406,
        ME_SyncRequestNullAssetCount = 407,
        ME_OrderRequestPriceOrQuantityNull = 408,
        ME_OrderRequestClientIdNull = 409,
        ME_OrderBookNotFound = 410,

        ME_OrderQtyIsLessThenLotSize = 411,
        ME_StepSizeCantBeZero = 412,
        ME_StepSizeIsNotValidated = 413,
        ME_PriceTickIsNotValidated = 414,
        ME_DPRIsNotValdated = 415,
        ME_TradingStatusIsSuspended = 416,
        ME_TradingStatusIsDeleted = 417,
        ME_CancelrequestClientIdNull = 418,
        ME_CancelrequestAssetNull = 419,
        ME_CancelRequestNoOrdersPresentInBook = 420,

        ME_NoValidationPresent = 421,
        ME_MarketTypeNotValidated = 422,
        ME_TransactionAttributesNotValidated = 423,
        ME_AccountTypeNotValidated = 424,
        ME_TransactionTypeNotValidated = 425,
        ME_TransactionValidityNotValidated = 426,
        ME_TransactionPermissionStatusNotValidated = 427,

        ME_OrderRequestAssetNull = 428,
        ME_OrderRequestOrderNoNull = 429,
        ME_SyncRequestInstanceWiseAssetCountNull = 430,
        #endregion


        #region Others (-599 to -500 and 500 to 599)
        //Error
        CompInst_Exception = 500,
        CompInst_ConfigurationNotFound = 501,
        CompInst_RouteIsNotProper = 502,

        //Success or Warning
        // CompInst_Success = -500,
        //ProcessQueue_Success = -501,
        #endregion

        #region MQ COnfiguration (-699 to -600 and 600 to 699)
        MQ_BrokerUnreachable = -699,
        MQ_ConnectionFailure = -698,
        MQ_ChannelClosed = -697,
        MQ_Sucess = -696,
        MQ_Failure = -695,
        MQ_OerationInterupted = -694,
        MQ_Authentication_Failure = -693,

        #endregion

        #region BalanceCron(-700 to -799 and 700 to 799)
        BalanceCron_Success = 700,
        BalanceCron_Error = -700,
        BalanceCron_Failure = -701,
        BalanceCron_KeyNotFound = -702,
        BalanceCron_KeyFound = 702,
        #endregion


        #region Chart statuscodes (-800 to -899 and 800 to 899)
        Chart_Error = -800,
        Chart_Failure = -801,
        #endregion


        #region MT statuscodes (-900 to -999 and 900 to 999)
        MT_Agent_Success = 900,
        MT_Agent_Error = 901,
        MT_ThresholdLimitReached = 902,

        MT_SNOC_Success = 902,
        MT_SNOC_Error = 903,
        MT_Success = 904,
        MT_Failure = 905,

        MT_Agent_ProcessNotRunning = 906,
        MT_API_DeadComponentsPresent = 907,
        MT_API_StartConnectivityOfComponents = 908,

        MT_ProcessableCategory = 909,
        MT_UnProcessableCategory = 910,
        #endregion

        #region CMA (-1499 to -1400 and  1400 t0 1499)
        CMA_Failure = -1403,
        CMA_KeyNotFound = -1402,
        CMA_Success = 1400,//success
        CMA_Error = 1401,
        CMA_UserSessionUpdated = 1402,

        #endregion

        Success = 0,
        Failure = -1

        #region MQStatusCodes ()

        #endregion



    }
}
