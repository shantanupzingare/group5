﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class InfoStatistics
    {
        //Header
        // public CMA_MessageHeader MessageHeader;
        public CMA_InfoID InfoId;
        public CMA_BrokerID BrokerId;
        public CMA_SiteID SiteId;
        public ComponentIdentifier ComponentId;
        public CMA_InstanceID InstanceId;
        public CMA_ParamID ParamId;
        public CMA_References Reference;// RAM/ OMS/ CTCL.OMS/RAM
        public CMA_Value nvcValue;
        public CMA_TimeStamp dtmTimeStamp;
        //public CMA_CommonMasterAttributes CommonMasterAttributes;
    }
}
