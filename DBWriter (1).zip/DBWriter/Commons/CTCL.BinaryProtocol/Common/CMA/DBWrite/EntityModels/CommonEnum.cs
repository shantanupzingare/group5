﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels
{
    public enum CMA_OperationStatus : short
    {
        Active = 1,
        Suspended = 2,
        MarkedDeleted = 3
    }
    public enum CMA_TradingStatus : short
    {
        OpenAllowed = 1,
        CloseAllowed = 2,
        FullAccess = 3
    }

    public enum CMA_ContactLevel : short
    {
        Primary = 1,
        Secondary = 2
    }
    public enum CMA_EntityType : short
    {
        Entity = 1,
        EntityContact = 2
    }

    public enum CMA_ProofType : short
    {
        PoA = 1,
        PoI = 2,
        PAN = 3,
        CoI = 4
    }



}
