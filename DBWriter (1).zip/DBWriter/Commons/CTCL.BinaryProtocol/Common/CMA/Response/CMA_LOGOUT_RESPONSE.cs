﻿using CTCL.BinaryProtocol.Common.CMA.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Response
{
   
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_LOGOUT_RESPONSE
    {
        public CMA_MessageHeader MessageHeader;
        public CMA_LogoutStatusString LogoutStatusString;
    }
}
