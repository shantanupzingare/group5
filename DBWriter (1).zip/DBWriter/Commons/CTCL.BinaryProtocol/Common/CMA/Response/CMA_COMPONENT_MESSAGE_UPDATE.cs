﻿using CTCL.BinaryProtocol.Common.CMA.Enum;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System.Runtime.InteropServices;
using static CTCL.BinaryProtocol.Common.CMA.Commons.CMACommons;

namespace CTCL.BinaryProtocol.Common.CMA.Response
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class CMA_COMPONENT_MESSAGE_UPDATE
    {
        public CTCL_MessageHeader MessageHeader;
        public CMA_RequestId RequestID;
        public CTCL_Message ResponseString;
        public CMA_StatusCode SuccessFailureFlag;
        public CTCL_TimeStamp LocalUpdateTime;
    }
}
