﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Response;

public class MCX_ETI_ResponseHeader
{
    public MCX_ETI_RequestTime RequestTime;
    public MCX_ETI_SendingTime SendingTime;
    public MCX_ETI_MsgSeqNum MsgSeqNum;
    public MCX_ETI_Pad4 Pad4;
}

