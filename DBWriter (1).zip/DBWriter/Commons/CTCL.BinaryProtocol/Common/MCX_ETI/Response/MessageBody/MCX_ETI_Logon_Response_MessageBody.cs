﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Response.MessageBody;

public class MCX_ETI_Logon_Response_MessageBody
{
    public MCX_ETI_LastLoginTime LastLoginTime;
    public MCX_ETI_DaysLeftForPsswordExpiry DaysLeftForPsswordExpiry;
    public MCX_ETI_GraceLoginsLeft GraceLoginsLeft;
    public MCX_ETI_Pad6 Pad6;

}

