﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Response.MessageBody;

public class MCX_ETI_Logout_Response_MessageBody
{ 

}

