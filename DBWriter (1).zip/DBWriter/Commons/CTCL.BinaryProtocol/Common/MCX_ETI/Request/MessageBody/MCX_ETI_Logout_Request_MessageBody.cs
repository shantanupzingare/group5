﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Request.MessageBody;
public class MCX_ETI_Logout_Request_MessageBody
{
    public MCX_ETI_Username Username;
    public MCX_ETI_Pad4 Pad4;

}

