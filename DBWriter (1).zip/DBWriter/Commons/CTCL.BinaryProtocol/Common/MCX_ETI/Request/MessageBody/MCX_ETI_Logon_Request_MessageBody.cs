﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Request.MessageBody;
public class MCX_ETI_Logon_Request_MessageBody
{
    public MCX_ETI_Username Username;
    public MCX_ETI_Password Password;
    public MCX_ETI_EncryptedDataMessageSize EncryptedDataMessageSize;
    public MCX_ETI_Filler7 Filler7;

}

