﻿using CTCL.BinaryProtocol.Common.MCX_ETI.Common;

namespace CTCL.BinaryProtocol.Common.MCX_ETI.Request;

public class MCX_ETI_RequestHeader
{
    public MCX_ETI_MsgSeqNum MsgSeqNum;
    public MCX_ETI_SenderSubID SenderSubID;
}

