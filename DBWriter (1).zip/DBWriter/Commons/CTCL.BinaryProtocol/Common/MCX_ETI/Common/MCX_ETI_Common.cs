﻿namespace CTCL.BinaryProtocol.Common.MCX_ETI.Common;



public struct MCX_ETI_BodyLen
{
    private UInt32 _bodyLen;
    public UInt32 BodyLen { get => _bodyLen; set => _bodyLen = value; }
}

public struct MCX_ETI_TemplateID
{
    private UInt16 _templateID;
    public UInt16 TemplateID { get => _templateID; set => _templateID = value; }
}

public struct MCX_ETI_NetworkMsgID
{
    private string _networkMsgID;
    public string NetworkMsgID { get => _networkMsgID; set => _networkMsgID = value; }
}

public struct MCX_ETI_Pad2
{
    private string _pad2;
    public string Pad2 { get => _pad2; set => _pad2 = value; }
}

public struct MCX_ETI_MsgSeqNum
{
    private UInt32 _msgSeqNum;
    public UInt32 MsgSeqNum { get => _msgSeqNum; set => _msgSeqNum = value; }
}

public struct MCX_ETI_SenderSubID
{
    private UInt32 _senderSubID;
    public UInt32 SenderSubID { get => _senderSubID; set => _senderSubID = value; }
}

public struct MCX_ETI_Username
{
    private UInt32 _userName;
    public UInt32 Username { get => _userName; set => _userName = value; }
}

public struct MCX_ETI_EncryptedDataMessageSize
{
    private UInt32 _encryptedDataMessageSize;
    public UInt32 EncryptedDataMessageSize { get => _encryptedDataMessageSize; set => _encryptedDataMessageSize = value; }
}

public struct MCX_ETI_Filler7
{
    private string _filler7;
    public string Filler7 { get => _filler7; set => _filler7 = value; }
}

public struct MCX_ETI_Password
{
    private string _password;
    public string Password { get => _password; set => _password = value; }
}

public struct MCX_ETI_RequestTime
{
    private long _requestTime;
    public long RequestTime { get => _requestTime; set => _requestTime = value; }
}

public struct MCX_ETI_SendingTime
{
    private long _sendingTime;
    public long SendingTime { get => _sendingTime; set => _sendingTime = value; }
}

public struct MCX_ETI_Pad4
{
    private string _pad4;
    public string Pad4 { get => _pad4; set => _pad4 = value; }
}

public struct MCX_ETI_LastLoginTime
{
    private long _lastLoginTime;
    public long LastLoginTime { get => _lastLoginTime; set => _lastLoginTime = value; }
}
public struct MCX_ETI_DaysLeftForPsswordExpiry
{
    private byte _daysLeftForPsswordExpiry;
    public byte DaysLeftForPsswordExpiry { get => _daysLeftForPsswordExpiry; set => _daysLeftForPsswordExpiry = value; }
}

public struct MCX_ETI_GraceLoginsLeft
{
    private byte _graceLoginsLeft;
    public byte GraceLoginsLeft { get => _graceLoginsLeft; set => _graceLoginsLeft = value; }
}

public struct MCX_ETI_Pad6
{
    private string _pad6;
    public string Pad6 { get => _pad6; set => _pad6 = value; }
}
