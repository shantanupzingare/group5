﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTCL.BinaryProtocol.AssetManger
{
    public class CTCL_AssetManger
    {
        //public Dictionary<TEmplate, SubAssetCollection> ExchangeCache;
        public Dictionary<Exchange, AssetCollection> ExchangeCache;
        public CTCL_AssetManger()
        {
            Build();
        }

        public void Build()
        {
            List<Asset> assets = new List<Asset>();
            ExchangeCache = new Dictionary<Exchange, AssetCollection>();


            List<SubAsset> SubsAssetForNSEFO = new List<SubAsset>();
            SubsAssetForNSEFO.Add(new SubAsset()
            {
                SubAssetObject = CTCL_SUBAsset.Individual,
                InstrumentCollection = new List<Instrument>  {
                    new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE,
                    SubinstrumentCollection = new List<SubInstrument>() {
                         new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
                    new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
                },
                    new Instrument() { SubAssetObject = CTCL_Instrument.SPOT,
                        //SubinstrumentCollection = new List<SubInstrument>() {
                        // new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.NA }}
                    }
                }
            });
            SubsAssetForNSEFO.Add(
            new SubAsset()
            {
                SubAssetObject = CTCL_SUBAsset.Index,
                InstrumentCollection = new List<Instrument>  {
                    new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE ,
                    SubinstrumentCollection = new List<SubInstrument>() {
                         new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
                    new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
                }
                }
            }
            );
            //SubsAssetForNSEFO.Add(new SubAsset()
            //{
            //    Asset = CTCL_Asset.Index,
            //    SubinstrumentCollection = new List<SubInstrument> {
            //        new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
            //        new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }
            //        }
            //});

            assets.Add(new Asset { AssetObject = CTCL_Asset.Equity, SubAssetCollection = SubsAssetForNSEFO });
           
            ExchangeCache.Add(new Exchange { ExchangeIdentifier = CTCL_Exchange.NSE }, new AssetCollection { AssetList = assets });



            //for MCX
            List<SubAsset> SubsAssetForMcx = new List<SubAsset>();
            SubsAssetForMcx.Add(new SubAsset()
            {
                SubAssetObject = CTCL_SUBAsset.Individual,
                InstrumentCollection = new List<Instrument>  {
                    new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE,
                    SubinstrumentCollection = new List<SubInstrument>() {
                         new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
                    new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
                }

                }
            });
            SubsAssetForMcx.Add(
           new SubAsset()
           {
               SubAssetObject = CTCL_SUBAsset.Index,
               InstrumentCollection = new List<Instrument>  {
                    new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE ,
                    SubinstrumentCollection = new List<SubInstrument>() {
                         new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
                    new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
                }
               }
           });
           assets = new List<Asset>();
            assets.Add(new Asset { AssetObject = CTCL_Asset.Commodity, SubAssetCollection = SubsAssetForMcx });

            ExchangeCache.Add(new Exchange { ExchangeIdentifier = CTCL_Exchange.MCX }, new AssetCollection { AssetList = assets });

			//for BSE

			List<SubAsset> SubsAssetForBSEFO = new List<SubAsset>();
			SubsAssetForBSEFO.Add(new SubAsset()
			{
				SubAssetObject = CTCL_SUBAsset.Individual,
				InstrumentCollection = new List<Instrument>  {
					new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE,
					SubinstrumentCollection = new List<SubInstrument>() {
						 new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
					new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
				},
					new Instrument() { SubAssetObject = CTCL_Instrument.SPOT,
                    }
				}
			});
			SubsAssetForBSEFO.Add(
			new SubAsset()
			{
				SubAssetObject = CTCL_SUBAsset.Index,
				InstrumentCollection = new List<Instrument>  {
					new Instrument() { SubAssetObject = CTCL_Instrument.DERIVATIVE ,
					SubinstrumentCollection = new List<SubInstrument>() {
						 new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.F },
					new SubInstrument() { SubInstrumentEnum = CTCL_SubInstrument.O }}
				}
				}
			}
			);
			assets = new List<Asset>();
			assets.Add(new Asset { AssetObject = CTCL_Asset.Equity, SubAssetCollection = SubsAssetForBSEFO });

			ExchangeCache.Add(new Exchange { ExchangeIdentifier = CTCL_Exchange.BSE }, new AssetCollection { AssetList = assets });

			//
			//List<SubAsset> SubsAssetForNSECM = new List<SubAsset>();
			//SubsAssetForNSECM.Add(new SubAsset()
			//{
			//    Asset = CTCL_Asset.Stock
			//});

			//ExchangeCache = new Dictionary<Exchange, SubAssetCollection>();
			//ExchangeCache.Add(new Exchange()
			//{
			//    ExchangeIdentifier = CTCL_ExchangeIdentifier.NSE_FO
			//}, new SubAssetCollection
			//{
			//    AssetCollection = SubsAssetForNSEFO
			//});

			//ExchangeCache.Add(new Exchange()
			//{
			//    ExchangeIdentifier = CTCL_ExchangeIdentifier.NSE_CM
			//}, new SubAssetCollection
			//{
			//    AssetCollection = SubsAssetForNSECM
			//});
		}



        //public void AddorUpdateAssetManager()
        //{
        //    ExchangeCache.TryGetValue()
        //}

        public SecurityContractData getSecurityContractData(string InstrumentName,CTCL_ExchangeIdentifier exchangeIdentifier)
        {
            SecurityContractData securityContractData = new SecurityContractData();

            switch (InstrumentName)
            {
                case "OPTIDX":
                    securityContractData.intSubInstrument = (int)CTCL_SubInstrument.O;
                    securityContractData.intSubAsset = (int)CTCL_SUBAsset.Index;
                    break;
                case "OPTSTK":
                    securityContractData.intSubInstrument = (int)CTCL_SubInstrument.O;
                    securityContractData.intSubAsset = (int)CTCL_SUBAsset.Individual;
                    break;
                case "FUTIDX":
                    securityContractData.intSubInstrument = (int)CTCL_SubInstrument.F;
                    securityContractData.intSubAsset = (int)CTCL_SUBAsset.Index;
                    break;
                case "FUTSTK":
                    securityContractData.intSubInstrument = (int)CTCL_SubInstrument.F;
                    securityContractData.intSubAsset = (int)CTCL_SUBAsset.Individual;
                    break;
                case "EQ":
                    securityContractData.intSubInstrument = 0;
                    securityContractData.intSubAsset = (int)CTCL_SUBAsset.Individual;
                    break;
            }
            if (exchangeIdentifier == CTCL_ExchangeIdentifier.NSE_FO)
            {
                securityContractData.intExchange = (int)CTCL_Exchange.NSE;
                securityContractData.intAsset = (int)CTCL_Asset.Equity;
                securityContractData.intInstrument = (int)CTCL_Instrument.DERIVATIVE;
            }
            else if(exchangeIdentifier == CTCL_ExchangeIdentifier.MCX_FO)
            {
                securityContractData.intExchange = (int)CTCL_Exchange.MCX;
                securityContractData.intAsset = (int)CTCL_Asset.Commodity;
                securityContractData.intInstrument = (int)CTCL_Instrument.DERIVATIVE;
            }
            else if(exchangeIdentifier == CTCL_ExchangeIdentifier.BSE_CM)
            {
                securityContractData.intExchange = (int)CTCL_Exchange.BSE;
                securityContractData.intAsset = (int)CTCL_Asset.Equity;
                securityContractData.intInstrument = (int)CTCL_Instrument.SPOT;
            }
            else
            {
                securityContractData.intExchange = (int)CTCL_Exchange.NSE;
                securityContractData.intAsset = (int)CTCL_Asset.Equity;
                securityContractData.intInstrument = (int)CTCL_Instrument.SPOT;
            }

            return securityContractData;
        }

        public class Exchange
        {
            public CTCL_Exchange ExchangeIdentifier;
        }
        public class AssetCollection
        {
            public List<Asset> AssetList;
        }

        //public class SubAssetCollection
        //{
        //    public List<SubAsset> SubAssetList;
        //}
        public class Asset
        {
            public CTCL_Asset AssetObject;
            public bool isSelected;
            public List<SubAsset> SubAssetCollection;
        }

        public class SubAsset
        {
            public CTCL_SUBAsset SubAssetObject;
            public bool isSelected;
            public List<Instrument> InstrumentCollection;
        }

        public class Instrument
        {
            public CTCL_Instrument SubAssetObject;
            public bool isSelected;
            public List<SubInstrument> SubinstrumentCollection;
        }
        public class SubInstrument
        {
            public CTCL_SubInstrument SubInstrumentEnum;
            public bool isSelected;
        }

        public class SecurityContractData
        {
            public int intExchange;
            public int intAsset;
            public int intInstrument;
            public int intSubInstrument;
            public int intSubAsset;
        }
    }
}
