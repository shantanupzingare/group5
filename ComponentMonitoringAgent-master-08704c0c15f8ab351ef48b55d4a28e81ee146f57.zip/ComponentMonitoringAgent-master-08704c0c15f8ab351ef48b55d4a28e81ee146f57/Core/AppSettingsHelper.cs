﻿namespace AgentWorker.Core
{
    using Microsoft.Extensions.Configuration;
    using System;

    public static class AppSettingHelper
    {
        static AppSettingHelper()
        {
            Configuration = new ConfigurationBuilder()
             .SetBasePath(ProcessDirectory)
             .AddJsonFile("appsettings.json")
             .Build();
        }

        public static string ProcessDirectory
        {
            get
            {
                return AppDomain.CurrentDomain.BaseDirectory;
            }
        }

        public static IConfigurationRoot Configuration { get; }
    }
}
