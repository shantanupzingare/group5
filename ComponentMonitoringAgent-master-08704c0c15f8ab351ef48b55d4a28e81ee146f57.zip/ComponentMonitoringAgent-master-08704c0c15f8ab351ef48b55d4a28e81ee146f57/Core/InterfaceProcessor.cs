﻿using AgentWorker.Global;
using AgentWorker.Listener;
using BinaryProtocol.Common;
using CTCL.CacheManagement.ComponentSessionManager;
using Utility.ComponentInstance;

namespace AgentWorker.Core
{
    public class InterfaceProcessor
    {
        ComponentInstanceSetup componentInstanceSetup;
        private static Dictionary<string, ListenerOfMQ> listenerFromMQ; // All Listener 
        public ComponentSessionManager componentSessionManager;

        public InterfaceProcessor()
        {
            //componentInstanceSetup = new ComponentInstanceSetup(Config.connectionString);
            listenerFromMQ = new();
            componentSessionManager = new();
        }
        public Response Init()
        {
            Response response = new Response();
            var omsInterfaces = componentInstanceSetup.GetInterface(ComponentType.AgentWorker, Config.AgentWorkerId); // interfaces.Tables[0];

            if (omsInterfaces.StatusCode != StatusCode.Success)
            {
                return response.Set(StatusCode.OMS_Error, "My Interfaces couldn't be loaded.." + omsInterfaces.Message);
            }

            //int i = 0;
            foreach (var component in (List<ComponentInstanceInterface>)omsInterfaces.ExtraInfo)
            {
                var queueConfiguration = new QueueConfiguration
                {
                    ExchangeName = component.Configuration.ExchangeName,
                    HostName = component.Configuration.HostName,
                    MQName = component.Configuration.MQName,
                    PassWord = component.Configuration.PassWord,
                    Port = component.Configuration.Port,
                    UserName = component.Configuration.UserName,
                    VirtualHost = component.Configuration.VirtualHost
                };
                //AgentWorker as Destination
                if (component.DestComponentInfo.ComponentType == ComponentType.AgentWorker && component.DestComponentInfo.InstanceId == Config.AgentWorkerId)
                {
                    ListenerOfMQ listenerOfMQ;
                    if (!listenerFromMQ.TryGetValue(component.Route, out listenerOfMQ))
                    {
                        listenerOfMQ = new ListenerOfMQ(queueConfiguration);
                        listenerFromMQ.Add(component.Route, listenerOfMQ);
                    }
                    //Add Source
                    listenerOfMQ.AddSource(component.SourceComponentInfo);
                }
            }
            return response.Set(StatusCode.Success, "Interfaces loaded.." + omsInterfaces.Message);
        }
        public Response InitNew(int srcComponentId, int srcInstanceId)
        {
            Response response = new Response();

            string nvcRoute = $"{((ComponentType)srcComponentId).ToString()}{srcInstanceId}_{ComponentType.AgentWorker}{Config.AgentWorkerId}|" +
                $"{((ComponentType)srcComponentId).ToString()}{srcInstanceId}_{ComponentType.AgentWorker}{Config.AgentWorkerId}|" +
                $"{Config.RabbitLogin}|{Config.RabbitPwd}|/|{Config.RabbitIp}|{Config.RabbitPort}";

            ComponentType srcCompId = (ComponentType)srcComponentId;
            int srcInstId = srcInstanceId;

            ComponentType destCompId = (ComponentType)ComponentType.AgentWorker;
            int destInstId = Config.AgentWorkerId;

            var sep = nvcRoute.Split('|');
            if (sep.Length != 7)
            {
                return response.Set(StatusCode.Failure, "Route is not proper!!!");
            }

            string ExName = sep[0];
            string MQName = sep[1];
            string UserName = sep[2];
            string PassWord = sep[3];
            string VirtualHost = sep[4];
            string HostName = sep[5];
            int Port = Convert.ToInt32(sep[6]);

            ComponentInstanceInterface componentInstanceInterface = new();
            componentInstanceInterface.Configuration = new()
            {
                ExchangeName = ExName,
                MQName = MQName,
                UserName = UserName,
                PassWord= PassWord,
                VirtualHost = VirtualHost,
                HostName = HostName,
                Port = Port,
            };
            componentInstanceInterface.Route = nvcRoute;
            componentInstanceInterface.DestComponentInfo = new ComponentInfo
            {
                ComponentType = destCompId,
                InstanceId = destInstId
            };

            componentInstanceInterface.SourceComponentInfo = new ComponentInfo
            {
                ComponentType = srcCompId,
                InstanceId = srcInstId
            };

            ListenerOfMQ listenerOfMQ;
            if (!listenerFromMQ.TryGetValue(componentInstanceInterface.Route, out listenerOfMQ))
            {
                listenerOfMQ = new ListenerOfMQ(componentInstanceInterface.Configuration);
                listenerFromMQ.Add(componentInstanceInterface.Route, listenerOfMQ);
            }
            //Add Source
            listenerOfMQ.AddSource(componentInstanceInterface.SourceComponentInfo);
            InitListeners(listenerOfMQ);
            return response.Set(StatusCode.Success, "Interfaces loaded..");
        }
        public void InitListeners(ListenerOfMQ mq)
        {
            ConsoleLog.ConsoleWrite("INIT RABBIT");

            var componentInfoData = mq.GetComponentInfo();
            ComponentSession dbSession = new();
            dbSession.ComponentType = componentInfoData.Item1;
            dbSession.instanceId = componentInfoData.Item2;
            componentSessionManager.Add(dbSession);
            var sessionAdd = componentSessionManager.Get(componentInfoData.Item1, componentInfoData.Item2);
            if (sessionAdd.Item1.StatusCode == StatusCode.Success)
            {
                mq.AddComponentSession(sessionAdd.Item2);
            }

            var mqRes = mq.Initialize();
            // ConsoleLog.ConsoleWrite($"INIT RABBIT COMPLETE {componentInfoData.Item1}");
            ConsoleLog.ConsoleWrite($"INIT RABBIT COMPLETE ");
        }
    }
}
