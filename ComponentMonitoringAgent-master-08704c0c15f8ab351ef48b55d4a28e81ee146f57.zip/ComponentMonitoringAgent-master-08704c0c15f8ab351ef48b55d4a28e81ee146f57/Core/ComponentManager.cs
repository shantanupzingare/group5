﻿using AgentWorker.Global;
using AgentWorker.Models.Response;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using System.Diagnostics;
using System.Management;
using System.ServiceProcess;

namespace AgentWorker.Core
{
	public class ComponentManager
	{
		private ComponentType componentType;
		private int InstanceId;
		private string exePath=string.Empty;
		private string CmdParameters;
		private Process _process;
		private int PID;
		private string processName;
		ManualResetEvent _mre;
		private bool isRunAsService;
		private string serviceName;
		private bool isRunning;
		private CancellationTokenSource CancellationTokenSource;
		private CancellationToken token;
		public ComponentManager(ComponentInfoData componentInfoData)
		{
			componentType = (ComponentType)componentInfoData.ComponentType;
			InstanceId = componentInfoData.InstanceId;
			exePath = string.IsNullOrEmpty(componentInfoData.ExecutablePath)?string.Empty: componentInfoData.ExecutablePath;
			CmdParameters = componentInfoData.CmdParameters;
			_mre = new ManualResetEvent(false);
			serviceName = componentInfoData.ServiceName;
		}

		public Response StartComponent(bool isRunAsServiceInput, string requestId)
		{
			Response response= new Response();
			isRunAsService= isRunAsServiceInput;
			
			if (_process != null && !_process.HasExited)
			{
				StopComponent();
			}

			if (isRunAsService)
			{
				ServiceController service = new ServiceController(serviceName);
				try
				{
					TimeSpan timeout = TimeSpan.FromMilliseconds(Config.serviceTimerOut);

					service.Start();
					service.WaitForStatus(ServiceControllerStatus.Running, timeout);
					response.Set(StatusCode.Success, $"Service started {serviceName}");

					string query = $"Select ProcessId FROM Win32_Service WHERE Name = {serviceName}";
					ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
					ManagementObjectCollection collections = searcher.Get();

					foreach (ManagementObject collection in collections)
					{
						int processId = 0;
						processId = Convert.ToInt32(collection["ProcessId"]);
						Process process = Process.GetProcessById(processId);
						if (process != null)
						{
							_process = process;
							processName = _process.ProcessName.Trim();
							StartComponentOperationInfoTracking();
							// send message on websocket of running  process;
						}
					}
				}
				catch (Exception ex)
				{
					Log.Error($"Exception occured while running service {serviceName} | {ex}");
					response.Set(StatusCode.Failure, $"Exception occured while running service {serviceName} | {ex}");
				}
			}
			else
			{
				var cmdParameters = $"{CmdParameters} --rid={requestId}"; 
				_process = new Process();
				_process.StartInfo = new ProcessStartInfo()
				{
					FileName = exePath,
					Arguments = cmdParameters,
					UseShellExecute = true,
					RedirectStandardOutput = false,
					RedirectStandardError = false,
					CreateNoWindow = false
				};
				try
				{
					_process.Start();
					PID = _process.Id;
					processName = _process.ProcessName.Trim();
					ConsoleLog.ConsoleWrite($"Process started with PID {_process.Id} | Name {_process.ProcessName} | instanceId {InstanceId}");
					response.Set(StatusCode.Success, $"Process started with PID {_process.Id} | Name {_process.ProcessName} | instanceId {InstanceId}");
				 	//StartComponentOperationInfoTracking();
				}

				catch (Exception ex)
				{
					Log.Error($"Exception occured while running the process | instanceId {InstanceId} {ex} ");
					response.Set(StatusCode.Failure, $"Exception occured while running the process | instanceId {InstanceId} {ex}");
				}
			}

			return response;
		}

		public Response StopComponent()
		{
			Response response= new Response();
			if (isRunAsService)
			{
				ServiceController service = new ServiceController(serviceName);
				try
				{
					TimeSpan timeout = TimeSpan.FromMilliseconds(Config.serviceTimerOut);
					CancellationTokenSource.Cancel();
					service.Stop();
					service.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                    SetIsRunning(false);
                    response.Set(StatusCode.Success, $"Service stopped {serviceName}");
				
				}
				catch(Exception ex)
				{
					Log.Error($"Exception occured while stopping service {serviceName}");
					response.Set(StatusCode.Failure, $"Exception occured while stopping service {serviceName}");
				}
			}
			else
			{
				if (_process != null && !_process.HasExited)
				{
					try
					{
						if(CancellationTokenSource!=null)
							CancellationTokenSource.Cancel();
						_process.Kill();
						_process.WaitForExit();
						SetIsRunning(false);
						ConsoleLog.ConsoleWrite($"Process stopped {PID} | Name {processName} | instanceId {InstanceId}");
						response.Set(StatusCode.Success, $"Process stopped {PID} | Name {processName} | instanceId {InstanceId}");
					}
					catch (Exception ex)
					{
						Log.Error($"An error occured while stopping the process | instanceId {InstanceId} : {ex}");
						response.Set(StatusCode.Failure, $"An error occured while stopping the process | instanceId {InstanceId} : {ex}");
					}

				}
				else
				{
					Log.Info($"Process is already stopped or was never started | instanceId {InstanceId} ");
					response.Set(StatusCode.Failure, $"Process is already stopped or was never started {processName} | instanceId {InstanceId}");
				}
			}
			return response;
		}

		public bool GetIsRunning()
		{
			return isRunning;
		}

		public void SetIsRunning(bool flag)
		{
			isRunning = flag;
			if(isRunning)
            {
                if (_process == null || _process.Id == 0 || _process.HasExited)
                {
                    SetExistingProcess();
                }
            }
			else
			{
				_process = null;
			}
		}
		
		public void SetExistingProcess()
		{
			try
			{
				string wmiQery = string.Format("select CommandLine, ProcessId, Name from Win32_Process where ExecutablePath='{0}'", exePath.Replace("\\", "\\\\"));
				ManagementObjectSearcher searcher = new ManagementObjectSearcher(wmiQery);
				ManagementObjectCollection collections = searcher.Get();

				foreach (ManagementObject collection in collections)
				{
					Console.WriteLine("{0} | {1} | {2}", collection["CommandLine"], collection["ProcessId"], collection["Name"]);

					string ags = $"{collection["Name"]} {componentType}_{InstanceId}";

					var processId = GetProcessIdOfExistingProcess(ags);
					Process process = Process.GetProcessById(processId);
					if (process != null)
					{
						_process = process;
						processName = _process.ProcessName;
						StartComponentOperationInfoTracking();
						// send message on websocket of running  process;
					}
				}
			}
			catch (Exception ex)
			{
				Log.Error($"Exception occured while setting existing process | {ex}");
				// send message on websocket;
			}
			
		}

		private void StartComponentOperationInfoTracking()
		{
			if(CancellationTokenSource != null)
			{
				CancellationTokenSource.Cancel();
			}
			CancellationTokenSource = new CancellationTokenSource();
			token = CancellationTokenSource.Token;
			try
			{
				Task.Factory.StartNew(() =>
				{
					while (true)
					{
						_mre.WaitOne(10000);
						if (token.IsCancellationRequested) break;
						
						var cpu = GetCPU();
						var ram = GetRam();
						Console.WriteLine($"{componentType} | {InstanceId} | CPU usage {cpu:F2}% | Working SET Memory {ram:F2} MB");
						//send to FE on websocket
						ComponentTechincalInfo componentTechincalInfo = new()
						{
							MessageCode = (int)CMA_OpCode.CMA_TECHNICAL_PARAM_REQ,
							ComponentType = (int)componentType,
							InstanceId = InstanceId,
							CPUPercentage = cpu,
							RAMUsage = ram,
							TimeStamp = DateTime.Now
						};
						CoreProcess.wsClientManager.Enqueue(componentTechincalInfo);
					};
				}, token);
			}
			catch (Exception ex)
			{
				Log.Error($"Exception occured in technical parametrs {ex}");
			}
		}

		private double GetCPU()
		{
			try
            {
                if (_process != null && !_process.HasExited)
                {
                    _process.Refresh();
                    TimeSpan startCpu = _process.TotalProcessorTime;
                    DateTime startTIme = DateTime.UtcNow;
                    Thread.Sleep(1000);
                    TimeSpan endCPU = _process.TotalProcessorTime;
                    DateTime endTime = DateTime.UtcNow;

                    double cpuUsedMs = (endCPU - startCpu).TotalMilliseconds;
                    double totalMS = (endTime - startTIme).TotalMilliseconds;
                    return cpuUsedMs / Environment.ProcessorCount / totalMS * 100;
                }
                return 0.0;
            }
			catch (Exception ex)
            {
                Log.Error($"Error while Getting CPU | {ex.Message}");
                return 0.0;
            }
		}

		private double GetRam()
		{
			try
            {
                if (_process != null && !_process.HasExited)
                {
                    _process.Refresh();
                    Thread.Sleep(1000);
                    return (_process.WorkingSet64) / 1024.0 / 1024.0;
                }
                return 0.0;
            }
			catch (Exception ex)
			{
				Log.Error($"Error while Getting RAM | {ex.Message}");
				return 0.0;
			}
		}

		private int GetProcessIdOfExistingProcess(string args)
		{
			int processId = 0;
			try
			{
				Process process = new Process();
				process.StartInfo = new ProcessStartInfo()
				{
					FileName = Config.batchFilePath,
					Arguments = args,
					UseShellExecute = false,
					RedirectStandardOutput = true,
					RedirectStandardError = true,
					CreateNoWindow = true,
				};
				process.Start();

				string[] output = process.StandardOutput.ReadToEnd().Split("\r\n");
				string error = process.StandardError.ReadToEnd();
				//set processId
				if (!string.IsNullOrEmpty(output[0]))
				{
					processId = Convert.ToInt32(output[0]);
				}
				process.WaitForExit();

			}
			catch (Exception ex)
			{
				Log.Error($"Exception occured while reading batch output | {ex}");
			}
			
			return processId;
		}

	}

}
