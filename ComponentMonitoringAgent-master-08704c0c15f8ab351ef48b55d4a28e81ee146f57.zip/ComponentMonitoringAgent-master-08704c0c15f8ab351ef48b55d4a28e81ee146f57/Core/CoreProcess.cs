﻿using BinaryProtocol.Common;
using Exchange.Logs;
using Serilog.Core;
using Serilog.Events;
using Serilog;
using AgentWorker.Global;
using AgentWorker.Processor;
using System.Net;
using AgentWorker.MasterCache;
using AgentWorker.Models.Response;
using System.Diagnostics;
using CTCL.BinaryProtocol.Common.CMA.Enum;

namespace AgentWorker.Core
{
    public class CoreProcess
    {
        public static Response response;
        private static LogProcessor logProcessor;
        public static InterfaceProcessor interfaceProcessor;
        public static ComponentHandshakeManager handshakeManager;
        public static FileDataCache fileDataCache;
        public static WebSocketClientManager wsClientManager;
        public static List<FilePathInfo> filePathInfo;
        public static ComponentDataCache compDataCache;
        public static Dictionary<(ComponentType, int), ComponentManager> componentManager;
        public static Dictionary<int, SpanFileInfo> spanFileInfo;
        public static Dictionary<int, SpanFileInfo> varElmFileInfo;
        public static Dictionary<int, FileSystemWatcher> fileSystemWatcherDict;

        public static Response Initialize()
        {
            response = new();
            LogConfiguration logConfiguration = new LogConfiguration
            {
                FilesizeLimitBytes = 50000000,
                LogFileNameWithPath = Config.logfile,
                LoggingLevelSwitch = new LoggingLevelSwitch
                {
                    MinimumLevel = Config.logLevel == 0 ? LogEventLevel.Debug : (LogEventLevel)Config.logLevel,
                },
                OutputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}",
                RetainedFileCount = Config.logFileCount,
                RollingInterval = RollingInterval.Day,
                RollOnFileSizeLimit = true,
            };

            LogType logType = (LogType)Config.logLevel;

            if (logProcessor == null)
            {
                logProcessor = new LogProcessor(logConfiguration);
            }

            spanFileInfo = new();
            varElmFileInfo = new();
            fileDataCache = new();
            compDataCache = new();
            handshakeManager = new();
            componentManager = new();
            fileSystemWatcherDict = new();
            InitLocalIp();
            //Config.GetConfigurationSettings();
            //CacheOnLoad.LoadAllCacheData();
            interfaceProcessor = new();
            //interfaceProcessor.Init();
            //interfaceProcessor.InitListeners();
            wsClientManager = new(Config.WebSocketUrl);
            return new Response()
            {
                Message = ""
            };
        }
        public static Response SendToLogQueue(LogObject data)
        {
            if (!data.Equals(default(LogObject)) && logProcessor != null)
            {
                return logProcessor.Enqueue(data);
            }
            else if (logProcessor == null)
            {
                return response.Set(StatusCode.OMS_Failure, "logProcessor is null");
            }
            else
            {
                return response.Set(StatusCode.OMS_Failure, "data is null");
            }
        }
        public static Response InitLocalIp()
        {
            Response response = new Response();
            Global.Log.Info($"Fetching Local IP adress");
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    Config.LocalIp = ip.ToString();
                    Global.Log.Info($"Local IP adress {Config.LocalIp}");
                }
            }
            return response.Set(StatusCode.Success, "Sucess");
        }

        public static Response StartComponent(ComponentType componentType, int instanceId, bool isRunAsService, string requestID)
        {
            Response response = new Response();
            if (componentManager.TryGetValue((componentType, instanceId), out var component) && component != null)
            {
                response = component.StartComponent(isRunAsService, requestID);
            }
            else
            {
                response.Set(StatusCode.Failure, $"Component infomation is not found for {componentType} and instanceID {instanceId}");
            }

            ComponentStatus componentStatus = new()
            {
                ComponentType = (int)componentType,
                InstanceId = instanceId,
                IsSucessStatus = false,
                Message = response.Message,
                MessageCode = 0
            };
            //send on web socket

            return response;
        }

        public static Response StopComponent(ComponentType componentType, int instanceId)
        {
            Response response = new Response();
            if (componentManager.TryGetValue((componentType, instanceId), out var component) && component != null)
            {
                response = component.StopComponent();
            }
            else
            {
                response.Set(StatusCode.Failure, $"Component infomation is not found for {componentType} and instanceID {instanceId}");
            }

            //send on web socket 
            var resp = Helper.Helper.PrepareComponentStatus((int)componentType, instanceId, response.StatusCode == StatusCode.Success ? (int)CMA_StatusCode.Stopped : (int)CMA_StatusCode.Completed, "");
            if (response.StatusCode == StatusCode.Success)
            {
                SetIsRunning(componentType, instanceId, false);
            }
            wsClientManager.Enqueue(resp);
            return response;
        }

        public static Response CopyFileData(string sourcePath, string destinationPath)
        {
            Response response = new();

            try
            {
                if (!File.Exists(destinationPath))
                {
                    File.Copy(sourcePath, destinationPath);
                    response.Set(StatusCode.Success, $"File copied from {sourcePath} to {destinationPath} sucessfully");
                }
                else
                {
                    response.Set(StatusCode.Failure, $"File already exists");
                }
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, $"Exception occured while copy file {ex}");
            }

            return response;
        }

        public static void SetIsRunning(ComponentType componentType, int instanceId, bool flag)
        {
            Response response = new Response();
            if (componentManager.TryGetValue((componentType, instanceId), out var component) && component != null)
            {
                component.SetIsRunning(flag);
            }
        }

        public static bool GetIsRunning(ComponentType componentType, int instanceId)
        {
            Response response = new Response();
            if (componentManager.TryGetValue((componentType, instanceId), out var component) && component != null)
            {
                return component.GetIsRunning();
            }
            return false;
        }

        public static void SetExistingProcess(ComponentType componentType, int instanceId)
        {
            if (componentManager.TryGetValue((componentType, instanceId), out var component) && component != null)
            {
                component.SetExistingProcess();
            }
        }

        public static void SendTechnicalDataOfServer()
        {
            ManualResetEvent _mre = new ManualResetEvent(false);
            Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    _mre.WaitOne(10000);
                    var cpu = GetCPUValue();
                    var ram = GetMemValue();

                    //send to FE on websocket
                    ComponentTechincalInfo componentTechincalInfo = new()
                    {
                        MessageCode = (int)CMA_OpCode.CMA_TECHNICAL_PARAM_REQ,
                        ComponentType = -1,
                        InstanceId = Config.AgentWorkerId,
                        CPUPercentage = cpu,
                        RAMUsage = ram,
                    };
                    wsClientManager.Enqueue(componentTechincalInfo);
                }
            });
        }

        private static int GetCPUValue()
        {
            int result = 0;
            try
            {
                var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                cpuCounter.NextValue();
                Thread.Sleep(1000);
                return (int)cpuCounter.NextValue();
            }
            catch (Exception ex)
            {
                Global.Log.Error($"Exception occured while fetching server cpu | {ex}");
            }
            return result;
        }

        private static int GetMemValue()
        {
            int result = 0;
            try
            {
                var memCounter = new PerformanceCounter("Memory", "% Committed Bytes in  Use");
                return (int)memCounter.NextValue();
            }
            catch (Exception ex)
            {
                Global.Log.Error($"Exception occured while fetching server ram | {ex}");
            }
            return result;
        }

        public class SpanFileInfo
        {
            public string FileName;
            public DateTime TimeStamp;
        }

        public static void InitWatcher(int id, string sourcePath)
        {
            //FileWatcherClass fileWatcherClass = new();
            FileSystemWatcher fileSystemWatcher = new(sourcePath);
            fileSystemWatcher.Created += new FileSystemEventHandler(OnChanged);
            fileSystemWatcher.EnableRaisingEvents = true;
            fileSystemWatcherDict.TryAdd(id, fileSystemWatcher);

            Console.WriteLine($"Watcher init for span {sourcePath}");
        }
        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            Console.WriteLine($"Onchange invoked {e.FullPath}");
            System.IO.FileInfo fileInfo = new(e.FullPath);
            var fileName = fileInfo.Name;
            var filePath = e.FullPath;

            DirectoryInfo diretory = new DirectoryInfo(filePath);
            string foldername = diretory.Parent.Name;

            if (foldername == "span")
            {
                var spanFileInfo = CoreProcess.filePathInfo.Where(y => y.FileName == "span").FirstOrDefault();
                if (spanFileInfo != null)
                {
                    var destinationPath = spanFileInfo.DestinationPath + "/" + fileName;

                    var resp = CoreProcess.CopyFileData(filePath, destinationPath);
                    if (resp.StatusCode == StatusCode.Success)
                    {
                        var spanFileCount = CoreProcess.spanFileInfo.Count + 1;
                        CoreProcess.spanFileInfo.TryAdd(spanFileCount, new() { FileName = fileName, TimeStamp = DateTime.Now });
                        SendAfterBodFileUploadStatus(spanFileInfo, true, resp.Message, fileName);
                        Global.Log.Info(resp.Message);
                    }
                }
            }
            else if (foldername == "varelm")
            {
                var varElmInfo = CoreProcess.filePathInfo.Where(y => y.FileName == "varelm").FirstOrDefault();
                if (varElmInfo != null)
                {
                    var destinationPath = varElmInfo.DestinationPath + "/" + fileName;

                    var resp = CoreProcess.CopyFileData(filePath, destinationPath);
                    if (resp.StatusCode == StatusCode.Success)
                    {
                        var elmFile = CoreProcess.varElmFileInfo.Count + 1;
                        CoreProcess.varElmFileInfo.TryAdd(elmFile, new() { FileName = fileName, TimeStamp = DateTime.Now });
                        SendAfterBodFileUploadStatus(varElmInfo, true, resp.Message, fileName);
                        Global.Log.Info(resp.Message);
                    }
                }
            }


        }
        private static void SendAfterBodFileUploadStatus(FilePathInfo filePathInfo, bool status, string message, string fileName)
        {
            FileStatus fileStatus = new()
            {
                MessageCode = (int)CMA_OpCode.FILE_UPLOAD_CONFIRMATION,
                BrokerId = Config.BrokerId,
                SiteId = Config.SiteId,
                AgentId = Config.AgentWorkerId,
                FileName = fileName,
                FileType = filePathInfo.FileType,
                Segment = filePathInfo.Segment,
                IsSucessStatus = status,
                Message = message,
                TimeStamp = DateTime.Now
            };
            CoreProcess.wsClientManager.Enqueue(fileStatus);
        }
    }
    public class FileWatcherClass
    {
        public FileSystemWatcher fileSystemWatcher;
    }
}
