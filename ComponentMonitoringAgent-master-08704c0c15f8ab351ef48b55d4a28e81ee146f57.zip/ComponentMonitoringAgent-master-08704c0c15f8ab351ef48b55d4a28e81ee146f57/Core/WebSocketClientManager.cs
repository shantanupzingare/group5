﻿using AgentWorker.Global;
using AgentWorker.Models.Request;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.WebSocketDotNetty;
using Utility.Queueing;

namespace AgentWorker.Core
{
	public class WebSocketClientManager
    {
        private InteractiveProcessQueue _interactiveProcessQueue;
		private WebSocketClient _client;
        private ProcessQueue<object> queue;
        private Thread thread;

        public WebSocketClientManager(string url)
        {
            queue = new ProcessQueue<object>();
            _interactiveProcessQueue = new InteractiveProcessQueue();
			_client = new WebSocketClient();
			_client.OnMessageReceived += OnDataReceived;
			_client.OnClientConnect += OnClientConnect;
			_client.OnClientDisconnect += OnClientDisConnect;
			_client.init();
            thread = new Thread(new ThreadStart(ListenQueue));
            thread.Start();
            Init(url);
		}

		private void Init(string url)
		{
			Uri uri = new Uri(url);
			_client.ConnectAsync(uri);
		}

		private void OnDataReceived(object message, bool isBinaryMessage)
		{
			var data = message.ToString();
			_interactiveProcessQueue.Enqueue(data);
		}

		private void OnClientConnect()
		{
			Log.Info("Web socket connected");

            AgentHandshakeReq handshakeReq = PrepareHandshakeReq();
            SendNew(handshakeReq);
		}

		private void OnClientDisConnect()
		{
			Log.Info("Web socket Disconnected");
		}

		private void Send(object res)
		{
            _client.SendAsync(res);
        }
        private void SendNew(object res)
        {
            _client.SendAsyncNew(res);
        }

        public void Enqueue(object data)
        {
            queue.Enqueue(data);
        }

        private void ListenQueue()
        {
            while (true)
            {
                if (queue.TryDequeue(out object res))
                {
                    Process(res);
                }
            }
        }

        private void Process(object res)
        {
            try
            {
                SendNew(res);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
        }
        private AgentHandshakeReq PrepareHandshakeReq()
        {
            AgentHandshakeReq handshakeReq = new()
            {
                MessageCode = (int)CMA_OpCode.AGENT_HANDSHAKE_REQ,
                IP = Config.LocalIp
            };
            return handshakeReq;
        }
    }
}
