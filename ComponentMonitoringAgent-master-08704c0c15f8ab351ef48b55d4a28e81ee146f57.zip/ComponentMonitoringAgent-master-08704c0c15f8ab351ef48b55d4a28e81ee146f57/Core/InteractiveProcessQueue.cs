﻿using AgentWorker.Global;
using AgentWorker.Models.Others;
using AgentWorker.Models.Request;
using AgentWorker.Models.Response;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using Newtonsoft.Json;
using Utility.Queueing;
using ComponentInfo = AgentWorker.Models.Response.ComponentInfo;
using FileInfoModel = AgentWorker.Models.Response.FileInfo;

namespace AgentWorker.Core
{
	public class InteractiveProcessQueue
	{
		private ProcessQueue<string> interactiveMessageQueue;
		Thread thread;
		ManualResetEvent _mre;
		ManualResetEvent _uploadWait;
		ManualResetEvent _componentWait;

		public InteractiveProcessQueue()
		{
			interactiveMessageQueue = new ProcessQueue<string>();
			_mre = new ManualResetEvent(false);
			_uploadWait = new ManualResetEvent(false);
			_componentWait = new ManualResetEvent(false);
			DrainerThreadInit();
		}

		public void Enqueue(string message)
		{
			interactiveMessageQueue.Enqueue(message);
		}
		private void DrainerThreadInit()
		{
			thread = new Thread(new ThreadStart(DrainMessage));
			thread.Start();
		}
		private void DrainMessage()
		{
			while (true)
			{
				if (interactiveMessageQueue.TryDequeue(out string message))
				{
					try
					{
						//Process message
						ProcessMessage(message);
					}
					catch (System.Exception ex)
					{
						Log.Error(message, $"Exception occured on message process {ex.Message}");

					}
				}
			}
		}
		private void ProcessMessage(string message)
		{
			var baseResponse = JsonConvert.DeserializeObject<MsgHeader>(message);
			if(baseResponse != null) 
			{
				var opcode = (CMA_OpCode)baseResponse.MessageCode;
				switch(opcode)
                {
                    case CMA_OpCode.AGENT_HANDSHAKE_RES:
                        {
                            Log.Info($"Received AGENT_HANDSHAKE_RES");
                            var handshakeRes = JsonConvert.DeserializeObject<MsgHeader>(message);
                            if (handshakeRes != null)
                            {
								Config.AgentWorkerId = handshakeRes.AgentId;
								Config.BrokerId = handshakeRes.BrokerId;
								Config.SiteId = handshakeRes.SiteId;

								//starting current server cpu and ram utilization
								//CoreProcess.SendTechnicalDataOfServer();

                                //send Login Req
                                //var loginReq = PrepareLoginReq();
                                //CoreProcess.wsClientManager.Enqueue(loginReq);

                                MsgHeader fileInfoReq = new() 
								{
									MessageCode = (int)CMA_OpCode.FILE_INFO_REQ,
                                    AgentId = Config.AgentWorkerId,
                                    BrokerId = Config.BrokerId,
                                    SiteId = Config.SiteId,
                                };
                                CoreProcess.wsClientManager.Enqueue(fileInfoReq);
                            }
							else
							{
								Log.Error($"Error while procesing AGENT_HANDSHAKE_RES");
							}
                        }
                        break;

                    case CMA_OpCode.LOGIN_RESPONSE:
						{
							Log.Info($"Received Login Response");
							var loginResponse = JsonConvert.DeserializeObject<StatusMessage>(message);
							if(loginResponse != null && loginResponse.IsSucessStatus)
							{
								MsgHeader fileInfoReq = new()
								{
									MessageCode = (int)CMA_OpCode.FILE_INFO_REQ,
									AgentId = Config.AgentWorkerId,	
									BrokerId = Config.BrokerId,	
									SiteId = Config.SiteId,	
								};
								CoreProcess.wsClientManager.Enqueue(fileInfoReq);
                            }
                            else
                            {
                                Log.Error($"Error while procesing LOGIN_RESPONSE");
                            }
                        }
						break;

                    case CMA_OpCode.FILE_INFO_RES:
                        {
                            Log.Info($"Received FILE_INFO_RES");
                            var fileInfoResponse = JsonConvert.DeserializeObject<FileInfoModel>(message);
                            if (fileInfoResponse != null)
                            {
								Config.MasterPath = fileInfoResponse.MasterPath;
								CoreProcess.filePathInfo = fileInfoResponse.Files;

								//Prepare ComponentInfo Download Req
								MsgHeader compInfoHeader = new() 
								{
									MessageCode = (int)CMA_OpCode.COMPONENT_INFO_REQ,
                                    AgentId = Config.AgentWorkerId,
                                    BrokerId = Config.BrokerId,
                                    SiteId = Config.SiteId,
                                };
                                CoreProcess.wsClientManager.Enqueue(compInfoHeader);
                            }
                            else
                            {
                                Log.Error($"Error while procesing FILE_INFO_RES");
                            }
                        }
                        break;

                    case CMA_OpCode.COMPONENT_INFO_RES:
                        {
                            Log.Info($"Received COMPONENT_INFO_RES");
                            var componentInfoResponse = JsonConvert.DeserializeObject<ComponentInfo>(message);
                            if (componentInfoResponse != null && componentInfoResponse.Data != null)
                            {
								for(int i=0; i<componentInfoResponse.Data.Count; i++)
								{
									CoreProcess.compDataCache.AddOrUpdate(componentInfoResponse.Data[i]);
									if (!CoreProcess.componentManager.TryGetValue(((ComponentType)componentInfoResponse.Data[i].ComponentType, componentInfoResponse.Data[i].InstanceId), out var componentManager)) 
									{
										componentManager = new(componentInfoResponse.Data[i]);
										CoreProcess.componentManager.Add(((ComponentType)componentInfoResponse.Data[i].ComponentType, componentInfoResponse.Data[i].InstanceId), componentManager);
										if(componentInfoResponse.Data[i].ComponentType!=-1)
										{
                                            CoreProcess.interfaceProcessor.InitNew(componentInfoResponse.Data[i].ComponentType, componentInfoResponse.Data[i].InstanceId);
                                            CoreProcess.SetExistingProcess((ComponentType)componentInfoResponse.Data[i].ComponentType, componentInfoResponse.Data[i].InstanceId);
                                        }

                                    }
                                }
                                //Prepare END MSG DOWNLOAD
                                MsgHeader endMsg = new()
                                {
                                    MessageCode = (int)CMA_OpCode.END_MSG_DOWNLOAD,
                                    AgentId = Config.AgentWorkerId,
                                    BrokerId = Config.BrokerId,
                                    SiteId = Config.SiteId,
                                };
                                CoreProcess.wsClientManager.Enqueue(endMsg);
                            }
                            else
                            {
                                Log.Error($"Error while procesing COMPONENT_INFO_RES");
                            }
                        }
                        break;

                    case CMA_OpCode.START_FILE_UPLOAD:
                        {
							if (!Config.isFileBODDoneToday)
							{
								Log.Info($"Received START_FILE_UPLOAD");
                                var fileUpload = JsonConvert.DeserializeObject<FileUploadReq>(message);
								if(fileUpload != null )
                                {
                                    CoreProcess.StartComponent(ComponentType.CONTRACT_MASTER_READER, -1, false, fileUpload.RequestId);
                                    while (true)
                                    {
                                        _uploadWait.WaitOne(5000);
                                        if (CoreProcess.GetIsRunning(ComponentType.CONTRACT_MASTER_READER, -1))
                                        {
                                            break;
                                        }
                                    }
                                    ProcessFileUpload();
                                }
							}
							else
							{
								bool status = false;
								var messages = "All mandatory files is already uploaded";
								SendEndFileUploadRes(status, messages);
							}
                            
                        }
                        break;

                    case CMA_OpCode.COMPONENT_START:
                        {
                            Log.Info($"Received COMPONENT_START");
                            var componentInitResponse = JsonConvert.DeserializeObject<ComponentInitReq>(message);
							if(componentInitResponse != null)
							{
								var startResp = CoreProcess.StartComponent((ComponentType)componentInitResponse.ComponentType, componentInitResponse.InstanceId, componentInitResponse.IsRunAsService, componentInitResponse.RequestId);
								if (startResp.StatusCode == StatusCode.Success)
									Log.Info(startResp.Message);
								else
									Log.Error(startResp.Message);
							}
                        }
						break;

					case CMA_OpCode.COMPONENT_STOP:
						Log.Info($"Received COMPONENT_STOP");
						var componentInitEndResponse = JsonConvert.DeserializeObject<ComponentInitReq>(message);
						if (componentInitEndResponse != null)
						{
							var startResp = CoreProcess.StopComponent((ComponentType)componentInitEndResponse.ComponentType, componentInitEndResponse.InstanceId);
							if (startResp.StatusCode == StatusCode.Success)
								Log.Info(startResp.Message);
							else
								Log.Error(startResp.Message);
						}
						break;

                    case CMA_OpCode.START_AFTER_BOD_FILE_UPLOAD:
                        {
                            Log.Info($"Received START_AFTER_BOD_FILE_UPLOAD");
                            var fileUpload = JsonConvert.DeserializeObject<FileUploadReq>(message);
                            if (fileUpload != null)
                            {
                                ProcessAfterBODFileUpload();
                            }

                        }
                        break;
                    default:
						break;
				}
			}
		}
		private void ProcessFileUpload()
		{
			//perform file upload here
			string message = string.Empty;
			bool status;
			var list = CoreProcess.filePathInfo.OrderBy(x => x.FilePriority).ToList();
			if(list != null)
			{
				for(int i=0; i<list.Count; i++) 
				{
					var segmentId = list[i].Segment;
					var fileType = list[i].FileType;
					var sourcePath = Config.MasterPath + "/" + list[i].FileName;

					//var res = CoreProcess.fileDataCache.Get(segmentId, fileType);
					if(/*res.Item1 && */list[i].IsUploadBeforeBod)
					{
						//var destinationPath = res.Item2.FilePath + "/" + list[i].FileName;
						var destinationPath = list[i].DestinationPath + "/" + list[i].FileName;
						var resp = CoreProcess.CopyFileData(sourcePath, destinationPath);
						if(resp.StatusCode == StatusCode.Success)
						{
							SendFileUploadStatus(list[i], true, resp.Message);
							Log.Info(resp.Message);
						}
						else
						{
							SendFileUploadStatus(list[i], false, resp.Message);
							Log.Error(resp.Message);
						}

						while (true)
						{
							_uploadWait.WaitOne(5000);
							if (list[i].IsFileUploadAck)
							{
								break;
							}
						}
					}
                    Thread.Sleep(3000);
                }
				message = "All mandatory file before bod process uploaded";
				status = true;
				Config.isFileBODDoneToday = true;
			}
			else
			{
				message = "no file found to upload";
				status = false;
			}
			SendEndFileUploadRes(status, message);
		}
		private void SendFileUploadStatus(FilePathInfo filePathInfo, bool status, string message)
		{
			FileStatus fileStatus = new()
			{
				MessageCode = (int)CMA_OpCode.FILE_UPLOAD_CONFIRMATION,
				BrokerId = Config.BrokerId,
				SiteId = Config.SiteId,
				AgentId = Config.AgentWorkerId,
				FileName = filePathInfo.FileName,
				FileType = filePathInfo.FileType,
				Segment = filePathInfo.Segment,
				IsSucessStatus = status,
				Message = message,
				TimeStamp = DateTime.Now
			};
			CoreProcess.wsClientManager.Enqueue(fileStatus);
		}
        private LoginRequest PrepareLoginReq()
        {
            LoginRequest request = new()
            {
                MessageCode = (int)CMA_OpCode.LOGIN_REQ,
                SiteId = Config.SiteId,
                AgentId = Config.AgentWorkerId,
                BrokerId = Config.BrokerId
            };
            return request;
        }
		private void SendEndFileUploadRes(bool status, string message)
		{
			//send appropriate status to FE
			StatusMessage statusMessage = new ();
			statusMessage.MessageCode = (int)CMA_OpCode.END_FILE_UPLOAD;
			statusMessage.SiteId = Config.SiteId;
			statusMessage.AgentId = Config.AgentWorkerId;
			statusMessage.BrokerId = Config.BrokerId;
			statusMessage.IsSucessStatus = status;
			statusMessage.Message = message;	
			CoreProcess.wsClientManager.Enqueue(statusMessage);
		}
		private void ProcessAfterBODFileUpload()
		{
            var list = CoreProcess.filePathInfo.Where(y => y.IsUploadBeforeBod == false).OrderBy(x => x.FilePriority).ToList();
            if (list != null)
			{
                for (int i = 0; i < list.Count; i++)
                {
                    var segmentId = list[i].Segment;
                    var fileType = list[i].FileType;

                    if (!list[i].IsUploadBeforeBod)
                    {
						if (list[i].FileName == "span")
                        {
							//var prefix = "nsccl.";
							//var date = DateTime.Now.ToString("yyyyMMdd");
							//var spanFileCount = CoreProcess.spanFileInfo.Count + 1;
							//var suffix = "i" + spanFileCount.ToString("D2") + ".spn";

							//var fileName = prefix + date + "." + suffix;

                            var sourcePath = Config.MasterPath + "/" + "span";
                            //var destinationPath = list[i].DestinationPath + "/" + fileName;
                            //var resp = CoreProcess.CopyFileData(sourcePath, destinationPath);

                            //if (resp.StatusCode == StatusCode.Success)
                            {
                                //CoreProcess.spanFileInfo.TryAdd(spanFileCount, new(){ FileName = fileName, TimeStamp = DateTime.Now });
                                CoreProcess.InitWatcher(1, sourcePath);
                                Console.WriteLine($"Watcher init for varelm {sourcePath}");
                                //FileSystemWatcher fileSystemWatcher = new(sourcePath);
                                //fileSystemWatcher.Created += new FileSystemEventHandler(OnChanged);
                                //fileSystemWatcher.EnableRaisingEvents = true;
                                //SendFileUploadStatus(list[i], true, "Sucess");
                                //Log.Info(resp.Message);
                            }
                            //else
                            //{
                            //    SendFileUploadStatus(list[i], false, "Failure");
                            //    Log.Error($"Failure while copying span file");
                            //}
                        }
						else if (list[i].FileName == "varelm")
						{
                            //var prefix = "C_VAR_";
                            //var date = DateTime.Now.ToString("ddMMyyyy");
							//var elmFileCount = CoreProcess.varElmFileInfo.Count + 1;
							
							//var fileName = prefix + date + "_" + elmFileCount + ".DAT";

                            var sourcePath = Config.MasterPath + "/" + "varelm";
							//var destinationPath = list[i].DestinationPath + "/" + fileName;
							//var resp = CoreProcess.CopyFileData(sourcePath, destinationPath);

							//if(resp.StatusCode == StatusCode.Success)
							{
								//CoreProcess.varElmFileInfo.TryAdd(elmFileCount, new() { FileName = fileName, TimeStamp = DateTime.Now });
								CoreProcess.InitWatcher(2,sourcePath);
                                Console.WriteLine($"Watcher init for varelm {sourcePath}");

                                //FileSystemWatcher fileSystemWatcher2 = new(sourcePath);
                                //fileSystemWatcher2.Created += new FileSystemEventHandler(OnChanged);
                                //fileSystemWatcher2.EnableRaisingEvents = true;
                                //SendFileUploadStatus(list[i], true, "Sucess");
                                Log.Info("Sucess");
                            }
                            //else
                            //{
                            //    SendFileUploadStatus(list[i], false, resp.Message);
                            //    Log.Error(resp.Message);
                            //}
                        }
                    }
                }
            }
        }
        private void OnChanged(object source, FileSystemEventArgs e)
        {
            System.IO.FileInfo fileInfo = new(e.FullPath);
			var fileName = fileInfo.Name;
			var filePath = e.FullPath;

			string[] pathInfo = filePath.Split('\\');
			if(pathInfo.Length == 3)
			{
				string[] innerArr = pathInfo[1].Split('/');
				if(innerArr.Length == 2)
                {
                    if (innerArr[1] == "span")
                    {
                        var spanFileInfo = CoreProcess.filePathInfo.Where(y => y.FileName == "span").FirstOrDefault();
                        if (spanFileInfo != null)
                        {
                            var destinationPath = spanFileInfo.DestinationPath + "/" + fileName;

                            var resp = CoreProcess.CopyFileData(filePath, destinationPath);
                            if (resp.StatusCode == StatusCode.Success)
                            {
                                var spanFileCount = CoreProcess.spanFileInfo.Count + 1;
                                CoreProcess.spanFileInfo.TryAdd(spanFileCount, new() { FileName = fileName, TimeStamp = DateTime.Now });
                                SendAfterBodFileUploadStatus(spanFileInfo, true, resp.Message, fileName);
                                Log.Info(resp.Message);
                            }
                        }
                    }
                    else if (innerArr[1] == "varelm")
                    {
                        var varElmInfo = CoreProcess.filePathInfo.Where(y => y.FileName == "varelm").FirstOrDefault();
                        if (varElmInfo != null)
                        {
                            var destinationPath = varElmInfo.DestinationPath + "/" + fileName;

                            var resp = CoreProcess.CopyFileData(filePath, destinationPath);
                            if (resp.StatusCode == StatusCode.Success)
                            {
                                var elmFile = CoreProcess.varElmFileInfo.Count + 1;
                                CoreProcess.varElmFileInfo.TryAdd(elmFile, new() { FileName = fileName, TimeStamp = DateTime.Now });
                                SendAfterBodFileUploadStatus(varElmInfo, true, resp.Message, fileName);
                                Log.Info(resp.Message);
                            }
                        }
                    }
                }
			}
        }
        private void SendAfterBodFileUploadStatus(FilePathInfo filePathInfo, bool status, string message, string fileName)
        {
            FileStatus fileStatus = new()
            {
                MessageCode = (int)CMA_OpCode.FILE_UPLOAD_CONFIRMATION,
                BrokerId = Config.BrokerId,
                SiteId = Config.SiteId,
                AgentId = Config.AgentWorkerId,
                FileName = fileName,
                FileType = filePathInfo.FileType,
                Segment = filePathInfo.Segment,
                IsSucessStatus = status,
                Message = message,
                TimeStamp = DateTime.Now
            };
            CoreProcess.wsClientManager.Enqueue(fileStatus);
        }
    }
}
