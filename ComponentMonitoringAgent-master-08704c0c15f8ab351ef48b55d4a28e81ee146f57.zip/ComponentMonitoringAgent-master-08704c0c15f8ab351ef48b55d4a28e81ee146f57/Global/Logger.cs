﻿using Exchange.Logs;

namespace AgentWorker.Global
{
    public class Logger
    {
        private static LogManager logManager;
        static Logger()
        {
            LogConfiguration logConfiguration = new LogConfiguration
            {
                FilesizeLimitBytes = 50000000,
                LogFileNameWithPath = Config.logfile,
                LoggingLevelSwitch = new Serilog.Core.LoggingLevelSwitch
                {
                    MinimumLevel = Serilog.Events.LogEventLevel.Information,
                },
                OutputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}",
                RetainedFileCount = 0,
                RollingInterval = Serilog.RollingInterval.Infinite,
                RollOnFileSizeLimit = true,
            };

            logManager = new LogManager(logConfiguration);
        }

        public static void LogError(string msg, object logObject)
        {
            logManager.Error(msg, logObject);
        }

        public static void LogInfo(string msg, object logObject = null)
        {
            if (logObject == null)
            {
                logManager.Info(msg);

            }
            else
            {
                logManager.Info(msg, logObject);
            }
        }
    }
}
