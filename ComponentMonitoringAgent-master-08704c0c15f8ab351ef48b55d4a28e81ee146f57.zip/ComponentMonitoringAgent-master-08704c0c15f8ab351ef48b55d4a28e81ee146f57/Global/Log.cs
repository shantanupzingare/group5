﻿using AgentWorker.Core;
using BinaryProtocol.Common;

namespace AgentWorker.Global
{
    internal class Log
    {
        private static LogType _logType;
        internal Log(LogType logType)
        {
            _logType = logType;
        }

        internal void UpdateLogType(LogType logType)
        {
            _logType = logType;
        }

        internal static void Verbose(object Object, string message = "")
        {
            if (_logType > LogType.Verbose)
            {
                Object = null;
                message = null;
                return;
            }
            LogObject logObject = new LogObject(LogType.Verbose, message, Object);
            CoreProcess.SendToLogQueue(logObject);
        }

        internal static void Debug(object Object, string message = "")
        {
            if (_logType > LogType.Debug)
            {
                Object = null;
                message = null;
                return;
            }
            LogObject logObject = new LogObject(LogType.Debug, message, Object);
            CoreProcess.SendToLogQueue(logObject);
        }
        internal static void Info(string message = "")
        {
            if (_logType > LogType.Info)
            {
                message = null;
                return;
            }

            LogObject logObject = new LogObject(LogType.Info, message);
            CoreProcess.SendToLogQueue(logObject);
        }
        internal static void Warning(object Object, string message = "")
        {
            if (_logType > LogType.Warning)
            {
                Object = null;
                message = null;
                return;
            }
            LogObject logObject = new LogObject(LogType.Warning, message, Object);
            CoreProcess.SendToLogQueue(logObject);
        }
        internal static void Error(object Object, string message = "")
        {
            if (_logType > LogType.Error)
            {
                Object = null;
                message = null;
                return;
            }
            LogObject logObject = new LogObject(LogType.Error, message, Object);
            CoreProcess.SendToLogQueue(logObject);
        }

        internal static void Fatal(object Object, string message = "")
        {
            if (_logType > LogType.Fatal)
            {
                Object = null;
                message = null;
                return;
            }
            LogObject logObject = new LogObject(LogType.Error, message, Object);
            CoreProcess.SendToLogQueue(logObject);
        }
    }
}
