﻿using AgentWorker.Core;
using AgentWorker.MasterCache;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using System.Data;
using Filetype = AgentWorker.MasterCache.Filetype;

namespace AgentWorker.Global
{
    public static class CacheOnLoad
    {
        //public static void LoadAllCacheData()
        //{
        //    if (Config.IsFileUploadAllowed)
        //    {
        //        ConsoleLog.ConsoleWrite("Filling File Path Statistics");
        //        GetConfiguredFilePath();
        //        ConsoleLog.ConsoleWrite("File Path Statistics Data filled.");
        //    }
        //}
        //public static Response GetConfiguredFilePath()
        //{
        //    Response response = new Response();
        //    try
        //    {
        //        DataSet ds;
        //        ds = CommonHelper.ExecuteProcedureForDataSet("usp_GetFileUploadData");
        //        if (ds == null || ds.Tables.Count == 0)
        //        {
        //            return response.Set(StatusCode.Failure, " no record found.");
        //        }
        //        foreach (DataRow dr in ds.Tables[0].Rows)
        //        {
        //            SegmentId segmentId = new SegmentId();
        //            segmentId._segmentId = Convert.ToInt32(dr[0]);
        //            segmentId._filetype = Convert.ToInt32(dr[1]);


        //            Filetype filetype = new Filetype();
        //            filetype._fileType = Convert.ToInt32(dr[1]);

        //            FileDetails fileDetails = new FileDetails();
        //            fileDetails.SegmentId = Convert.ToInt32(dr[0]);
        //            fileDetails.FileType = Convert.ToInt32(dr[1]);
        //            fileDetails.FilePath = Convert.ToString(dr[2]);
        //            fileDetails.Source = Convert.ToString(dr[3]);
        //            fileDetails.VersionNo = Convert.ToInt32(dr[4]);
        //            fileDetails.LastNoOfRecords = Convert.ToInt32(dr[5]);
        //            fileDetails.FileSizeInBytes = Convert.ToInt32(dr[6]);
        //            fileDetails.FileRefreshFrequency = Convert.ToInt32(dr[7]);
        //            fileDetails.dtmFileLastuploadTime = Convert.ToDateTime(dr[8]);
        //            fileDetails.IsActive = Convert.ToBoolean(dr[9]);
        //            fileDetails.IsDeleted = Convert.ToBoolean(dr[10]);
        //            fileDetails.Remark = Convert.ToString(dr[11]);
        //            fileDetails.UpdatedBy = Convert.ToString(dr[12]);
        //            fileDetails.UpdatedOn = Convert.ToDateTime(dr[13]);

        //            CoreProcess.fileDataCache.AddOrUpdate(fileDetails);

        //        }
        //        return response.Set(StatusCode.Success, "All fileWatchers initialized.");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error($"{ex.Message} | Error while filling File Upload Staistics Data");
        //        return response.Set(StatusCode.Failure, "Error while filling File Upload Staistics Data");
        //    }
        //}
    }
}
