﻿using AgentWorker.Core;
using AgentWorker.Models.Response;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.CacheManagement.ComponentSessionManager;
using CTCL.Utility;

namespace AgentWorker.Global
{
    public class ComponentHandshakeManager
    {
        public void StartHeartBeatChecker()
        {
            Task.Factory.StartNew(() =>
            {
                ManualResetEvent _heartBeatChecker = new ManualResetEvent(false);
                while (true)
                {
                    _heartBeatChecker.WaitOne(Config.heartbeatCheckInterval * 1000);
                    var allComponentSession = CoreProcess.interfaceProcessor.componentSessionManager.Get();
                    if (allComponentSession != null && allComponentSession.Count > 0)
                    {
                        for (int i = 0; i < allComponentSession.Count; i++)
                        {
                            var sessionObj = allComponentSession.ElementAt(i);
                            if (sessionObj != null && sessionObj.componentHandshake != ComponentHandshakeStatus.INACTIVE)
                            {
                                var expriryTime = sessionObj.lastHearBeatRecevieTime.ToCTCLDateTime().AddSeconds(Config.ConfigurationValueAliveInst);
                                if (expriryTime < DateTime.Now)
                                {
                                    sessionObj.componentHandshake = ComponentHandshakeStatus.INACTIVE;
                                    CoreProcess.interfaceProcessor.componentSessionManager.Update(sessionObj);
                                    Disconnect(sessionObj);
                                    Log.Info($"Compnent {sessionObj.ComponentType} | instanceName {sessionObj.instanceId} | Compnent status {sessionObj.componentHandshake}");
                                }
                            }
                        }
                    }
                }
            });
        }
        private void Disconnect(ComponentSession sessionObj)
        {
            CoreProcess.SetIsRunning(sessionObj.ComponentType, sessionObj.instanceId, false);
            ComponentStatus componentStatus = Helper.Helper.PrepareComponentStatus((int)sessionObj.ComponentType, sessionObj.instanceId, (int)CMA_StatusCode.Stopped, "Disconnected because of heartbeat");
            CoreProcess.wsClientManager.Enqueue(componentStatus);
        }
    }
}
