﻿using AgentWorker.Core;
using BinaryProtocol.Common;
using System.Data;

namespace AgentWorker.Global
{
    public class Config
    {
        public static string logfile;
        public static int logLevel;
        public static int logFileCount;
        public static ushort prefetchCount;
        public static string port;
        public static int AgentWorkerId;
        public static int BrokerId;
        public static int SiteId;
        public static string LocalIp;
        public static Response response;
        public static int heartbeatCheckInterval;
        public static int ConfigurationValueAliveInst;
        public static bool IsFileUploadAllowed;
        public static string WebSocketUrl;
        public static string MasterPath;
		public static int serviceTimerOut = 100;
        public static bool isFileBODDoneToday;
        public static string RabbitIp;
        public static string RabbitPort;
        public static string RabbitLogin;
        public static string RabbitPwd;
        public static string batchFilePath;

        static Config()
        {
            response = new Response();
            logfile = AppSettingHelper.Configuration["LogFilePath"];
            prefetchCount = Convert.ToUInt16(AppSettingHelper.Configuration["PrefetchCount"]);
            logLevel = Convert.ToInt32(AppSettingHelper.Configuration["LogLevel"]);
            logFileCount = Convert.ToInt32(AppSettingHelper.Configuration["LogFileCount"]);
            port = AppSettingHelper.Configuration["ServerPort"];
            prefetchCount = Convert.ToUInt16(AppSettingHelper.Configuration["PrefetchCount"]);
            heartbeatCheckInterval = Convert.ToInt32(AppSettingHelper.Configuration["heartbeatCheckInterval"]);
            ConfigurationValueAliveInst = Convert.ToInt32(AppSettingHelper.Configuration["ConfigurationValueAliveInst"]);
            IsFileUploadAllowed = Convert.ToBoolean(AppSettingHelper.Configuration["IsFileUploadAllowed"]);
            WebSocketUrl = AppSettingHelper.Configuration["WebSocketUrl"];
            RabbitIp = AppSettingHelper.Configuration["RabbitIp"];
            RabbitPort = AppSettingHelper.Configuration["RabbitPort"];
            RabbitLogin = AppSettingHelper.Configuration["RabbitLogin"];
            RabbitPwd = AppSettingHelper.Configuration["RabbitPwd"];
            batchFilePath = "BatchFiles\\getprocess3.bat";
        }

        //public static Response GetConfigurationSettings()
        //{
        //    DataSet ds;
        //    var dbParams = new Dictionary<string, object>();
        //    dbParams.Add("IP", Config.LocalIp);
        //    ds = CommonHelper.ExecuteProcedureForDataSet("usp_GetCMAAgentConfigMaster", dbParams);
        //    if (ds == null)
        //    {
        //        return response.Set(StatusCode.Failure, "CMAAgentConfigMaster info not loaded.");
        //    }
        //    return FillCMAAgentConfigMaster(ds.Tables[0]);
        //}
        //private static Response FillCMAAgentConfigMaster(DataTable dataTable)
        //{
        //    try
        //    {
        //        foreach (DataRow dr in dataTable.Rows)
        //        {
        //            BrokerId = Convert.ToInt32(dr[0]);
        //            SiteId = Convert.ToInt32(dr[1]);
        //            AgentWorkerId = Convert.ToInt32(dr[2]);
        //        }
        //        Log.Info($"Records fetched from DB for CMAAgentConfigMaster : {dataTable.Rows.Count}");

        //        return response.Set(StatusCode.Success, "CMAAgentConfigMaster config filled successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        return response.Set(StatusCode.Failure, "Failed to fill CMAAgentConfigMaster config.");
        //    }
        //}
    }
}
