﻿using CTCL.CacheManagement.Helper;
using System.Collections.Concurrent;

namespace AgentWorker.MasterCache
{
    public class FileDataCache
    {
        private ConcurrentDictionary<SegmentId, FileNode> fileDataDic;
        public FileDataCache()
        {
            fileDataDic = new ConcurrentDictionary<SegmentId, FileNode>();
        }
        public void AddOrUpdate(FileDetails fileDetails)
        {
            SegmentId segmentId = new SegmentId();
            segmentId._segmentId = fileDetails.SegmentId;
            segmentId._filetype = fileDetails.FileType;

            if (!fileDataDic.TryGetValue(segmentId, out FileNode fileNode))
            {
                fileNode = new();
                fileDataDic.TryAdd(segmentId, fileNode);
            }
            fileNode.AddOrUpdate(fileDetails);
        }
        public (bool, FileDetails) Get(int segmentId, int fileType)
        {
            SegmentId segId = new();
            segId._segmentId = segmentId;
            segId._filetype = fileType;

            if(fileDataDic.TryGetValue(segId, out FileNode fileNode) && fileNode != null) 
            {
                return fileNode.Get(fileType);
            }
            return (false, null);
        }
    }
    public class FileNode
    {
        private ConcurrentDictionary<Filetype, FileDetails> Node;
        public FileNode()
        {
            Node = new ConcurrentDictionary<Filetype, FileDetails>();
        }
        public void AddOrUpdate(FileDetails fileDetails)
        {
            Filetype filetype = new Filetype();
            filetype._fileType = fileDetails.FileType;

            if (!Node.TryGetValue(filetype, out FileDetails fileDetails1))
            {
                fileDetails1 = new();
                Node.TryAdd(filetype, fileDetails1);
            }
            CacheUpdateHelper.UpdateObjectReference(fileDetails, fileDetails1);
        }
        public (bool, FileDetails) Get(int fileType)
        {
            Filetype filetype = new Filetype();
            filetype._fileType = fileType;

            if (Node.TryGetValue(filetype, out FileDetails fileDetails) && fileDetails != null)
            {
                return (true, fileDetails);
            }
            return (false, null);
        }
    }
    public struct SegmentId
    {
        public int _segmentId { get; set; }
        public int _filetype { get; set; }
    }
    public class FileDetails
    {
        public int SegmentId { get; set; }
        public int FileType { get; set; }
        public string FilePath { get; set; }
        public string Source { get; set; }
        public int VersionNo { get; set; }
        public int LastNoOfRecords { get; set; }
        public int FileSizeInBytes { get; set; }
        public int FileRefreshFrequency { get; set; }
        public DateTime dtmFileLastuploadTime { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string Remark { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }

        public FileSystemWatcher watcher;

        public bool isFileUploadAck { get; set; }
    }
    public struct Filetype
    {
        public int _fileType { get; set; }
    }
}
