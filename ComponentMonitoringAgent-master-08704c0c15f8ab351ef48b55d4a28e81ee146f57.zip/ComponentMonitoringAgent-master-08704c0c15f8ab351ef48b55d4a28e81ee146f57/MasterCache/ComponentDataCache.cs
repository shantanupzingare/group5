﻿using AgentWorker.Models.Response;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.CacheManagement.Helper;
using System.Collections.Concurrent;

namespace AgentWorker.MasterCache
{
    public class ComponentDataCache
    {
        private ConcurrentDictionary<ComponentIdentifier, InstanceWiseCache> componentWiseDix;
        public ComponentDataCache()
        {
            componentWiseDix = new ConcurrentDictionary<ComponentIdentifier, InstanceWiseCache>();
        }
        public void AddOrUpdate(ComponentInfoData compDetails)
        {
            ComponentIdentifier compId = new(compDetails.ComponentType);

            if (!componentWiseDix.TryGetValue(compId, out InstanceWiseCache instanceWiseCache))
            {
                instanceWiseCache = new();
                componentWiseDix.TryAdd(compId, instanceWiseCache);
            }
            instanceWiseCache.AddOrUpdate(compDetails);
        }

        public (Response, ComponentInfoData?) Get(int componentId, int instanceId)
        {
            Response response = new();
            try
            {
                if(componentWiseDix.TryGetValue(new ComponentIdentifier(componentId), out var instanceWiseCache) && instanceWiseCache != null)
                {
                    return instanceWiseCache.Get(instanceId);
                }
                response.Set(StatusCode.Failure, "Component info not found in component wise dictionary");
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, $"Exception occured while fetching component wise info | {ex}");
            }
            return (response, null);
		}
    }

    public class InstanceWiseCache
    {
        private ConcurrentDictionary<CTCL_ComponentInstanceIdentifier, ComponentInfoData> instanceWiseDic;
        public InstanceWiseCache()
        {
            instanceWiseDic = new ConcurrentDictionary<CTCL_ComponentInstanceIdentifier, ComponentInfoData>();
        }
        public void AddOrUpdate(ComponentInfoData compDetails)
        {
            CTCL_ComponentInstanceIdentifier instanceId = new(compDetails.InstanceId);

            if (!instanceWiseDic.TryGetValue(instanceId, out ComponentInfoData compDetails1))
            {
                compDetails1 = new();
                instanceWiseDic.TryAdd(instanceId, compDetails1);
            }
            CacheUpdateHelper.UpdateObjectReference(compDetails, compDetails1);
        }

        public (Response,ComponentInfoData?) Get(int instanceId)
        {
            Response response = new();
            try
            {
                if(instanceWiseDic.TryGetValue(new CTCL_ComponentInstanceIdentifier(instanceId), out var  componentInfoData) && componentInfoData != null)
                {
                    response.Set(StatusCode.Success, "");
                    return (response, componentInfoData);
                }
                else
                {
                    response.Set(StatusCode.Failure, "Component info not found");
                }
            }
            catch (Exception ex)
            {
                response.Set(StatusCode.Failure, $"Exception occured while fetching component info | {ex}");
            }

            return (response, null);
        }
	}
}
