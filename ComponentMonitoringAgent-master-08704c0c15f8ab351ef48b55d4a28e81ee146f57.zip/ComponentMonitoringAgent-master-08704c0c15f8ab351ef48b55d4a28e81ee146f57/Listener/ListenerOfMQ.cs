﻿using AgentWorker.Core;
using AgentWorker.Global;
using AgentWorker.MasterCache;
using AgentWorker.Models.Response;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Commons;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using CTCL.BinaryProtocol.Common.CMA.Response;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Request;
using CTCL.CacheManagement.ComponentSessionManager;
using CTCL.Utility;
using MQueue;
using Utility;
using ComponentInfo = BinaryProtocol.Common.ComponentInfo;
using InstanceMaster = BinaryProtocol.Common.InstanceMaster;

namespace AgentWorker.Listener
{
    public class ListenerOfMQ
    {
        private Conversion conversion;
        private Compression compression;
        private Queue<byte[]> datafromMQ;
        private MQConfiguration mqConfig;
        private MQConsumer mqConsumer;
        private MQPublisher mqPublisher;
        private string queueName;
        private ushort prefetchCount;
        private string exchangeName;
        private int instanceId;
        private ComponentSession componentSession;

        private Dictionary<string, ComponentInfo> sourceInfo; //ComponenId|InstanceId
        private ComponentType sourceComponentType;
        private InstanceMaster instanceMaster;

        public ListenerOfMQ(QueueConfiguration queueConfig)
        {
            sourceInfo = new Dictionary<string, ComponentInfo>();
            compression = new Compression(0);
            var resp = compression.Initialize();
            if (resp.StatusCode != StatusCode.Success)
            {
                Log.Error(resp, "----ListenerOfMQ ---- compression ---");
                throw new Exception(resp.Message);
            }
            datafromMQ = new Queue<byte[]>();
            prefetchCount = Config.prefetchCount;
            conversion = new Conversion();

            mqConfig = new MQConfiguration
            {
                HostName = new MQHostName { hostname = queueConfig.HostName },
                Password = new MQPassword { password = queueConfig.PassWord },
                Port = new MQPort { port = queueConfig.Port },
                UserName = new MQUserName { username = queueConfig.UserName },
                VirtualHost = new MQVirtualHost { virtualhost = queueConfig.VirtualHost },
                LogFilePath = new MQLogFilePath { filepath = Config.logfile.Replace("\\AgentWorker\\", "\\AgentWorker\\MQ\\") },
                Component = ComponentType.MailSender,
                ExchangeName = new MQExchangeName { exchangename = queueConfig.ExchangeName },
                QueueName = new MQQueueName { queuename = queueConfig.MQName },
            };
            queueName = queueConfig.MQName;
            exchangeName = queueConfig.ExchangeName;
        }

        public Response AddSource(ComponentInfo componentInfo)
        {
            Response response = new Response();
            sourceComponentType = componentInfo.ComponentType;
            instanceId = componentInfo.InstanceId;
            var key = componentInfo.ComponentType + "|" + componentInfo.InstanceId;
            if (!sourceInfo.ContainsKey(key))
            {
                sourceInfo.Add(key, componentInfo);
                return response.Set(StatusCode.Success, "Added Sucessfully.");
            }
            return response.Set(StatusCode.Failure, "Already Exist.");
        }
        public Response Initialize(bool IsAutoAck = true)
        {
            Response response = new Response();
            try
            {
                if (prefetchCount > 0)
                {
                    mqConsumer = new MQConsumer(mqConfig, MqConsumer_evtMessageRecieverEvent, true);
                    response = mqConsumer.ConsumeMQ(IsAutoAck, prefetchCount);
                }
                else
                {
                    mqConsumer = new MQConsumer(mqConfig, MqConsumer_evtMessageRecieverEvent);
                    response = mqConsumer.ConsumeMQ(IsAutoAck);
                }

                if (response.StatusCode != StatusCode.Success)
                {
                    Log.Error(response.Message, "Couldn't Intilize Consumer.");
                    return response.Set(StatusCode.Failure, "Couldn't Intilize Consumer.", mqConfig);
                }

                Log.Debug(response.Message, "MQ Consumer Connected Successfully");
                return response.Set(StatusCode.Success, "MQ Consumer Connected Successfully", mqConfig);
            }
            catch (Exception ex)
            {
                Log.Error(StatusCode.Failure, "MQ Consumer Connection Failed. Error :" + ex.Message);
                return response.Set(StatusCode.Failure, "MQ Consumer Connection Failed. Error :" + ex.ToString());
                //logs
            }
        }
        private void MqConsumer_evtMessageRecieverEvent(ReadOnlyMemory<byte> message, ulong delieveryTag)
        {
            if (message.Length > 0)
            {
                try
                {
                    Log.Info("Writing in the file");
                    PreDeCompressMsgAndSend(message.ToArray());
                }
                catch (Exception ex)
                {
                    Log.Error(null, "Exception occured while writing in file" + ex.Message);
                }
            }
            else
            {
                Log.Error(null, "Message null in mqconsumer");
            }
        }
        private byte[] PreAllocBuffer = new byte[16384];
        private byte[] GetCompressBytesFromMessage(byte[] data)
        {
            var compressBytesRes = compression.Compress(data);
            if (compressBytesRes.StatusCode == StatusCode.Success)
            {
                return (byte[])compressBytesRes.ExtraInfo;
            }
            else
            {
                Log.Error("Failed to compress." + compressBytesRes.Message);
                return null;
            }

        }
        public Response AddInstanceMaster(InstanceMaster instanceMaster)
        {
            Response response = new Response();
            this.instanceMaster = instanceMaster;
            return response.Set(StatusCode.Success, "Added Sucessfully.");
        }
        public void PreDeCompressMsgAndSend(byte[] message)
        {
            try
            {
                var unCompressesBytesRes = compression.Decompress(message);
                if (unCompressesBytesRes.StatusCode == StatusCode.Success)
                {
                    var unCompressesBytes = (byte[])unCompressesBytesRes.ExtraInfo;
                    int counter = unCompressesBytes.Length;
                    int index = 0;
                    while (counter != 0)
                    {
                        //Take length;
                        var length = BitConverter.ToInt32(unCompressesBytes, index);
                        counter = counter - sizeof(int);
                        index = index + sizeof(int);
                        var byteMsg = new byte[length];
                        Buffer.BlockCopy(unCompressesBytes, index, byteMsg, 0, length);

                        counter = counter - length;
                        index = index + length;

                        var opcode = BitConverter.ToInt16(byteMsg, 0);
                        bool isHandshakeOpcode = HandleComponentHandshake(opcode, byteMsg);
						if (!isHandshakeOpcode)
						{

                            Log.Info($"Message Recevied from {sourceComponentType}");
							switch (sourceComponentType)
							{
                                case ComponentType.CONTRACT_MASTER_READER:
                                    ProcessContractMasterResponse(opcode, byteMsg);
									break;
                                default :
									// handle component status for all components
									ProcessOMSResponse(opcode, byteMsg);
									break;
							}
						}
					}
                }
                else
                {
                    Log.Error(null, $"Unable to compress message {unCompressesBytesRes.Message}");
                }
            }
            catch (Exception ex)
            {
                Log.Error(null, "Exception occured while processing meaage from mq consumer" + ex.Message);

            }

        }
        public (ComponentType, int) GetComponentInfo()
        {
            return (sourceComponentType, instanceId);
        }
        public Response AddComponentSession(ComponentSession componentSession)
        {
            Response response = new Response();
            this.componentSession = componentSession;
            return response.Set(StatusCode.Success, "Added Sucessfully.");
        }
        private bool HandleComponentHandshake(short opcode, byte[] byteMsg)
        {
            bool isHandshakeOpcode = false;
            switch ((CTCL_OpCode)opcode)
            {
                case CTCL_OpCode.HeartBeat:
                    {
                        isHandshakeOpcode = true;
                        if (componentSession != null)
                        {
                            var heartBeat = conversion.FromBytesToObject<CTCL_Heartbeat_Req>(byteMsg);
                            componentSession.lastHearBeatRecevieTime = heartBeat.MessageHeader.TimeStamp.TimeStamp;
                        }

                    }
                    break;
                case CTCL_OpCode.COMPONENT_STATUS_UPDATE:
                    isHandshakeOpcode = true;
                    if (componentSession != null)
                    {
                        var statusUpdate = conversion.FromBytesToObject<CTCL_Heartbeat_Req>(byteMsg);
                        componentSession.componentHandshake = statusUpdate.ComponentHandshakeStatus;
                        if (componentSession.componentHandshake == ComponentHandshakeStatus.READY_TO_ROUTE)
                        {
                            Log.Info($"Component {componentSession.ComponentType} is connected");
       //                     if(!CoreProcess.GetIsRunning(componentSession.ComponentType, instanceId))
       //                     {
							//	CoreProcess.SetExistingProcess(componentSession.ComponentType, instanceId);
       //                         // If the component is stopped and user manually restart it than in this case is attact the process 
							//}
                        }
                        //SendComponentStatus(statusUpdate.MessageHeader, statusUpdate.ComponentHandshakeStatus);
                    }
                    break;

                default:
                    break;
            }
            return isHandshakeOpcode;
        }

        private void ProcessContractMasterResponse(short opcode, byte[] byteMsg)
        {
			switch ((CTCL_OpCode)opcode)
			{
				case CTCL_OpCode.FILE_UPLOAD_START_ACKNOWLEDGEMENT:
                    var fileStartRequest = conversion.FromBytesToObject<CMA_FileUploadResponse>(byteMsg);
                    var feReq = ConvertFileUploadResponse(fileStartRequest);
                    if (feReq.Item1)
                    {
                        CoreProcess.wsClientManager.Enqueue(feReq.Item2);
                    }
                    break;
				case CTCL_OpCode.FILE_UPLOAD_END_ACKNOWLEDGEMENT:
					var fileEndRequest = conversion.FromBytesToObject<CMA_FileUploadResponse>(byteMsg);
					var feEndReq = ConvertFileUploadResponse(fileEndRequest);
                    if (feEndReq.Item1)
                    {
                        CoreProcess.wsClientManager.Enqueue(feEndReq.Item2);
                    }
                    break;
                case CTCL_OpCode.CMA_COMPONENT_STATUS:
                    {
                        ProcessOMSResponse(opcode, byteMsg);
                    }
                    break;
				default:
					break;
			}
		}

        private (bool,FileStatus) ConvertFileUploadResponse(CMA_FileUploadResponse fileupload)
        {
            var fileName = string.Empty;
            var res = CoreProcess.filePathInfo.Where(x => x.Segment == fileupload.SegmentId.SegmentId && x.FileType == fileupload.FileType.id).FirstOrDefault();
            if(res == null)
            {
                Log.Error($"Could not find file info for segment {fileupload.SegmentId.SegmentId} and file type {fileupload.FileType.id}");
                return (false, null);
            }
            //         var res = CoreProcess.fileDataCache.Get(fileupload.SegmentId.SegmentId, fileupload.FileType.id);
   //         if (res.Item1)
   //         {
   //             fileName = res.Item2.Remark;
			//}

			FileStatus fileStatus = new();
            fileStatus.MessageCode = (int)CMA_OpCode.FILE_UPLOAD_CONFIRMATION;
            fileStatus.BrokerId = Config.BrokerId;
            fileStatus.SiteId = Config.SiteId;
            fileStatus.AgentId = Config.AgentWorkerId;
            fileStatus.FileName = res.FileName;
            fileStatus.FileType = fileupload.FileType.id;
            fileStatus.Segment = fileupload.SegmentId.SegmentId;
            fileStatus.IsSucessStatus = fileupload.StatusCode == StatusCode.Success ? true : false;
            fileStatus.Message = fileupload.StatusMessage.Message.ToTruncateEndString();
            fileStatus.TimeStamp = fileupload.TimeStamp.TimeStamp.ToCTCLDateTime();

            for(int i=0; i<CoreProcess.filePathInfo.Count; i++)
            {
                if (CoreProcess.filePathInfo[i].FileType == fileupload.FileType.id
                    && CoreProcess.filePathInfo[i].Segment == fileupload.SegmentId.SegmentId)
                {
                    if (fileupload.MessageHeader.OpCode == CTCL_OpCode.FILE_UPLOAD_END_ACKNOWLEDGEMENT)
                    {
                        CoreProcess.filePathInfo[i].IsFileUploadAck = true;
                    }
                    
                }
            }

            return (true,fileStatus);
		}
        private void ProcessOMSResponse(short opcode, byte[] byteMsg)
        {
            switch ((CTCL_OpCode)opcode)
            {
                case CTCL_OpCode.CMA_COMPONENT_STATUS:
                    {
                        var componentUpdate = conversion.FromBytesToObject<CMA_COMPONENT_MESSAGE_UPDATE>(byteMsg);
                        if(componentUpdate != null)
                        {
                            var resp = Helper.Helper.PrepareComponentStatus(componentUpdate.MessageHeader.SourceComponentIdentifier.ComponentId,
                                componentUpdate.MessageHeader.SourceComponentInstance.ComponentInstanceId,
                                (int)componentUpdate.SuccessFailureFlag, componentUpdate.ResponseString.Message.ToTruncateEndString(),
                                componentUpdate.RequestID.RequestId.ToTruncateEndString());
                            if (componentUpdate.SuccessFailureFlag == CMA_StatusCode.Completed)
                            {
                                CoreProcess.SetIsRunning((ComponentType)componentUpdate.MessageHeader.SourceComponentIdentifier.ComponentId, componentUpdate.MessageHeader.SourceComponentInstance.ComponentInstanceId, true);
                            }
                            CoreProcess.wsClientManager.Enqueue(resp);
                        }
                    }
                    break;
            }
        }
    }
}
