namespace AgentWorker
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IHost host = Host.CreateDefaultBuilder(args)
            .UseWindowsService(config =>
            {
                config.ServiceName = "AgentWorker";
            })
            .ConfigureServices(services =>
            {
                services.AddHostedService<Worker>(services => new Worker());
                //services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            })
            .Build();
            host.Run();
        }
    }
}