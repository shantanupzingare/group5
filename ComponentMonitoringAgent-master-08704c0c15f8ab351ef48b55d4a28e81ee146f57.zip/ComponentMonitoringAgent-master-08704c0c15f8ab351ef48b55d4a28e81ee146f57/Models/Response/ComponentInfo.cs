﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Response
{
    public class ComponentInfo : MsgHeader
    {
        [JsonProperty("data")]
        public List<ComponentInfoData> Data { get; set; }
    }

    public class ComponentInfoData
    {
        [JsonProperty("componentType")]
        public int ComponentType { get; set; }

        [JsonProperty("instanceId")]
        public int InstanceId { get; set; }

        [JsonProperty("executablePath")]
        public string ExecutablePath { get; set; }

        [JsonProperty("cmdParameters")]
        public string CmdParameters { get; set; }

		[JsonProperty("serviceName")]
		public string ServiceName { get; set; }

		[JsonProperty("priority")]
		public int Priority { get; set; }
    }
}
