﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Response
{
    public class ComponentStatus : StatusMessage
    {
        [JsonProperty("componentType")]
        public int ComponentType { get; set; }

        [JsonProperty("instanceId")]
        public int InstanceId { get; set; }

        [JsonProperty("componentState")]
        public int ComponentState { get; set; }

        [JsonProperty("timeStamp")]
        public DateTime TimeStamp { get; set; }

        [JsonProperty("requestId")]
        public string RequestId { get; set; }
    }
}
