﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Response
{
	public class ComponentTechincalInfo : MsgHeader
	{
		[JsonProperty("componentType")]
		public int ComponentType { get; set; }

		[JsonProperty("instanceId")]
		public int InstanceId { get; set; }

		[JsonProperty("cPUPercentage")]
		public double CPUPercentage { get; set; }
		[JsonProperty("rAMUsage")]
		public double RAMUsage { get; set; }

        [JsonProperty("timeStamp")]
        public DateTime TimeStamp { get; set; }
    }
}
