﻿using AgentWorker.Models.Others;
using CTCL.BinaryProtocol.Common.CMA.Commons;
using Newtonsoft.Json;

namespace AgentWorker.Models.Response
{
    public class FileStatus : StatusMessage
    {
        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("segment")]
        public int Segment { get; set; }

        [JsonProperty("fileType")]
        public int FileType { get; set; }

		[JsonProperty("timeStamp")]
		public DateTime TimeStamp { get;set; }

    }
}
