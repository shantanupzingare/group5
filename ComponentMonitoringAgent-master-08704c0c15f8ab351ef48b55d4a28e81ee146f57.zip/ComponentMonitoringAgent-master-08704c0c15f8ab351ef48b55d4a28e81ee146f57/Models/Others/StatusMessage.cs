﻿using Newtonsoft.Json;

namespace AgentWorker.Models.Others
{
    public class StatusMessage : MsgHeader
    {
        [JsonProperty("isSucessStatus")]
        public bool IsSucessStatus { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }
    }
}
