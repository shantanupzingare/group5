﻿using AgentWorker.Global;
using Newtonsoft.Json;

namespace AgentWorker.Models.Others
{
    public class MsgHeader
    {
        [JsonProperty("messageCode")]
        public int MessageCode { get; set; }

        [JsonProperty("brokerId")]
        public int BrokerId { get; set; }

        [JsonProperty("siteId")]
        public int SiteId { get; set; }

        [JsonProperty("agentId")]
        public int AgentId { get; set; }

        public MsgHeader()
        {
            BrokerId = Config.BrokerId;
            SiteId = Config.SiteId;
            AgentId = Config.AgentWorkerId;
		}

		public MsgHeader(int messageCode)
		{
            MessageCode = messageCode;
			BrokerId = Config.BrokerId;
			SiteId = Config.SiteId;
			AgentId = Config.AgentWorkerId;
		}
	}
}
