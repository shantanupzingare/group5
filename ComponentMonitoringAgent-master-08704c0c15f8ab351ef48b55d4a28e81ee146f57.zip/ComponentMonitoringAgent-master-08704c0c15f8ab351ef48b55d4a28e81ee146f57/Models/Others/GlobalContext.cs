﻿using System.Net.WebSockets;

namespace AgentWorker.Models.Others
{
    public class GlobalContext
    {

        ClientWebSocket clientWeb = new ClientWebSocket();
        public static string pIdServiceName;
        public static string paramId;
        public static Uri uriContext;
    }
}
