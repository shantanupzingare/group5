﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Request
{
    public class LoginRequest : MsgHeader
    {
        [JsonProperty("brokerId")]
        public int BrokerId { get; set; }

        [JsonProperty("siteId")]
        public int SiteId { get; set; }

        [JsonProperty("agentId")]
        public int AgentId { get; set; }
    }
}
