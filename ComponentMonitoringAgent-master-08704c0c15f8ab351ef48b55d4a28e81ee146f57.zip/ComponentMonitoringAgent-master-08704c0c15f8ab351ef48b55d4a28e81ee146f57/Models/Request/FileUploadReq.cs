﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Request
{
    public class FileUploadReq : MsgHeader
	{
		[JsonProperty("requestId")]
		public string RequestId { get; set; }
	}
}
