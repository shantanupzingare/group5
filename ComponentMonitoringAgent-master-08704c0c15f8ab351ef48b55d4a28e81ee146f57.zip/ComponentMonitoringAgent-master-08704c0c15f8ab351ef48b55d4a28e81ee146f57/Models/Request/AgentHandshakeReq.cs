﻿using AgentWorker.Models.Others;
using Newtonsoft.Json;

namespace AgentWorker.Models.Request
{
    public class AgentHandshakeReq : MsgHeader
    {
        [JsonProperty("ip")]
        public string IP { get; set; }
    }
}
