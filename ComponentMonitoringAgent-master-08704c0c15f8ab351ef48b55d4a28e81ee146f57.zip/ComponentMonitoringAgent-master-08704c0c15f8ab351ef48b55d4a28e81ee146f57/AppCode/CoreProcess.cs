﻿using BinaryProtocol.Common;
using Exchange.Logs;
using TradingAPI.Core.Services;
using TradingAPI.Core.Services.Interface;
using TradingAPI.Global;
using TradingAPI.TransactionInfo;

namespace TradingAPI.Core
{
    public class CoreProcess
    {
        public static Response response;
        private static LogProcessor logProcessor;
        public static WebSocketIdWiseSession webSocketIdWiseSession;


        public static Response Initialize(IClient client)
        {
            response = new();

            LogConfiguration logConfiguration = new LogConfiguration
            {
                FilesizeLimitBytes = 50000000,
                LogFileNameWithPath = Config.logfile,
                LoggingLevelSwitch = new Serilog.Core.LoggingLevelSwitch
                {
                    MinimumLevel = Config.logLevel == 0 ? Serilog.Events.LogEventLevel.Debug : (Serilog.Events.LogEventLevel)Config.logLevel,
                },
                OutputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}",
                RetainedFileCount = Config.logFileCount,
                RollingInterval = Serilog.RollingInterval.Day,
                RollOnFileSizeLimit = true,
            };

            LogType logType = (LogType)Config.logLevel;

            if (logProcessor == null)
            {
                logProcessor = new LogProcessor(logConfiguration);
            }

            webSocketIdWiseSession = new();
            return new Response()
            {
                Message = ""
            };
        }

        public static Response SendToLogQueue(LogObject data)
        {
            if (!data.Equals(default(LogObject)) && logProcessor != null)
            {
                return logProcessor.Enqueue(data);
            }
            else if (logProcessor == null)
            {
                Global.Log.Error(null, "logProcessor is null");
                return response.Set(StatusCode.OMS_Failure, "logProcessor is null");
            }
            else
            {
                Global.Log.Error(null, "SendToLogQueue data is null");
                return response.Set(StatusCode.OMS_Failure, "data is null");
            }
        }
    }
}
