﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL;
using CTCL.Utility;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using MarketAPI.Models.Response;
using MarketAPI.Global;
using CTCL.Utility.EncryptionAlgorithms;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Request;
using MarketAPI.Models.Binary;
using MarketAPI.Common.Structs;
using Utility;

namespace MarketAPI.Core
{
    public class Helper
    {
        private static Conversion conversion;

        static Helper()
        {
            conversion = new();
        }

        public static string SerializeObject(object obj)
        {
            try
            {
                return JsonConvert.SerializeObject(obj);
            }
            catch (Exception ex)
            {
                return "Error in serialize :" + ex.Message;
            }

        }

        public static bool ValidateRequestSize<T>(byte[] reqData)
        {
            var actualSize = Marshal.SizeOf(typeof(T));
            var size = reqData.Length;
            if (actualSize == size)
            {
                return true;
            }
            else
            {
                Log.Error(reqData, "Request size is invalid!");
                return false;
            }
        }

        public static (bool, string) GenerateToken(string clientName)
        {
            try
            {
                CTCL_STRTerminalID clientId = new(clientName.ToCharArray());

                if (ApiClientInfo.tokenWiseDict.TryGetValue(clientId, out CTCL_STRTerminalID value))
                {
                    return new(false, "User already logged in");
                }

                string secretKey = Config.JwtSecretKey;

                var claims = new[]
                {
                    new Claim(ClaimTypes.Name, clientName)
                };

                var key = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Convert.FromBase64String(secretKey));

                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(issuer: "Api", audience: "User", claims: claims, expires: DateTime.UtcNow.AddHours(24), signingCredentials: creds);

                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenString = tokenHandler.WriteToken(token);

                var encryptedToken = TripleDESEncryptionLib.Encrypt(tokenString);

                ApiClientInfo.AddOrUpdate(encryptedToken, clientName);

                return (true, encryptedToken);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return (false, "Error occurred while generating token");
            }
        }

        public static string DecodeToken(string encryptedToken)
        {
            try
            {
                var jwtToken = TripleDESEncryptionLib.Decrypt(encryptedToken);

                JwtSecurityTokenHandler tokenHandler = new();
                JwtSecurityToken jwtSecurityToken = tokenHandler.ReadJwtToken(jwtToken);

                if (jwtSecurityToken != null)
                {
                    // Access specific claims by their type
                    string clientId = jwtSecurityToken.Claims.FirstOrDefault(claim => claim.Type == ClaimTypes.Name)?.Value;
                    CTCL_STRTerminalID strCLientId = new(clientId.ToCharArray());

                    if (jwtSecurityToken.ValidTo > DateTime.UtcNow)
                    {
                        if (!string.IsNullOrEmpty(clientId))
                        {
                            CTCL_STRTerminalID clientID = new(clientId.ToCharArray());
                            if (ApiClientInfo.tokenWiseDict.TryGetValue(clientID, out CTCL_STRTerminalID cTCL_STRTerminalID))
                            {
                                return clientId;
                            }
                        }
                    }
                    else if (ApiClientInfo.tokenWiseDict.TryGetValue(strCLientId, out CTCL_STRTerminalID token))
                    {
                        ApiClientInfo.tokenWiseDict.TryRemove(strCLientId, out token);
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return null;
            }
        }

        public static string GenerateSecretKey()
        {
            string key = Guid.NewGuid().ToString();
            var secretKey = TripleDESEncryptionLib.Encrypt(key);
            return secretKey;
        }

        public static Response ExpireToken(string clientId)
        {
            Response response = new();
            CTCL_STRTerminalID clientID = new(clientId.ToCharArray());

            if (ApiClientInfo.tokenWiseDict.TryGetValue(clientID, out CTCL_STRTerminalID token))
            {
                ApiClientInfo.tokenWiseDict.Remove(clientID, out CTCL_STRTerminalID cTCL_STRTerminalID);
            }
            return response.Set(BinaryProtocol.Common.StatusCode.Success, "successfully logout from all API.");
        }

        public static CTCL_MessageHeader PrepareMessageHeader<T>(CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode opCode, int desComponentIdentifier, CTCL_ExchangeSegmentId exchangeSegmentId)
        {
            var time = DateTime.Now.ToCTCLEpoch();
            return PrepareMessageHeader<T>(opCode, desComponentIdentifier, exchangeSegmentId, new CTCL_TimeStamp(time));

        }
        public static CTCL_MessageHeader PrepareMessageHeader<T>(CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode opCode, int desComponentIdentifier, CTCL_ExchangeSegmentId exchangeSegmentId, CTCL_TimeStamp timeStamp)
        {
            CTCL_MessageHeader messageHeader = new();
            messageHeader.OpCode = opCode;
            messageHeader.TimeStamp.TimeStamp = timeStamp.TimeStamp;
            messageHeader.MessageLength.Messagelength = Marshal.SizeOf(typeof(T));
            messageHeader.SourceComponentIdentifier.ComponentId = (int)ComponentType.MarketApi;
            messageHeader.DestinationComponentIdentifier.ComponentId = desComponentIdentifier;
            messageHeader.ExchangeSegmentId = exchangeSegmentId;

            return messageHeader;
        }

        public static ResponseData PrepareResponseData(string type, string code, string description)
        {
            ResponseData responseData = new()
            {
                Type = type,
                Code = code,
                Description = description
            };
            return responseData;
        }

        public static double ConvertPaiseToRupees(long value)
        {
            return value / Math.Pow(10, Config.DecimalLocator);
        }
        public static long ConvertRupeesToPaise(int value)
        {
            return Convert.ToInt64(value * Math.Pow(10, Config.DecimalLocator));
        }

        public static long ToUnixEpoxTime(DateTimeOffset dateTime)
        {
            return dateTime.ToUnixTimeSeconds() - 315460800;
        }

        public static CTCL_LOGIN_REQ PrepareLoginReq(string userId, string pass)
        {
            CTCL_LOGIN_REQ loginReq = new CTCL_LOGIN_REQ();
            loginReq.AuthDetails = new CTCL_AuthDetails();
            loginReq.AuthDetails.TerminalID = new CTCL_TerminalID(userId.ToCharArray());
            loginReq.AuthDetails.Password = new CTCL_Password(PasswordHelper.Encrypt(pass));
            loginReq.AuthDetails.sourceType = DeviceType.Windows;
            loginReq.AuthDetails.versionNumber = new("1.0.0.100".ToCharArray());
            loginReq.AuthDetails.encrKey = new("DSDK-SgjdlDkjfms-fwf".ToCharArray());

            CTCL_ExchangeSegmentId segmentId = new((int)CTCL_ExchangeIdentifier.NSE_CM);

            loginReq.MessageHeader = PrepareMessageHeader<CTCL_LOGIN_REQ>(CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode.LOGIN_REQ, (int)ComponentType.OMS, segmentId);
            return loginReq;
        }

        public static byte[] PrepareTLPacketData(Touchline touchline)
        {
            PacketData packetData = new();
            packetData.isGzipCompressed.GzipCompressed = 1;
            packetData.PacketSize.Size = (ushort)Marshal.SizeOf(typeof(Touchline));
            packetData.messageCode.Code = 1501;
            packetData.exchangeSegment = touchline.exchangeSegment;
            packetData.exchangeInstrumentID = touchline.exchangeInstrumentId;
            packetData.bookType = touchline.BookType;
            packetData.marketType = touchline.MarketType;
            packetData.CompressedPacketSize.compressedPacketSize = 0;
            packetData.UnCompressedPacketSize.unCompressedPacketSize = Marshal.SizeOf(typeof(Touchline));

            byte[] isGzipCompressedBytes = new byte[Marshal.SizeOf(typeof(IsGzipCompressed))];
            byte[] packetSizeBytes = new byte[Marshal.SizeOf(typeof(PacketSize))];
            byte[] messageCodeBytes = new byte[Marshal.SizeOf(typeof(MessageCode))];
            byte[] exchangeSegmentBytes = new byte[Marshal.SizeOf(typeof(ExchangeSegment))];
            byte[] exchangeInstrumentIDBytes = new byte[Marshal.SizeOf(typeof(ExchangeInstrumentId))];
            byte[] bookTypeBytes = new byte[Marshal.SizeOf(typeof(BookType))];
            byte[] marketTypeBytes = new byte[Marshal.SizeOf(typeof(Common.Structs.MarketType))];
            byte[] compressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(CompressedPacketSize))];
            byte[] unCompressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(UnCompressedPacketSize))];
            byte[] touchlineDataBytes = new byte[Marshal.SizeOf(typeof(Touchline))];

            byte[] data = new byte[isGzipCompressedBytes.Length + packetSizeBytes.Length + messageCodeBytes.Length + exchangeSegmentBytes.Length + exchangeInstrumentIDBytes.Length + bookTypeBytes.Length + marketTypeBytes.Length + compressedPacketSizeBytes.Length + unCompressedPacketSizeBytes.Length + touchlineDataBytes.Length];

            int offset = 0;

            isGzipCompressedBytes = conversion.GetBytesFromObject(packetData.isGzipCompressed);
            Buffer.BlockCopy(isGzipCompressedBytes, 0, data, offset, isGzipCompressedBytes.Length);
            offset += isGzipCompressedBytes.Length;

            packetSizeBytes = conversion.GetBytesFromObject(packetData.PacketSize);
            Buffer.BlockCopy(packetSizeBytes, 0, data, offset, packetSizeBytes.Length);
            offset += packetSizeBytes.Length;

            messageCodeBytes = conversion.GetBytesFromObject(packetData.messageCode);
            Buffer.BlockCopy(messageCodeBytes, 0, data, offset, messageCodeBytes.Length);
            offset += messageCodeBytes.Length;

            exchangeSegmentBytes = conversion.GetBytesFromObject(packetData.exchangeSegment);
            Buffer.BlockCopy(exchangeSegmentBytes, 0, data, offset, exchangeSegmentBytes.Length);
            offset += exchangeSegmentBytes.Length;

            exchangeInstrumentIDBytes = conversion.GetBytesFromObject(packetData.exchangeInstrumentID);
            Buffer.BlockCopy(exchangeInstrumentIDBytes, 0, data, offset, exchangeInstrumentIDBytes.Length);
            offset += exchangeInstrumentIDBytes.Length;

            bookTypeBytes = conversion.GetBytesFromObject(packetData.bookType);
            Buffer.BlockCopy(bookTypeBytes, 0, data, offset, bookTypeBytes.Length);
            offset += bookTypeBytes.Length;

            marketTypeBytes = conversion.GetBytesFromObject(packetData.marketType);
            Buffer.BlockCopy(marketTypeBytes, 0, data, offset, marketTypeBytes.Length);
            offset += marketTypeBytes.Length;

            compressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.CompressedPacketSize);
            Buffer.BlockCopy(compressedPacketSizeBytes, 0, data, offset, compressedPacketSizeBytes.Length);
            offset += compressedPacketSizeBytes.Length;

            unCompressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.UnCompressedPacketSize);
            Buffer.BlockCopy(unCompressedPacketSizeBytes, 0, data, offset, unCompressedPacketSizeBytes.Length);
            offset += unCompressedPacketSizeBytes.Length;

            touchlineDataBytes = conversion.GetBytesFromObject(touchline);
            Buffer.BlockCopy(touchlineDataBytes, 0, data, offset, touchlineDataBytes.Length);

            return data;
        }

        public static byte[] PrepareMarketDepthPacketData(MarketDepth marketDepth)
        {
            byte[] marketDepthDataBytesRes = getByteDataFromBCASTObject(marketDepth);

            PacketData packetData = new();
            packetData.isGzipCompressed.GzipCompressed = 1;
            packetData.PacketSize.Size = (ushort)marketDepthDataBytesRes.Length;
            packetData.messageCode.Code = 1502;
            packetData.exchangeSegment = marketDepth.exchangeSegment;
            packetData.exchangeInstrumentID = marketDepth.exchangeInstrumentId;
            packetData.bookType = marketDepth.bookType;
            packetData.marketType = marketDepth.marketType;
            packetData.CompressedPacketSize.compressedPacketSize = 0;
            packetData.UnCompressedPacketSize.unCompressedPacketSize = (ushort)marketDepthDataBytesRes.Length;

            byte[] isGzipCompressedBytes = new byte[Marshal.SizeOf(typeof(IsGzipCompressed))];
            byte[] packetSizeBytes = new byte[Marshal.SizeOf(typeof(PacketSize))];
            byte[] messageCodeBytes = new byte[Marshal.SizeOf(typeof(MessageCode))];
            byte[] exchangeSegmentBytes = new byte[Marshal.SizeOf(typeof(ExchangeSegment))];
            byte[] exchangeInstrumentIDBytes = new byte[Marshal.SizeOf(typeof(ExchangeInstrumentId))];
            byte[] bookTypeBytes = new byte[Marshal.SizeOf(typeof(BookType))];
            byte[] marketTypeBytes = new byte[Marshal.SizeOf(typeof(Common.Structs.MarketType))];
            byte[] compressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(CompressedPacketSize))];
            byte[] unCompressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(UnCompressedPacketSize))];
            byte[] marketDepthDataBytes = new byte[marketDepthDataBytesRes.Length];

            byte[] data = new byte[isGzipCompressedBytes.Length + packetSizeBytes.Length + messageCodeBytes.Length + exchangeSegmentBytes.Length + exchangeInstrumentIDBytes.Length + bookTypeBytes.Length + marketTypeBytes.Length + compressedPacketSizeBytes.Length + unCompressedPacketSizeBytes.Length + marketDepthDataBytes.Length];

            int offset = 0;

            isGzipCompressedBytes = conversion.GetBytesFromObject(packetData.isGzipCompressed);
            Buffer.BlockCopy(isGzipCompressedBytes, 0, data, offset, isGzipCompressedBytes.Length);
            offset += isGzipCompressedBytes.Length;

            packetSizeBytes = conversion.GetBytesFromObject(packetData.PacketSize);
            Buffer.BlockCopy(packetSizeBytes, 0, data, offset, packetSizeBytes.Length);
            offset += packetSizeBytes.Length;

            messageCodeBytes = conversion.GetBytesFromObject(packetData.messageCode);
            Buffer.BlockCopy(messageCodeBytes, 0, data, offset, messageCodeBytes.Length);
            offset += messageCodeBytes.Length;

            exchangeSegmentBytes = conversion.GetBytesFromObject(packetData.exchangeSegment);
            Buffer.BlockCopy(exchangeSegmentBytes, 0, data, offset, exchangeSegmentBytes.Length);
            offset += exchangeSegmentBytes.Length;

            exchangeInstrumentIDBytes = conversion.GetBytesFromObject(packetData.exchangeInstrumentID);
            Buffer.BlockCopy(exchangeInstrumentIDBytes, 0, data, offset, exchangeInstrumentIDBytes.Length);
            offset += exchangeInstrumentIDBytes.Length;

            bookTypeBytes = conversion.GetBytesFromObject(packetData.bookType);
            Buffer.BlockCopy(bookTypeBytes, 0, data, offset, bookTypeBytes.Length);
            offset += bookTypeBytes.Length;

            marketTypeBytes = conversion.GetBytesFromObject(packetData.marketType);
            Buffer.BlockCopy(marketTypeBytes, 0, data, offset, marketTypeBytes.Length);
            offset += marketTypeBytes.Length;

            compressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.CompressedPacketSize);
            Buffer.BlockCopy(compressedPacketSizeBytes, 0, data, offset, compressedPacketSizeBytes.Length);
            offset += compressedPacketSizeBytes.Length;

            unCompressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.UnCompressedPacketSize);
            Buffer.BlockCopy(unCompressedPacketSizeBytes, 0, data, offset, unCompressedPacketSizeBytes.Length);
            offset += unCompressedPacketSizeBytes.Length;

            marketDepthDataBytes = marketDepthDataBytesRes;
            Buffer.BlockCopy(marketDepthDataBytes, 0, data, offset, marketDepthDataBytes.Length);

            return data;
        }

        public static byte[] getByteDataFromBCASTObject(MarketDepth marketDepth)
        {
            byte[] messageVersion = new byte[Marshal.SizeOf(typeof(PacketSize))];
            byte[] applicationType = new byte[Marshal.SizeOf(typeof(PacketSize))];
            byte[] tokenID = new byte[Marshal.SizeOf(typeof(TokenID))];
            byte[] sequenceNumber = new byte[Marshal.SizeOf(typeof(SequenceNumber))];
            byte[] SkipBytes = new byte[Marshal.SizeOf(typeof(SkipBytes))];
            byte[] exchangeSegment = new byte[Marshal.SizeOf(typeof(ExchangeSegment))];
            byte[] exchangeInstrumentId = new byte[Marshal.SizeOf(typeof(ExchangeInstrumentId))];
            byte[] exchangeTimestamp = new byte[Marshal.SizeOf(typeof(ExchangeTimestamp))];
            byte[] BidCount = new byte[Marshal.SizeOf(typeof(Size))];
            byte[] BidMarketDeptRowList = new byte[Marshal.SizeOf(typeof(MarketDepthRowInfo))];
            byte[] AskCount = new byte[Marshal.SizeOf(typeof(Size))];
            byte[] AskMarketDeptRowList = new byte[Marshal.SizeOf(typeof(MarketDepthRowInfo))];
            byte[] BidMarketDeptRow = new byte[Marshal.SizeOf(typeof(MarketDepthRowInfo))];
            byte[] AskMarketDeptRow = new byte[Marshal.SizeOf(typeof(MarketDepthRowInfo))];
            byte[] LastUpdateTime = new byte[Marshal.SizeOf(typeof(ExchangeTimestamp))];
            byte[] LastTradePrice = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] LastTradedQuantity = new byte[Marshal.SizeOf(typeof(TotalOrders))];
            byte[] totalBuyQuantity = new byte[Marshal.SizeOf(typeof(TotalQuantity))];
            byte[] totalSellQuantity = new byte[Marshal.SizeOf(typeof(TotalQuantity))];
            byte[] totalTradedQuantity = new byte[Marshal.SizeOf(typeof(TotalQuantity))];
            byte[] averageTradedPrice = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] lastTradedTime = new byte[Marshal.SizeOf(typeof(LastTradedTime))];
            byte[] percentChange = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] open = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] high = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] low = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] close = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] totalvaluetraded = new byte[Marshal.SizeOf(typeof(Price))];
            byte[] bbtotalbuy = new byte[Marshal.SizeOf(typeof(BuyBack))];
            byte[] bbtotalsell = new byte[Marshal.SizeOf(typeof(BuyBack))];
            byte[] bookType = new byte[Marshal.SizeOf(typeof(BookType))];
            byte[] marketType = new byte[Marshal.SizeOf(typeof(Common.Structs.MarketType))];

            byte[] data = new byte[messageVersion.Length + applicationType.Length + tokenID.Length + sequenceNumber.Length + SkipBytes.Length + exchangeSegment.Length + exchangeInstrumentId.Length + 
                exchangeTimestamp.Length + BidCount.Length + (BidMarketDeptRowList.Length * marketDepth.BidMarketDeptRowList.Count) + AskCount.Length + 
                (AskMarketDeptRowList.Length * marketDepth.AskMarketDeptRowList.Count) + BidMarketDeptRow.Length + AskMarketDeptRow.Length + LastUpdateTime.Length + LastTradePrice.Length +
                LastTradedQuantity.Length + totalBuyQuantity.Length + totalSellQuantity.Length + totalTradedQuantity.Length + averageTradedPrice.Length +
                lastTradedTime.Length + percentChange.Length + open.Length + high.Length + low.Length + close.Length + totalvaluetraded.Length + bbtotalbuy.Length + bbtotalsell.Length + bookType.Length + marketType.Length];
            int offset = 0;

            messageVersion = conversion.GetBytesFromObject(marketDepth.messageVersion);
            Buffer.BlockCopy(messageVersion, 0, data, offset, messageVersion.Length);
            offset += messageVersion.Length;

            applicationType = conversion.GetBytesFromObject(marketDepth.applicationType);
            Buffer.BlockCopy(applicationType, 0, data, offset, applicationType.Length);
            offset += applicationType.Length;

            tokenID = conversion.GetBytesFromObject(marketDepth.tokenID);
            Buffer.BlockCopy(tokenID, 0, data, offset, tokenID.Length);
            offset += tokenID.Length;

            sequenceNumber = conversion.GetBytesFromObject(marketDepth.sequenceNumber);
            Buffer.BlockCopy(sequenceNumber, 0, data, offset, sequenceNumber.Length);
            offset += sequenceNumber.Length;

            SkipBytes = conversion.GetBytesFromObject(marketDepth.SkipBytes);
            Buffer.BlockCopy(SkipBytes, 0, data, offset, SkipBytes.Length);
            offset += SkipBytes.Length;

            exchangeSegment = conversion.GetBytesFromObject(marketDepth.exchangeSegment);
            Buffer.BlockCopy(exchangeSegment, 0, data, offset, exchangeSegment.Length);
            offset += exchangeSegment.Length;

            exchangeInstrumentId = conversion.GetBytesFromObject(marketDepth.exchangeInstrumentId);
            Buffer.BlockCopy(exchangeInstrumentId, 0, data, offset, exchangeInstrumentId.Length);
            offset += exchangeInstrumentId.Length;

            exchangeTimestamp = conversion.GetBytesFromObject(marketDepth.exchangeTimestamp);
            Buffer.BlockCopy(exchangeTimestamp, 0, data, offset, exchangeTimestamp.Length);
            offset += exchangeTimestamp.Length;

            BidCount = conversion.GetBytesFromObject(marketDepth.BidCount);
            Buffer.BlockCopy(BidCount, 0, data, offset, BidCount.Length);
            offset += BidCount.Length;

            for(int i=0; i<marketDepth.BidMarketDeptRowList.Count; i++)
            {
                BidMarketDeptRowList = conversion.GetBytesFromObject(marketDepth.BidMarketDeptRowList[i]);
                Buffer.BlockCopy(BidMarketDeptRowList, 0, data, offset, BidMarketDeptRowList.Length);
                offset += BidMarketDeptRowList.Length;
            }

            AskCount = conversion.GetBytesFromObject(marketDepth.AskCount);
            Buffer.BlockCopy(AskCount, 0, data, offset, AskCount.Length);
            offset += AskCount.Length;

            for (int i=0; i<marketDepth.AskMarketDeptRowList.Count; i++)
            {
                AskMarketDeptRowList = conversion.GetBytesFromObject(marketDepth.AskMarketDeptRowList[i]);
                Buffer.BlockCopy(AskMarketDeptRowList, 0, data, offset, AskMarketDeptRowList.Length);
                offset += AskMarketDeptRowList.Length;
            }

            BidMarketDeptRow = conversion.GetBytesFromObject(marketDepth.BidMarketDeptRow);
            Buffer.BlockCopy(BidMarketDeptRow, 0, data, offset, BidMarketDeptRow.Length);
            offset += BidMarketDeptRow.Length;

            AskMarketDeptRow = conversion.GetBytesFromObject(marketDepth.AskMarketDeptRow);
            Buffer.BlockCopy(AskMarketDeptRow, 0, data, offset, AskMarketDeptRow.Length);
            offset += AskMarketDeptRow.Length;

            LastUpdateTime = conversion.GetBytesFromObject(marketDepth.LastUpdateTime);
            Buffer.BlockCopy(LastUpdateTime, 0, data, offset, LastUpdateTime.Length);
            offset += LastUpdateTime.Length;

            LastTradePrice = conversion.GetBytesFromObject(marketDepth.LastTradePrice);
            Buffer.BlockCopy(LastTradePrice, 0, data, offset, LastTradePrice.Length);
            offset += LastTradePrice.Length;

            LastTradedQuantity = conversion.GetBytesFromObject(marketDepth.LastTradedQuantity);
            Buffer.BlockCopy(LastTradedQuantity, 0, data, offset, LastTradedQuantity.Length);
            offset += LastTradedQuantity.Length;

            totalBuyQuantity = conversion.GetBytesFromObject(marketDepth.totalBuyQuantity);
            Buffer.BlockCopy(totalBuyQuantity, 0, data, offset, totalBuyQuantity.Length);
            offset += totalBuyQuantity.Length;

            totalSellQuantity = conversion.GetBytesFromObject(marketDepth.totalSellQuantity);
            Buffer.BlockCopy(totalSellQuantity, 0, data, offset, totalSellQuantity.Length);
            offset += totalSellQuantity.Length;

            totalTradedQuantity = conversion.GetBytesFromObject(marketDepth.totalTradedQuantity);
            Buffer.BlockCopy(totalTradedQuantity, 0, data, offset, totalTradedQuantity.Length);
            offset += totalTradedQuantity.Length;

            averageTradedPrice = conversion.GetBytesFromObject(marketDepth.averageTradedPrice);
            Buffer.BlockCopy(averageTradedPrice, 0, data, offset, averageTradedPrice.Length);
            offset += averageTradedPrice.Length;

            lastTradedTime = conversion.GetBytesFromObject(marketDepth.lastTradedTime);
            Buffer.BlockCopy(lastTradedTime, 0, data, offset, lastTradedTime.Length);
            offset += lastTradedTime.Length;

            percentChange = conversion.GetBytesFromObject(marketDepth.percentChange);
            Buffer.BlockCopy(percentChange, 0, data, offset, percentChange.Length);
            offset += percentChange.Length;

            open = conversion.GetBytesFromObject(marketDepth.open);
            Buffer.BlockCopy(open, 0, data, offset, open.Length);
            offset += open.Length;

            high = conversion.GetBytesFromObject(marketDepth.high);
            Buffer.BlockCopy(high, 0, data, offset, high.Length);
            offset += high.Length;

            low = conversion.GetBytesFromObject(marketDepth.low);
            Buffer.BlockCopy(low, 0, data, offset, low.Length);
            offset += low.Length;

            close = conversion.GetBytesFromObject(marketDepth.close);
            Buffer.BlockCopy(close, 0, data, offset, close.Length);
            offset += close.Length;

            totalvaluetraded = conversion.GetBytesFromObject(marketDepth.totalvaluetraded);
            Buffer.BlockCopy(totalvaluetraded, 0, data, offset, totalvaluetraded.Length);
            offset += totalvaluetraded.Length;

            bbtotalbuy = conversion.GetBytesFromObject(marketDepth.bbtotalbuy);
            Buffer.BlockCopy(bbtotalbuy, 0, data, offset, bbtotalbuy.Length);
            offset += bbtotalbuy.Length;

            bbtotalsell = conversion.GetBytesFromObject(marketDepth.bbtotalsell);
            Buffer.BlockCopy(bbtotalsell, 0, data, offset, bbtotalsell.Length);
            offset += bbtotalsell.Length;

            bookType = conversion.GetBytesFromObject(marketDepth.bookType);
            Buffer.BlockCopy(bookType, 0, data, offset, bookType.Length);
            offset += bookType.Length;

            marketType = conversion.GetBytesFromObject(marketDepth.marketType);
            Buffer.BlockCopy(marketType, 0, data, offset, marketType.Length);
            
            return data;
        }

        public static byte[] PrepareOpenInterestPacketData(OpenInterest openInterest)
        {
            PacketData packetData = new();
            packetData.isGzipCompressed.GzipCompressed = 1;
            packetData.PacketSize.Size = (ushort)Marshal.SizeOf(typeof(OpenInterest));
            packetData.messageCode.Code = 1501;
            packetData.exchangeSegment = openInterest.exchangeSegment;
            packetData.exchangeInstrumentID = openInterest.exchangeInstrumentId;
            packetData.bookType = new(1);//need to check
            packetData.marketType = openInterest.MarketType;
            packetData.CompressedPacketSize.compressedPacketSize = 0;
            packetData.UnCompressedPacketSize.unCompressedPacketSize = Marshal.SizeOf(typeof(OpenInterest));

            byte[] isGzipCompressedBytes = new byte[Marshal.SizeOf(typeof(IsGzipCompressed))];
            byte[] packetSizeBytes = new byte[Marshal.SizeOf(typeof(PacketSize))];
            byte[] messageCodeBytes = new byte[Marshal.SizeOf(typeof(MessageCode))];
            byte[] exchangeSegmentBytes = new byte[Marshal.SizeOf(typeof(ExchangeSegment))];
            byte[] exchangeInstrumentIDBytes = new byte[Marshal.SizeOf(typeof(ExchangeInstrumentId))];
            byte[] bookTypeBytes = new byte[Marshal.SizeOf(typeof(BookType))];
            byte[] marketTypeBytes = new byte[Marshal.SizeOf(typeof(Common.Structs.MarketType))];
            byte[] compressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(CompressedPacketSize))];
            byte[] unCompressedPacketSizeBytes = new byte[Marshal.SizeOf(typeof(UnCompressedPacketSize))];
            byte[] openInterestBytes = new byte[Marshal.SizeOf(typeof(OpenInterest))];

            byte[] data = new byte[isGzipCompressedBytes.Length + packetSizeBytes.Length + messageCodeBytes.Length + exchangeSegmentBytes.Length + exchangeInstrumentIDBytes.Length + bookTypeBytes.Length + marketTypeBytes.Length + compressedPacketSizeBytes.Length + unCompressedPacketSizeBytes.Length + openInterestBytes.Length];

            int offset = 0;

            isGzipCompressedBytes = conversion.GetBytesFromObject(packetData.isGzipCompressed);
            Buffer.BlockCopy(isGzipCompressedBytes, 0, data, offset, isGzipCompressedBytes.Length);
            offset += isGzipCompressedBytes.Length;

            packetSizeBytes = conversion.GetBytesFromObject(packetData.PacketSize);
            Buffer.BlockCopy(packetSizeBytes, 0, data, offset, packetSizeBytes.Length);
            offset += packetSizeBytes.Length;

            messageCodeBytes = conversion.GetBytesFromObject(packetData.messageCode);
            Buffer.BlockCopy(messageCodeBytes, 0, data, offset, messageCodeBytes.Length);
            offset += messageCodeBytes.Length;

            exchangeSegmentBytes = conversion.GetBytesFromObject(packetData.exchangeSegment);
            Buffer.BlockCopy(exchangeSegmentBytes, 0, data, offset, exchangeSegmentBytes.Length);
            offset += exchangeSegmentBytes.Length;

            exchangeInstrumentIDBytes = conversion.GetBytesFromObject(packetData.exchangeInstrumentID);
            Buffer.BlockCopy(exchangeInstrumentIDBytes, 0, data, offset, exchangeInstrumentIDBytes.Length);
            offset += exchangeInstrumentIDBytes.Length;

            bookTypeBytes = conversion.GetBytesFromObject(packetData.bookType);
            Buffer.BlockCopy(bookTypeBytes, 0, data, offset, bookTypeBytes.Length);
            offset += bookTypeBytes.Length;

            marketTypeBytes = conversion.GetBytesFromObject(packetData.marketType);
            Buffer.BlockCopy(marketTypeBytes, 0, data, offset, marketTypeBytes.Length);
            offset += marketTypeBytes.Length;

            compressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.CompressedPacketSize);
            Buffer.BlockCopy(compressedPacketSizeBytes, 0, data, offset, compressedPacketSizeBytes.Length);
            offset += compressedPacketSizeBytes.Length;

            unCompressedPacketSizeBytes = conversion.GetBytesFromObject(packetData.UnCompressedPacketSize);
            Buffer.BlockCopy(unCompressedPacketSizeBytes, 0, data, offset, unCompressedPacketSizeBytes.Length);
            offset += unCompressedPacketSizeBytes.Length;

            openInterestBytes = conversion.GetBytesFromObject(openInterest);
            Buffer.BlockCopy(openInterestBytes, 0, data, offset, openInterestBytes.Length);

            return data;
        }
    }
}
