﻿using BinaryProtocol.Common;
using Exchange.Logs;
using Serilog.Events;
using System.Text;
using Utility.Queueing;

namespace TradingAPI.Core
{
    internal class LogProcessor
    {
        private ProcessQueue<LogObject> logQueue;
        private Thread thread;
        private LogManager logManager;
        private StringBuilder logMsg;
        public LogProcessor(LogConfiguration logConfiguration)
        {
            logMsg = new StringBuilder();
            logManager = new LogManager(logConfiguration);
            logQueue = new ProcessQueue<LogObject>();
            thread = new Thread(new ThreadStart(ListenQueue));
            thread.Start();
        }
        public Response Enqueue(LogObject data)
        {
            return logQueue.Enqueue(data);
        }
        private void ListenQueue()
        {
            while (true)
            {
                if (logQueue.TryDequeue(out LogObject data))
                {
                    LogDataProcess(data);
                }
                data.Object = null;
                data.Message = null;
            }

        }

        private void LogDataProcess(LogObject data)
        {
            LogObject logObject = data;

            logMsg.Clear();
            logMsg.Append("Msg: " + data.Message);

            if (logObject.Object != null)
            {
                logMsg.Append(", Object: " + Helper.SerializeObject(logObject.Object));
            }

            try
            {
                switch (logObject.LogType)
                {
                    case LogType.Verbose:
                        logManager.Verbose(logMsg.ToString());
                        break;
                    case LogType.Debug:
                        logManager.Debug(logMsg.ToString());
                        break;
                    case LogType.Error:
                        logManager.Error(logMsg.ToString());
                        break;
                    case LogType.Info:
                        logManager.Info(logMsg.ToString());
                        break;
                    case LogType.Warning:
                        logManager.Warning(logMsg.ToString());
                        break;
                    case LogType.Fatal:
                        logManager.Error(logMsg.ToString());
                        break;
                    default:
                        break;
                }
            }
            catch (System.Exception ex)
            {
                logManager.Error(ex, "Msg: Error in log, Object: ");
            }
            finally
            {
                logObject.Message = null;
                logObject.Object = null;
                logMsg.Clear();
            }
        }

        public void ChangeLogType(LogEventLevel loglevel)
        {
            logManager.ChangeLogLevel(loglevel);
        }
    }
}
