﻿using BinaryProtocol.Common;
using DBHelper.Common;
using System.Data;
using TradingAPI.Core;

namespace TradingAPI.Global
{
    public class Config
    {
        public static string logfile;
        public static int logLevel;
        public static int logFileCount;
        public static ushort prefetchCount;

        static Config()
        {
            logfile = AppSettingHelper.Configuration["LogFile"];
            
            prefetchCount = Convert.ToUInt16(AppSettingHelper.Configuration["PrefetchCount"]);
            
            logLevel = Convert.ToInt32(AppSettingHelper.Configuration["LogLevel"]);
            logFileCount = Convert.ToInt32(AppSettingHelper.Configuration["LogFileCount"]);
        }
    }
}
