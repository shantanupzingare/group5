﻿using BinaryProtocol.Common;
using BinaryProtocol.TCP;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.CacheManagement.Structs;
using Exchange.WebSocketServer.SocketManager;
using TradingAPI.Global;

namespace AgentWorker.AppCode
{
    internal class SocketManager
    {
        public static void Initialize()
        {
            WebsocketManager.OnOpenConnection += WebsocketManager_OnOpenConnection;
            WebsocketManager.OnMessageReceived += WebsocketManager_OnMessageReceived;
            WebsocketManager.OnErrorListener += WebsocketManager_OnErrorListener;
            WebsocketManager.OnCloseConnection += WebsocketManager_OnCloseConnection;

            Exchange.WebSocketServer.Global.Startup.Setup();
        }

        private static void WebsocketManager_OnOpenConnection(SocketSession socketSession)
        {
            Log.Info("On Ws open con->" + socketSession.Context.Channel.Id.AsShortText());

            int startIndex = socketSession.QueryString.IndexOf("=") + 1;
            int length = socketSession.QueryString.Length - startIndex;

            string token = socketSession.QueryString.Substring(startIndex, length);
            var user = Helper.DecodeToken(token);

            if (user == null)
            {
                WebsocketManager.CloseConnection(socketSession);
                return;
            }

            var entityInfo = CoreEntity.entityInfo.Get(new DisplayCode() { displayCode = user.ToCharArray() });
            if (entityInfo.Item1.StatusCode == StatusCode.Success)
            {
                entityInfo.Item2.AuthDetail.WebSocketSessionToken = new WebSocketSessionToken() { webSocketSessionToken = socketSession.Context.Channel.Id.AsShortText() };
            }

            UserSession userSession = new UserSession
            {
                SocketSession = socketSession,
                WebSocketSessionToken = new WebSocketSessionToken() { webSocketSessionToken = socketSession.Context.Channel.Id.AsShortText() }
            };

            CoreProcess.webSocketIdWiseSession.AddOrUpdateWebSocketToken(userSession);
        }

        private static void WebsocketManager_OnMessageReceived(SocketSession socketSession, byte[] receivedmsg)
        {
            Log.Info("On WS msg rec ->" + socketSession.Context.Channel.Id.AsShortText());


            //ReceivedMessageAndSession AppendedObject = new ReceivedMessageAndSession
            //{
            //    ValidPacket = receivedmsg,
            //    SocketSesson = socketSession,
            //};
            //CoreProcess.SendFromCLToOmsDecider(AppendedObject);
        }

        private static void WebsocketManager_OnErrorListener(SocketSession socketSession, Exception ex)
        {
            Log.Error(ex);
        }

        public static void WebsocketManager_OnCloseConnection(SocketSession socketSession)
        {
            WebSocketSessionToken webSocketSessionToken = new WebSocketSessionToken() { webSocketSessionToken = socketSession.Context.Channel.Id.AsShortText() };
            Log.Info("Ws Close Evt: " + socketSession.Context.Channel.Id.AsShortText());
            Response responseConnectionClose = CoreProcess.webSocketIdWiseSession.RemoveWebSocketId(webSocketSessionToken);
        }

        public static void Send(AliasName aliasName, object data)
        {
            var entityData = CoreEntity.entityInfo.Get(new DisplayCode(aliasName.aliasName.ToCharArray()));
            if (entityData.Item1.StatusCode == StatusCode.Success)
            {
                var websocketSessionToken = entityData.Item2.AuthDetail.WebSocketSessionToken;
                var userSession = CoreProcess.webSocketIdWiseSession.GetWebSocketData(websocketSessionToken);
                if (userSession.StatusCode == StatusCode.Success)
                {
                    UserSession userSession1 = (UserSession)userSession.ExtraInfo;
                    userSession1.SocketSession.Send(data);
                }
            }
        }
    }

    public struct BeneficiaryClientId
    {
        public string beneficiaryAccount;
    }

    public struct SessionId
    {
        public string sessionId;
    }

    public struct UserSession
    {
        public BeneficiaryClientId BeneficiaryAccount;
        public WebSocketSessionToken WebSocketSessionToken;
        public SessionId SessionToken;
        public LoginStatus LoginStatus;
        public DownloadStatus DownloadStatus;
        public SocketSession SocketSession;
        public DeviceType DeviceType;
        public CTCL_TimeStamp CreatedAt;
        public CTCL_TimeStamp UpdatedAt;
    }
}
