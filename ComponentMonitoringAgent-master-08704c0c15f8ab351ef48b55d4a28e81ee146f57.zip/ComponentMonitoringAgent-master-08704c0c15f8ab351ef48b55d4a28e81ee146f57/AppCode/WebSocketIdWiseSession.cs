﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.CacheManagement.Structs;
using TradingAPI.Core;

namespace TradingAPI.Global
{

    public class WebSocketIdWiseSession
    {
        private Dictionary<WebSocketSessionToken, UserSession> dictWebsocketWiseSession;

        public WebSocketIdWiseSession()
        {
            dictWebsocketWiseSession = new Dictionary<WebSocketSessionToken, UserSession>();
        }

        public Response AddOrUpdateWebSocketToken(UserSession userSession)
        {
            Response response = new Response();
            try
            {
                if (userSession.WebSocketSessionToken.webSocketSessionToken != null && userSession.WebSocketSessionToken.webSocketSessionToken != "")
                {
                    lock (dictWebsocketWiseSession)
                    {
                        if (!dictWebsocketWiseSession.TryAdd(userSession.WebSocketSessionToken, userSession))
                        {
                            CTCL_TimeStamp currentTime = new(DateTime.Now.Ticks);
                            userSession.CreatedAt = currentTime;
                            userSession.UpdatedAt = currentTime;
                            dictWebsocketWiseSession[userSession.WebSocketSessionToken] = userSession;
                            return response = response.Set(StatusCode.Success, "Successfully Updated WebSocketData in Dictionary", userSession);
                        }
                        else
                        {
                            return response = response.Set(StatusCode.Success, "Successfully Added WebSocketData in Dictionary", userSession);
                        }
                    }
                }
                else
                {
                    return response = response.Set(StatusCode.OMS_Error, "WebSocket ID cannot Be Null or Empty", userSession);
                }
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occured while Adding WebSocket data in classfile OmsWebSocketToken.cs,methodname = AddOrUpdateWebSocketToken", ex);
            }
        }

        public Response RemoveWebSocketId(WebSocketSessionToken webSocketSessionToken)
        {
            Response response = new Response();
            try
            {
                lock (dictWebsocketWiseSession)
                {
                    if (dictWebsocketWiseSession.Remove(webSocketSessionToken, out UserSession removedSession))
                    {
                        Log.Info("WebsocketWiseSession removed for webSocketSessionToken: " + webSocketSessionToken.webSocketSessionToken);

                        response = response.Set(StatusCode.Success, "Successfully Removed OrderID from WebSocket Session Token", removedSession);
                    }
                    else
                    {
                        response = response.Set(StatusCode.OMS_KeyNotFound, "Key Not Found while Removing WebSocket data in classfile OmsWebSocketToken.cs,methodname = RemoveOrderId", null);
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occurred in classfile OmsWebSocketToken.cs,methodname = RemoveOrderId", ex);
            }
        }

        public Response GetWebSocketData(WebSocketSessionToken webSocketSessionToken)
        {
            Response response = new Response();
            try
            {
                lock (dictWebsocketWiseSession)
                {
                    if (dictWebsocketWiseSession.TryGetValue(webSocketSessionToken, out UserSession _userSession))
                    {
                        return response.Set(StatusCode.Success, "Data Found Successfully :" + webSocketSessionToken.webSocketSessionToken + " .", _userSession);
                    }
                    else
                    {
                        return response.Set(StatusCode.OMS_KeyNotFound, "WebSocket ID Does not Exists:" + webSocketSessionToken.webSocketSessionToken + " .", _userSession);
                    }
                }
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occured while Retrieve WebSocket data in classfile OmsWebSocketToken.cs,methodname = GetWebSocketData", ex);
            }
        }

        public Response UpdateDownloadStatus(WebSocketSessionToken webSocketSessionToken, DownloadStatus downloadStatus)
        {
            Response response = new Response();
            try
            {
                response = GetWebSocketData(webSocketSessionToken);
                if (response.StatusCode == StatusCode.Success)
                {
                    UserSession userSession = (UserSession)response.ExtraInfo;
                    userSession.DownloadStatus = downloadStatus;

                    return AddOrUpdateWebSocketToken(userSession);
                }
                else
                {
                    return response.Set(StatusCode.OMS_KeyNotFound, "WebSocket ID Does not Exists:" + webSocketSessionToken.webSocketSessionToken + " .");
                }
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occured while Retrieve WebSocket data in classfile OmsWebSocketToken.cs,methodname = GetWebSocketData", ex);
            }
        }


    }
}
