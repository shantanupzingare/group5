﻿using Serilog;
using Serilog.Core;
using Serilog.Events;
using System;

namespace Exchange.Logs
{
    public class LogManager
    {
        private Logger logger;
        private LoggingLevelSwitch loggingLevelSwitch;
        public LogManager(string logFilePath)
        {
            logger = new LoggerConfiguration().MinimumLevel.Verbose()
                   .WriteTo.Async(a => a.File(logFilePath,
                   rollOnFileSizeLimit: true,
                   fileSizeLimitBytes: 20971520,
                   rollingInterval: RollingInterval.Day,
                   outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}"))
                   .CreateLogger();
        }

        public LogManager(LogConfiguration logConfiguration)
        {
            loggingLevelSwitch = logConfiguration.LoggingLevelSwitch;

            logger = new LoggerConfiguration().MinimumLevel.ControlledBy(loggingLevelSwitch)
                   .WriteTo.Async(a => a.File(logConfiguration.LogFileNameWithPath,
                                              rollOnFileSizeLimit: logConfiguration.RollOnFileSizeLimit,
                                              fileSizeLimitBytes: logConfiguration.FilesizeLimitBytes,
                                              rollingInterval: logConfiguration.RollingInterval,
                                              outputTemplate: logConfiguration.OutputTemplate,
                                              retainedFileCountLimit: (logConfiguration.RetainedFileCount > 0) ? logConfiguration.RetainedFileCount : (int?)null))
                   .CreateLogger();
        }

        public LogManager(LogConfiguration logConfiguration, LogEventLevel explicitLogEventLevel, string explicitFileName)
        {
            loggingLevelSwitch = logConfiguration.LoggingLevelSwitch;

            logger = new LoggerConfiguration()
                   .MinimumLevel.ControlledBy(loggingLevelSwitch)
                   .WriteTo.Logger(l => l.Filter.ByIncludingOnly(e => e.Level == explicitLogEventLevel).WriteTo.Async(a => a.File(path: explicitFileName,
                                                                                                                                  rollOnFileSizeLimit: logConfiguration.RollOnFileSizeLimit,
                                                                                                                                  fileSizeLimitBytes: logConfiguration.FilesizeLimitBytes,
                                                                                                                                  rollingInterval: logConfiguration.RollingInterval,
                                                                                                                                  outputTemplate: logConfiguration.OutputTemplate,
                                                                                                                                  retainedFileCountLimit: (logConfiguration.RetainedFileCount > 0) ? logConfiguration.RetainedFileCount : (int?)null)))
                   .WriteTo.Logger(l => l.Filter.ByIncludingOnly(e => e.Level != explicitLogEventLevel).WriteTo.Async(a => a.File(path: logConfiguration.LogFileNameWithPath,
                                                                                                                                  rollOnFileSizeLimit: logConfiguration.RollOnFileSizeLimit,
                                                                                                                                  fileSizeLimitBytes: logConfiguration.FilesizeLimitBytes,
                                                                                                                                  rollingInterval: logConfiguration.RollingInterval,
                                                                                                                                  outputTemplate: logConfiguration.OutputTemplate,
                                                                                                                                  retainedFileCountLimit: (logConfiguration.RetainedFileCount > 0) ? logConfiguration.RetainedFileCount : (int?)null)))
                   .CreateLogger();

        }

        public void ChangeLogLevel(LogEventLevel _logLevelEvent)
        {
            loggingLevelSwitch.MinimumLevel = _logLevelEvent;
        }


        public void Verbose(string message)
        {
            logger.Verbose(message);
        }
        public void Verbose<T>(string message, T propertyValue)
        {
            logger.Verbose<T>(message, propertyValue);
        }
        public void Verbose(string message, params object[] propertyValues)
        {
            logger.Verbose(message, propertyValues);
        }
        public void Debug(string message)
        {
            logger.Debug(message);
        }
        public void Debug<T>(string message, T propertyValue)
        {
            logger.Debug<T>(message, propertyValue);
        }
        public void Debug(string message, params object[] propertyValues)
        {
            logger.Debug(message, propertyValues);
        }
        public void Error(string errorMessage)
        {
            logger.Error(errorMessage);
        }
        public void Error<T>(string errorMessage, T propertyValue)
        {
            logger.Error<T>(errorMessage, propertyValue);
        }
        public void Error(string errorMessage, params object[] propertyValues)
        {
            logger.Error(errorMessage, propertyValues);
        }
        public void Error(Exception exception, string errorMessage)
        {
            logger.Error(errorMessage, exception);
        }
        public void Info(string infoMessage)
        {
            logger.Information(infoMessage);
        }
        public void Info<T>(string infoMessage, T propertyValue)
        {
            logger.Information<T>(infoMessage, propertyValue);
        }
        public void Info(string infoMessage, params object[] propertyValues)
        {
            logger.Information(infoMessage, propertyValues);
        }
        public void Warning(string infoMessage)
        {
            logger.Warning(infoMessage);
        }
        public void Warning<T>(string infoMessage, T propertyValue)
        {
            logger.Warning<T>(infoMessage, propertyValue);
        }
        public void Warning(string infoMessage, params object[] propertyValues)
        {
            logger.Warning(infoMessage, propertyValues);
        }


        public void Fatal(string infoMessage)
        {
            logger.Fatal(infoMessage);
        }
        public void Fatal<T>(string infoMessage, T propertyValue)
        {
            logger.Fatal<T>(infoMessage, propertyValue);
        }
        public void Fatal(string infoMessage, params object[] propertyValues)
        {
            logger.Fatal(infoMessage, propertyValues);
        }

        public void Error(string v, object p)
        {
            logger.Error(v, p);
        }
        
        public bool IsEnabled(LogEventLevel logEventLevel)
        {
            return logger.IsEnabled(logEventLevel);
        }
    }

    public class LogConfiguration
    {
        public string LogFileNameWithPath;
        public bool RollOnFileSizeLimit;
        public long FilesizeLimitBytes;
        public RollingInterval RollingInterval;
        public string OutputTemplate;
        public LoggingLevelSwitch LoggingLevelSwitch;
        public int RetainedFileCount;
    }


}
