﻿using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.CacheManagement.Models.Masters;

namespace MarketAPI.Global
{
    public class CoreEntity
    {
        public static EntityCategoryMaster entityCategory;
        public static EntityInfoMaster entityInfo;
        public static EntityTypeInfoMaster entityTypeInfo;
        public static EntityContactDetailMaster entityContactDetail;
        public static List<CTCL_TerminalID> clients;
        static CoreEntity()
        {
            entityInfo = new EntityInfoMaster();
            entityCategory = new EntityCategoryMaster();
            entityTypeInfo = new EntityTypeInfoMaster();
            entityContactDetail = new EntityContactDetailMaster();
            clients = new();
        }
    }
}
