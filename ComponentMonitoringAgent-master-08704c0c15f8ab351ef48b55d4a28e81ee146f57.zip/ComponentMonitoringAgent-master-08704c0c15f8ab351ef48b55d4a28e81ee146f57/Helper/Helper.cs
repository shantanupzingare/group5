﻿using AgentWorker.Global;
using AgentWorker.Models.Response;
using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using Newtonsoft.Json;

namespace AgentWorker.Helper
{
    public class Helper
    {
        public static string SerializeObject(object obj)
        {
            try
            {
                return JsonConvert.SerializeObject(obj);
            }
            catch (Exception ex)
            {
                return "Error in serialize :" + ex.Message;
            }
        }
        public static ComponentStatus PrepareComponentStatus(int compId, int instanceId, int compState, string message, string requestId = "")
        {

            ComponentStatus componentStatus = new()
            {
                MessageCode = (int)CMA_OpCode.COMPONENT_STATE_UPDATE,
                BrokerId = Config.BrokerId,
                SiteId = Config.SiteId,
                AgentId = Config.AgentWorkerId,
                ComponentType = compId,
                InstanceId = instanceId,
                ComponentState = compState,
                Message = message,
                TimeStamp = DateTime.Now,
                IsSucessStatus = true,
                RequestId = requestId
            };
            return componentStatus;
        }
    }
}
