﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace AgentWorker.Helper
{
	public static class ConsoleHelper
	{
		[DllImport("user32.dll", SetLastError =true)]
		private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
		
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern int GetwWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
		
		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		[DllImport("user32.dll")]
		private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);

		[DllImport("user32.dll")]
		private static extern bool IsWindowVisible(IntPtr hwnd);
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

		private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
		public static string GetConsoleName(int processId) 
		{
			string name = string.Empty;
			EnumWindows((hWnd, lparam) =>
			{

				uint processidFound = GetWindowThreadProcessId(hWnd, out processidFound);

				if (processidFound == processId)
				{
					StringBuilder windowTitle = new StringBuilder(256);
					GetwWindowText(hWnd, windowTitle, windowTitle.Capacity);
					Console.WriteLine(windowTitle);
					name=  windowTitle.ToString();
					return false;
				}
				return true;
			}, IntPtr.Zero);

			return name;
		}


	}
}
