 
(function() {
    $('#showAddView').click(function () {
        $('#FormView').slideToggle();
    })

    $('#CompMaster').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });
    $('#FileMaster').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });
    $('#startBOD').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": false,
    });

    $('#BOD').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });
    
    $('#brokerMaster').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });
    $('#InstanceMaster').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });

    $('#CompntMaster').DataTable({
        "paging": true,
        "pageLength": 5,
        "searching": true,
        "ordering": true,
    });


})();