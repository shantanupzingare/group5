﻿using LoginSignupCore.Core;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using System.Data.SqlClient;

namespace LoginSignupCore.Data
{
    public class AgentwiseFilesRepository
    {
        public void InsertAgentWiseFilesData(AgentwiseFiles map)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "INSERT INTO AgentToFileMappingMaster(intAgentId,intFileId,nvcRemarks," +
                    "dtmCreatedOn,intCreatedBy,IsActive,IsDeleted) VALUES (@intAgentId,@intFileId,@nvcRemarks," +
                    "@dtmCreatedOn,@intCreatedBy,@IsActive,@IsDeleted)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", map.AgentId);
                    command.Parameters.AddWithValue("@intFileId", map.FileId);
                    command.Parameters.AddWithValue("@nvcRemarks", map.Remarks);
                    command.Parameters.AddWithValue("@dtmCreatedOn", map.DtmCreationDate);
                    command.Parameters.AddWithValue("@intCreatedBy", map.IntCreatedBy);
                    command.Parameters.AddWithValue("@IsActive", 1);
                    command.Parameters.AddWithValue("@IsDeleted", 0);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                string fileMasterquery = "SELECT intSegmentId,intFileType,nvcFileName," +
                    "intPriority,isUploadBeforeBod,nvcDestinationPath" +
                    " from FileInfoMaster where intId=@intId and IsActive=@IsActive and IsDeleted=@IsDeleted";
                using (var command = new SqlCommand(fileMasterquery, connection))
                {
                    command.Parameters.AddWithValue("@intId", map.FileId);
                    command.Parameters.AddWithValue("@IsActive", 1);
                    command.Parameters.AddWithValue("@IsDeleted", 0);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FileMasterInfo file = new FileMasterInfo();
                            file.SegmentId = reader.GetInt32(reader.GetOrdinal("intSegmentId"));
                            file.FileType = reader.GetInt32(reader.GetOrdinal("intFileType"));
                            file.FileName = reader.GetString(reader.GetOrdinal("nvcFileName"));
                            file.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            file.IsUploadBeforeBOD = reader.GetBoolean(reader.GetOrdinal("isUploadBeforeBod"));
                            file.DestinationPath = reader.GetString(reader.GetOrdinal("nvcDestinationPath"));
                            file.AgentId = map.AgentId;
                            file.BrokerId = map.BrokerId;
                            file.SiteId = map.SiteId;

                            CoreProcess.agentSessionCache.AddOrUpdate(file);
                        }
                    }
                }
            }
        }
        public List<AgentwiseFiles> GetAllFilesAgentWise(int agentID)
        {
            var files = new List<AgentwiseFiles>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT a.intId,a.intAgentId,a.intFileId,a.IsActive,a.IsDeleted," +
                    "a.nvcRemarks,a.dtmCreatedOn,a.intCreatedBy,a.dtmUpdatedOn,a.intUpdatedBy,b.nvcFileName" +
                     " from AgentToFileMappingMaster a JOIN FileInfoMaster b on b.intId = a.intFileId" +
                     " where a.intAgentId=@intAgentId and a.IsDeleted = 0 and b.IsDeleted = 0 ";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentID);


                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            AgentwiseFiles file = new AgentwiseFiles();
                            file.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                            file.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
                            file.FileId = reader.GetInt32(reader.GetOrdinal("intFileId"));
                            file.FileName = reader.GetString(reader.GetOrdinal("nvcFileName"));
                            file.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
                            file.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
                            file.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            file.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            file.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
                                             : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
                            file.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            file.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));
                            files.Add(file);
                        }
                    }
                }

            }
            return files;
        }
        //public void UpdateData(Component component)
        //{
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        string query =
        //            "update AgentMasterWiseComponents set nvcExePath=@nvcExePath,nvcCmdParam=@nvcCmdParam,bitIsRunAsService=@bitIsRunAsService,nvcServiceName=@nvcServiceName,intPriority=@intPriority,nvcRemarks=@nvcRemarks," +
        //            "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
        //        using (var command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@intId", component.Id);
        //            //command.Parameters.AddWithValue("@intComponentType", component.ComponentType);
        //            //command.Parameters.AddWithValue("@intInstanceId", component.InstanceId);
        //            command.Parameters.AddWithValue("@nvcExePath", component.ExePath);
        //            command.Parameters.AddWithValue("@nvcCmdParam", component.CmdParam);
        //            command.Parameters.AddWithValue("@bitIsRunAsService", component.IsRunAsService);
        //            command.Parameters.AddWithValue("@nvcServiceName", component.ServiceName);
        //            command.Parameters.AddWithValue("@intPriority", component.Priority);
        //            command.Parameters.AddWithValue("@nvcRemarks", component.Remarks);
        //            command.Parameters.AddWithValue("@dtmUpdatedOn", component.DtmUpdationDate);
        //            command.Parameters.AddWithValue("@intUpdatedBy", component.IntUpdatedBy);
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //        }

        //    }
        //}
        //public Component GetComponentById(int Id)
        //{
        //    var component = new Component();
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        string query = "SELECT intId,intAgentId,intInstanceId,intComponentType,nvcExePath,nvcCmdParam,bitIsRunAsService,nvcServiceName" +
        //            ",intPriority,IsActive,IsDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy from AgentMasterWiseComponents where intId=@intId";
        //        using (var command = new SqlCommand(query, connection))
        //        {
        //            command.Parameters.AddWithValue("@intId", Id);
        //            connection.Open();
        //            using (var reader = command.ExecuteReader())
        //            {
        //                while (reader.Read())
        //                {
        //                    component.Id = reader.GetInt32(reader.GetOrdinal("intId"));
        //                    component.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
        //                    component.ComponentType = reader.GetInt32(reader.GetOrdinal("intComponentType"));
        //                    component.ExePath = reader.GetString(reader.GetOrdinal("nvcExePath"));
        //                    component.CmdParam = reader.GetString(reader.GetOrdinal("nvcCmdParam"));
        //                    component.InstanceId = reader.GetInt32(reader.GetOrdinal("intInstanceId"));
        //                    component.IsRunAsService = reader.GetBoolean(reader.GetOrdinal("bitIsRunAsService"));
        //                    component.ServiceName = reader.GetString(reader.GetOrdinal("nvcServiceName"));
        //                    component.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
        //                    component.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
        //                    component.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
        //                    component.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
        //                    component.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
        //                    component.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
        //                                               : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
        //                    component.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
        //                    component.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));

        //                }
        //            }
        //        }

        //    }
        //    return component;
        //}
        public void UpdateIsDelete(AgentwiseFiles map)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "update AgentToFileMappingMaster set IsDeleted=@IsDeleted,nvcRemarks=@nvcRemarks," +
                    "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", map.Id);
                    command.Parameters.AddWithValue("@IsDeleted", map.IsDeleted);
                    command.Parameters.AddWithValue("@nvcRemarks", map.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", map.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", map.IntUpdatedBy);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

            }
        }
        public void UpdateIsActive(AgentwiseFiles map)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "update AgentToFileMappingMaster set IsActive=@IsActive,nvcRemarks=@nvcRemarks," +
                    "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", map.Id);
                    command.Parameters.AddWithValue("@IsActive", map.IsActive);
                    command.Parameters.AddWithValue("@nvcRemarks", map.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", map.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", map.IntUpdatedBy);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

            }
        }
        public List<FileDropDown> GetFileDropDowmList()
        {
            var files = new List<FileDropDown>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT  intId , nvcFileName FROM FileInfoMaster where isActive=1 and isDeleted=0 ";
                using (var command = new SqlCommand(query, connection))
                {
                  
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FileDropDown file = new FileDropDown();
                            file.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                            file.Name = reader.GetString(reader.GetOrdinal("nvcFileName"));
                            
                            files.Add(file);
                        }
                    }
                }

            }
            return files;
        }
    }
}
