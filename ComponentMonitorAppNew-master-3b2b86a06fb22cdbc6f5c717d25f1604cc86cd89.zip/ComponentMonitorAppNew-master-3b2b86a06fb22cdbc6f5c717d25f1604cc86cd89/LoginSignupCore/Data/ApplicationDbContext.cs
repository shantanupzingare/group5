﻿using Microsoft.EntityFrameworkCore;
using LoginSignupCore.Models;
using Microsoft.EntityFrameworkCore.Design;
using LoginSignupCore.Global;

namespace LoginSignupCore.Data
{
	public class ApplicationDbContext:DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> Options):base(Options)
		{
		}

		public DbSet<RegisterViewModel> Accounts { get; set; }

        public DbSet<AlertThreshold> AlertThresholds { get; set; }

		public DbSet<ComponentMaster> ComponentMasters { get; set; }

		public DbSet<ComponentParameter> ComponentParameters { get; set; }

		public DbSet<InstanceMaster> InstanceMasters { get; set; }

        public DbSet<AgentSiteMonitoringData> AgentSiteMonitoringDatas { get; set; }

        public DbSet<BrokerMaster> BrokerMasters { get; set; }

        public DbSet<BrokerSites> BrokerSitess { get; set; }

        public virtual DbSet<AgentSiteMonitoringData> AgentSiteMonitoringData { get; set; }

        public virtual DbSet<BrokerMaster> BrokerMaster { get; set; }

        public virtual DbSet<BrokerSites> BrokerSites { get; set; }

        public virtual DbSet<VwComponentInstanceBrokerWiseData> VwComponentInstanceBrokerWiseData { get; set; }

        public virtual DbSet<VwInfoStatsData> VwInfoStatsData { get; set; }

        public virtual DbSet<VwComponentParameter> VwComponentParameter { get; set; }

        public virtual DbSet<VwAlertThreshold> VwAlertThreshold { get; set; }

        public virtual DbSet<VwInstanceMaster> VwInstanceMaster { get; set; }
        public virtual DbSet<CTCLTimer> CTCLTimer { get; set; }

        public DbSet<AgentMaster> AgentMaster { get; set; }
        public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
		{
			public ApplicationDbContext CreateDbContext(string[] args)
			{
				var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
				optionsBuilder.UseSqlServer(Config.connectionString);

				return new ApplicationDbContext(optionsBuilder.Options);
			}
		}
	}
}




