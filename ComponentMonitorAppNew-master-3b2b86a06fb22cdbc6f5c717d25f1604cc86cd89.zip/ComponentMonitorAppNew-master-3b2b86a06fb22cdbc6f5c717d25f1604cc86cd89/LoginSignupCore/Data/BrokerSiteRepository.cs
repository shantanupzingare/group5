﻿using LoginSignupCore.Core;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using System.Data.SqlClient;

namespace LoginSignupCore.Data
{
    public class BrokerSiteRepository
    {
        public (bool,string) InsertBrokerSiteData(BrokerSites brokerSites)
        {
            try
            {
                using var connection = new SqlConnection(Config.connectionString);
                string query =
                    "INSERT INTO BrokerSites(nvcSiteName,intBrokerId,nvcMasterFilePath,IsActive,IsDeleted,dtmCreationDate,intCreatedBy)" +
                    "VALUES (@nvcSiteName,@intBrokerId,@nvcMasterFilePath,@IsActive,@IsDeleted,@dtmCreationDate,@intCreatedBy)" +
                    "SELECT SCOPE_IDENTITY()";
                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@nvcSiteName", brokerSites.NvcSiteName);
                command.Parameters.AddWithValue("@intBrokerId", brokerSites.IntBrokerId);
                command.Parameters.AddWithValue("@nvcMasterFilePath", brokerSites.NvcMasterFilePath);
                command.Parameters.AddWithValue("@IsActive", 1);
                command.Parameters.AddWithValue("@IsDeleted", 0);
                command.Parameters.AddWithValue("@dtmCreationDate", DateTime.Now.Date);
                command.Parameters.AddWithValue("@intCreatedBy", brokerSites.IntCreatedBy);
                connection.Open();
                object id = command.ExecuteScalar();
                if (id != null)
                {
                    _ = int.TryParse(id.ToString(), out int siteId);
                    if (siteId != 0)
                    {
                        int brokerId = brokerSites.IntBrokerId;
                        string masterPath = brokerSites.NvcMasterFilePath;

                        CoreProcess.agentSessionCache.AddOrUpdate(brokerId, siteId, masterPath);
                    }
                }
                Log.Info($"Broker Site Data Saved sucessfully");
                return (true, $"Broker Site Data Saved sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error($"Error while Inserting BrokerSite Data | {ex.Message}");
                return (false, $"Error while Inserting BrokerSite Data | {ex.Message}");
            }
        }
        public (bool, string) UpdateBrokerSiteData(BrokerSites brokerSites)
        {
            try
            {
                using var connection = new SqlConnection(Config.connectionString);
                string query = "update BrokerSites set nvcSiteName=@nvcSiteName,nvcMasterFilePath=@nvcMasterFilePath where id=@id";
                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@nvcSiteName",brokerSites.NvcSiteName);
                command.Parameters.AddWithValue("@nvcMasterFilePath", brokerSites.NvcMasterFilePath);
                command.Parameters.AddWithValue("@id", brokerSites.Id);
                connection.Open();
                object id = command.ExecuteScalar();
                if (id != null)
                {
                    _ = int.TryParse(id.ToString(), out int siteId);
                    if (siteId != 0)
                    {
                        int brokerId = brokerSites.IntBrokerId;
                        string masterPath = brokerSites.NvcMasterFilePath;

                        CoreProcess.agentSessionCache.AddOrUpdate(brokerId, siteId, masterPath);
                    }
                }
                Log.Info($"Broker Site Data Saved sucessfully");
                return (true, $"Broker Site Data Saved sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error($"Error while Inserting BrokerSite Data | {ex.Message}");
                return (false, $"Error while Inserting BrokerSite Data | {ex.Message}");
            }

        }
        public BrokerSites GetBrokerSitesById(int id)
        {

            var site = new BrokerSites();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT id,nvcSiteName,intBrokerId,nvcMasterFilePath,IsActive,IsDeleted,intCreatedBy,dtmCreationDate,intUpdatedBy,dtmUpdationDate  FROM BrokerSites where id=" + id;
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", id);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            site.Id = reader.GetInt32(reader.GetOrdinal("id"));
                            site.NvcSiteName = reader.GetString(reader.GetOrdinal("nvcSiteName"));
                            site.IntBrokerId = reader.GetInt32(reader.GetOrdinal("intBrokerId"));
                            site.NvcMasterFilePath = reader.GetString(reader.GetOrdinal("nvcMasterFilePath"));
                            site.IsActive = reader.GetInt32(reader.GetOrdinal("IsActive"));
                            site.IsDeleted = reader.GetInt32(reader.GetOrdinal("IsDeleted"));


                        }
                    }
                }

            }
            return site;
        }
    }
}
