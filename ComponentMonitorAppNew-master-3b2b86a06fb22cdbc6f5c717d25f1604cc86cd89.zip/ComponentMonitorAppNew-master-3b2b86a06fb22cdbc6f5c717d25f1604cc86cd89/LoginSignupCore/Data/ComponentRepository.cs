﻿using LoginSignupCore.Core;
using LoginSignupCore.Global;
using LoginSignupCore.Models;
using System.Data.SqlClient;
using ComponentMaster = LoginSignupCore.MasterCache.ComponentMaster;

namespace LoginSignupCore.Data
{
    public class ComponentRepository
    {
        public void InsertAgentWiseComponentData(Component component)
        {
            try
            {
                using var connection = new SqlConnection(Config.connectionString);
                string query =
                    "INSERT INTO AgentMasterWiseComponents(intAgentId,intComponentType,intInstanceId,nvcExePath,nvcCmdParam,bitIsRunAsService,nvcServiceName,intPriority,nvcRemarks," +
                    "dtmCreatedOn,intCreatedBy,IsActive,IsDeleted) VALUES (@intAgentId,@intComponentType,@intInstanceId,@nvcExePath,@nvcCmdParam,@bitIsRunAsService,@nvcServiceName,@intPriority,@nvcRemarks," +
                    "@dtmCreatedOn,@intCreatedBy,@IsActive,@IsDeleted)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", component.AgentId);
                    command.Parameters.AddWithValue("@intComponentType", component.ComponentType);
                    command.Parameters.AddWithValue("@intInstanceId", component.InstanceId);
                    command.Parameters.AddWithValue("@nvcExePath", component.ExePath);
                    command.Parameters.AddWithValue("@nvcCmdParam", component.CmdParam);
                    command.Parameters.AddWithValue("@bitIsRunAsService", component.IsRunAsService);
                    command.Parameters.AddWithValue("@nvcServiceName", component.ServiceName);
                    command.Parameters.AddWithValue("@intPriority", component.Priority);
                    command.Parameters.AddWithValue("@nvcRemarks", component.Remarks);
                    command.Parameters.AddWithValue("@dtmCreatedOn", component.DtmCreationDate);
                    command.Parameters.AddWithValue("@intCreatedBy", component.IntCreatedBy);
                    command.Parameters.AddWithValue("@IsActive", 1);
                    command.Parameters.AddWithValue("@IsDeleted", 0);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                ComponentMaster compMaster = new();
                compMaster.AgentId = component.AgentId;
                compMaster.BrokerId = component.BrokerId;
                compMaster.SiteId = component.SiteId;
                compMaster.ComponentId = component.ComponentType;
                compMaster.InstanceId = component.InstanceId;
                compMaster.ExePath = component.ExePath;
                compMaster.CmdParam = component.CmdParam;
                compMaster.IsRunAsService = component.IsRunAsService;
                compMaster.ServiceName = component.ServiceName;
                compMaster.Priority = component.Priority;
                compMaster.ComponentName = component.ComponentName;
                CoreProcess.agentSessionCache.AddOrUpdate(compMaster);
            }
            catch (Exception ex)
            {
                Log.Error($"Error while Mapping Agent with Component | {ex.Message}");
            }
        }
        public List<Component> GetAllComponentAgentWise(int agentID)
        {
            var components = new List<Component>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT a.intId,a.intAgentId,a.intInstanceId,a.intComponentType,a.nvcExePath,a.nvcCmdParam,a.bitIsRunAsService,a.nvcServiceName,b.intPriority,a.IsActive,a.IsDeleted,a.nvcRemarks,a.dtmCreatedOn,a.intCreatedBy,a.dtmUpdatedOn,a.intUpdatedBy,b.nvcComponentName from AgentMasterWiseComponents a JOIN ComponentMaster b on b.intComponentId=a.intComponentType where a.intAgentId=@intAgentId and a.IsDeleted=0 and b.bitIsDelete=0";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentID);
                   

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Component component = new Component();
                            component.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                            component.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
                            component.ComponentType = reader.GetInt32(reader.GetOrdinal("intComponentType"));
                            component.ExePath = reader.GetString(reader.GetOrdinal("nvcExePath"));
                            component.CmdParam = reader.GetString(reader.GetOrdinal("nvcCmdParam"));
                            component.ComponentName = reader.GetString(reader.GetOrdinal("nvcComponentName"));
                            component.InstanceId = reader.GetInt32(reader.GetOrdinal("intInstanceId"));
                            component.IsRunAsService = reader.GetBoolean(reader.GetOrdinal("bitIsRunAsService"));
                            component.ServiceName = reader.GetString(reader.GetOrdinal("nvcServiceName"));
                            component.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            component.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
                            component.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
                            component.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            component.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            component.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
                                                       : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
                            component.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            component.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));
                            components.Add(component);
                        }
                    }
                }

            }
            return components;
        }
        public void UpdateData(Component component)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "update AgentMasterWiseComponents set nvcExePath=@nvcExePath,nvcCmdParam=@nvcCmdParam,bitIsRunAsService=@bitIsRunAsService,nvcServiceName=@nvcServiceName,intPriority=@intPriority,nvcRemarks=@nvcRemarks," +
                    "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", component.Id);
                    //command.Parameters.AddWithValue("@intComponentType", component.ComponentType);
                    //command.Parameters.AddWithValue("@intInstanceId", component.InstanceId);
                    command.Parameters.AddWithValue("@nvcExePath", component.ExePath);
                    command.Parameters.AddWithValue("@nvcCmdParam", component.CmdParam);
                    command.Parameters.AddWithValue("@bitIsRunAsService", component.IsRunAsService);
                    command.Parameters.AddWithValue("@nvcServiceName", component.ServiceName);
                    command.Parameters.AddWithValue("@intPriority", component.Priority);
                    command.Parameters.AddWithValue("@nvcRemarks", component.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", component.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", component.IntUpdatedBy);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

            }
        }
        public Component GetComponentById(int Id)
        {
            var component = new Component();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                //string query = "SELECT intId,intAgentId,intInstanceId,intComponentType,nvcExePath,nvcCmdParam,bitIsRunAsService,nvcServiceName" +
                //    ",intPriority,IsActive,IsDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy from AgentMasterWiseComponents where intId=@intId";

                string query=   "select a.intId,a.intAgentId,a.intComponentType,a.intInstanceId,a.nvcExePath,a.nvcCmdParam,a.bitIsRunAsService," +
                                "a.nvcServiceName ,a.intPriority,a.IsActive,a.IsDeleted,a.nvcRemarks,a.dtmCreatedOn,a.intCreatedBy,a.dtmUpdatedOn,a.intUpdatedBy,c.nvcComponentName from AgentMasterWiseComponents a INNER JOIN ComponentMaster  c " +
                                "ON a.intComponentType = c.intComponentId"+
                                " where a.intId=@intId and a.IsDeleted = 0";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", Id);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            component.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                            component.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
                            component.ComponentType = reader.GetInt32(reader.GetOrdinal("intComponentType"));
                            component.ExePath = reader.GetString(reader.GetOrdinal("nvcExePath"));
                            component.CmdParam = reader.GetString(reader.GetOrdinal("nvcCmdParam"));
                            component.InstanceId = reader.GetInt32(reader.GetOrdinal("intInstanceId"));
                            component.IsRunAsService = reader.GetBoolean(reader.GetOrdinal("bitIsRunAsService"));
                            component.ServiceName = reader.GetString(reader.GetOrdinal("nvcServiceName"));
                            component.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            component.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
                            component.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
                            component.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            component.ComponentName = reader.GetString(reader.GetOrdinal("nvcComponentName"));
                            component.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            component.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
                                                       : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
                            component.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            component.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));
                            
                        }
                    }
                }

            }
            return component;
        }
        public void UpdateIsDelete(Component component)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "update AgentMasterWiseComponents set IsDeleted=@IsDeleted,nvcRemarks=@nvcRemarks," +
                    "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", component.Id);
                    //command.Parameters.AddWithValue("@intComponentType", component.ComponentType);
                    //command.Parameters.AddWithValue("@intInstanceId", component.InstanceId);
                    command.Parameters.AddWithValue("@IsDeleted", component.IsDeleted);
                    command.Parameters.AddWithValue("@nvcRemarks", component.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", component.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", component.IntUpdatedBy);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

            }
        }
        public void UpdateIsActive(Component component)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "update AgentMasterWiseComponents set IsActive=@IsActive,nvcRemarks=@nvcRemarks," +
                    "intUpdatedBy=@intUpdatedBy,dtmUpdatedOn=@dtmUpdatedOn where intId=@intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", component.Id);
                    //command.Parameters.AddWithValue("@intComponentType", component.ComponentType);
                    //command.Parameters.AddWithValue("@intInstanceId", component.InstanceId);
                    command.Parameters.AddWithValue("@IsActive", component.IsActive);
                    command.Parameters.AddWithValue("@nvcRemarks", component.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", component.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", component.IntUpdatedBy);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

            }
        }
        public List<ComponentDropDown> GetComponentDropDowmList(int agentId)
        {
            var comps = new List<ComponentDropDown>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "select intComponentId , nvcComponentName,intPriority from ComponentMaster where intComponentId  not in (select intComponentType from AgentMasterWiseComponents where intAgentId="+ agentId+") and bitIsActive=1 and bitIsDelete=0";
                using (var command = new SqlCommand(query, connection))
                {

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ComponentDropDown comp = new ComponentDropDown();
                            comp.Id = reader.GetInt32(reader.GetOrdinal("intComponentId"));
                            comp.Name = reader.GetString(reader.GetOrdinal("nvcComponentName"));
                            comp.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            comps.Add(comp);
                        }
                    }
                }

            }
            return comps;
        }
    }
}
