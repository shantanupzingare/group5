﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using LoginSignupCore.Global;
using LoginSignupCore.Models;
using System.Data.SqlClient;
using ComponentMaster = LoginSignupCore.Models.ComponentMaster;

namespace LoginSignupCore.Data
{
    public class ComponentMasterRepository
    {
        public void InsertComponentMasterData(ComponentMaster componentMaster)
        {
            using var connection = new SqlConnection(Config.connectionString);
            string query =
                "INSERT INTO ComponentMaster(intComponentId,nvcComponentName,numCpuThreshold,numRamThreshold,intPriority,dtmCreatedOn,intCreatedBy,bitIsActive,bitIsDelete)" +
                " VALUES (@intComponentId,@nvcComponentName,@numCpuThreshold,@numRamThreshold,@intPriority,@dtmCreatedOn,@intCreatedBy,@bitIsActive,@bitIsDelete)";
            using var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@intComponentId", componentMaster.IntComponentId);
            command.Parameters.AddWithValue("@nvcComponentName", componentMaster.NvcComponentName);
            command.Parameters.AddWithValue("@numCpuThreshold", componentMaster.CpuThreshold);
            command.Parameters.AddWithValue("@numRamThreshold", componentMaster.RamThreshold);
            command.Parameters.AddWithValue("@intPriority", componentMaster.IntPriority);
            command.Parameters.AddWithValue("@dtmCreatedOn", DateTime.Now.Date);
            command.Parameters.AddWithValue("@intCreatedBy", globals.User_ID);
            command.Parameters.AddWithValue("@bitIsActive", 1);
            command.Parameters.AddWithValue("@bitIsDelete", 0);
            connection.Open();
            command.ExecuteNonQuery();
        }
        public List<ComponentMaster> Get()
        {
            var components = new List<ComponentMaster>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT intId,intComponentId,nvcComponentName,numCpuThreshold,numRamThreshold,intPriority,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy,bitIsActive,bitIsDelete" +
                    " from ComponentMaster where  bitIsDelete=@bitIsDelete";
                using var command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@bitIsDelete", 0);
                connection.Open();
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    ComponentMaster component = new ComponentMaster();
                    component.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                    component.IntComponentId = reader.GetInt32(reader.GetOrdinal("intComponentId"));
                    component.NvcComponentName = reader.GetString(reader.GetOrdinal("nvcComponentName"));
                    component.CpuThreshold = (double)reader.GetDecimal(reader.GetOrdinal("numCpuThreshold"));
                    component.RamThreshold = (double)reader.GetDecimal(reader.GetOrdinal("numRamThreshold"));
                    component.IntPriority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                    component.BitIsActive = reader.GetInt32(reader.GetOrdinal("bitIsActive"));
                    components.Add(component);
                }
            }
            return components;
        }
        public ComponentMaster GetcompById(int id)
        {
            var component = new ComponentMaster();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT intId,intComponentId,nvcComponentName,numCpuThreshold,numRamThreshold,intPriority,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy,bitIsActive,bitIsDelete from ComponentMaster where intId = @intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", id);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            component.Id = reader.GetInt32(reader.GetOrdinal("intId"));
                            component.IntComponentId = reader.GetInt32(reader.GetOrdinal("intComponentId"));
                            component.NvcComponentName = reader.GetString(reader.GetOrdinal("nvcComponentName"));
                            component.CpuThreshold = Convert.ToDouble(reader.GetDecimal(reader.GetOrdinal("numCpuThreshold")));
                            component.RamThreshold = Convert.ToDouble(reader.GetDecimal(reader.GetOrdinal("numRamThreshold")));
                            component.IntPriority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            component.BitIsActive = reader.GetInt32(reader.GetOrdinal("bitIsActive"));
                            component.BitIsDelete = reader.GetInt32(reader.GetOrdinal("bitIsDelete"));


                        }
                    }
                }

            }
            return component;
        }

        public int UpdateIsActiveData(ComponentMaster Master)
        {
            using (SqlConnection conn = new SqlConnection(Config.connectionString))
            {
                SqlCommand cmd = new SqlCommand("Update  ComponentMaster Set BitIsActive = @BitIsActive,DtmUpdatedOn =@DtmUpdatedOn,IntUpdatedBy =@IntUpdatedBy Where intId = @intId", conn);

                cmd.Parameters.AddWithValue("@intId", Master.Id);
                cmd.Parameters.AddWithValue("@BitIsActive", Master.BitIsActive);
                cmd.Parameters.AddWithValue("@DtmUpdatedOn", Master.DtmUpdatedOn);
                cmd.Parameters.AddWithValue("@IntUpdatedBy", Master.IntUpdatedBy);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
        }
    }
}
