﻿using LoginSignupCore.Core;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using System.Data.SqlClient;

namespace LoginSignupCore.Data
{
    public class AgentRepository
    {
        public void InsertUpdateData(AgentMaster agentMaster)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query =
                    "INSERT INTO AgentMaster (nvcAgentName,intBrokerId,intBrokerSiteId,nvcInstanceIP,nvcRemarks,dtmCreatedOn,intCreatedBy)" +
                    "VALUES(@nvcAgentName,@intBrokerId,@intBrokerSiteId,@nvcInstanceIP,@nvcRemarks,@dtmCreatedOn,@intCreatedBy)" +
                    "SELECT SCOPE_IDENTITY()";
                using (var command = new SqlCommand(query,connection))
                {
                    command.Parameters.AddWithValue("@nvcAgentName", agentMaster.AgentName);
                    command.Parameters.AddWithValue("@intBrokerId", agentMaster.BrokerId);
                    command.Parameters.AddWithValue("@intBrokerSiteId", agentMaster.BrokerSiteId);
                    command.Parameters.AddWithValue("@nvcInstanceIP", agentMaster.nvcInstanceIP);
                    command.Parameters.AddWithValue("@nvcRemarks", agentMaster.Remarks);
                    command.Parameters.AddWithValue("@dtmCreatedOn", agentMaster.DtmCreationDate);
                    command.Parameters.AddWithValue("@intCreatedBy", agentMaster.IntCreatedBy);
                    connection.Open();
                    object id = command.ExecuteScalar();
                    if(id != null)
                    {
                        _ = int.TryParse(id.ToString(), out int agentId);
                        if(agentId != 0)
                        {
                            AgentSessionInfo agentSessionInfo = new();
                            agentSessionInfo.AgentId = agentId;
                            agentSessionInfo.BrokerId = agentMaster.BrokerId;
                            agentSessionInfo.SiteId = agentMaster.BrokerSiteId;
                            agentSessionInfo.IP = agentMaster.nvcInstanceIP;
                            agentSessionInfo.AgentName = agentMaster.AgentName;

                            CoreProcess.ipSessionCache.AddOrUpdate(agentSessionInfo);
                            CoreProcess.agentSessionCache.AddOrUpdate(agentSessionInfo);
                        }
                    }
                }

            }
        }
        public List<AgentMaster> GetAllAgents(int brokerid, int siteid,int isdelete=0)
        {
            var agents = new List<AgentMaster>();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT intAgentId,nvcAgentName,intBrokerId,intBrokerSiteId,nvcInstanceIP,IsActive,IsDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy " +
                    "from AgentMaster where intBrokerId=@intBrokerId and intBrokerSiteId=@intBrokerSiteId and IsDeleted=@IsDeleted";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intBrokerId", brokerid);
                    command.Parameters.AddWithValue("@intBrokerSiteId", siteid);
                    command.Parameters.AddWithValue("@IsDeleted", isdelete);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            AgentMaster agent = new AgentMaster();
                            agent.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
                            agent.AgentName = reader.GetString(reader.GetOrdinal("nvcAgentName"));
                            agent.BrokerId = reader.GetInt32(reader.GetOrdinal("intBrokerId"));
                            agent.BrokerSiteId = reader.GetInt32(reader.GetOrdinal("intBrokerSiteId"));
                            agent.nvcInstanceIP = reader.GetString(reader.GetOrdinal("nvcInstanceIP"));
                            agent.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
                            agent.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
                            agent.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            agent.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            agent.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
                                                       : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
                            agent.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            agent.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));
                            agents.Add(agent);
                        }
                    }
                }

            }
            return agents;
        }
        public AgentMaster GetAgentById(int agentID)
        {
            var agent = new AgentMaster();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "SELECT intAgentId,nvcAgentName,intBrokerId,intBrokerSiteId,nvcInstanceIP,IsActive,IsDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy,dtmUpdatedOn,intUpdatedBy from AgentMaster where intAgentId=@intAgentId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentID);
                    
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {

                            agent.AgentId = reader.GetInt32(reader.GetOrdinal("intAgentId"));
                            agent.AgentName = reader.GetString(reader.GetOrdinal("nvcAgentName"));
                            agent.BrokerId = reader.GetInt32(reader.GetOrdinal("intBrokerId"));
                            agent.BrokerSiteId = reader.GetInt32(reader.GetOrdinal("intBrokerSiteId"));
                            agent.nvcInstanceIP = reader.GetString(reader.GetOrdinal("nvcInstanceIP"));
                            agent.IsActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsActive")));
                            agent.IsDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("IsDeleted")));
                            agent.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            agent.DtmCreationDate = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            agent.DtmUpdationDate = (reader.IsDBNull(reader.GetOrdinal("dtmUpdatedOn")) ? DateTime.MinValue
                                                       : reader.GetDateTime(reader.GetOrdinal("dtmUpdatedOn")));
                            agent.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            agent.IntUpdatedBy = reader.IsDBNull(reader.GetOrdinal("intUpdatedBy")) ? -1 : reader.GetInt32(reader.GetOrdinal("intUpdatedBy"));
                           
                        }
                    }
                }

            }
            return agent;
        }
        public int UpdateData(AgentMaster agentMaster)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "update AgentMaster set nvcAgentName=@nvcAgentName,nvcInstanceIP=@nvcInstanceIP," +
                    "nvcRemarks=@nvcRemarks,dtmUpdatedOn=@dtmUpdatedOn,intUpdatedBy=@intUpdatedBy where intAgentId=@intAgentId";


                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentMaster.AgentId);
                    command.Parameters.AddWithValue("@nvcAgentName", agentMaster.AgentName);
                    command.Parameters.AddWithValue("@nvcInstanceIP", agentMaster.nvcInstanceIP);
                    command.Parameters.AddWithValue("@nvcRemarks", agentMaster.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", agentMaster.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", agentMaster.IntUpdatedBy);
                    connection.Open();
                    int rowAffected = command.ExecuteNonQuery();
                    return rowAffected;
                }

            }
        }
        public int DeleteData(AgentMaster agentMaster)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "update AgentMaster set IsDeleted=@IsDeleted,nvcRemarks=@nvcRemarks,dtmUpdatedOn=@dtmUpdatedOn,intUpdatedBy=@intUpdatedBy where intAgentId=@intAgentId";


                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentMaster.AgentId);
                    command.Parameters.AddWithValue("@IsDeleted", agentMaster.IsDeleted);
                    command.Parameters.AddWithValue("@nvcRemarks", agentMaster.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", agentMaster.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", agentMaster.IntUpdatedBy);
                    connection.Open();
                    int rowAffected = command.ExecuteNonQuery();
                    return rowAffected;
                }

            }
        }
        public int UpdateIsActiveData(AgentMaster agentMaster)
        {
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "update AgentMaster set IsActive=@IsActive,nvcRemarks=@nvcRemarks,dtmUpdatedOn=@dtmUpdatedOn,intUpdatedBy=@intUpdatedBy where intAgentId=@intAgentId";


                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intAgentId", agentMaster.AgentId);
                    command.Parameters.AddWithValue("@IsActive", agentMaster.IsActive);
                    command.Parameters.AddWithValue("@nvcRemarks", agentMaster.Remarks);
                    command.Parameters.AddWithValue("@dtmUpdatedOn", agentMaster.DtmUpdationDate);
                    command.Parameters.AddWithValue("@intUpdatedBy", agentMaster.IntUpdatedBy);
                    connection.Open();
                    int rowAffected = command.ExecuteNonQuery();
                    return rowAffected;
                }

            }
        }
    }
}
