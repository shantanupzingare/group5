﻿using Microsoft.EntityFrameworkCore;
using LoginSignupCore.Models;
using Microsoft.EntityFrameworkCore.Design;
using LoginSignupCore.Global;

namespace LoginSignupCore.Data
{
	public class ApplicatonDBContext:DbContext
	{
		public ApplicatonDBContext(DbContextOptions<ApplicatonDBContext> Options):base(Options)
		{
		}

		public DbSet<RegisterViewModel> Accounts { get; set; }

        public DbSet<AlertThreshold> AlertThresholds { get; set; }

		public DbSet<ComponentMaster> ComponentMasters { get; set; }

		public DbSet<ComponentParameter> ComponentParameters { get; set; }

		public DbSet<InstanceMaster> InstanceMasters { get; set; }

        public DbSet<AgentSiteMonitoringData> AgentSiteMonitoringDatas { get; set; }

        public DbSet<BrokerMaster> BrokerMasters { get; set; }

        public DbSet<BrokerSites> BrokerSitess { get; set; }

        public virtual DbSet<AgentSiteMonitoringData> AgentSiteMonitoringData { get; set; }

        public virtual DbSet<BrokerMaster> BrokerMaster { get; set; }

        public virtual DbSet<BrokerSites> BrokerSites { get; set; }

        public virtual DbSet<VwComponentInstanceBrokerWiseData> VwComponentInstanceBrokerWiseData { get; set; }

        public virtual DbSet<VwInfoStatsData> VwInfoStatsData { get; set; }

        public virtual DbSet<VwComponentParameter> VwComponentParameter { get; set; }

        public virtual DbSet<VwAlertThreshold> VwAlertThreshold { get; set; }

        public virtual DbSet<VwInstanceMaster> VwInstanceMaster { get; set; }

        public virtual DbSet<CTCLTimer> CTCLTimer { get; set; }

        public virtual DbSet<InfoMaster> InfoMaster { get; set; }

        public virtual DbSet<InfoStatistics> InfoStatistics { get; set; }

        public virtual DbSet<BrokerSiteCredentials> BrokerSiteCredentials { get; set; }

        public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<ApplicatonDBContext>
		{
			public ApplicatonDBContext CreateDbContext(string[] args)
			{
				var optionsBuilder = new DbContextOptionsBuilder<ApplicatonDBContext>();
                optionsBuilder.UseSqlServer(Config.connectionString);


                return new ApplicatonDBContext(optionsBuilder.Options);
			}
		}
	}
}




