﻿using LoginSignupCore.Global;
using LoginSignupCore.Models;
using System.Data.SqlClient;

namespace LoginSignupCore.Data
{
    public class BrokerRepository
    {
        public BrokerMaster GetBrokerById(int id)
        {
            var broker = new BrokerMaster();
            using (var connection = new SqlConnection(Config.connectionString))
            {
                string query = "Select id, isnull(NvcBrokerName,'') NvcBrokerName, IsActive  from BrokerMaster where id = @id";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            broker.Id = reader.GetInt32(reader.GetOrdinal("id"));
                            broker.NvcBrokerName = reader.GetString(reader.GetOrdinal("NvcBrokerName"));
                            broker.IsActive = reader.GetInt32(reader.GetOrdinal("IsActive"));
                        }
                    }
                }

            }
            return broker;
        }
    }
}
