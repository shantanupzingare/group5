﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using LoginSignupCore.Global;
using LoginSignupCore.Models;
using System.Data.SqlClient;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace LoginSignupCore.Data
{
    public class FileRepository
    {
        private readonly string _connectionString = Config.connectionString;

        public List<FileMaster> GetAllFiles()
        {
            var file = new List<FileMaster>();
            using (var connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT intId,intSegmentId,intFileType,nvcFileName,intPriority,isUploadBeforeBod,isActive,isDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy from FileInfoMaster where isDeleted = 0";
                using (var cmd = new SqlCommand(query, connection))
                {
                    connection.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FileMaster fileMaster = new FileMaster();
                            fileMaster.id = reader.GetInt32(reader.GetOrdinal("intId"));
                            fileMaster.SegmentId = (CTCL_ExchangeIdentifier)reader.GetInt32(reader.GetOrdinal("intSegmentId"));
                            fileMaster.FileType = reader.GetInt32(reader.GetOrdinal("intFileType"));
                            fileMaster.FileName = reader.GetString(reader.GetOrdinal("nvcFileName"));
                            fileMaster.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            fileMaster.UploadBeforeBod = reader.GetBoolean(reader.GetOrdinal("isUploadBeforeBod"));
                            fileMaster.isActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("isActive")));
                            fileMaster.isDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("isDeleted")));
                            fileMaster.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            fileMaster.IntCreatedOn = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            fileMaster.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));
                            file.Add(fileMaster);
                        }
                    }

                }
            }
            return file;
        }

        public FileMaster GetFileById(int id)
        {
            var fileMaster = new FileMaster();
            using (var connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT intId,intSegmentId,intFileType,nvcFileName,intPriority,nvcDestinationPath,isUploadBeforeBod,isActive,isDeleted,nvcRemarks,dtmCreatedOn,intCreatedBy from FileInfoMaster where intId = @intId";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@intId", id);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            fileMaster.id = reader.GetInt32(reader.GetOrdinal("intId"));
                            fileMaster.SegmentId = (CTCL_ExchangeIdentifier)reader.GetInt32(reader.GetOrdinal("intSegmentId"));
                            fileMaster.FileType = reader.GetInt32(reader.GetOrdinal("intFileType"));
                            fileMaster.FileName = reader.GetString(reader.GetOrdinal("nvcFileName"));
                            fileMaster.Priority = reader.GetInt32(reader.GetOrdinal("intPriority"));
                            fileMaster.nvcDestinationPath = reader.GetString(reader.GetOrdinal("nvcDestinationPath"));
                            fileMaster.UploadBeforeBod = reader.GetBoolean(reader.GetOrdinal("isUploadBeforeBod"));
                            fileMaster.isActive = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("isActive")));
                            fileMaster.isDeleted = Convert.ToInt32(reader.GetBoolean(reader.GetOrdinal("isDeleted")));
                            fileMaster.Remarks = reader.GetString(reader.GetOrdinal("nvcRemarks"));
                            fileMaster.IntCreatedOn = reader.GetDateTime(reader.GetOrdinal("dtmCreatedOn"));
                            fileMaster.IntCreatedBy = reader.GetInt32(reader.GetOrdinal("intCreatedBy"));

                        }
                    }
                }

            }
            return fileMaster;
        }
        public void InsertFiles(FileMaster fileMaster)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                string query = "Insert Into FileInfoMaster(intSegmentId,intFileType,nvcFileName,intPriority,isUploadBeforeBod,nvcDestinationPath,isActive,isDeleted,nvcRemarks" +
                    ",dtmCreatedOn,intCreatedBy) Values " +
                    "(@intSegmentId,@intFileType,@nvcFileName,@intPriority,@isUploadBeforeBod,@nvcDestinationPath,@isActive,@isDeleted,@nvcRemarks,@dtmCreatedOn" +
                    ",@intCreatedBy)";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@intSegmentId", fileMaster.SegmentId);
                    cmd.Parameters.AddWithValue("@intFileType", fileMaster.FileType);
                    cmd.Parameters.AddWithValue("@nvcFileName", fileMaster.FileName);
                    cmd.Parameters.AddWithValue("@intPriority", fileMaster.Priority);
                    cmd.Parameters.AddWithValue("@isUploadBeforeBod", fileMaster.UploadBeforeBod);
                    cmd.Parameters.AddWithValue("@nvcDestinationPath", fileMaster.nvcDestinationPath);
                    cmd.Parameters.AddWithValue("@isActive", fileMaster.isActive);
                    cmd.Parameters.AddWithValue("@isDeleted", fileMaster.isDeleted);
                    cmd.Parameters.AddWithValue("@nvcRemarks", fileMaster.Remarks);
                    cmd.Parameters.AddWithValue("@dtmCreatedOn", fileMaster.IntCreatedOn);
                    cmd.Parameters.AddWithValue("@intCreatedBy", fileMaster.IntCreatedBy);
                    connection.Open();
                    cmd.ExecuteNonQuery();

                }
            }
        }

        public int Delete(FileMaster fileMaster)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("Update  FileInfoMaster Set isDeleted = @isDeleted,nvcRemarks =@nvcRemarks,dtmUpdatedOn =@dtmUpdatedOn,intUpdatedBy =@intUpdatedBy Where intId = @intId", conn);

                cmd.Parameters.AddWithValue("@intId", fileMaster.id);
                cmd.Parameters.AddWithValue("@isDeleted", fileMaster.isDeleted);
                cmd.Parameters.AddWithValue("@nvcRemarks", fileMaster.Remarks);
                cmd.Parameters.AddWithValue("@dtmUpdatedOn", fileMaster.UpdatedOn);
                cmd.Parameters.AddWithValue("@intUpdatedBy", fileMaster.UpdatedBy);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
        }


        public int UpdateIsActiveData(FileMaster fileMaster)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("Update  FileInfoMaster Set isActive = @isActive,nvcRemarks =@nvcRemarks,dtmUpdatedOn =@dtmUpdatedOn,intUpdatedBy =@intUpdatedBy Where intId = @intId", conn);

                cmd.Parameters.AddWithValue("@intId", fileMaster.id);
                cmd.Parameters.AddWithValue("@isActive", fileMaster.isActive);
                cmd.Parameters.AddWithValue("@nvcRemarks", fileMaster.Remarks);
                cmd.Parameters.AddWithValue("@dtmUpdatedOn", fileMaster.UpdatedOn);
                cmd.Parameters.AddWithValue("@intUpdatedBy", fileMaster.UpdatedBy);
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
        }

        public void Update(FileMaster fileMaster)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                string query = "Update FileInfoMaster SET nvcFileName = @nvcFileName,nvcDestinationPath = @nvcDestinationPath, isActive =@isActive,dtmUpdatedOn =@dtmUpdatedOn" +
                    ",intUpdatedBy = @intUpdatedBy ,nvcRemarks =@nvcRemarks WHERE intId = @intId ";
                using (var cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("intid", fileMaster.id);
                    cmd.Parameters.AddWithValue("@nvcFileName", fileMaster.FileName);
                    cmd.Parameters.AddWithValue("@nvcDestinationPath", fileMaster.nvcDestinationPath);
                    cmd.Parameters.AddWithValue("@isActive", fileMaster.isActive);
                    cmd.Parameters.AddWithValue("@dtmUpdatedOn", fileMaster.UpdatedOn);
                    cmd.Parameters.AddWithValue("@intUpdatedBy", fileMaster.UpdatedBy);
                    cmd.Parameters.AddWithValue("@nvcRemarks", fileMaster.Remarks);
                    connection.Open();
                    cmd.ExecuteNonQuery();

                }
            }

        }

    }
}
