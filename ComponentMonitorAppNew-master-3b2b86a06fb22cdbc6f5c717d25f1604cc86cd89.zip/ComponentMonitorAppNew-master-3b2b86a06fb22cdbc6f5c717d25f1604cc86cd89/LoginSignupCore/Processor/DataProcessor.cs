﻿using CTCL.BinaryProtocol.Common.CTCL;
using System.Runtime.InteropServices;
using Response = BinaryProtocol.Common.Response;
using StatusCode = BinaryProtocol.Common.StatusCode;
using CTCL_OpCode = CTCL.BinaryProtocol.Common.CTCL.Enum.CTCL_OpCode;
using CMA_OpCode = CTCL.BinaryProtocol.Common.CMA.Enum.CMA_OpCode;
using CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels;
using LoginSignupCore.Global;
using Utility;

namespace LoginSignupCore.Processor
{
    public class DataProcessor
    {
        Conversion conversion;
        CMA_InfoMasterMessageProcessor infoMasterMessageProcessor;
        CMA_InfoStatisticsMessageProcessor infoStatisticsMessageProcessor;

        public DataProcessor()
        {
            conversion = new Conversion();
            infoMasterMessageProcessor = new CMA_InfoMasterMessageProcessor();
            infoStatisticsMessageProcessor = new CMA_InfoStatisticsMessageProcessor();
        }

        public Response SourceComp_DataProcess(byte[] ValidPacket)
        {
            Response response = new Response();
            try
            {
                if (ValidPacket != null && ValidPacket.Length != 0)
                {
                    CTCL_MessageHeader msgOrderInfoObj1 = conversion.FromBytesToObject<CTCL_MessageHeader>(ValidPacket);
                    //var opcode = BitConverter.ToInt32(ValidPacket, 0);
                    Console.WriteLine($"{msgOrderInfoObj1.OpCode}");
                    switch (msgOrderInfoObj1.OpCode)
                    {
                        case (CTCL_OpCode)CMA_OpCode.INFO_MASTER_FOR_DB:
                            if (IsDataValid<InfoMaster>(ValidPacket))
                            {
                                InfoMaster entity = conversion.FromBytesToObject<InfoMaster>(ValidPacket);
                                response = infoMasterMessageProcessor.processInfoMasterData(entity);
                            }
                            else
                            {
                                response = response.Set(StatusCode.Failure, "Request Type & bytes of data doesn't match (Invalid data) OpCode ->" + msgOrderInfoObj1.OpCode.ToString(), null);
                            }
                            break;

                        case (CTCL_OpCode)CMA_OpCode.INFO_STATISTICS_FOR_DB:
                            if (IsDataValid<InfoStatistics>(ValidPacket))
                            {
                                InfoStatistics entity = conversion.FromBytesToObject<InfoStatistics>(ValidPacket);
                                response = infoStatisticsMessageProcessor.processInfoStatisticsData(entity);
                            }
                            else
                            {
                                response = response.Set(StatusCode.Failure, "Request Type & bytes of data doesn't match (Invalid data) OpCode ->" + msgOrderInfoObj1.OpCode.ToString(), null);
                            }
                            break;

                        default:
                            response = response.Set(StatusCode.Failure, "Request type is not valid transcode ->" + msgOrderInfoObj1.OpCode + DateTime.UtcNow, msgOrderInfoObj1.OpCode.ToString());
                            break;
                    }
                }
                else
                {
                    response = response.Set(StatusCode.Failure, "Invalid bytes of Data or Data is Null or byte Array is empty. DateTime->" + DateTime.UtcNow);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "exception in coreprocess dataprocess");
            }
            return response;
        }

        private bool IsDataValid<T>(byte[] data)
        {
            int size = Marshal.SizeOf<T>();
            int sizeOfArray = data.Length;
            Log.Debug(null, "Bytelength: " + sizeOfArray);
            Log.Debug(null, "Structlength: " + size);
            return sizeOfArray == size;
        }


    }
}

