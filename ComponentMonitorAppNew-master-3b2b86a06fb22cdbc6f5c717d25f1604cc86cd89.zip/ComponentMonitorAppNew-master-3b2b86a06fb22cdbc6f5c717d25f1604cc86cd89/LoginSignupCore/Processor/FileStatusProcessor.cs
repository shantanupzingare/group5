﻿using BinaryProtocol.Common;
using LoginSignupCore.Global;
using LoginSignupCore.Models.Response;
using System.Data;
using System.Data.SqlClient;

namespace LoginSignupCore.Processor
{
    public class FileStatusProcessor
    {
        private SqlConnection PersistSqlConn;
        private SqlTransaction tran;

        public Response ProcessFileStatusData(FileStatus fileStatus)
        {
            Response response = new Response();
            try
            {
                DataTable dt = new DataTable();
                // Adding Columns
                //
                DataColumn COLUMN = new DataColumn();
                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intBrokerId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intSiteId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intAgentId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intFileType";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intSegment";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "nvcFileName";
                COLUMN.DataType = typeof(string);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmUploadedOn";
                COLUMN.DataType = typeof(DateTime);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "bitIsSucessStatus";
                COLUMN.DataType = typeof(bool);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "nvcRemarks";
                COLUMN.DataType = typeof(string);

                dt.Columns.Add(COLUMN);

                DataRow DR = dt.NewRow();
                DR[0] = fileStatus.BrokerId;
                DR[1] = fileStatus.SiteId;
                DR[2] = fileStatus.AgentId;
                DR[3] = fileStatus.FileType;
                DR[4] = fileStatus.Segment;
                DR[5] = fileStatus.FileName;
                DR[6] = fileStatus.TimeStamp;
                DR[7] = fileStatus.IsSucessStatus;
                DR[8] = fileStatus.Message;
                dt.Rows.Add(DR);

                if (PersistSqlConn == null || PersistSqlConn.State != ConnectionState.Open)
                {
                    PersistSqlConn = new SqlConnection(Config.connectionString);
                    PersistSqlConn.Open();
                }

                using (tran = PersistSqlConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                {
                    using (SqlConnection con = new SqlConnection(Config.connectionString))
                    {
                        using SqlCommand cmd = new SqlCommand("[dbo].[usp_FileStatus_ins]");
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@FileStatus", dt);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    tran.Commit();
                }
                Log.Info("FileStatus data saved to Database ");
                return response.Set((BinaryProtocol.Common.StatusCode)StatusCode.Success, "FileStatus Data uploaded Sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "FileStatus data couldn't save  to Database ");
                return response.Set(StatusCode.Failure, "Error Occured at FileStatus Data Insert :" + ex.Message);
            }
        }
    }
}
