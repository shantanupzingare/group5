﻿//using ConsumerDBComponent.Common;
using CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels;
using System.Data;
using System.Data.SqlClient;
using Response = BinaryProtocol.Common.Response;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Log = LoginSignupCore.Global.Log;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using LoginSignupCore.Global;
//using InfoMaster = LoginSignupCore.Models.InfoMaster;

namespace LoginSignupCore.Processor
{
    public class CMA_InfoMasterMessageProcessor
    {
        private SqlConnection? PersistSqlConn;
        private SqlTransaction? tran;
        public Response processInfoMasterData(InfoMaster infoMasterMasterObj)
        {
            CTCL_CommonMasterAttributes cTCL_CommonMasterAttributes = new CTCL_CommonMasterAttributes();
            Response response = new Response();
            try
            {
                DataTable dt = new DataTable();
                // Adding Columns
                //
                DataColumn COLUMN = new DataColumn();
                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intBrokerId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intSiteId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intComponentId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intInstanceId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intParamId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "ParamAttribute";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "BrokerSiteInstanceId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intUpdatedBy";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmUpdatedOn";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmTimeSTamp";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                DataRow DR = dt.NewRow();
                DR[0] = infoMasterMasterObj.BrokerId.BrokerID;
                DR[1] = infoMasterMasterObj.SiteId.SiteId;
                DR[2] = infoMasterMasterObj.ComponentId.ComponentId;
                DR[3] = infoMasterMasterObj.InstanceId.InstanceID;
                DR[4] = infoMasterMasterObj.ParamId.ParamID;
                DR[5] = infoMasterMasterObj.ParamAttribute.ParamAttribute;
                DR[6] = infoMasterMasterObj.BrokerSiteInstanceId.BrokerSiteInstanceID;
                DR[7] = cTCL_CommonMasterAttributes.LastUpdatedBy.id;
                DR[8] = cTCL_CommonMasterAttributes.LastUpdatedTime.TimeStamp;
                //DR[9] = infoMasterMasterObj.dtmTimeStamp;
                dt.Rows.Add(DR);

                if (PersistSqlConn == null || PersistSqlConn.State != ConnectionState.Open)
                {
                    PersistSqlConn = new SqlConnection(Config.connectionString);
                    PersistSqlConn.Open();
                }

                using (tran = PersistSqlConn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    using (SqlConnection con = new SqlConnection(Config.connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("[dbo].[usp_InfoMaster_insupd]"))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Connection = con;
                            cmd.Parameters.AddWithValue("@InfoMaster", dt);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    tran.Commit();
                }
                Log.Info(" Info Master data saved to Database ");
                return response.Set(StatusCode.Success, "Info Master Data uploaded Sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error(ex, " Info Master data couldn't save  to Database ");
                return response.Set(StatusCode.Failure, "Error Occured at Info Master Data Insert :" + ex.Message);
            }
        }

    }
}
