﻿using CTCL.BinaryProtocol.Common.CMA.DBWrite.EntityModels;
using CTCL.BinaryProtocol.Common.CTCL.DBWrite.EntityModels;
using System.Data;
using System.Data.SqlClient;
using Response = BinaryProtocol.Common.Response;
using StatusCode = BinaryProtocol.Common.StatusCode;
using Log = LoginSignupCore.Global.Log;
using LoginSignupCore.Global;

namespace LoginSignupCore.Processor
{
    public class CMA_InfoStatisticsMessageProcessor
    {
        CTCL_CommonMasterAttributes cTCL_CommonMasterAttributes = new CTCL_CommonMasterAttributes();

        private SqlConnection? PersistSqlConn;
        private SqlTransaction? tran;
        public Response processInfoStatisticsData(InfoStatistics infoMasterStatisticsObj)
        {
            Response response = new Response();
            try
            {
                DataTable dt = new DataTable();
                // Adding Columns
                //
                DataColumn COLUMN = new DataColumn();
                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intBrokerId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intSiteId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intComponentId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intInstanceId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intParamId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "nvcReference";
                COLUMN.DataType = typeof(char);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "nvcValue";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intUpdatedBy";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmUpdatedOn";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmTimeSTamp";
                COLUMN.DataType = typeof(long);
                dt.Columns.Add(COLUMN);

                DataRow DR = dt.NewRow();
                DR[0] = infoMasterStatisticsObj.BrokerId.BrokerID;
                DR[1] = infoMasterStatisticsObj.SiteId.SiteId;
                DR[2] = infoMasterStatisticsObj.ComponentId.ComponentId;
                DR[3] = infoMasterStatisticsObj.InstanceId.InstanceID;
                DR[4] = infoMasterStatisticsObj.ParamId.ParamID;
                DR[5] = infoMasterStatisticsObj.Reference.References;
                DR[6] = infoMasterStatisticsObj.nvcValue.Value;
                DR[7] = cTCL_CommonMasterAttributes.LastUpdatedBy.id;
                DR[8] = cTCL_CommonMasterAttributes.LastUpdatedTime.TimeStamp;
                DR[9] = infoMasterStatisticsObj.dtmTimeStamp;
                dt.Rows.Add(DR);

                if (PersistSqlConn == null || PersistSqlConn.State != ConnectionState.Open)
                {
                    PersistSqlConn = new SqlConnection(Config.connectionString);
                    PersistSqlConn.Open();
                }

                using (tran = PersistSqlConn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    using (SqlConnection con = new SqlConnection(Config.connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("[dbo].[usp_InfoStatistics_insupd]"))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Connection = con;
                            cmd.Parameters.AddWithValue("@InfoStatistics", dt);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    tran.Commit();
                }
                Log.Info("Info Statistics data saved to Database ");
                return response.Set(StatusCode.Success, "Info Statistics Data uploaded Sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Info Statistics data couldn't save  to Database ");
                return response.Set(StatusCode.Failure, "Error Occured at Info Statistics Data Insert :" + ex.Message);
            }
        }

    }
}
