﻿using Utility.Queueing;
using BinaryProtocol.Common;
using LoginSignupCore.Models.Others;
using Newtonsoft.Json;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using LoginSignupCore.Models.Response;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Core;
using Org.BouncyCastle.Ocsp;
using LoginSignupCore.Models.Request;

namespace LoginSignupCore.Processor
{
	public class DBProcessor
	{
		private ProcessQueue<string> processQueue;
		Thread thread;
		FileStatusProcessor fileStatusProcessor;
        ComponentStatusProcessor componentStatusProcessor;
        CompTechnicalInfoProcessor compTechnicalInfoProcessor;
		ManualResetEvent _mre;
        Thread techInfoThread;

        public DBProcessor()
		{
			fileStatusProcessor = new();
			componentStatusProcessor = new();
			compTechnicalInfoProcessor = new();
			_mre= new ManualResetEvent(false);
            processQueue = new();
            DrainerThreadInit();
   //         techInfoThread = new(new ThreadStart(ProcessCompTechMre));
			//techInfoThread.Start();
        }

		private void DrainerThreadInit()
		{
			thread = new Thread(new ThreadStart(DrainerMethod));
			thread.Start();
		}
		public Response Enqueue(string message)
		{
			return processQueue.Enqueue(message);	
		}
		private void DrainerMethod()
		{
			while (true)
			{
				if (processQueue.TryDequeue(out string message))
				{
					try
					{
						ProcessMessage(message);
					}
					catch (Exception ex)
					{
						Log.Error($"Error while DrainerMethod in DbProcessor | {ex.Message}");
					}
				}
			}
		}
		private void ProcessMessage(string message)
		{
            var baseResponse = JsonConvert.DeserializeObject<MsgHeader>(message);
            if (baseResponse != null)
			{
                var opcode = (CMA_OpCode)baseResponse.MessageCode;
                switch (opcode)
				{
                    case CMA_OpCode.COMPONENT_STATE_UPDATE:
                        {
                            var compStatus = JsonConvert.DeserializeObject<ComponentStatus>(message);
                            if (compStatus != null)
                            {
								componentStatusProcessor.ProcessComponentStatusData(compStatus);
                            }
                            else
                            {
                                Log.Error($"Error while writing COMPONENT_STATE_UPDATE in db");
                            }
                        }
                        break;

                    case CMA_OpCode.FILE_UPLOAD_CONFIRMATION:
                        {
                            var fileStatus = JsonConvert.DeserializeObject<FileStatus>(message);
                            if (fileStatus != null)
                            {
								fileStatusProcessor.ProcessFileStatusData(fileStatus);
                            }
                            else
                            {
                                Log.Error($"Error while writing FILE_UPLOAD_CONFIRMATION in db");
                            }
                        }
                        break;

                    case CMA_OpCode.CMA_TECHNICAL_PARAM_REQ:
                        {
                            var techInfo = JsonConvert.DeserializeObject<ComponentTechincalInfo>(message);
                            if (techInfo != null)
                            {
                                var resp = IsWriteInDb(techInfo);
                                if (resp.Item1)
                                {
                                    var info = CoreProcess.agentSessionCache.GetTechnicalInfo(resp.Item2);
                                    if(info.Item1 && info.Item2 != null)
                                    {
                                        //info.Item2.Timestamp = DateTime.Now.Date;
                                        compTechnicalInfoProcessor.ProcessComponentTechnicalInfoData(info.Item2);
                                    }
                                }
                            }
                            else
                            {
                                Log.Error($"Error while writing CMA_TECHNICAL_PARAM_REQ in db");
                            }
                        }
                        break;

                    default:
                        break;
                }

            }

        }

        private (bool, CompInitReq) IsWriteInDb(ComponentTechincalInfo componentsTechnicalInfo)
        {
            CompInitReq compInitReq = new()
            {
                AgentId = componentsTechnicalInfo.AgentId,
                BrokerId = componentsTechnicalInfo.BrokerId,
                SiteId = componentsTechnicalInfo.SiteId,
                CompId = componentsTechnicalInfo.ComponentType,
                InstanceId = componentsTechnicalInfo.InstanceId
            };

            var res = CoreProcess.agentSessionCache.GetComponentMaster(compInitReq);
            if(res.Item1 && res.Item2 != null)
            {
                double cpuThreshold = res.Item2.CpuThresholdLimit;
                double ramThreshold = res.Item2.RamThresholdLimit;

                if (cpuThreshold <= componentsTechnicalInfo.CPUPercentage || ramThreshold <= componentsTechnicalInfo.RAMUsage)
                    return (true, compInitReq);
            }
            return (false, compInitReq);
        }
        //private void ProcessCompTechMre()
        //{
        //	while(true)
        //	{
        //		_mre.WaitOne(60000);
        //		List<ComponentsTechnicalInfo> list = CoreProcess.agentSessionCache.GetTechnicalInfo();
        //		foreach(var item in list)
        //      {
        //			ProcessComponentTechnicalInfo(item);
        //      }
        //	}
        //}
        //      private void ProcessComponentTechnicalInfo(ComponentsTechnicalInfo componentsTechnicalInfo)
        //{
        //          compTechnicalInfoProcessor.ProcessComponentTechnicalInfoData(componentsTechnicalInfo);
        //      }
    }
}
