﻿using BinaryProtocol.Common;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using System.Data;
using System.Data.SqlClient;

namespace LoginSignupCore.Processor
{
    public class CompTechnicalInfoProcessor
    {
        private SqlConnection PersistSqlConn;
        private SqlTransaction tran;

        public Response ProcessComponentTechnicalInfoData(ComponentsTechnicalInfo compTechncialInfo)
        {
            Response response = new Response();
            try
            {
                DataTable dt = new DataTable();
                // Adding Columns
                //
                DataColumn COLUMN = new DataColumn();
                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intBrokerId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intSiteId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intAgentId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intComponentId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "intInstanceId";
                COLUMN.DataType = typeof(int);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numRamUtilization";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numCpuUtilization";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numCpuHigh";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numCpuLow";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numRamHigh";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "numRamLow";
                COLUMN.DataType = typeof(double);
                dt.Columns.Add(COLUMN);

                COLUMN = new DataColumn();
                COLUMN.ColumnName = "dtmUpdatedOn";
                COLUMN.DataType = typeof(string);

                dt.Columns.Add(COLUMN);

                DataRow DR = dt.NewRow();
                DR[0] = compTechncialInfo.BrokerId;
                DR[1] = compTechncialInfo.SiteId;
                DR[2] = compTechncialInfo.AgentId;
                DR[3] = compTechncialInfo.ComponentId;
                DR[4] = compTechncialInfo.InstanceId;
                DR[5] = compTechncialInfo.RAMUtilization;
                DR[6] = compTechncialInfo.CPUUtilization;
                DR[7] = compTechncialInfo.CPUHigh;
                DR[8] = compTechncialInfo.CPULow;
                DR[9] = compTechncialInfo.RAMHigh;
                DR[10] = compTechncialInfo.RAMLow;
                DR[11] = compTechncialInfo.Timestamp;
                dt.Rows.Add(DR);

                if (PersistSqlConn == null || PersistSqlConn.State != ConnectionState.Open)
                {
                    PersistSqlConn = new SqlConnection(Config.connectionString);
                    PersistSqlConn.Open();
                }

                using (tran = PersistSqlConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                {
                    using (SqlConnection con = new SqlConnection(Config.connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("[dbo].[usp_CompTechnicalInfo_ins]"))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Connection = con;
                            cmd.Parameters.AddWithValue("@CompTechnicalInfo", dt);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();

                        }
                    }
                    tran.Commit();
                }
                Log.Info("CompTechnicalInfo data saved to Database ");
                return response.Set((BinaryProtocol.Common.StatusCode)StatusCode.Success, "CompTechnicalInfo Data uploaded Sucessfully");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "CompTechnicalInfo data couldn't save  to Database ");
                return response.Set(StatusCode.Failure, "Error Occured at CompTechnicalInfo Data Insert :" + ex.Message);
            }
        }
    }
}
