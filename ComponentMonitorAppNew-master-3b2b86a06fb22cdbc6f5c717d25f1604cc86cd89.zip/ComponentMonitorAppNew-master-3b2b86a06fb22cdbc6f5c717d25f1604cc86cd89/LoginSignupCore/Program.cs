using LoginSignupCore.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using LoginSignupCore;
using LoginSignupCore.Global;
using LoginSignupCore.Core;

var builder = WebApplication.CreateBuilder(args);
new exitHook();
// Add services to the container.
builder.Services.AddHostedService<Worker>(services => new Worker());
builder.Services.AddSingleton<IHostLifetime, NoopConsoleLifetime>();
builder.Services.AddControllersWithViews();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
	options.IdleTimeout = TimeSpan.FromMinutes(20);
});

builder.Services.AddSession(options=>
{
	options.IOTimeout= TimeSpan.FromMinutes(30);
	options.Cookie.HttpOnly= true;
	options.Cookie.IsEssential= true;
});
builder.Services.AddAuthentication(
	CookieAuthenticationDefaults.AuthenticationScheme)
	.AddCookie(option => {
		option.LoginPath = "/Account/Login"; 
		option.ExpireTimeSpan = TimeSpan.FromMinutes(20);
	});

builder.Services.AddDbContext<ApplicatonDBContext>(
	options => { options.UseSqlServer(Config.connectionString); }
	);
var app = builder.Build();

app.UseSession();


// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
	//app.UseExceptionHandler("/Home/Error");
	//// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
	//app.UseHsts();
//}

//app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
	name: "default",
	pattern: "{controller=Account}/{action=Login}/{id?}");

Config.GetConfigurationSettings();
app.Urls.Add(Config.AppUrl);
app.Run();






