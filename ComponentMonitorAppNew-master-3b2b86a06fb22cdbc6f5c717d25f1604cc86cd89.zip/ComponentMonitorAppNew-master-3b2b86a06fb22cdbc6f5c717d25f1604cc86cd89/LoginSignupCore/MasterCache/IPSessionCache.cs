﻿using CTCL.CacheManagement.Helper;
using System.Collections.Concurrent;

namespace LoginSignupCore.MasterCache
{
    public class IPSessionCache
    {
        private ConcurrentDictionary<IpInfo, AgentSessionInfo> _ipWiseCache;
        public IPSessionCache()
        {
            _ipWiseCache = new();
        }
        public void AddOrUpdate(AgentSessionInfo agentSessionInfo)
        {
            IpInfo ip = new() { ipInfo = agentSessionInfo.IP };
            if (!_ipWiseCache.TryGetValue(ip, out AgentSessionInfo agentSession))
            {
                agentSession = new();
                _ipWiseCache.TryAdd(ip, agentSession);
            }
            CacheUpdateHelper.UpdateObjectReference(agentSessionInfo, agentSession);
        }
        public (bool, AgentSessionInfo) Get(string ip)
        {
            IpInfo iP = new() { ipInfo = ip };
            if (_ipWiseCache.TryGetValue(iP, out AgentSessionInfo agentSessionInfo) && agentSessionInfo != null)
            {
                return (true, agentSessionInfo);
            }
            return (false, null);
        }
    }
    public struct IpInfo
    {
        public string ipInfo;
    }
}
