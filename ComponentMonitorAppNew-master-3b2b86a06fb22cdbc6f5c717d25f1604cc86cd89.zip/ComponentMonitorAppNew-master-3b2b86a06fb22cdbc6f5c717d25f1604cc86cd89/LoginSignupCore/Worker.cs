﻿using CTCL.Utility;
using LoginSignupCore.Core;

namespace LoginSignupCore
{
    public class Worker : BackgroundService
    {
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await CoreProcess.Initialize();
            new ConsoleHelper();
        }

        /// <summary>
        /// Executes when the service is ready to start.
        /// </summary>
        /// <param name="cancellationToken"><see cref="CancellationToken"/></param>
        /// <returns><see cref="Task"/></returns>
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            return base.StartAsync(cancellationToken);
        }
    }
    public class NoopConsoleLifetime : IHostLifetime, IDisposable
    {
        private readonly ILogger<NoopConsoleLifetime> _logger;

        public NoopConsoleLifetime(ILogger<NoopConsoleLifetime> logger)
        {
            _logger = logger;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        public Task WaitForStartAsync(CancellationToken cancellationToken)
        {
            Console.CancelKeyPress += OnCancelKeyPressed;
            return Task.CompletedTask;
        }

        private void OnCancelKeyPressed(object? sender, ConsoleCancelEventArgs e)
        {
            _logger.LogInformation("Ctrl+C has been pressed, ignoring.");
            e.Cancel = true;
        }

        public void Dispose()
        {
            Console.CancelKeyPress -= OnCancelKeyPressed;
        }
    }
    public class ConsoleHelper : exitHook
    {
        public ConsoleHelper()
        {
            new Thread(Process).Start();
        }

        private void Process()
        {
            while (true)
            {
                Console.WriteLine("Enter Your Choice");
                var choice = GetChoice();
                switch (choice)
                {
                    case -1:
                        exitHookInit();
                        break;
                    default:
                        Console.WriteLine("Wrong Choice");
                        break;
                }
            }
        }

        private int GetChoice()
        {
            try
            {
                var res = Convert.ToInt32(Console.ReadLine());
                return res;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Plz enter a number only");
                return GetChoice();
            }
        }
        private void exitHookInit()
        {
            string strExitconfirm;
            Console.WriteLine("Are you sure you want to exit y/n ");
            strExitconfirm = Console.ReadLine();
            if (strExitconfirm?.ToLower() == "y")
            {
                Environment.Exit(0);
            }
            else
            {
                // ask();
            }
        }
    }
}
