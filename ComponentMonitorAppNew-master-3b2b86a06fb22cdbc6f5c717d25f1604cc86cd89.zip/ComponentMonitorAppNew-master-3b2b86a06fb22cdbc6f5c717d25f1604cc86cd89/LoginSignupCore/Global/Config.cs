﻿using BinaryProtocol.Common;
using DBHelper.Common;
using System.Data;

namespace LoginSignupCore.Global
{
    public class Config
    {
        public static string logfile;
        public static int logLevel;
        public static int logFileCount;
        public static string connectionString;
        public static long Id;
        public static string AppUrl;
        public static string WebSocketUrl;
        public static int dbTimeOut;

        static Config()
        {
            logfile = AppSettingHelper.Configuration["LogFile"];
            logLevel = Convert.ToInt32(AppSettingHelper.Configuration["LogLevel"]);
            logFileCount = Convert.ToInt32(AppSettingHelper.Configuration["LogFileCount"]);
            connectionString = AppSettingHelper.Configuration["ConnectionStrings:DBCTCL"];
            dbTimeOut = Convert.ToInt32(AppSettingHelper.Configuration["DBTimeOut"]);
        }
        public static void GetConfigurationSettings()
        {
            DatabaseHelper db;
            using (db = new DatabaseHelper(connectionString, DataProviders.SqlServer))
            {
                var dr = db.ExecuteReader("usp_GetConfigurationSettings", CommandType.StoredProcedure, Config.dbTimeOut);
                if (dr == null)
                {
                    return;
                }

                while (dr.Read())
                {
                    if ("APIIP" == dr[2].ToString())
                    {
                        AppUrl = dr["ConfigurationValue"].ToString();
                    }
                    else if("WSIP" == dr[2].ToString())
                    {
                        WebSocketUrl = dr["ConfigurationValue"].ToString();
                        if (WebSocketUrl != null)
                        {
                            Exchange.WebSocketServer.Global.Startup.ip = WebSocketUrl.Split(":")[1].Replace("/", "");
                            Exchange.WebSocketServer.Global.Startup.socketPort = Convert.ToInt32(WebSocketUrl.Split(":")[2]);
                        }
                    }
                }
            }
        }
    }
}
