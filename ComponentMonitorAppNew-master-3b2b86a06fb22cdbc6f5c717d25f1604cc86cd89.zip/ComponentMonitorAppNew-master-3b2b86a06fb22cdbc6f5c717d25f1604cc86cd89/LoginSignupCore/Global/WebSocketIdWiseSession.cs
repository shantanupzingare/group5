﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.CacheManagement.Helper;
using Exchange.WebSocketServer.SocketManager;
using LoginSignupCore.Core;
using System.Collections.Concurrent;
using WebSocketSessionToken = Exchange.WebSocketServer.SocketManager.WebSocketSessionToken;

namespace LoginSignupCore.Global
{
    public class WebSocketIdWiseSession
    {
        private Dictionary<WebSocketSessionToken, UserSession> dictWebsocketWiseSession;
        private ConcurrentDictionary<WebSocketSessionToken, AgentSessionWs> dictWebsocketWiseSessionNew;

        public WebSocketIdWiseSession()
        {
            dictWebsocketWiseSession = new Dictionary<WebSocketSessionToken, UserSession>();
            dictWebsocketWiseSessionNew = new();
        }

        public Response AddOrUpdateWebSocketToken(UserSession userSession)
        {
            Response response = new Response();
            try
            {
                if (userSession.WebSocketSessionToken.webSocketSessionToken != null && userSession.WebSocketSessionToken.webSocketSessionToken != "")
                {
                    lock (dictWebsocketWiseSession)
                    {
                        if (!dictWebsocketWiseSession.TryAdd(userSession.WebSocketSessionToken, userSession))
                        {
                            CTCL_TimeStamp currentTime = new(DateTime.Now.Ticks);
                            userSession.CreatedAt = currentTime;
                            userSession.UpdatedAt = currentTime;
                            dictWebsocketWiseSession[userSession.WebSocketSessionToken] = userSession;
                            return response = response.Set(StatusCode.Success, "Successfully Updated WebSocketData in Dictionary", userSession);
                        }
                        else
                        {
                            return response = response.Set(StatusCode.Success, "Successfully Added WebSocketData in Dictionary", userSession);
                        }
                    }
                }
                else
                {
                    return response = response.Set(StatusCode.OMS_Error, "WebSocket ID cannot Be Null or Empty", userSession);
                }
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occured while Adding WebSocket data in classfile OmsWebSocketToken.cs,methodname = AddOrUpdateWebSocketToken", ex);
            }
        }

        public Response RemoveWebSocketId(WebSocketSessionToken webSocketSessionToken)
        {
            Response response = new Response();
            try
            {
                lock (dictWebsocketWiseSession)
                {
                    if (dictWebsocketWiseSession.Remove(webSocketSessionToken, out UserSession removedSession))
                    {
                        Log.Info("WebsocketWiseSession removed for webSocketSessionToken: " + webSocketSessionToken.webSocketSessionToken);

                        response = response.Set(StatusCode.Success, "Successfully Removed OrderID from WebSocket Session Token", removedSession);
                    }
                    else
                    {
                        response = response.Set(StatusCode.OMS_KeyNotFound, "Key Not Found while Removing WebSocket data in classfile OmsWebSocketToken.cs,methodname = RemoveOrderId", null);
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occurred in classfile OmsWebSocketToken.cs,methodname = RemoveOrderId", ex);
            }
        }

        public Response GetWebSocketData(WebSocketSessionToken webSocketSessionToken)
        {
            Response response = new Response();
            try
            {
                lock (dictWebsocketWiseSession)
                {
                    if (dictWebsocketWiseSession.TryGetValue(webSocketSessionToken, out UserSession _userSession))
                    {
                        return response.Set(StatusCode.Success, "Data Found Successfully :" + webSocketSessionToken.webSocketSessionToken + " .", _userSession);
                    }
                    else
                    {
                        return response.Set(StatusCode.OMS_KeyNotFound, "WebSocket ID Does not Exists:" + webSocketSessionToken.webSocketSessionToken + " .", _userSession);
                    }
                }
            }
            catch (Exception ex)
            {
                return response = response.Set(StatusCode.OMS_Error, "Error Occured while Retrieve WebSocket data in classfile OmsWebSocketToken.cs,methodname = GetWebSocketData", ex);
            }
        }

        public Dictionary<WebSocketSessionToken, UserSession> Get()
        {
            return dictWebsocketWiseSession;
        }

        public Response AddOrUpdate(WebSocketSessionToken webSocketSessionToken, AgentSessionWs agentSession)
        {
            Response response = new Response();
            try
            {
                if (!dictWebsocketWiseSessionNew.TryGetValue(webSocketSessionToken, out AgentSessionWs agentSession1))
                {
                    agentSession1 = new();
                    dictWebsocketWiseSessionNew.TryAdd(webSocketSessionToken, agentSession1);
                }
                CacheUpdateHelper.UpdateObjectReference(agentSession, agentSession1);
            }
            catch (Exception ex)
            {
                Log.Error($"Error Occured while Adding WebSocket data | {ex.Message}");
                return response.Set(StatusCode.OMS_Error, "Error Occured while Adding WebSocket data", ex);
            }
            return response.Set(StatusCode.Success, "Successfully Added WebSocketData in Dictionary");
        }
        public Response Remove(WebSocketSessionToken webSocketSessionToken)
        {
            Response response = new Response();
            try
            {
                if (dictWebsocketWiseSessionNew.TryGetValue(webSocketSessionToken, out AgentSessionWs agentSession1))
                {
                    var agentInfo = CoreProcess.agentSessionCache.GetSession(agentSession1.BrokerId, agentSession1.SiteId, agentSession1.AgentId);
                    if (agentInfo.Item1 && agentInfo.Item2 != null)
                    {
                        agentInfo.Item2.IsConnected = false;
                        agentInfo.Item2.Session = null;
                    }
                    dictWebsocketWiseSession.Remove(webSocketSessionToken);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"Error Occured while Removing WebSocket data | {ex.Message}");
                return response.Set(StatusCode.OMS_Error, "Error Occured while Removing WebSocket data", ex);
            }
            return response.Set(StatusCode.Success, "Successfully Removed WebSocketData from Dictionary");
        }
    }

    public class AgentSessionWs
    {
        public int BrokerId;
        public int SiteId;
        public int AgentId;
    }
}
