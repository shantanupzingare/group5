﻿using DBHelper.Common;
using System.Data;

namespace LoginSignupCore.Global
{
    public class CommonHelper
    {
        public static DataSet ExecuteProcedureForDataSet(string spName, Dictionary<string, object> dbParams = null)
        {
            try
            {
                var db = new DatabaseHelper(Config.connectionString, DataProviders.SqlServer);

                if (dbParams != null)
                {
                    foreach (var kv in dbParams)
                    {
                        db.AddParameter(kv.Key, kv.Value);
                    }
                }
                var dataSet = db.ExecuteDataSet(spName, CommandType.StoredProcedure, 900);
                db.ClearParameter();

                if (dataSet == null || dataSet.Tables.Count == 0)
                {
                    Log.Error(null, "No Records found in Sp->" + spName);
                    return null;
                }
                else
                {
                    //log

                    return dataSet;
                }

            }
            catch (Exception ex)
            {
                //log
                Log.Error(ex, "Exception Occured in Common Helper ExecuteProcedure ");
                return null;
            }
        }
    }
}
