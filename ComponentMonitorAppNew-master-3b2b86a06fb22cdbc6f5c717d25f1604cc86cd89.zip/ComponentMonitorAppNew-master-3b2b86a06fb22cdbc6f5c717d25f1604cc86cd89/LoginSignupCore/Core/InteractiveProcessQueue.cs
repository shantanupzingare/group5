﻿using CTCL.BinaryProtocol.Common.CMA.Enum;
using Exchange.WebSocketServer.SocketManager;
using LoginSignupCore.Global;
using LoginSignupCore.Models;
using LoginSignupCore.Models.Others;
using LoginSignupCore.Models.Request;
using LoginSignupCore.Models.Response;
using Newtonsoft.Json;
using Utility.Queueing;

namespace LoginSignupCore.Core
{
    public class InteractiveProcessQueue
    {
        private ProcessQueue<DataFlowModel> interactiveMessageQueue;
        Thread thread;
        ManualResetEvent _mre;
        public InteractiveProcessQueue()
        {
            interactiveMessageQueue = new ProcessQueue<DataFlowModel>();
            _mre = new ManualResetEvent(false);
            DrainerThreadInit();
        }

        public void Enqueue(DataFlowModel message)
        {
            interactiveMessageQueue.Enqueue(message);
        }
        private void DrainerThreadInit()
        {
            thread = new Thread(new ThreadStart(DrainMessage));
            thread.Start();
        }
        private void DrainMessage()
        {
            while (true)
            {
                if (interactiveMessageQueue.TryDequeue(out DataFlowModel message))
                {
                    try
                    {
                        //Process message
                        ProcessMessage(message);
                    }
                    catch (System.Exception ex)
                    {
                        Log.Error(message, $"Exception occured on message process {ex.Message}");
                    }
                }
            }
        }
        private void ProcessMessage(DataFlowModel message)
        {
            try
            {
                if (message.Data != null)
                {
                    string reqData = message.Data.ToString();
                    var baseResponse = JsonConvert.DeserializeObject<MsgHeader>(reqData);
                    if (baseResponse != null)
                    {
                        var opcode = (CMA_OpCode)baseResponse.MessageCode;
                        switch (opcode)
                        {
                            case CMA_OpCode.AGENT_HANDSHAKE_REQ:
                                {
                                    Log.Info($"Received AGENT_HANDSHAKE_REQ");
                                    var agentHandshakeReq = JsonConvert.DeserializeObject<AgentHandshakeReq>(reqData);
                                    if (agentHandshakeReq != null)
                                    {
                                        var data = CoreProcess.ipSessionCache.Get(agentHandshakeReq.IP);

                                        //update socket session in sgent wise cache

                                        if (data.Item1)
                                        {
                                            data.Item2.Session = message.Token;
                                            AgentSessionWs agentSessionWs = new()
                                            {
                                                AgentId = data.Item2.AgentId,
                                                BrokerId = data.Item2.BrokerId,
                                                SiteId = data.Item2.SiteId,
                                            };
                                            CoreProcess.webSocketIdWiseSession.AddOrUpdate(new WebSocketSessionToken() { webSocketSessionToken = message.Token.Context.Channel.Id.AsShortText() }, agentSessionWs);
                                            CoreProcess.agentSessionCache.AddOrUpdate(data.Item2);
                                            MsgHeader res = new()
                                            {
                                                MessageCode = (int)CMA_OpCode.AGENT_HANDSHAKE_RES,
                                                AgentId = data.Item2.AgentId,
                                                BrokerId = data.Item2.BrokerId,
                                                SiteId = data.Item2.SiteId
                                            };
                                            CoreProcess.socketManager.Enqueue(new() { Token = message.Token, Data = res });
                                        }
                                        else
                                        {
                                            Log.Error($"Data not found | {agentHandshakeReq.IP} not found");
                                        }
                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing AGENT_HANDSHAKE_REQ");
                                    }
                                }
                                break;

                            case CMA_OpCode.LOGIN_REQ:
                                {
                                    Log.Info($"Received LoginRequest");
                                    var loginReq = JsonConvert.DeserializeObject<LoginRequest>(reqData);
                                    if (loginReq != null)
                                    {

                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing LoginRequest");
                                    }
                                }
                                break;

                            case CMA_OpCode.COMPONENT_INFO_REQ:
                                {
                                    Log.Info($"Received COMPONENT_INFO_REQ");
                                    var compInfoReq = JsonConvert.DeserializeObject<MsgHeader>(reqData);
                                    if (compInfoReq != null)
                                    {
                                        var compList = CoreProcess.agentSessionCache.GetComponentMaster(compInfoReq.BrokerId, compInfoReq.SiteId, compInfoReq.AgentId);
                                        if (compList.Item1)
                                        {
                                            var responseData = Helper.PrepareComponentInfoResponse(compList.Item2);
                                            responseData.MessageCode = (int)CMA_OpCode.COMPONENT_INFO_RES;
                                            CoreProcess.socketManager.Enqueue(new() { Token = message.Token, Data = responseData });
                                        }
                                        else
                                        {
                                            Log.Error($"Error while fetching Compoent Master Data");
                                        }
                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing COMPONENT_INFO_REQ");
                                    }
                                }
                                break;

                            case CMA_OpCode.FILE_INFO_REQ:
                                {
                                    Log.Info($"Received FILE_INFO_REQ");
                                    var fileInfoReq = JsonConvert.DeserializeObject<MsgHeader>(reqData);
                                    if (fileInfoReq != null)
                                    {
                                        var fileList = CoreProcess.agentSessionCache.GetFileMasterInfo(fileInfoReq.BrokerId, fileInfoReq.SiteId, fileInfoReq.AgentId);
                                        if (fileList.Item1)
                                        {
                                            var responseData = Helper.PrepareFileInfoResponse(fileList.Item2);
                                            var masterPath = CoreProcess.agentSessionCache.GetMasterPath(fileInfoReq.BrokerId, fileInfoReq.SiteId);
                                            responseData.MessageCode = (int)CMA_OpCode.FILE_INFO_RES;
                                            if (masterPath.Item1 && masterPath.Item2 != null)
                                            {
                                                responseData.MasterPath = masterPath.Item2;
                                            }
                                            CoreProcess.socketManager.Enqueue(new() { Token = message.Token, Data = responseData });
                                        }
                                        else
                                        {
                                            Log.Error($"Error while fetching FILE_INFO_REQ Data");
                                        }
                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing FILE_INFO_REQ");
                                    }
                                }
                                break;

                            case CMA_OpCode.FILE_UPLOAD_CONFIRMATION:
                                {
                                    Log.Info($"Received FILE_UPLOAD_CONFIRMATION");
                                    var fileStatus = JsonConvert.DeserializeObject<FileStatus>(reqData);
                                    if (fileStatus != null)
                                    {
                                        CoreProcess.agentSessionCache.AddOrUpdate(fileStatus);
                                        CoreProcess.dBProcessor.Enqueue(reqData);
                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing FILE_UPLOAD_CONFIRMATION");
                                    }
                                }
                                break;

                            case CMA_OpCode.COMPONENT_STATE_UPDATE:
                                {
                                    Log.Info($"Received COMPONENT_STATE_UPDATE");
                                    var compStatus = JsonConvert.DeserializeObject<ComponentStatus>(reqData);
                                    if (compStatus != null)
                                    {
                                        CoreProcess.agentSessionCache.AddOrUpdate(compStatus);
                                        CoreProcess.dBProcessor.Enqueue(reqData);
                                    }
                                    else
                                    {
                                        Log.Error($"Error while procesing COMPONENT_STATE_UPDATE");
                                    }
                                }
                                break;

                            case CMA_OpCode.CMA_TECHNICAL_PARAM_REQ:
                                {
                                    Log.Info($"Received CMA_TECHNICAL_PARAM_REQ");
                                    var techInfo = JsonConvert.DeserializeObject<ComponentTechincalInfo>(reqData);
                                    if (techInfo != null)
                                    {
                                        var info = Helper.PrepareTechnicalParamModel(techInfo);
                                        if (info.InstanceId != 0)
                                        {
                                            CoreProcess.agentSessionCache.AddOrUpdate(info);
                                        }
                                        CoreProcess.dBProcessor.Enqueue(reqData);
                                    }
                                    else
                                    {

                                        Log.Error($"Error while procesing CMA_TECHNICAL_PARAM_REQ");
                                    }
                                }
                                break;

                            case CMA_OpCode.END_MSG_DOWNLOAD:
                                {
                                    Log.Info($"Received END_MSG_DOWNLOAD");
                                    var session = CoreProcess.agentSessionCache.GetSession(baseResponse.BrokerId, baseResponse.SiteId, baseResponse.AgentId);
                                    if (session.Item1 && session.Item2 != null)
                                    {
                                        session.Item2.IsConnected = true;
                                    }
                                }
                                break;

                            default:
                                break;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Log.Error($"Error occured during ProcessMessage");
            }
        }
    }
    public class DataFlowModel
    {
        public SocketSession Token;
        public object Data;
    }
}
