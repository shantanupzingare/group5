﻿using BinaryProtocol.Common;
using SocketSession = Exchange.WebSocketServer.SocketManager.SocketSession;
using LoginSignupCore.Global;
using Exchange.WebSocketServer.SocketManager;
using WebSocketSessionToken = Exchange.WebSocketServer.SocketManager.WebSocketSessionToken;
using Utility.Queueing;
using LoginSignupCore.Models;

namespace LoginSignupCore.Core
{
    public class SocketManager
    {
        private ProcessQueue<DataFlowModel> queue;
        private Thread thread;
        private InteractiveProcessQueue _interactiveProcessQueue;
        public async Task Initialize()
        {
            queue = new();
            thread = new Thread(new ThreadStart(ListenQueue));
            thread.Start();
            _interactiveProcessQueue = new InteractiveProcessQueue();
            WebsocketManager.OnOpenConnection += WebsocketManager_OnOpenConnection;
            WebsocketManager.OnStringMessageReceived += WebsocketManager_OnMessageReceived;
            WebsocketManager.OnErrorListener += WebsocketManager_OnErrorListener;
            WebsocketManager.OnCloseConnection += WebsocketManager_OnCloseConnection;

            await Exchange.WebSocketServer.Global.Startup.Setup();
        }

        private void WebsocketManager_OnOpenConnection(SocketSession socketSession)
        {
            Log.Info($"On Ws open con-> {socketSession.Context.Channel.Id.AsShortText()}");
            //UserSession userSession = new UserSession
            //{
            //    SocketSession = socketSession,
            //    WebSocketSessionToken = new WebSocketSessionToken() { webSocketSessionToken = socketSession.Context.Channel.Id.AsShortText() }
            //};
            //CoreProcess.webSocketIdWiseSession.AddOrUpdateWebSocketToken(userSession);
        }
        private void WebsocketManager_OnMessageReceived(SocketSession socketSession, object receivedmsg)
        {
            _interactiveProcessQueue.Enqueue(new() { Token = socketSession, Data = receivedmsg});
        }
        private static void WebsocketManager_OnErrorListener(SocketSession socketSession, Exception ex)
        {
            Log.Error(ex);
        }
        public static void WebsocketManager_OnCloseConnection(SocketSession socketSession)
        {
            if(socketSession != null && socketSession.Context != null && socketSession.Context.Channel != null)
            {
                WebSocketSessionToken webSocketSessionToken = new WebSocketSessionToken() { webSocketSessionToken = socketSession.Context.Channel.Id.AsShortText() };
                CoreProcess.webSocketIdWiseSession.Remove(webSocketSessionToken);
                Log.Info("Ws Close Evt: " + socketSession.Context.Channel.Id.AsShortText());
            }
        }
        public static void Send(SocketSession socketSession, object data)
        {
            if(socketSession!=null)
                WebsocketManager.Send(socketSession, data);
        }
        public void Enqueue(DataFlowModel data)
        {
            queue.Enqueue(data);
        }
        private void ListenQueue()
        {
            while (true)
            {
                if (queue.TryDequeue(out DataFlowModel res))
                {
                    Send(res.Token, res.Data);
                }
            }
        }
    }
}