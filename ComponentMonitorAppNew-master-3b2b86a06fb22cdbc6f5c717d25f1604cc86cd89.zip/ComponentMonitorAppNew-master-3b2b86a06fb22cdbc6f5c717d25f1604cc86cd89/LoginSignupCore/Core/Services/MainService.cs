﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models.Others;
using LoginSignupCore.Models.Request;

namespace LoginSignupCore.Core.Services
{
    public class MainService
    {
        public void StartComponent(CompInitReq compInitReq)
        {
            (bool, ComponentMaster) resp = CoreProcess.agentSessionCache.GetComponentMaster(compInitReq);
            if(resp.Item1)
            {
                (bool, AgentSessionInfo) sessionInfo = CoreProcess.agentSessionCache.GetSession(compInitReq.BrokerId, compInitReq.SiteId, compInitReq.AgentId);
                if(sessionInfo.Item1 && sessionInfo.Item2.Session!=null)
                {
                    CoreProcess.agentSessionCache.AddOrUpdate(compInitReq,true);
                    var compReq = Helper.PrepareComponentInitReq(resp.Item2, CMA_OpCode.COMPONENT_START);
                    DataFlowModel dataFlowModel = new()
                    {
                        Data = compReq,
                        Token = sessionInfo.Item2.Session
                    };
                    CoreProcess.socketManager.Enqueue(dataFlowModel);
                }
                Log.Warning(sessionInfo.Item2.AgentName,"session is null");
            }
        }

        public void StopComponent(CompInitReq compInitReq)
        {
            (bool, ComponentMaster) resp = CoreProcess.agentSessionCache.GetComponentMaster(compInitReq);
            if (resp.Item1)
            {
                (bool, AgentSessionInfo) sessionInfo = CoreProcess.agentSessionCache.GetSession(compInitReq.BrokerId, compInitReq.SiteId, compInitReq.AgentId);
                if (sessionInfo.Item1)
                {
                    var compReq = Helper.PrepareComponentInitReq(resp.Item2, CMA_OpCode.COMPONENT_STOP);
                    DataFlowModel dataFlowModel = new()
                    {
                        Data = compReq,
                        Token = sessionInfo.Item2.Session
                    };
                    CoreProcess.socketManager.Enqueue(dataFlowModel);
                }
            }
        }

        public void StartFileUpload(CompInitReq compInitReq)
        {
            (bool, AgentSessionInfo) sessionInfo = CoreProcess.agentSessionCache.GetSession(compInitReq.BrokerId, compInitReq.SiteId, compInitReq.AgentId);
            if (sessionInfo.Item1 && sessionInfo.Item2.IsConnected)
            {
                FileUploadReq fileUploadReq = new()
                {
                    MessageCode = (int)CMA_OpCode.START_FILE_UPLOAD,
                    RequestId = Helper.GenerateRequestId((int)ComponentType.CONTRACT_MASTER_READER, -1, compInitReq.AgentId)
                };
                DataFlowModel dataFlowModel = new()
                {
                    Data = fileUploadReq,
                    Token = sessionInfo.Item2.Session
                };
                CoreProcess.socketManager.Enqueue(dataFlowModel);
            }
        }

        public void StartAfterBodFileUpload(CompInitReq compInitReq)
        {
            (bool, AgentSessionInfo) sessionInfo = CoreProcess.agentSessionCache.GetSession(compInitReq.BrokerId, compInitReq.SiteId, compInitReq.AgentId);
            if (sessionInfo.Item1)
            {
                FileUploadReq fileUploadReq = new()
                {
                    MessageCode = (int)CMA_OpCode.START_AFTER_BOD_FILE_UPLOAD,
                    //RequestId = Helper.GenerateRequestId((int)ComponentType.RMS, -1, compInitReq.AgentId)
                };
                DataFlowModel dataFlowModel = new()
                {
                    Data = fileUploadReq,
                    Token = sessionInfo.Item2.Session
                };
                CoreProcess.socketManager.Enqueue(dataFlowModel);
            }
        }
    }
}
