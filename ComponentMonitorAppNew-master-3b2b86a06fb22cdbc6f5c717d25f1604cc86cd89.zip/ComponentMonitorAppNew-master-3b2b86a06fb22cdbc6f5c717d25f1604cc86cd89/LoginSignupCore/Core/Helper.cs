﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models.Request;
using LoginSignupCore.Models.Response;
using Newtonsoft.Json;
using Utility;
using ComponentInfo = LoginSignupCore.Models.Response.ComponentInfo;
using FileInfo = LoginSignupCore.Models.Response.FileInfo;


namespace LoginSignupCore.Core
{
    public class Helper
    {
        private static Conversion conversion;

        static Helper()
        {
            conversion = new();
        }

        public static string SerializeObject(object obj)
        {
            try
            {
                return JsonConvert.SerializeObject(obj);
            }
            catch (Exception ex)
            {
                return "Error in serialize :" + ex.Message;
            }

        }

		public static ComponentInfo PrepareComponentInfoResponse(List<Component> compList)
		{
			ComponentInfo componentInfo = new();
			if (compList != null)
			{
				componentInfo.Data = new();
				for (int i = 0; i < compList.Count; i++)
				{
					ComponentInfoData componentInfoData = new();
					componentInfoData.ComponentType = compList[i].componentMaster.ComponentId;
					componentInfoData.InstanceId = compList[i].componentMaster.InstanceId;
					componentInfoData.CmdParameters = compList[i].componentMaster.CmdParam;
					componentInfoData.ExecutablePath = compList[i].componentMaster.ExePath;
					componentInfoData.Priority = compList[i].componentMaster.Priority;
					componentInfoData.ServiceName = compList[i].componentMaster.ServiceName;

					componentInfo.Data.Add(componentInfoData);
				}
			}
			return componentInfo;
		}
		public static FileInfo PrepareFileInfoResponse(List<FileMasterInfo> fileList)
		{
			FileInfo fileInfo = new();
			if (fileList != null)
			{
				fileInfo.Files = new();
				for (int i = 0; i < fileList.Count; i++)
				{
					FilePathInfo filePathInfo = new();
					filePathInfo.FileName = fileList[i].FileName;
					filePathInfo.FilePriority = fileList[i].Priority;
					filePathInfo.Segment = fileList[i].SegmentId;
					filePathInfo.FileType = fileList[i].FileType;
					filePathInfo.IsUploadBeforeBod = fileList[i].IsUploadBeforeBOD;
					filePathInfo.DestinationPath = fileList[i].DestinationPath;

                    fileInfo.Files.Add(filePathInfo);
                }
            }
            return fileInfo;
        }
        public static ComponentInitReq PrepareComponentInitReq(ComponentMaster componentMaster, CMA_OpCode opCode)
        {
            ComponentInitReq componentInitReq = new()
            {
                AgentId = componentMaster.AgentId,
                BrokerId = componentMaster.BrokerId,
                SiteId = componentMaster.SiteId,
                MessageCode = (int)opCode,
                ComponentType = componentMaster.ComponentId,
                InstanceId = componentMaster.InstanceId,
                IsRunAsService = componentMaster.IsRunAsService,
                RequestId = GenerateRequestId(componentMaster.ComponentId, componentMaster.InstanceId, componentMaster.AgentId)
            };
            return componentInitReq;
        }
        public static ComponentsTechnicalInfo PrepareTechnicalParamModel(ComponentTechincalInfo technicalInfo)
        {
            ComponentsTechnicalInfo componentsTechnicalInfo = new()
            {
                BrokerId = technicalInfo.BrokerId,
                SiteId = technicalInfo.SiteId,
                AgentId = technicalInfo.AgentId,
                ComponentId = technicalInfo.ComponentType,
                InstanceId = technicalInfo.InstanceId,
                CPUUtilization = technicalInfo.CPUPercentage,
                RAMUtilization = technicalInfo.RAMUsage,
                ComponentName = ((ComponentType)technicalInfo.ComponentType).ToString(),
                AgentName =  CoreProcess.agentSessionCache.GetSession(technicalInfo.BrokerId, technicalInfo.SiteId,technicalInfo.AgentId).Item2?.AgentName??string.Empty,
                Timestamp = DateTime.Now.ToString("dd/MM/yyyyTHH:mm:ss")

            };
            return componentsTechnicalInfo;
        }
        public static string GenerateRequestId(int compId, int instanceId, int agentInstanceId)
        {
            int agentCompId = (int)ComponentType.AgentWorker;
            //Length 2
            string agentId = agentCompId.ToString("D2");
            //Length 4
            string agentInstId = agentInstanceId.ToString("D4");
            //Length 2
            string destCompId = compId.ToString("D2");
            //Length 2
            string destInsId = "";
            if (instanceId < 0)
            {
                destInsId = "01";
            }
            else
            {
                destInsId = instanceId.ToString("D2");
            }
            //Length 4
            string year = DateTime.Now.Year.ToString("D4");
            //Length 2
            string month = DateTime.Now.Month.ToString("D2");
            //Length 2
            string date = DateTime.Now.Day.ToString("D2");
            //Length 14
            string id = (++Config.Id).ToString("D14");

            string requestId = string.Concat(agentId, agentInstId, destCompId, destInsId, year, month, date, id);
            if (requestId.Length == 32)
                return requestId;
            return DateTime.Now.Ticks.ToString("D32");
        }
    }
}
