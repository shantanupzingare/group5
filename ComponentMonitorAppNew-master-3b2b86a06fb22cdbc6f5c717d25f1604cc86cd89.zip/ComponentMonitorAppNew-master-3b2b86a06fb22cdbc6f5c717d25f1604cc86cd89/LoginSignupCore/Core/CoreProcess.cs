﻿using BinaryProtocol.Common;
using Exchange.Logs;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Processor;
using Serilog;
using Serilog.Core;
using Serilog.Events;

namespace LoginSignupCore.Core
{
    public class CoreProcess
    {
        public static Response response;
        private static LogProcessor logProcessor;
        public static WebSocketIdWiseSession webSocketIdWiseSession;
        public static SocketManager socketManager;
        public static AgentSessionCache agentSessionCache;
        public static IPSessionCache ipSessionCache;
        public static DBProcessor dBProcessor;

        public static async Task<Response> Initialize()
        {
            response = new();

            LogConfiguration logConfiguration = new LogConfiguration
            {
                FilesizeLimitBytes = 50000000,
                LogFileNameWithPath = Config.logfile,
                LoggingLevelSwitch = new LoggingLevelSwitch
                {
                    MinimumLevel = Config.logLevel == 0 ? LogEventLevel.Debug : (LogEventLevel)Config.logLevel,
                },
                OutputTemplate = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u5}] {Message:lj}{NewLine}{Exception}",
                RetainedFileCount = Config.logFileCount,
                RollingInterval = RollingInterval.Day,
                RollOnFileSizeLimit = true,
            };

            LogType logType = (LogType)Config.logLevel;

            if (logProcessor == null)
            {
                logProcessor = new LogProcessor(logConfiguration);
            }

            dBProcessor = new();
            ipSessionCache = new();
            agentSessionCache = new();
            webSocketIdWiseSession = new();
            socketManager = new();
            CacheOnLoad.LoadAllCacheData();
            await socketManager.Initialize();
            return new Response()
            {
                Message = ""
            };
        }

        public static Response SendToLogQueue(LogObject data)
        {
            if (!data.Equals(default(LogObject)) && logProcessor != null)
            {
                return logProcessor.Enqueue(data);
            }
            else if (logProcessor == null)
            {
                return response.Set(StatusCode.OMS_Failure, "logProcessor is null");
            }
            else
            {
                return response.Set(StatusCode.OMS_Failure, "data is null");
            }
        }
    }
}
