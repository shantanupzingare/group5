﻿using System.Runtime.InteropServices;

namespace LoginSignupCore.Core
{
    public class exitHook
    {
        private const int MF_BYCOMMAND = 0x00000000;
        public const int SC_CLOSE = 0xF060;

        [DllImport("user32.dll")]
        public static extern int DeleteMenu(IntPtr hMenu, int nPosition, int wFlags);

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        private static extern IntPtr GetConsoleWindow();

        static exitHook()
        {
            DeleteMenu(GetSystemMenu(GetConsoleWindow(), false), SC_CLOSE, MF_BYCOMMAND);
        }

        public static void exitHookInit()
        {
            string strExit, strExitconfirm;

            Console.CancelKeyPress += Console_CancelKeyPress;
            Console.WriteLine("running");


        }

        private static void Console_CancelKeyPress(object? sender, ConsoleCancelEventArgs args)
        {
            args.Cancel = true;
            //ask();

        }

        public static void ask()
        {
            Console.WriteLine("Type exit and press Enter to Close the Programm ");
        }
    }
}
