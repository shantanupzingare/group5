﻿//using LoginSignupCore.Data;
//using LoginSignupCore.Models;
//using Microsoft.AspNetCore.Mvc;
//using System.Security.Claims;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using Microsoft.EntityFrameworkCore;
//using System.Data;
//using Microsoft.Data.SqlClient;
//using Microsoft.AspNetCore.Mvc.Rendering;

//namespace LoginSignupCore.Controllers
//{
//    public class AlertController : Controller
//    {
//        private readonly ApplicatonDBContext _dbcontext;
       
//        public IActionResult Alert()
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");

//            }
//            globals.Broker_Site = "Please Select";
//            globals.Component_Name = "Please Select";
//            globals.Parameter_Name = "Please Select";

//            GetDropdownList();
//            GetDropdownComponentList();
//            GetDropdownParameterList("");
//            return View();
//        }

//        public AlertController(ApplicatonDBContext context)
//        {
//            _dbcontext = context;
//        }

//        [HttpPost]
//        public IActionResult Alert(AlertThreshold alertThreshold)
//        {
//            ViewBag.successStatus = 0;
//            try
//            {
//                var pId = Request.Form["BrokerSiteId"];
//                var pCompId = Request.Form["IntComponentId"];
//                var pParamId = Request.Form["IntParamId"];
//                ViewBag.ComponentName = Request.Form["ComponentName"];
//                ViewBag.ParameterName = Request.Form["ParameterName"];

//                alertThreshold.IntCreatedBy = globals.User_ID;
//                alertThreshold.BitIsDelete = 0;
//                alertThreshold.BitIsActive = 1;
//                alertThreshold.DtmCreatedOn = DateTime.Now.Date;
//                _dbcontext.AlertThresholds.Add(alertThreshold);
//                _dbcontext.SaveChanges();
//                ViewBag.successStatus = 1;
//                GetDropdownList();
//                GetDropdownComponentList();
//                GetDropdownParameterList("");
//                GetDropdownListReload(pId);
//                GetDropdownComponentListReload(pCompId);
//                GetDropdownParameterListReload(pId);
//                return View(alertThreshold);
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//            }
//            return View(alertThreshold);
//        }

//        [HttpPost]
//        public IActionResult AlertUpdate(AlertThreshold alertThreshold)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");

//            }
//            ViewBag.successStatus = 0;
//            try
//            {
//                        int id = Convert.ToInt32(Request.Form["Id"]);
//                        int intParamId = Convert.ToInt32(Request.Form["IntParamId"]);
//                        int intComponentId = Convert.ToInt32(Request.Form["IntComponentId"]);
//                        string componentName = Request.Form["ComponentName"];
//                        string brokerSiteId = Request.Form["BrokerSiteId"];                        

//                        int intThresholdValue = Convert.ToInt32(Request.Form["IntThresholdValue"]);
//                        DateTime dtmupdateon = DateTime.Now;
//                        int intUpdatedBy = globals.User_ID;
//                        var bitIsActive = 0;
//                        string mvalue = Request.Form["BitIsActive"];

//                        if (mvalue == "1")
//                        {
//                            bitIsActive = 1;
//                        }
//                        else if (mvalue == "on") 
//                        {
//                            bitIsActive = 1;
//                        }
//                        else if (mvalue == "1,on") 
//                        {
//                            bitIsActive = 1;
//                        }
//                        else if (mvalue == "0,on")
//                        {
//                            bitIsActive = 1;
//                        }
//                        else
//                        {
//                            bitIsActive = 0;
//                        }

//                        try
//                        {
//                            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//                            {
//                                if (cmd.Connection.State != ConnectionState.Open)
//                                {
//                                    cmd.Connection.Open();
//                                }
//                                cmd.CommandText = "update AlertThreshold set IntParamId='" + intParamId + "',IntComponentId='" + intComponentId + "',ComponentName='" + componentName + "', BrokerSiteId='" + brokerSiteId + "', intThresholdValue ='" + intThresholdValue + "' , iniUpdatedBy ='" + intUpdatedBy + "',dtmUpdatedOn='" + dtmupdateon + "', bitIsActive = '" + bitIsActive + "' where Id = '" + id + "'";
//                                cmd.ExecuteNonQuery();
//                                cmd.Connection.Close();

//                                ViewBag.Status = 1;

//                                ViewBag.model = alertThreshold;
//                                return RedirectToAction("DisplayData", "Alert");
//                            }

//                        }
//                        catch (Exception ee)
//                        {
//                            ViewBag.Status = 0;
//                            return RedirectToAction("Alert", "Alert");

//                        }
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//            }
//            return RedirectToAction("Alert", "Alert");
//        }

//        [HttpPost]
//        public IActionResult Clear(AlertThreshold alertThreshold)
//        {
//            ViewBag.successStatus = null;
//            globals.Broker_Site = "Please Select";
//            globals.Component_Name = "Please Select";
//            return RedirectToAction("Alert", "Alert");
//        }
       
//        public async Task<IActionResult> Logout()
//        {
//            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//            globals.User_ID = 0;
//            return RedirectToAction("Login", "Account");
            
//        }


//        [HttpPost]
//        public IActionResult Edit(VwAlertThreshold _alertThreshold)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");
//            }

//            int id = Convert.ToInt32(Request.Form["Id"]);
//            var bitIsActive = Request.Form["mvalue"];
//            ViewBag.mvalue = bitIsActive;

//            int paramId = Convert.ToInt32(Request.Form["ParamId"]);
//            var brokerSiteName = Request.Form["BrokerSiteName"];
//            var nvcComponentName = Request.Form["ComponentName"];
//            var intComponentId = Request.Form["Intcomponentid"];
//            var brokerSiteId = Request.Form["BrokerSiteId"];
//            ViewBag.sitename = brokerSiteName;
//            ViewBag.ComponentName = nvcComponentName;
//            ViewBag.Intcomponentid = intComponentId;
//            ViewBag.BrokerSiteId = brokerSiteId;
//            ViewBag.ParamId = paramId;

//            globals.Broker_Site = brokerSiteId;
//            globals.BrokerId_update = Convert.ToString(brokerSiteId);
//            globals.Component_ID = Convert.ToInt32(intComponentId);

//            GetDropdownList();
//            GetDropdownComponentList();
//            GetDropdownParameterList("");
//            return View(_alertThreshold);
//        }

//        public void GetDropdownList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentsid = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public void GetDropdownListReload(string brokerSiteId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 and cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) = '" + brokerSiteId + "' order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Broker_Site = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownParameterList(string pBrokerSiteId)
//        {
            
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            if (string.IsNullOrEmpty(pBrokerSiteId))
//            {
//                cmd.CommandText = "select  parameterName, cast(paramId as varchar) paramId from ComponentParameter order by ParameterName";
//            }
//            else
//            {
//                cmd.CommandText = "select  parameterName, cast(paramId as varchar) paramId from ComponentParameter where brokerSiteId = '" + pBrokerSiteId + "' order by ParameterName";
//            }
            
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelParametersid = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public void GetDropdownParameterListReload(string brokerSiteId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            if (string.IsNullOrEmpty(brokerSiteId))
//            {
//                cmd.CommandText = "select parameterName, cast(paramId as varchar) paramId from ComponentParameter order by ParameterName";
//            }
//            else
//            {
//                cmd.CommandText = "select parameterName, cast(paramId as varchar) paramId from ComponentParameter where brokerSiteId = '" + brokerSiteId + "' order by ParameterName";
//            }
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Parameter_Name = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownComponentListReload(string intComponentId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where c.intComponentId = '" + intComponentId + "' and  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Component_Name = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownComponentList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentName = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public IActionResult DisplayData()
//        {

//            List<VwAlertThreshold> alertThresholds = new List<VwAlertThreshold>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "Select [id],[intParamID] , [intComponentId] , [ComponentName] , [BrokerSiteName] , [BrokerSiteID] , [intThresholdValue] , [ParameterName] , [ParamId] , cast([bitIsActive] as int) bitIsActive from vwAlertThreshold order by brokerSitename";

//            Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {

//                    alertThresholds.Add(new VwAlertThreshold
//                    {
//                        Id = dataread.GetInt32(0),
//                        IntParamId = dataread.GetInt32(1),
//                        IntComponentId = dataread.GetInt32(2),
//                        ComponentName = dataread.GetString(3),
//                        BrokerSiteName = dataread.GetString(4),
//                        BrokerSiteId = dataread.GetString(5),
//                        IntThresholdValue = dataread.GetInt32(6),
//                        ParameterName = dataread.GetString(7),
//                        ParamId = dataread.GetInt32(8),
//                        BitIsActive = dataread.GetInt32(9)
//                    }); ; ; ;
                    
//                }
//                cmd.Connection.Close();
                
//                ViewBag.model = alertThresholds;
//                return View();
//            }
//            return View(); 
//        }


//    }   
//}
