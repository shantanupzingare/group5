﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using System.Data;
namespace LoginSignupCore.Controllers
{
    public class BrokerMasterController : Controller
    {

        private readonly ApplicatonDBContext _dbcontext;
        private readonly BrokerRepository brokerRepository;

        public BrokerMasterController(ApplicatonDBContext context)
        {
            _dbcontext = context;
            brokerRepository = new();
        }
        public IActionResult BrokerMaster()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Clear(BrokerMaster brokerMaster)
        {
            ViewBag.successStatus = null;
            return RedirectToAction("BrokerMaster", "BrokerMaster");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            globals.User_ID = 0;
            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public IActionResult BrokerMaster(int id)
        {
           // ViewBag.successStatus = 0;
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                return RedirectToAction("Login", "Account");
            }
            var res = brokerRepository.GetBrokerById(id);
            return PartialView("BrokerMaster", res);
        }

        [HttpPost]
        public IActionResult BrokerMaster(BrokerMaster brokerMaster)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }
            // ViewBag.successStatus = 0;
            try
            {
                brokerMaster.IntCreatedBy = globals.User_ID;
                brokerMaster.IsDeleted = 0;
                brokerMaster.IsActive = 1;
                brokerMaster.DtmCreationDate = DateTime.Now.Date;
                _dbcontext.BrokerMasters.Add(brokerMaster);
                _dbcontext.SaveChanges();
               // ViewBag.successStatus = 1;
               //brokerMaster = null;
                //return View(brokerMaster);
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("DisplayData","BrokerMaster");
        }

        public IActionResult DisplayData(BrokerMaster brokermaster)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }

            List<BrokerMaster> brokerMasters = new List<BrokerMaster>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }
            cmd.CommandText = "Select id, isnull(NvcBrokerName,'') NvcBrokerName, IsActive  from BrokerMaster where IsDeleted = 0";

            Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
            if (dataread.HasRows)
            {
                while (dataread.Read())
                {

                    brokerMasters.Add(new BrokerMaster
                    {
                        Id = dataread.GetInt32(0),
                        NvcBrokerName = dataread.GetString(1),
                        IsActive = dataread.GetInt32(2)
                    });

                }
                cmd.Connection.Close();
            }
            BrokerView viewbroker = new();
                viewbroker.brokers = brokerMasters;
                viewbroker.broker = brokermaster;
            return View(viewbroker);
        }
        [HttpPost]
        public IActionResult BrokerMasterUpdate(BrokerMaster brokerMaster)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");

            }
           ViewBag.successStatus = 0;
            try
            {
                var id = Convert.ToInt32(Request.Form["Id"]);
                var brokerName = Request.Form["NvcBrokerName"];
                var dtmupdateon = DateTime.Now;
                var intUpdatedBy = globals.User_ID;
                var isActive = 0;
                string mvalue = Request.Form["IsActive"];

                if (mvalue == "1")
                {
                    isActive = 1;
                }
                else if (mvalue == "on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else if (mvalue == "0,on")
                {
                    isActive = 1;
                }
                else
                {
                    isActive = 0;
                }

                try
                {
                    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                    {
                        if (cmd.Connection.State != ConnectionState.Open)
                        {
                            cmd.Connection.Open();
                        }
                        cmd.CommandText = "update BrokerMaster set NvcBrokerName='" + brokerName + "',intUpdatedBy = '" + intUpdatedBy + "', dtmUpdationDate = '" + dtmupdateon + "', IsActive = '" + isActive + "'  where Id = '" + id + "'";
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();

                        ViewBag.Status = 1;
                        ViewBag.successStatus = 1;

                        ViewBag.model = brokerMaster;
                        return RedirectToAction("DisplayData", "BrokerMaster");
                    }

                }
                catch (Exception ee)
                {
                    ViewBag.Status = 0;
                    ViewBag.successStatus = 0;
                    return RedirectToAction("BrokerMaster", "BrokerMaster");

                }
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("BrokerMaster", "BrokerMaster");
        }


        public IActionResult Update(int id, int isActive)
        {

            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }
            var comp = new ComponentMaster()
            {
                Id = id,
                BitIsActive = isActive,
                DtmUpdatedOn = DateTime.Now,
                IntUpdatedBy = globals.User_ID
            };
            try
            {
                var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                {
                    if (cmd.Connection.State != ConnectionState.Open)
                    {
                        cmd.Connection.Open();
                    }
                    cmd.CommandText = "update BrokerMaster set IsActive='" + comp.BitIsActive + "',intUpdatedBy = '" + comp.IntUpdatedBy + "', dtmUpdationDate = '" + comp.DtmUpdatedOn + "'  where Id = '" + comp.Id + "'";
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();

                    ViewBag.Status = 1;
                    ViewBag.successStatus = 1;

                    //ViewBag.model = _brokerMaster;

                }
                return RedirectToAction("DisplayData", "BrokerMaster");
            }
            catch (Exception ex)
            {
                ViewBag.Status = 0;
                ViewBag.successStatus = 0;
                //ViewBag.model = _brokerMaster;
                return RedirectToAction("DisplayData", "BrokerMaster");
            }

        }
        [HttpPost]
        public IActionResult Edit(BrokerMaster _brokerMaster)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {

                return RedirectToAction("Login", "Account");

            }

            int id = Convert.ToInt32(Request.Form["Id"]);
            var IsActive = Request.Form["mvalue"];
            ViewBag.mvalue = IsActive;
            var res =brokerRepository.GetBrokerById(id);
            res.IsActive = _brokerMaster.IsActive;
            return RedirectToAction("DisplayData",res);
        }


    }
}
