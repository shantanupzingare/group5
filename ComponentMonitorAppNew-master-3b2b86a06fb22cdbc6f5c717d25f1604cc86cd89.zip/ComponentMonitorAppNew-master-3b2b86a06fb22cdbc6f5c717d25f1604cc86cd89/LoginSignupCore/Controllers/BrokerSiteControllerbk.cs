﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class BrokerSiteControllerbk : Controller
    {
        private readonly ApplicatonDBContext _dbcontext;
        public BrokerSiteControllerbk(ApplicatonDBContext context)
        {
            _dbcontext = context;
        }

        [HttpGet]
        public IActionResult BrokerSites()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }

            //globals.BrokerIdList = "Please Select";
            //GetDropdownList();
            DisplayData();
            return View();
        }

        [HttpPost]
        public IActionResult GetBrokerSites()
        {
            
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            int brokerid = Convert.ToInt32( Request.Form["brokerid"]);
            string brokername = Request.Form["NvcBrokerName"];

            globals.BrokerId = brokerid;
            globals.BrokerName = brokername;
            //globals.BrokerIdList = "Please Select";
            // GetDropdownList();
            DisplayData();
            return RedirectToAction("BrokerSites", "BrokerSite");
        }
        

        //public void GetDropdownList()
        //{
        //    List<SelectList> Lista = new List<SelectList>();
        //    Lista.Add(new SelectList { Text = "", Value = "", Selected = true });
        //    Lista = CommonDropDowns.GetBrokerName(brokerMasters);

        //    foreach (var brokers in brokerData)
        //    {
        //        Lista.Add(item: new SelectList { Text = brokers.nvcBrokerName, Value = brokers.ParameterName });
        //    }
        //    ViewData["BrokerNameList"] = Lista;
        //}


        [HttpPost]
        public IActionResult BrokerSites(BrokerSites _brokerSites)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            string name = Request.Form["Para"];

            globals.BrokerIdList = name;
            ViewBag.successStatus = 0;
            try
            {
                if (globals.BrokerId != 0)
                {
                    _brokerSites.IntBrokerId = globals.BrokerId;
                    _brokerSites.IntCreatedBy = globals.User_ID;
                    _brokerSites.IsDeleted = 0;
                    _brokerSites.IsActive = 1;
                    _brokerSites.DtmCreationDate = DateTime.Now.Date;
                    _dbcontext.BrokerSites.Add(_brokerSites);
                    _dbcontext.SaveChanges();
                    ViewBag.successStatus = 1;
                    _brokerSites = null;
                    DisplayData();
                    return View(_brokerSites);
                }
                else
                {
                    ViewBag.successStatus = 0;
                }
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return View(_brokerSites);
        }

        [HttpPost]
        public IActionResult Edit(BrokerSites brokerSites)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;
            try
            {
                var id = Convert.ToInt32(Request.Form["Id"]);
                var brokerName = Request.Form["NvcBrokerName"];
                var dtmupdateon = DateTime.Now;
                var intUpdatedBy = globals.User_ID;
                var isActive = 0;
                string mvalue =Convert.ToString( Request.Form["IsActive"]);

                if (mvalue == "1")
                {
                    isActive = 1;
                }
                else if (mvalue == "on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else
                {
                    isActive = 0;
                }

                try
                {
                    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                    {
                        if (cmd.Connection.State != ConnectionState.Open)
                        {
                            cmd.Connection.Open();
                        }
                        cmd.CommandText = "update brokerSites set intUpdatedBy = '" + intUpdatedBy + "', dtmUpdationDate = '" + dtmupdateon + "', IsActive = '" + isActive + "'  where Id = '" + id + "'";
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();

                        ViewBag.Status = 1;
                        ViewBag.successStatus = 1;

                        ViewBag.model = brokerSites;
                        return RedirectToAction("BrokerSites", "BrokerSite");
                    }

                }
                catch (Exception ee)
                {
                    ViewBag.Status = 0;
                    ViewBag.successStatus = 0;
                    return RedirectToAction("BrokerSite", "BrokerSite");

                }
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("BrokerMaster", "BrokerMaster");
        }

        //public void GetDropdownList()
        //{
        //    List<SelectListItem> Lista = new List<SelectListItem>();
        //    Lista.Add(new SelectListItem { Text = "", Value = "", Selected = true });
        //    var componentData = GetBrokerList();

        //    foreach (var brokerlist in componentData)
        //    {
        //        Lista.Add(item: new SelectListItem { Text = brokerlist.NvcBrokerName, Value = brokerlist.NvcBrokerName });
        //    }
        //    ViewData["YourListofclassnames"] = Lista;
        //}

        //public List<BrokerMaster> GetBrokerList()
        //{
        //    string jointvalue = "";
        //    List<BrokerMaster> brokerMasters = new List<BrokerMaster>();
        //    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
        //    {
        //        if (cmd.Connection.State != ConnectionState.Open)
        //        {
        //            cmd.Connection.Open();
        //        }
        //        cmd.CommandText = "Select Cast(Id as varchar) +' - '+ NvcBrokerName  jointval from BrokerMaster order by NvcBrokerName";
        //        SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();

        //        if (dataread.HasRows)
        //        {
        //            while (dataread.Read())
        //            {
        //                jointvalue = dataread.GetString(0);

        //                brokerMasters.Add(new BrokerMaster
        //                {
        //                    NvcBrokerName = dataread.GetString(0)
        //                }); ; ;
        //            }
        //            ViewBag.modelComponentsid = new SelectList(brokerMasters, "NvcBrokerName", "NvcBrokerName");
        //        }
        //        return brokerMasters;
        //    }
        //}

        [HttpPost]
        public IActionResult Clear(BrokerMaster brokerMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;
            globals.BrokerId = 0;
            globals.BrokerName = null;
            globals.BrokerIdList = null;
            DisplayData();
            return RedirectToAction("BrokerSites", "BrokerSite");

        }

        public IActionResult DisplayData()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            List<BrokerSites> brokerSites = new List<BrokerSites>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }
            cmd.CommandText = "Select id, isnull(NvcSiteName,'') NvcSiteName, IsActive  from BrokerSites where intbrokerid = '" + globals.BrokerId + "' and IsDeleted = 0";

            Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
            if (dataread.HasRows)
            {
                while (dataread.Read())
                {

                    brokerSites.Add(new BrokerSites
                    {
                        Id = dataread.GetInt32(0),
                        NvcSiteName = dataread.GetString(1),
                        IsActive = dataread.GetInt32(2)
                    }); ; ; ;

                }
                cmd.Connection.Close();

                ViewBag.model = brokerSites;
                return View();
            }
            return View();
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }


    }
}
