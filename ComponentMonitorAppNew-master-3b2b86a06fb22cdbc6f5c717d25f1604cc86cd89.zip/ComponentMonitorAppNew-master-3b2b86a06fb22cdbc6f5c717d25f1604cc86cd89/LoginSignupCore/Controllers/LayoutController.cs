﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class LayoutController : Controller
    {
        private readonly ApplicatonDBContext _dbcontext;

        public LayoutController(ApplicatonDBContext context)
        {
            _dbcontext = context;
        }
        public IActionResult SidebarPartial()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            Dictionary<int, List<TreeViewNode>> nodes = new();
            Dictionary<int, string> BrokerName = new();
            foreach (BrokerMaster type in _dbcontext.BrokerMaster.ToList())
            {

                if (!nodes.TryGetValue(type.Id, out var treeViewNode))
                {
                    //var treeview = new  TreeViewNode { id = type.Id, parent = "#", text = type.NvcBrokerName };
                    nodes.Add(type.Id, new List<TreeViewNode>());
                    BrokerName.Add(type.Id, type.NvcBrokerName);
                }
            }

            foreach (BrokerSites type in _dbcontext.BrokerSites)
            {
                if (nodes.TryGetValue(type.IntBrokerId, out var treeViewNode))
                {
                    var treeview = new TreeViewNode { id = type.IntBrokerId, cid = type.Id, parent = "_", text = type.NvcSiteName };
                    treeViewNode.Add(treeview);
                }
                else
                {
                    var list = new List<TreeViewNode>();
                    var treeview = new TreeViewNode { id = type.IntBrokerId, cid = type.Id, parent = "_", text = type.NvcSiteName };
                    list.Add(treeview);
                    nodes.Add(type.IntBrokerId, list);
                }
            }
            var MenuItems = new DictionaryOfTreeViewModl()
            {
                MenuItem = nodes,
                BokerName = BrokerName,
            };
            return PartialView("_SidebarPartial", MenuItems);
        }
        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
