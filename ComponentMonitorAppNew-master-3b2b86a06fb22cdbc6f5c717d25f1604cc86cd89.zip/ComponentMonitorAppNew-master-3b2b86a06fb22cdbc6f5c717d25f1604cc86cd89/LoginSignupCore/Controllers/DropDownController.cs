﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using LoginSignupCore.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using LoginSignupCore.Data;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class DropDownController : Controller
    {

        private readonly ApplicatonDBContext _dbcontext;

        public DropDownController(ApplicatonDBContext context)
        {
            _dbcontext = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            globals.componentname = "Please Select";
            GetDropdownList ();

            return View();
            //return View();
        }

        [HttpPost]
        public IActionResult Index(AlertThreshold _alertThreshold)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            string name = Request.Form["Para"];
            globals.componentname = name;
           // string nameval = _alertThreshold.ComponentName;
            GetDropdownList();
            return View();
        }

        public void GetDropdownList()
        {
            List<SelectListItem> Lista = new List<SelectListItem>();
            Lista.Add(new SelectListItem { Text = "", Value = "", Selected = true });
            var componentData = GetComponentParameter();

            foreach (var classes in componentData)
            {
                Lista.Add(item: new SelectListItem { Text = classes.ParameterName, Value = classes.ParameterName });
            }
            ViewData["YourListofclassnames"] = Lista;
        }

        public List<ComponentParameter> GetComponentParameter()
        {
            string jointvalue = "";            
            List<ComponentParameter> componentParameter = new List<ComponentParameter>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            {
                if (cmd.Connection.State != ConnectionState.Open)
                {
                    cmd.Connection.Open();
                }
                cmd.CommandText = "Select Cast(ParamId as varchar) +' - '+ ParameterName  jointval from ComponentParameter order by ParameterName";
                SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();

                if (dataread.HasRows)
                {
                    while (dataread.Read())
                    {
                        jointvalue = dataread.GetString(0);

                        componentParameter.Add(new ComponentParameter
                        {
                            ParameterName = dataread.GetString(0)
                        }); ; ;
                    }
                    ViewBag.modelComponentsid = new SelectList(componentParameter, "ParameterName", "ParameterName");
                }
                return componentParameter;
            }
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }


    }
}
