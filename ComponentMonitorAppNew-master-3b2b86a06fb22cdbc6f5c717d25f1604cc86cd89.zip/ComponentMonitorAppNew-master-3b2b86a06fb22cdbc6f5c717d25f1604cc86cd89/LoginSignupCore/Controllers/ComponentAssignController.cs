﻿using LoginSignupCore.Core;
using LoginSignupCore.Data;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using LoginSignupCore.Models.Request;
using LoginSignupCore.Models.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Security.Claims;
using System.Security.Policy;
using Component = LoginSignupCore.Models.Component;

namespace LoginSignupCore.Controllers
{

    public class ComponentAssignController: Controller
    {
        private readonly ComponentRepository componentRepository;
        public ComponentAssignController()
        {
            componentRepository = new();
        }
        [HttpGet]
        public IActionResult ComponentsMaster(int agentId, int brokerid,int siteid,int id=0)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ComponentViewModel ComponentsView = new();
            try
            {
                ComponentsView.Components = componentRepository.GetAllComponentAgentWise(agentId);
                ComponentsView.Component = new();
                ComponentsView.Component.AgentId = agentId;
                ComponentsView.Component.BrokerId = brokerid;
                ComponentsView.Component.SiteId = siteid;
                ComponentsView.Component.Id = id;
                ComponentsView.Component.AgentName = CoreProcess.agentSessionCache.GetSession(brokerid, siteid, agentId).Item2?.AgentName??string.Empty;

            }
            catch (Exception ex)
            {
                throw;
            }
            return View(ComponentsView);
        }
        [HttpPost]
        public IActionResult Component(Component componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var component = new Component()
            {
                Id= componentMaster.Id,
                BrokerId = componentMaster.BrokerId,
                SiteId = componentMaster.SiteId,
                AgentId= componentMaster.AgentId,
                ComponentType= componentMaster.ComponentType,
                ExePath= componentMaster.ExePath,
                InstanceId = componentMaster.InstanceId,
                CmdParam= string.IsNullOrEmpty(componentMaster.CmdParam) ?"": componentMaster.CmdParam,
                IsRunAsService = componentMaster.IsRunAsService,
                ServiceName = componentMaster.ServiceName,
                Priority=componentMaster.Priority,
                DtmCreationDate = DateTime.Now.Date,
                IntCreatedBy = globals.User_ID,
                Remarks = componentMaster.Remarks,
                ComponentName = componentMaster.ComponentName,
                AgentName = CoreProcess.agentSessionCache.GetSession(componentMaster.BrokerId, componentMaster.SiteId, componentMaster.AgentId).Item2?.AgentName??string.Empty
            };
            if (ModelState.IsValid)
            {
                try
                {
                    componentRepository.InsertAgentWiseComponentData(component);
                }
                catch (Exception ex)
                {
                    throw;
                }
             return RedirectToAction("ComponentsMaster", new { agentId = componentMaster.AgentId, brokerid = componentMaster.BrokerId, siteid = componentMaster.SiteId });

            }
            foreach (var item in ModelState.Values.SelectMany(v => v.Errors))
            {
                Console.WriteLine(item.ErrorMessage);
            }
            List<ComponentDropDown> list = componentRepository.GetComponentDropDowmList(component.AgentId);
            if (list != null && list.Count > 0)
                //ViewBag.ComponentDropDown = list;
            componentMaster.com = list;
             return RedirectToAction("Component", new { agentId = componentMaster.AgentId, brokerid = componentMaster.BrokerId, siteid = componentMaster.SiteId });
            //return PartialView(component);
        }
       [HttpGet("ComponentAssign/ComponentFile/{agentId}/{brokerid}/{siteid}/{id?}")]
        public IActionResult ComponentFile(int agentId, int brokerid, int siteid,int id=0)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            Component comp = new Component();
            if (id != 0)
            {
                 comp = componentRepository.GetComponentById(id);
                comp.BrokerId = brokerid;
                comp.SiteId = siteid;
                comp.AgentName =  CoreProcess.agentSessionCache.GetSession(brokerid,siteid,agentId).Item2?.AgentName??string.Empty;


            }
            else
            {
                 comp = new Component()
                {
                    Id = 0,
                    AgentId = agentId,
                    BrokerId = brokerid,
                    SiteId= siteid
                };
            }

            List<ComponentDropDown> list = componentRepository.GetComponentDropDowmList(agentId);
            if (list != null && list.Count > 0)
                comp.com = list;

            return PartialView("Component", comp);
            //return RedirectToAction("ComponentsMaster", new { agentId = comp.AgentId, brokerid = comp.BrokerId, siteid = comp.SiteId });
        }
       
        public IActionResult Update(Component componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var component = new Component()
            {
                Id = componentMaster.Id,
                AgentId = componentMaster.AgentId,
                ComponentType = componentMaster.ComponentType,
                ExePath = componentMaster.ExePath,
                CmdParam = componentMaster.CmdParam ?? string.Empty,
                IsRunAsService = componentMaster.IsRunAsService,
                ServiceName = componentMaster.ServiceName,
                Priority = componentMaster.Priority,
                DtmUpdationDate = DateTime.Now.Date,
                IntUpdatedBy = globals.User_ID,
                Remarks = componentMaster.Remarks
            };
            try
            {
                componentRepository.UpdateData(component);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("ComponentsMaster", new { agentId = componentMaster.AgentId, brokerid =componentMaster.BrokerId, siteid =componentMaster.SiteId });

        }
      
        public IActionResult Delete(Component componentmaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var component = new Component()
            {
                Id = componentmaster.Id,
                AgentId = componentmaster.AgentId,
                IsDeleted = 1,
                DtmUpdationDate = DateTime.Now.Date,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Deleted AgentwiseComponent",
                BrokerId = componentmaster.BrokerId,
                SiteId = componentmaster.SiteId
                
            };
            try
            {
                componentRepository.UpdateIsDelete(component);
                CompInitReq req = new CompInitReq()
                {
                    BrokerId = componentmaster.BrokerId,
                    SiteId = componentmaster.SiteId,
                    AgentId = componentmaster.AgentId,
                    CompId = componentmaster.ComponentType,
                    InstanceId = componentmaster.InstanceId
                };
                bool flag = true;
                CoreProcess.agentSessionCache.UpdateIsDeleteFlag(req, flag);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("ComponentsMaster", new { agentId = component.AgentId, brokerid = component.BrokerId, siteid = component.SiteId });

        }
        public IActionResult Edit(Component componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var component = new Component()
            {
                Id = componentMaster.Id,
                AgentId = componentMaster.AgentId,
                IsActive = componentMaster.IsActive,
                DtmUpdationDate = DateTime.Now.Date,
                IntUpdatedBy = globals.User_ID,
                Remarks = "IsActive AgentwiseComponent updated"
            };
            try
            {
                componentRepository.UpdateIsActive(component);
                CompInitReq req = new CompInitReq()
                {
                    BrokerId = componentMaster.BrokerId,
                    SiteId = componentMaster.SiteId,
                    AgentId = componentMaster.AgentId,
                    CompId = componentMaster.ComponentType,
                    InstanceId = componentMaster.InstanceId
                };
                bool flag = componentMaster.IsActive==1 ? true : false;
                CoreProcess.agentSessionCache.UpdateIsActiveFlag(req,flag);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("ComponentsMaster", new { agentId = componentMaster.AgentId, brokerid = componentMaster.BrokerId, siteid = componentMaster.SiteId });

        }
        public IActionResult Status(int brokerid, int siteid, int isAjax = 0)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            List<ComponentStatus> status = CoreProcess.agentSessionCache.GetComponentStatus(brokerid, siteid);
            //ViewBag.model = componentMasters;
            ComponentViewStatus comp = new ComponentViewStatus();
            comp.ComponentsStatus = status;
            comp.BrokerId = brokerid;
            comp.SiteId = siteid;

            if (isAjax == 1 )
            {
                var json = JsonConvert.SerializeObject(status);
                return Json(json);
            }
            return View(comp);
        }
        [HttpGet]
        public IActionResult Cancel(int agentId,int siteId, int brokerId)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");

            }
            return RedirectToAction("ComponentsMaster",new { agentId = agentId, brokerid = brokerId, siteid = siteId});
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
