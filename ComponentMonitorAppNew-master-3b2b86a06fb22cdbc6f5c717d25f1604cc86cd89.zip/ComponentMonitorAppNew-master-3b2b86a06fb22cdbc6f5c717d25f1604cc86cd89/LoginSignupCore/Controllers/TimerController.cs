﻿//using LoginSignupCore.Data;
//using LoginSignupCore.Models;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Mvc;
//using System.Security.Claims;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Data.SqlClient;
//using System.Data;

//namespace LoginSignupCore.Controllers
//{
//    public class TimerController : Controller
//    {
//        private readonly ApplicatonDBContext _dbcontext;
//        public TimerController(ApplicatonDBContext context)
//        {
//            _dbcontext = context;
//        }
//        public IActionResult DisplayData()
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!(claimUser.Identity.IsAuthenticated))
//            {
//                return RedirectToAction("Login", "Account");

//            }
//            GetTimerValue();
//            return View();
//        }

//        [HttpPost]
//        public IActionResult DisplayData(CTCLTimer cTCLTimer)
//        {            
//            try
//            {
//                ViewBag.successStatus = 0;
//                var pTimer = Request.Form["TimerinMins"];
//                var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//                {
//                    if (cmd.Connection.State != ConnectionState.Open)
//                    {
//                        cmd.Connection.Open();
//                    }
//                    cmd.CommandText = "update CTCLTimer set timerInMins=" + pTimer ;
//                    cmd.ExecuteNonQuery();
//                    cmd.Connection.Close();
//                    ViewBag.CMATimer = pTimer;
//                    globals.Timer = Convert.ToInt32(pTimer);
//                    ViewBag.successStatus = 1;                    
//                    ViewBag.model = cTCLTimer;
//                    return View();
//                }               
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//                return View();
//            }
           
//        }
        
//        public void GetTimerValue()
//        {            
//            try
//            {
//                var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//                if (cmd.Connection.State != ConnectionState.Open)
//                {
//                    cmd.Connection.Open();
//                }
//                cmd.CommandText = "SELECT timerinMins FROM CTCLtimer";
//                SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//                if (dataread.HasRows)
//                {
//                    while (dataread.Read())
//                    {
//                        globals.Timer = dataread.GetInt32(0);
//                    }
//                    ViewBag.CMATimer = globals.Timer;
//                }
//            }
//            catch(Exception ex)
//            {
//                globals.Timer = 5;
//                ViewBag.CMATimer = Convert.ToString(5);
//            }
//        }

//        public async Task<IActionResult> Logout()
//        {
//            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//            globals.User_ID = 0;
//            return RedirectToAction("Login", "Account");
//        }




//    }
//}
