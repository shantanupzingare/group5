﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using LoginSignupCore.Models.Request;
using LoginSignupCore.Core.Services;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class MainController : Controller
    {
        private readonly ApplicatonDBContext _dbcontext;
        public MainService _mainService;
        public MainController(ApplicatonDBContext context)
        {
            _dbcontext = context;
            _mainService = new();
        }
        public IActionResult Monitoring()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }
        //{
        //    ClaimsPrincipal claimUser = HttpContext.User;
        //    if (!(claimUser.Identity.IsAuthenticated))
        //    {
        //        return RedirectToAction("Login", "Account");
        //    }

        //    Dictionary<int, List<TreeViewNode>> nodes = new();
        //    Dictionary<int, string> BrokerName = new();
        //    foreach (BrokerMaster type in _dbcontext.BrokerMaster.ToList())
        //    {

        //        if (!nodes.TryGetValue(type.Id, out var treeViewNode))
        //        {
        //            //var treeview = new  TreeViewNode { id = type.Id, parent = "#", text = type.NvcBrokerName };
        //            nodes.Add(type.Id, new List<TreeViewNode>());
        //            BrokerName.Add(type.Id, type.NvcBrokerName);
        //        }
        //    }

        //    foreach (BrokerSites type in _dbcontext.BrokerSites)
        //    {
        //        if (nodes.TryGetValue(type.IntBrokerId, out var treeViewNode))
        //        {
        //            var treeview = new TreeViewNode { id = type.IntBrokerId, cid = type.Id, parent = "_", text = type.NvcSiteName };
        //            treeViewNode.Add(treeview);
        //        }
        //        else
        //        {
        //            var list = new List<TreeViewNode>();
        //            var treeview = new TreeViewNode { id = type.IntBrokerId, cid = type.Id, parent = "_", text = type.NvcSiteName };
        //            list.Add(treeview);
        //            nodes.Add(type.IntBrokerId, list);
        //        }
        //    }
        //    var MenuItems = new DictionaryOfTreeViewModl()
        //    {
        //        MenuItem = nodes,
        //        BokerName = BrokerName,
        //    };
        //    return PartialView("_SidebarPartial", MenuItems);

        //}
        private void GetSites(int pBrokerId)
        {
            List<LoginSignupCore.Models.VwInfoStatsData> vwInfoStatsData = new List<LoginSignupCore.Models.VwInfoStatsData>();
            var cmd2 = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd2.Connection.State != ConnectionState.Open)
            {
                cmd2.Connection.Open();
            }
            cmd2.CommandText = "Select distinct [IntSiteId] ,[BrokerName],VarBrokerId, NvcSiteName  from [vwInfoStatsData] where varBrokerId = '" + pBrokerId + "'";

            int counter = 101;
            Microsoft.Data.SqlClient.SqlDataReader dataread2 = (Microsoft.Data.SqlClient.SqlDataReader)cmd2.ExecuteReader();
            if (dataread2.HasRows)
            {
                while (dataread2.Read())
                {
                    counter = counter + 1;
                    vwInfoStatsData.Add(new LoginSignupCore.Models.VwInfoStatsData
                    {
                        IntSiteId = dataread2.GetInt32(0),
                        NvccomponentName = "T" + Convert.ToString(counter),
                        BrokerName = dataread2.GetString(1),
                        VarBrokerId = dataread2.GetInt32(2),
                        NvcSiteName = dataread2.GetString(3)
                    });
                    
                    GetSiteallComponents(dataread2.GetString(1), dataread2.GetInt32(0));
                    GetSiteTechnicalComponents(dataread2.GetInt32(2), dataread2.GetInt32(0));
                    GetSiteFunctionalComponents(dataread2.GetInt32(2), dataread2.GetInt32(0));
                    var BrokerId = dataread2.GetInt32(2);
                    var SiteId = dataread2.GetInt32(0);
                    var BrokerSiteInstanceId = Convert.ToString(BrokerId) + "-" + Convert.ToString(SiteId);
                    int Timer = globals.Timer;

                    //LoginSignupCore.AppCode.SocketManager.GetTechnicalData(BrokerSiteInstanceId,BrokerId,SiteId,Timer);
                    
                }                  
            }
            //LoginSignupCore.AppCode.SocketManager.GetTechnicalData("11-19", 11, 19, 1);
            ViewBag.Sites = vwInfoStatsData;
        }

        
        private void GetSiteallComponents(string pBrokerName,int pSiteId)
        {
            List<LoginSignupCore.Models.VwInfoStatsData> vwInfoStatsData = new List<LoginSignupCore.Models.VwInfoStatsData>();
            var cmd2 = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd2.Connection.State != ConnectionState.Open)
            {
                cmd2.Connection.Open();
            }
            cmd2.CommandText = "Select distinct intcomponentid,nvccomponentName,intinstanceid,nvcInstanceName,nvcInstanceIP,intPort,BrokerName,varBrokerId,ParamId,ParameterName,nvcReference,nvcValue,intSiteId,nvcSiteName from [VwInfoStatsData] where brokername = '" + pBrokerName + "' and intsiteid = '"+  pSiteId + "'";

            int counter = 10101;
            Microsoft.Data.SqlClient.SqlDataReader dataread2 = (Microsoft.Data.SqlClient.SqlDataReader)cmd2.ExecuteReader();
            if (dataread2.HasRows)
            {
                while (dataread2.Read())
                {
                    counter = counter + 1;
                    vwInfoStatsData.Add(new LoginSignupCore.Models.VwInfoStatsData
                    {
                        NvcInstanceName = "A" + Convert.ToString(counter),                        
                        NvccomponentName = dataread2.GetString(1),
                        Intinstanceid = dataread2.GetString(2)
                    }); ; ; ;

                }

            }           
            ViewBag.SiteComponents = vwInfoStatsData;
        }
        private void GetSiteTechnicalComponents(int pBrokerId, int pSiteId)
        {
            List<ComponentParameter> componentParameters = new List<ComponentParameter>();
            var cmd2 = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd2.Connection.State != ConnectionState.Open)
            {
                cmd2.Connection.Open();
            }
            cmd2.CommandText = "Select distinct [ParamId],[ComponentId],[InstanceId],[ParameterName],[BrokerSiteId] from ComponentParameter where [bitAttributeType] = 1 and  BrokerSiteId = '" + pBrokerId + "'+ '-' +'" + pSiteId + "'";

            int counter = 20101;
            Microsoft.Data.SqlClient.SqlDataReader dataread2 = (Microsoft.Data.SqlClient.SqlDataReader)cmd2.ExecuteReader();
            if (dataread2.HasRows)
            {
                while (dataread2.Read())
                {
                    counter = counter+ 1;
                    componentParameters.Add(new ComponentParameter
                    {
                        Remarks = "T" + Convert.ToString(counter),
                        ParamId = dataread2.GetInt32(0),
                        ComponentId = dataread2.GetString(1),
                        InstanceId = dataread2.GetString(2),
                        ParameterName = dataread2.GetString(3),
                        BrokerSiteId = dataread2.GetString(4)                       
                    }); ; ; ;
                }
             }
            ViewBag.SiteTechnicalComponents = componentParameters;
        }
        private void GetSiteFunctionalComponents(int pBrokerId, int pSiteId)
        {
            List<ComponentParameter> componentParameters = new List<ComponentParameter>();
            var cmd2 = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd2.Connection.State != ConnectionState.Open)
            {
                cmd2.Connection.Open();
            }
            cmd2.CommandText = "Select distinct [ParamId],[ComponentId],[InstanceId],[ParameterName],[BrokerSiteId] from ComponentParameter where [bitAttributeType] = 0 and  BrokerSiteId = '" + pBrokerId + "'+ '-' +'" + pSiteId + "'";

            int counter = 20101;
            Microsoft.Data.SqlClient.SqlDataReader dataread2 = (Microsoft.Data.SqlClient.SqlDataReader)cmd2.ExecuteReader();
            if (dataread2.HasRows)
            {
                while (dataread2.Read())
                {
                    counter = counter + 1;
                    componentParameters.Add(new ComponentParameter
                    {
                        BrokerSiteId = "F" + Convert.ToString(counter),
                        ParamId = dataread2.GetInt32(0),
                        ComponentId = dataread2.GetString(1),
                        InstanceId = dataread2.GetString(2),
                        ParameterName = dataread2.GetString(3),
                    }); ; ; ;
                }
            }
            ViewBag.SiteFunctionalComponents = componentParameters;
        }

        private string GetComponentName(int componentId)
        {
            string componentName = "";
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }
            cmd.CommandText = "Select top 1 nvcComponentName from [ComponentMaster] where intComponentId = '" + componentId + "'";

            Microsoft.Data.SqlClient.SqlDataReader dataread2 = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
            if (dataread2.HasRows)
            {
                while (dataread2.Read())
                {
                    componentName = dataread2.GetString(0);
                }
            }
            return componentName;
        }

        [HttpPost]
        public IActionResult StartProcess(LoginSignupCore.Models.VwInfoStatsData vwInfoStatsData)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            string brokerSiteId = Request.Form["BrokerSiteId"];
            int componentId = Convert.ToInt32(Request.Form["ComponentId"]);
            string serviceName = GetComponentName(componentId);   

            string action = "Start";

            //SocketManager.SendStopStartReq(brokerSiteId, serviceName, action);
            return RedirectToAction("Monitoring", "Main");
        }
        [HttpPost]
        public IActionResult StopProcess(LoginSignupCore.Models.VwInfoStatsData vwInfoStatsData)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            string brokerSiteId = Request.Form["BrokerSiteId"];
            int componentId = Convert.ToInt32(Request.Form["ComponentId"]);
            string serviceName = GetComponentName(componentId);

            string action = "Stop";

            //SocketManager.SendStopStartReq(brokerSiteId, serviceName, action);
            return RedirectToAction("Monitoring", "Main");
        }

        [HttpPost]
        public IActionResult StartComponent(CompInitReq compInitReq)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            (bool, string) isValid = ValidateRequest(compInitReq);
            if(isValid.Item1)
            {
                _mainService.StartComponent(compInitReq);
            }
            return RedirectToAction("StartComponent", "BODProcess", new { brokerid = compInitReq.BrokerId, siteid = compInitReq.SiteId, agentid = compInitReq.AgentId});
        }

        [HttpPost]
        public IActionResult StopComponent( CompInitReq compInitReq)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            (bool, string) isValid = ValidateRequest(compInitReq);
            if (isValid.Item1)
            {
                _mainService.StopComponent(compInitReq);
            }
            return RedirectToAction("StartComponent", "BODProcess", new { brokerid = compInitReq.BrokerId, siteid = compInitReq.SiteId, agentid = compInitReq.AgentId });

        }

        [HttpPost]
        public IActionResult StartFileUpload( CompInitReq compInitReq)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            (bool, string) isValid = ValidateRequest(compInitReq);
            if (isValid.Item1)
            {
                _mainService.StartFileUpload(compInitReq);
            }
            return RedirectToAction("Index", "BODProcess", new { brokerid = compInitReq.BrokerId, siteid = compInitReq.SiteId, agentid = compInitReq.AgentId });
        }

        [HttpPost]
        public IActionResult StartAfterBodFileUpload( CompInitReq compInitReq)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            (bool, string) isValid = ValidateRequest(compInitReq);
            if (isValid.Item1)
            {
                _mainService.StartAfterBodFileUpload(compInitReq);
            }
            return RedirectToAction("Index", "BODProcess", new { brokerid = compInitReq.BrokerId, siteid = compInitReq.SiteId, agentid = compInitReq.AgentId });
        }

        private (bool, string) ValidateRequest(CompInitReq compInitReq)
        {
            if (compInitReq == null)
                return (false, "Invalid Request");
            else if (compInitReq.BrokerId <= 0)
                return (false, "Invalid BrokerId");
            else if (compInitReq.SiteId <= 0)
                return (false, "Invalid SiteId");
            else if (compInitReq.AgentId <= 0)
                return (false, "Invalid AgentId");
            return (true, "");
        }
        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
