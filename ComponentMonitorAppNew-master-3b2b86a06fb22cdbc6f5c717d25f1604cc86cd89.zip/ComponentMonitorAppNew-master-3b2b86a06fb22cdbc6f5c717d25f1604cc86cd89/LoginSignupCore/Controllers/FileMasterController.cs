﻿using BinaryProtocol.Common;
using CTCL.BinaryProtocol.Common.CTCL.Common;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using CTCL.CacheManagement.Structs;
using LoginSignupCore.Core;
using LoginSignupCore.Data;
using LoginSignupCore.Global;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using LoginSignupCore.Models.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class FileMasterController : Controller
    {
        private readonly ApplicatonDBContext _dbcontext;
        private readonly FileRepository fileRepository;

        public FileMasterController(ApplicatonDBContext context)
        {
            _dbcontext = context;
            fileRepository = new FileRepository();
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult File(int id)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var segmentid = Enum.GetValues(typeof(CTCL_ExchangeIdentifier)).Cast<CTCL_ExchangeIdentifier>().Select(s => new SelectListItem
            {
                Value = ((int)s).ToString(),
                Text =s.ToString()

            }).ToList();
            ViewBag.SegmentId = segmentid;
            FileMaster fileMaster = fileRepository.GetFileById(id);
           
            return PartialView("File",fileMaster);
        }
 

        //for updating the file
        public IActionResult Fileupdate(int id)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            FileMaster fileMaster = fileRepository.GetFileById(id);
            return RedirectToAction("FileMaster", fileMaster);
        }

        //Display Files 
        [HttpGet]
        public IActionResult FileMaster(FileMaster file)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            FileViewModel fileView = new();
            try
            {
                fileView.files = fileRepository.GetAllFiles();
                fileView.file = new();
                if(file.id !=0)
                {
                    fileView.file = file;
                }
                else
                {
                    fileView.file.id = file.id;
                }
                
            }
            catch (Exception ex)
            {
                throw;
            }
            return View(fileView);

        }


        //For adding new File
        [HttpPost]
        public IActionResult AddFile(FileMaster fileMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            var file = new FileMaster() { SegmentId = fileMaster.SegmentId, FileType = fileMaster.FileType, FileName = fileMaster.FileName, Priority = fileMaster.Priority, UploadBeforeBod = fileMaster.UploadBeforeBod, nvcDestinationPath = fileMaster.nvcDestinationPath, isActive = 1, isDeleted= fileMaster.isDeleted, Remarks = "Files Added", IntCreatedOn= DateTime.Now.Date, IntCreatedBy= globals.User_ID, };
            try
            {
                if (file.FileName != null && file.UploadBeforeBod != null && file.Priority != 0 && file.SegmentId != 0 && file.FileType != 0)
                {
                    fileRepository.InsertFiles(file);
                }else
                {
                    TempData["ErrorMessage"] = "All fields are required";
                    return RedirectToAction("FileMaster", "FileMaster");
                }
            }
            catch (Exception ex)
            {
                if(ex.Message.Contains("unique_file_priority"))
                {
                    TempData["ErrorMessage"] = " Priority already exists, Kindly modify the priority and retry!";
                }
                else if(ex.Message.Contains("unique_FileType"))
                {
                    TempData["ErrorMessage"] = " FileType already exists, Kindly modify the FileType and retry!";
                }
                return RedirectToAction("FileMaster", "FileMaster");
            }
            return RedirectToAction("FileMaster", "FileMaster");
        }

        //For Updating the Files 
        [HttpPost]
        public IActionResult FileUpdate(FileMaster fileMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var file = new FileMaster()
            {
                id = fileMaster.id,
                FileName = fileMaster.FileName,
                nvcDestinationPath = fileMaster.nvcDestinationPath,
                Priority = fileMaster.Priority,
                UploadBeforeBod = fileMaster.UploadBeforeBod,
                isActive = 1,
                Remarks = "Files Updated",
                UpdatedBy = globals.User_ID,
                UpdatedOn = DateTime.Now.Date

            };
            try
            {
                fileRepository.Update(file);
            }
            catch (Exception ex)
            {
                throw;
            }
            var response = new FileMaster();
            return RedirectToAction("FileMaster", response);
        }

        //For Delete the File From FileMaster
        [HttpGet]
        public IActionResult Delete(int id)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var file = new FileMaster()
            {
                id = id,
                isDeleted = 1,
                UpdatedOn = DateTime.Now,
                UpdatedBy = globals.User_ID,
                Remarks = "Agent Deleted."
            };
            try
            {
                int rows = fileRepository.Delete(file);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("FileMaster", new { fid = file.id });

        }

        //For Activating and Deactivating File
        [HttpGet]
        public IActionResult UpdateIsActive(int id, int isActive)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var file = new FileMaster()
            {
                id = id,
                isActive = isActive,
                UpdatedOn = DateTime.Now,
                UpdatedBy = globals.User_ID,
                Remarks = "FileUpdated"
            };
            try
            {
                int rows = fileRepository.UpdateIsActiveData(file);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("FileMaster");

        }

        public IActionResult Clear(FileMaster filemaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = null;
            return RedirectToAction("FileMaster", "FileMaster");
        }

        public IActionResult FileStatus(int brokerId, int siteId, int isAjax = 0)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            List<FileStatus> status = CoreProcess.agentSessionCache.GetFileStatus(brokerId, siteId);
            var fileStatus = new FileStatusView();
            fileStatus.fileStatus = status;
            fileStatus.file.BrokerId= brokerId;
            fileStatus.file.SiteId= siteId;

            if (isAjax == 1)
            {
                var convertjson = JsonConvert.SerializeObject(fileStatus.fileStatus);
                return Json(convertjson);
            }
            return View(fileStatus);
        }
        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }


}
