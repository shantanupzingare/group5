﻿using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using LoginSignupCore.Data;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
	//[Authorize]
	public class HomeController : Controller
	{
		//private readonly ILogger<HomeController> _logger;
        private readonly ApplicatonDBContext _dbcontext;        
        public HomeController(ApplicatonDBContext context)
        {
            _dbcontext = context;
        }
  //      public HomeController(ILogger<HomeController> logger)
		//{
		//	_logger = logger;
		//}

		public IActionResult Index()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
		}

		public IActionResult Privacy()
		{
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}