﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Text;
using LoginSignupCore.Global;

namespace LoginSignupCore.Controllers
{
    public class AccountController : Controller
	{
		public IActionResult Index()
		{
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                return RedirectToAction("Login", "Account");

            }
            return View();
		}
		private readonly ApplicatonDBContext _dbcontext;
		public AccountController (ApplicatonDBContext context)
		{
			_dbcontext = context;
		}
		[HttpGet]
		public IActionResult Register() 
		{
            return View(new RegisterViewModel());
		}

        private string EncryptPass(string password)
        {
            string msg = "";
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            msg = Convert.ToBase64String(encode);
            return msg;
        }

        [HttpPost]
        public IActionResult Register(RegisterViewModel user)
        {
            if (ModelState.IsValid)
			{
                user.Password = EncryptPass(user.Password);
                user.ConfirmPassword = EncryptPass(user.ConfirmPassword);
                _dbcontext.Accounts.Add(user);
				_dbcontext.SaveChanges();
				return RedirectToAction("Login", "Account");
			}
            return View(user);
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost] 
        public async Task<IActionResult> Login(User model)
        {
            if (ModelState.IsValid)
			{
				var user=_dbcontext.Accounts.FirstOrDefault(u=>u.Email==model.Email);
				if (user!=null && user.Password == EncryptPass(model.Password)) 
				{
                    List<Claim> claims = new List<Claim>()
                    {
                        new Claim(ClaimTypes.NameIdentifier, model.Email),
                        new Claim(ClaimTypes.Name,user.Id.ToString()),
                        new Claim("OtherProperties", "Example Role")
                    };
                    ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims,
                        CookieAuthenticationDefaults.AuthenticationScheme);

                    LoginSignupCore.Models.globals.User_ID = user.Id;

                    AuthenticationProperties properties = new AuthenticationProperties()
                    {
                        AllowRefresh = true,
                        IsPersistent = model.KeepLoggedin
                    };
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                        new ClaimsPrincipal(claimsIdentity), properties);
                    HttpContext.Session.SetString("UserName",model.Email);
                    //TempData["Email"] = model.Email;
                    return RedirectToAction("Monitoring", "Main");
                }
				else
				{
					ViewData["Message"] = "Invalid email or password";
					ModelState.AddModelError("", "Invalid email or password");
					return View();
                }
			}
            return View(model);
        }

        public async Task<IActionResult> Logout()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            HttpContext.Session.Clear();
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            LoginSignupCore.Models.globals.User_ID = 0;
            return RedirectToAction("Login","Account");
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
