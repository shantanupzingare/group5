﻿using LoginSignupCore.Core;
using LoginSignupCore.Data;
using LoginSignupCore.MasterCache;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using System.Security.Policy;

namespace LoginSignupCore.Controllers
{
    public class AgentwiseFilesController : Controller
    {
        private readonly AgentwiseFilesRepository agentwiseFilesRepository;
        public AgentwiseFilesController()
        {
            agentwiseFilesRepository = new();
        }
        public IActionResult AgentWiseFileMaster(int agentId, int brokerid, int siteid)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");

            }
            AgentwiseFileViewModel AgentwiseFileView = new();
            try
            {
                AgentwiseFileView.Files = agentwiseFilesRepository.GetAllFilesAgentWise(agentId);
                AgentwiseFileView.File = new();
                AgentwiseFileView.File.AgentId = agentId;
                AgentwiseFileView.File.BrokerId = brokerid;
                AgentwiseFileView.File.SiteId = siteid;
                AgentwiseFileView.File.AgentName = CoreProcess.agentSessionCache.GetSession(brokerid, siteid, agentId).Item2?.AgentName??string.Empty;

            }
            catch (Exception ex)
            {
                throw;
            }
            return View(AgentwiseFileView);
        }
        [HttpPost]
        public IActionResult FileUpdate(AgentwiseFiles agentwiseFiles)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");
            }
            agentwiseFiles.DtmCreationDate = DateTime.Now;
            var claim = claimUser.Claims.Where(x => x.ValueType == ClaimTypes.Name).FirstOrDefault();
            agentwiseFiles.IntCreatedBy = claim==null?0:Convert.ToInt32(claim.Value);
            agentwiseFiles.Remarks = string.IsNullOrEmpty(agentwiseFiles.Remarks) ? string.Empty : agentwiseFiles.Remarks; 
            try
            {
                agentwiseFilesRepository.InsertAgentWiseFilesData(agentwiseFiles);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentWiseFileMaster", new { agentId = agentwiseFiles.AgentId, brokerid = agentwiseFiles.BrokerId, siteid = agentwiseFiles.SiteId });

        }

        //[HttpGet]
        [HttpGet("AgentwiseFile/File/{AgentId}/{brokerid}/{siteid}")]
        public IActionResult File(int AgentId, int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            var file = new AgentwiseFiles()
            {
                Id = 0,
                AgentId = AgentId,
                BrokerId =brokerid,
                SiteId = siteid,
                AgentName = CoreProcess.agentSessionCache.GetSession(brokerid,siteid,AgentId).Item2?.AgentName??string.Empty

            };
            var data = new FilesViewModel()
            {
                file = file,
                list = agentwiseFilesRepository.GetFileDropDowmList()
            };
            return PartialView("File", data);
        }


        [HttpGet("AgentwiseFiles/Delete/{id}/{aid}/{brokerid}/{siteid}")]
        public IActionResult Delete(int id, int aid, int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var file = new AgentwiseFiles()
            {
                Id = id,
                AgentId = aid,
                IsDeleted = 1,
                DtmUpdationDate = DateTime.Now.Date,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Deleted AgentwiseFile"
            };
            try
            {
                agentwiseFilesRepository.UpdateIsDelete(file);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentWiseFileMaster", new { agentId = aid, brokerid = brokerid, siteid = siteid });


        }
        [HttpPost]
        public IActionResult Edit(AgentwiseFiles fileMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var file = new AgentwiseFiles()
            {
                Id = fileMaster.Id,
                AgentId = fileMaster.AgentId,
                IsActive = fileMaster.IsActive,
                DtmUpdationDate = DateTime.Now.Date,
                IntUpdatedBy = globals.User_ID,
                Remarks = "IsActive AgentwiseFile updated"
            };
            try
            {
                agentwiseFilesRepository.UpdateIsActive(file);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentWiseFileMaster", new { agentId = fileMaster.AgentId, brokerid = fileMaster.BrokerId, siteid = fileMaster.SiteId });
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
