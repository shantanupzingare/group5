﻿//using LoginSignupCore.Models;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Mvc;
//using System.Security.Claims;
//using Microsoft.EntityFrameworkCore;
//using LoginSignupCore.Data;
//using System.Data;
//using Microsoft.Data.SqlClient;
//using Microsoft.AspNetCore.Mvc.Rendering;

//namespace LoginSignupCore.Controllers
//{
//    public class FunctionalController : Controller
//    {
//        private readonly ApplicatonDBContext _dbcontext;

//        public FunctionalController(ApplicatonDBContext context)
//        {
//            _dbcontext = context;
//        }
//        public IActionResult FunctionalParam()
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!(claimUser.Identity.IsAuthenticated))
//            {
//                globals.User_ID = 0;
//                return RedirectToAction("Login", "Account");
//            }
//            ViewBag.successStatus = null;
//            globals.Broker_Site = "Please Select";
//            globals.Component_Name = "Please Select";
//            globals.Instance_Name = "Please Select";
//            GetDropdownList();
//            GetDropdownComponentList();
//            GetDropdownInstanceList();
//            return View();
//        }

//        [HttpPost]
//        public IActionResult Clear(ComponentParameter componentParameter)
//        {
//            ViewBag.successStatus = null;
//            globals.Broker_Site = "Please Select";
//            globals.Component_Name = "Please Select";
//            globals.Instance_Name = "Please Select";
//            return RedirectToAction("FunctionalParam", "Functional");
//        }

//        public async Task<IActionResult> Logout()
//        {
//            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//            globals.User_ID = 0;
//            return RedirectToAction("Login", "Account");
//        }

//        [HttpPost]
//        public IActionResult FunctionalParam(ComponentParameter componentParameter)
//        {
//            ViewBag.successStatus = 0;
//            try
//            {
//                string pId = Request.Form["BrokerSiteId"];
//                string pCompId = Request.Form["ComponentId"];
//                string pInstId = Request.Form["InstanceId"];

//                componentParameter.IntCreatedBy = globals.User_ID;
//                componentParameter.BitIsDelete = 0;
//                componentParameter.BitIsActive = 1;
//                componentParameter.DtmCreatedOn = DateTime.Now.Date;
//                _dbcontext.ComponentParameters.Add(componentParameter);
//                _dbcontext.SaveChanges();
//                ViewBag.successStatus = 1;
//                GetDropdownList();
//                GetDropdownComponentList();
//                GetDropdownInstanceList();
//                GetDropdownListReload(pId);
//                GetDropdownComponentListReload(pCompId);
//                GetDropdownInstanceListReload(pInstId);
//                return View();
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//            }
//            return View();
//        }

//        public void GetDropdownListReload(string brokerSiteId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 and cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) = '" + brokerSiteId + "' order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Broker_Site = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentsid = new SelectList(Lista, "Text", "Value");
//            }
//        }


//        public void GetDropdownComponentListReload(string intComponentId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where c.intComponentId = '" + intComponentId + "' and  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Component_Name = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownComponentList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentName = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public void GetDropdownInstanceListReload(string intInstanceId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcInstanceName ,cast(intInstanceId as varchar) IntInstanceId from InstanceMaster i where IntInstanceId = '" + intInstanceId + "' and bitIsActive = 1 and bitIsDelete = 0 order by nvcInstanceName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Instance_Name = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownInstanceList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcInstanceName ,cast(intInstanceId as varchar) IntInstanceId from InstanceMaster i where bitIsActive = 1 and bitIsDelete = 0 order by nvcInstanceName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelInstanceName = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public IActionResult DisplayData()
//        {

//            List<VwComponentParameter> componentParameters = new List<VwComponentParameter>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            //cmd.CommandText = "Select isnull(paramid,0) ParamId, isnull(brokerSiteId,'') BrokerSiteId, isnull(componentid,'') ComponentId, isnull(instanceid,'') InstanceId, isnull(ParameterName,'') ParameterName, isnull(remarks,'') Remarks, Cast(bitIsActive as Integer) bitIsActive from ComponentParameter where bitAttributeType = 0 and  bitIsDelete = 0"; // bitAttributeType 0 is used for Functional Parameters
//            cmd.CommandText = "SELECT Cast([intcomponentid] as Varchar) IntComponentId ,[nvccomponentName] ,Cast([intinstanceid] as varchar) intInstanceId ,[nvcInstanceName] ,[BrokerSiteName] ,[varBrokerId] ,[ParamId] ,[ParameterName] ,[intSiteId] ,[nvcBrokerName] ,[nvcSiteName] ,[BrokerSiteId] ,[bitAttributeType], bitIsActive, Remarks FROM [vwComponentParameter] where bitAttributeType = 0"; // bitAttributeType 0 is used for Functional Parameters
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {

//                    componentParameters.Add(new VwComponentParameter
//                    {
//                        Intcomponentid = dataread.GetString(0),
//                        NvccomponentName = dataread.GetString(1),
//                        Intinstanceid = dataread.GetString(2),
//                        NvcInstanceName = dataread.GetString(3),
//                        BrokerSiteName = dataread.GetString(4),
//                        ParamId = dataread.GetInt32(6),
//                        ParameterName = dataread.GetString(7),
//                        BrokerSiteId = dataread.GetString(11),
//                        BitIsActive = dataread.GetInt32(13),
//                        Remarks = dataread.GetString(14)

//                    }); ; ; ;

//                }
//                cmd.Connection.Close();

//                ViewBag.model = componentParameters;
//                return View();
//            }
//            return View();
//        }


//        [HttpPost]
//        public IActionResult FunctionalUpdate(ComponentParameter componentParameter)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");

//            }

//            ViewBag.successStatus = 0;
//            try
//            {
//                var paramId = Convert.ToInt32(Request.Form["ParamId"]);

//                var brokerSiteId = Request.Form["BrokerSiteId"];

//                var instanceId = Request.Form["InstanceId"];



//                if ((brokerSiteId.ToString().Length < 1))
//                {
//                    brokerSiteId = globals.BrokerId_update;
//                }
//                else
//                {
//                    brokerSiteId = Request.Form["BrokerSiteId"];
//                }


//                if ((instanceId.ToString().Length < 1))
//                {
//                    instanceId = globals.Instance_id;
//                }
//                else
//                {
//                    instanceId = Request.Form["InstanceId"];
//                }

//                var parameterName = Request.Form["ParameterName"];
//                var remarks = Request.Form["Remarks"];
//                var dtmupdateon = DateTime.Now;
//                var intUpdatedBy = globals.User_ID;
//                var bitIsActive = 0;
//                string componentid = Request.Form["ComponentId"];
//                string mvalue = Request.Form["BitIsActive"];

//                if ((componentid.ToString().Length < 1))
//                {
//                    componentid = Convert.ToString(globals.Component_ID);
//                }
//                else
//                {
//                    componentid = Request.Form["ComponentId"];
//                }

//                if (mvalue == "1")
//                {
//                    bitIsActive = 1;
//                }
//                else if (mvalue == "on")
//                {
//                    bitIsActive = 1;
//                }
//                else if (mvalue == "1,on")
//                {
//                    bitIsActive = 1;
//                }
//                else if (mvalue == "0,on")
//                {
//                    bitIsActive = 1;
//                }
//                else
//                {
//                    bitIsActive = 0;
//                }

//                try
//                {
//                    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//                    {
//                        if (cmd.Connection.State != ConnectionState.Open)
//                        {
//                            cmd.Connection.Open();
//                        }
//                        cmd.CommandText = "update ComponentParameter set BrokerSiteId='" + brokerSiteId + "',ComponentId='" + componentid + "',InstanceId='" + instanceId + "', ParameterName = '" + parameterName + "', Remarks = '" + remarks + "' , intUpdatedBy = '" + intUpdatedBy + "', dtmUpdatedOn = '" + dtmupdateon + "', bitIsActive = '" + bitIsActive + "'  where ParamId = '" + paramId + "' and bitAttributeType = 0";
//                        cmd.ExecuteNonQuery();
//                        cmd.Connection.Close();

//                        ViewBag.Status = 1;

//                        ViewBag.model = componentParameter;
//                        return RedirectToAction("DisplayData", "Functional");
//                    }

//                }
//                catch (Exception ee)
//                {
//                    globals.Instance_id = " ";
//                    globals.Component_ID = 0;
//                    globals.BrokerId_update = " ";
//                    ViewBag.Status = 0;
//                    return RedirectToAction("FunctionalParam", "Functional");

//                }
//            }
//            catch (Exception ex)
//            {
//                globals.Instance_id = " ";
//                globals.Component_ID = 0;
//                globals.BrokerId_update = " ";
//                ViewBag.successStatus = 0;
//            }
//            return RedirectToAction("FunctionalParam", "Functional");
//        }


//        [HttpPost]
//        public IActionResult Edit(VwComponentParameter _componentParameter)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");
//            }

//            int id = Convert.ToInt32(Request.Form["ParamId"]);
//            var bitIsActive = Request.Form["mvalue"];
//            var brokerSiteName = Request.Form["BrokerSiteName"];
//            var nvcComponentName = Request.Form["NvccomponentName"];
//            var nvcInstanceName = Request.Form["NvcInstanceName"];
//            var intComponentId = Request.Form["Intcomponentid"];
//            var intinstanceid = Request.Form["Intinstanceid"];
//            var brokerSiteId = Request.Form["BrokerSiteId"];
//            ViewBag.sitename = brokerSiteName;
//            ViewBag.ComponentName = nvcComponentName;
//            ViewBag.InstanceName = nvcInstanceName;
//            ViewBag.mvalue = bitIsActive;
//            ViewBag.Intcomponentid = intComponentId;
//            ViewBag.IntInstanceId = intinstanceid;
//            ViewBag.BrokerSiteId = brokerSiteId;

//            globals.Broker_Site = brokerSiteId;
//            globals.BrokerId_update = Convert.ToString(brokerSiteId);
//            globals.Component_ID = Convert.ToInt32(intComponentId);
//            globals.Instance_id = Request.Form["Intinstanceid"];

//            GetDropdownList();
//            GetDropdownComponentList();
//            GetDropdownInstanceList();
//            return View(_componentParameter);
//        }



//    }
//}
