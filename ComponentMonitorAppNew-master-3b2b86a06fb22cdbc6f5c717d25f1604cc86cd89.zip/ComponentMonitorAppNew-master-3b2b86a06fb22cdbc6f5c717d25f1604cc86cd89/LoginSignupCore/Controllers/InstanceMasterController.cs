﻿//using LoginSignupCore.Data;
//using LoginSignupCore.Models;
//using Microsoft.AspNetCore.Authentication.Cookies;
//using Microsoft.AspNetCore.Authentication;
//using Microsoft.AspNetCore.Mvc;
//using System.Security.Claims;
//using Microsoft.EntityFrameworkCore;
//using System.Data;
//using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.Data.SqlClient;

//namespace LoginSignupCore.Controllers
//{
//    public class InstanceMasterController : Controller
//    {        

//        private readonly ApplicatonDBContext _dbcontext;

//        public InstanceMasterController(ApplicatonDBContext context)
//        {
//            _dbcontext = context;
//        }
//        public IActionResult Instances()
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!(claimUser.Identity.IsAuthenticated))
//            {
//                globals.User_ID = 0;
//                return RedirectToAction("Login", "Account");
//            }
//            globals.Component_Name = "Please Select";
//            globals.Broker_Site = "Please Select";
//            GetDropdownList();
//            GetDropdownComponentList();
//            return View();
//        }

//        [HttpPost]
//        public IActionResult Clear(InstanceMaster instanceMaster)
//        {
//            ViewBag.successStatus = null;
//            globals.Component_Name = "Please Select";
//            return RedirectToAction("Instances", "InstanceMaster");
//        }

//        public async Task<IActionResult> Logout()
//        {
//            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//            globals.User_ID = 0;
//            return RedirectToAction("Login", "Account");
//        }

//        [HttpPost]
//        public IActionResult Instances(InstanceMaster instanceMaster)
//         {
//            ViewBag.successStatus = 0;
//            try
//            {
//                var pCompId = Request.Form["IntComponentId"];
//                string pId = Request.Form["NvcBrokerSiteId"];
//                instanceMaster.NvcBrokerSiteId = pId;
//                instanceMaster.IntCreatedBy = globals.User_ID;
//                instanceMaster.BitIsDelete = 0;
//                instanceMaster.BitIsActive = 1;
//                instanceMaster.DtmCreatedOn = DateTime.Now.Date;
//                _dbcontext.InstanceMasters.Add(instanceMaster);
//                _dbcontext.SaveChanges();
//                ViewBag.successStatus = 1;
//                GetDropdownList();
//                GetDropdownListReload(pId);
//                GetDropdownComponentList();
//                GetDropdownComponentListReload(pCompId);
//                //instanceMaster = null;
//                return View();
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//            }
//            return View();
//        }

//        public void GetDropdownListReload(string brokerSiteId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 and cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) = '" + brokerSiteId + "' order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Broker_Site = dataread.GetString(0);
//                }
//            }
//        }

//        public void GetDropdownList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcBrokerName+' - '+nvcSiteName BrokerNameList,cast(s.intBrokerId as varchar)+'-'+cast(s.id as varchar) BrokerSiteId from BrokerSites s Inner Join BrokerMaster m on s.intBrokerId = m.id where s.IsActive = 1 and m.IsActive = 1 and s.IsDeleted = 0 and m.IsDeleted = 0 order by s.intBrokerId , s.id";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentsid = new SelectList(Lista, "Text", "Value");
//            }
//        }


//        public void GetDropdownComponentList()
//        {
//            List<SelectListItem> Lista = new List<SelectListItem>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    Lista.Add(new SelectListItem
//                    {
//                        Text = dataread.GetString(1),
//                        Value = dataread.GetString(0)
//                    }); ; ;
//                }
//                ViewBag.modelComponentName = new SelectList(Lista, "Text", "Value");
//            }
//        }

//        public IActionResult DisplayData()
//        {

//            List<VwInstanceMaster> instanceMasters = new List<VwInstanceMaster>();
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "Select isnull(IntInstanceId,0) IntInstanceId, isnull(IntComponentId,0) IntComponentId,isnull(nvcInstanceName,'') nvcInstanceName, isnull(nvcInstanceIP,'') nvcInstanceIP,isnull(IntPort,'') IntPort,isnull(VersionNo,0) VersionNo,isnull(CapacityWeightage,0) CapacityWeightage,Cast(bitIsActive as Integer) bitIsActive, isnull(NvcComponentName,'')NvcComponentName , isnull(NvcBrokerSiteName,'-') NvcBrokerSiteName, isnull(NvcBrokerSiteId,'-') NvcBrokerSiteId from vwInstanceMaster where bitIsDelete = 0";

//            Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {

//                    instanceMasters.Add(new VwInstanceMaster
//                    {
//                        IntInstanceId = dataread.GetInt32(0),                        
//                        IntComponentId = dataread.GetInt32(1),
//                        NvcInstanceName = dataread.GetString(2),
//                        NvcInstanceIp = dataread.GetString(3),
//                        IntPort = dataread.GetString(4),
//                        VersionNo = dataread.GetInt32(5),
//                        CapacityWeightage = dataread.GetInt32(6),
//                        BitIsActive = dataread.GetInt32(7),
//                        NvcComponentName = dataread.GetString(8),
//                        NvcBrokerSiteName= dataread.GetString(9),
//                        NvcBrokerSiteId= dataread.GetString(10)
//                    }); ; ; ;

//                }
//                cmd.Connection.Close();

//                ViewBag.model = instanceMasters;
//                return View();
//            }
//            return View();
//        }

//        [HttpPost]
//        public IActionResult InstanceMasterUpdate(InstanceMaster instanceMaster)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");

//            }
//            ViewBag.successStatus = 0;
//            try
//            {
//                var id = Convert.ToInt32(Request.Form["IntInstanceId"]);
//                var instanceName = Request.Form["NvcInstanceName"];
//                var componentId = Request.Form["IntComponentId"];
//                var instanceIp = Request.Form["NvcInstanceIp"];
//                var intport = Request.Form["IntPort"];
//                var version = Request.Form["VersionNo"];
//                var capacityWeightage = Request.Form["CapacityWeightage"];
//                var dtmupdateon = DateTime.Now;
//                var intUpdatedBy = globals.User_ID;
//                var isActive = 0;
//                string mvalue = Request.Form["BitIsActive"];

//                if (mvalue == "1"|| mvalue == "on" || mvalue == "1,on" || mvalue == "0,on")
//                {
//                    isActive = 1;
//                }
//                //else if (mvalue == "on")
//                //{
//                //    isActive = 1;
//                //}
//                //else if (mvalue == "1,on")
//                //{
//                //    isActive = 1;
//                //}
//                //else if (mvalue == "0,on")
//                //{
//                //    isActive = 1;
//                //}
//                else
//                {
//                    isActive = 0;
//                }

//                try
//                {
//                    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//                    {
//                        if (cmd.Connection.State != ConnectionState.Open)
//                        {
//                            cmd.Connection.Open();
//                        }
//                        cmd.CommandText = "update InstanceMaster set CapacityWeightage='" + capacityWeightage + "', VersionNo='" + version + "', IntPort='" + intport + "', NvcInstanceIp='" + instanceIp + "',IntComponentId='" + componentId + "', NvcInstanceName='" + instanceName + "',intUpdatedBy = '" + intUpdatedBy + "', dtmUpdatedOn = '" + dtmupdateon + "', BitIsActive = '" + isActive + "'  where intInstanceId = '" + id + "'";
//                        cmd.ExecuteNonQuery();
//                        cmd.Connection.Close();

//                        ViewBag.Status = 1;
//                        ViewBag.successStatus = 1;

//                        ViewBag.model = instanceMaster;
//                        return RedirectToAction("DisplayData", "InstanceMaster");
//                    }

//                }
//                catch (Exception ee)
//                {
//                    ViewBag.Status = 0;
//                    ViewBag.successStatus = 0;
//                    return RedirectToAction("Instances", "InstanceMaster");

//                }
//            }
//            catch (Exception ex)
//            {
//                ViewBag.successStatus = 0;
//            }
//            return RedirectToAction("Instances", "InstanceMaster");
//        }

//        [HttpPost]
//        public IActionResult Edit(VwInstanceMaster _instanceMaster)
//        {
//            ClaimsPrincipal claimUser = HttpContext.User;
//            if (!claimUser.Identity.IsAuthenticated)
//            {
//                return RedirectToAction("Login", "Account");
//            }

//           int id = Convert.ToInt32(Request.Form["IntInstanceId"]);
//            var IsActive = Request.Form["mvalue"];
//            ViewBag.mvalue = IsActive;
//            GetDropdownList();
//            GetDropdownComponentList();

//            return View(_instanceMaster);
//        }

//        public void GetDropdownComponentListReload(string intComponentId)
//        {
//            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
//            if (cmd.Connection.State != ConnectionState.Open)
//            {
//                cmd.Connection.Open();
//            }
//            cmd.CommandText = "select nvcComponentName ,cast(c.intComponentId as varchar) IntComponentId from ComponentMaster c where c.intComponentId = '" + intComponentId + "' and  c.bitIsActive = 1 and c.bitIsDelete = 0 order by nvcComponentName";
//            SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();
//            if (dataread.HasRows)
//            {
//                while (dataread.Read())
//                {
//                    globals.Component_Name = dataread.GetString(0);
//                }
//            }
//        }




//    }
//}
