﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class BrokerSiteController : Controller
    {
        private readonly ApplicatonDBContext _dbcontext;
        private readonly BrokerSiteRepository _brokerSiteRepository;
        public BrokerSiteController(ApplicatonDBContext context)
        {
            _dbcontext = context;
            _brokerSiteRepository = new();
        }

        [HttpGet]
        public IActionResult BrokerSites(int brokerid,string brokerName,int id=0)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }

            //globals.BrokerIdList = "Please Select";
            GetDropdownList();
            DisplayData();
            BrokerSites sites = new BrokerSites()
            {
                IntBrokerId = brokerid
            };
            if(id!=0)
            {
                sites = _brokerSiteRepository.GetBrokerSitesById(id);
            }
            return View(sites);
        }
        [HttpGet]
         public IActionResult cancel(int brokerid , string brokername)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            return RedirectToAction("BrokerSites", new { brokerid = brokerid, brokerName = brokername});
        }

        [HttpPost]
        public IActionResult GetBrokerSites(BrokerMaster brokerMaster)
        {
            
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            

            globals.BrokerId = brokerMaster.Id;
            globals.BrokerName = brokerMaster.NvcBrokerName;
            //globals.BrokerIdList = "Please Select";
            // GetDropdownList();
            DisplayData();
            return RedirectToAction("BrokerSites", new {  brokerid = brokerMaster.Id, brokerName=brokerMaster.NvcBrokerName });
        }
        

        public void GetDropdownList()
        {
            List<string>[] Lista = new List<string>[2];
            Lista[0] = new List<string>();
            Lista[1] = new List<string>();     

            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            {
                if (cmd.Connection.State != ConnectionState.Open)
                {
                    cmd.Connection.Open();
                }
                cmd.CommandText = "Select nvcBrokerName Text,cast(id as varchar) Value from BrokerMaster order by nvcBrokerName";
                using SqlDataReader dataread = (SqlDataReader)cmd.ExecuteReader();

                if (dataread.HasRows)
                {
                    while (dataread.Read())
                    {
                        Lista[0].Add(dataread.IsDBNull(0) ? "": dataread.GetString(0));
                        Lista[1].Add(dataread.IsDBNull(1) ? "" : dataread.GetString(1));
                    }
                }                
            } 
            ViewData["BrokerNameList"] = Lista;
        }


        [HttpPost]
        public IActionResult BrokerSites(BrokerSites _brokerSites)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            string name = Request.Form["Para"];

            globals.BrokerIdList = name;
            ViewBag.successStatus = 0;
            try
            {
                if (ModelState.IsValid)
                {
                    (bool, string) result;
                    if (_brokerSites.Id != 0)
                    {
                        //update
                        result = _brokerSiteRepository.UpdateBrokerSiteData(_brokerSites); 
                    }
                    else
                    {
                        result = _brokerSiteRepository.InsertBrokerSiteData(_brokerSites);
                    }
                    ViewBag.successStatus = result.Item1 == true ? 1 : 0;

                    return RedirectToAction("BrokerSites", new { brokerid = _brokerSites.IntBrokerId,id=0 });
                }
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("BrokerSites", new { brokerid = _brokerSites.IntBrokerId });
           // return View(_brokerSites);
        }

        [HttpPost]
        public IActionResult Edit(BrokerSites brokerSites)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;
            try
            {
                var id = Convert.ToInt32(Request.Form["Id"]);
                var brokerName = Request.Form["NvcBrokerName"];
                var dtmupdateon = DateTime.Now;
                var intUpdatedBy = globals.User_ID;
                var isActive = 0;
                string mvalue =Convert.ToString( Request.Form["IsActive"]);

                if (mvalue == "1")
                {
                    isActive = 1;
                }
                else if (mvalue == "on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else
                {
                    isActive = 0;
                }

                try
                {
                    var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                    {
                        if (cmd.Connection.State != ConnectionState.Open)
                        {
                            cmd.Connection.Open();
                        }
                        cmd.CommandText = "update brokerSites set intUpdatedBy = '" + intUpdatedBy + "', dtmUpdationDate = '" + dtmupdateon + "', IsActive = '" + isActive + "'  where Id = '" + id + "'";
                        cmd.ExecuteNonQuery();
                        cmd.Connection.Close();

                        ViewBag.Status = 1;
                        ViewBag.successStatus = 1;
                        ViewBag.model = brokerSites;
                        return RedirectToAction("BrokerSites", "BrokerSite");
                    }

                }
                catch (Exception ee)
                {     
                    ViewBag.Status = 0;
                    ViewBag.successStatus = 0;
                    return RedirectToAction("BrokerSite", "BrokerSite");

                }
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("BrokerMaster", "BrokerMaster");
        }

        //public void GetDropdownList()
        //{
        //    List<SelectListItem> Lista = new List<SelectListItem>();
        //    Lista.Add(new SelectListItem { Text = "", Value = "", Selected = true });
        //    var componentData = GetBrokerList();

        //    foreach (var brokerlist in componentData)
        //    {
        //        Lista.Add(item: new SelectListItem { Text = brokerlist.NvcBrokerName, Value = brokerlist.NvcBrokerName });
        //    }
        //    ViewData["YourListofclassnames"] = Lista;
        //}

        public List<BrokerMaster> GetBrokerList()
        {
            string jointvalue = "";
            List<BrokerMaster> brokerMasters = new List<BrokerMaster>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            {
                if (cmd.Connection.State != ConnectionState.Open)
                {
                    cmd.Connection.Open();
                }
                cmd.CommandText = "Select Cast(Id as varchar) +' - '+ NvcBrokerName  jointval from BrokerMaster order by NvcBrokerName";
                using SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();

                if (dataread.HasRows)
                {
                    while (dataread.Read())
                    {
                        jointvalue = dataread.GetString(0);

                        brokerMasters.Add(new BrokerMaster
                        {
                            NvcBrokerName = dataread.GetString(0)
                        }); ; ;
                    }
                    ViewBag.modelComponentsid = new SelectList(brokerMasters, "NvcBrokerName", "NvcBrokerName");
                }
                return brokerMasters;
            }
        }

        [HttpPost]
        public IActionResult Clear(BrokerMaster brokerMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;
            globals.BrokerId = 0;
            globals.BrokerName = null;
            globals.BrokerIdList = null;
            DisplayData();
            return RedirectToAction("BrokerSites", "BrokerSite");

        }

        public IActionResult DisplayData()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            List<BrokerSites> brokerSites = new List<BrokerSites>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }
            cmd.CommandText = "Select id, intBrokerId,isnull(NvcSiteName,'') NvcSiteName, IsActive  from BrokerSites where intbrokerid = '" + globals.BrokerId + "' and IsDeleted = 0";

            using Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
            if (dataread.HasRows)
            {
                while (dataread.Read())
                {

                    brokerSites.Add(new BrokerSites
                    {
                        Id = dataread.GetInt32(0),
                        IntBrokerId=dataread.GetInt32(1),
                        NvcSiteName = dataread.GetString(2),
                        IsActive = dataread.GetInt32(3)
                    });

                }
                cmd.Connection.Close();

                ViewBag.model = brokerSites;
                return View();
            }
            return View();
        }

        [HttpGet]
        public IActionResult Sites(int key, string name)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }

            var list = _dbcontext.BrokerSites.Where(x => x.IntBrokerId == key).ToList();
            var sites = new SiteViewModel()
            {
                brokerName = name,
                sites = list
            };
            return View(sites);
        }

        [HttpGet]
        public IActionResult Site(int brokerid, int siteid)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }

            BrokerSites site = _dbcontext.BrokerSites.Where(x => x.IntBrokerId == brokerid && x.Id == siteid).First();
           
            return View(site);
        }
        [HttpGet]
        public IActionResult SiteFile(int id)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var brokersite = _brokerSiteRepository.GetBrokerSitesById(id);
            return PartialView("site", brokersite);
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
