﻿using LoginSignupCore.Core;
using Component = LoginSignupCore.MasterCache.Component;
using Microsoft.AspNetCore.Mvc;
using System.Security.Policy;
using LoginSignupCore.Models;
using LoginSignupCore.MasterCache;
using Microsoft.Extensions.Logging;
using CTCL.BinaryProtocol.Common.CMA.Enum;
using Newtonsoft.Json;
using LoginSignupCore.Data;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class BODProcessController : Controller
    {
        private readonly BrokerRepository brokerRepository;
        private readonly BrokerSiteRepository brokerSiteRepository;
        public BODProcessController()
        {
            brokerRepository = new();
            brokerSiteRepository = new();
        }
        public IActionResult Index(int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            AgentMaster agent = new AgentMaster()
            {
                BrokerSiteId = siteid,
                BrokerId = brokerid,
                AgentName =  brokerRepository.GetBrokerById(brokerid).NvcBrokerName,
                SiteName = brokerSiteRepository.GetBrokerSitesById(siteid).NvcSiteName,
            };
            return View(agent);
        }
        public IActionResult StartComponent(int brokerid, int siteid, int isAjax= 0)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            List<Component> componentMasters = new List<Component>();
            var componentMaster = CoreProcess.agentSessionCache.GetComponentMaster(brokerid, siteid);
            if (componentMaster.Item1 == true && componentMaster.Item2 != null && componentMaster.Item2.Count > 0)
            {
                componentMasters = componentMaster.Item2.Where(x => x.componentMaster.IsActive == true && x.componentMaster.IsDelete == false).OrderBy(p => p.componentMaster.Priority).ToList();

                if (componentMasters.Any())
                {
                    componentMasters[0].isenabled = true;
                    for (int i = 1; i < componentMasters.Count; i++)
                    {

                        if (componentMasters[i - 1].isRequestSend == true && componentMasters[i - 1].status == (int)CMA_StatusCode.Completed)
                        {
                            componentMasters[i].isenabled = true;
                        }
                        else
                        {
                            componentMasters[i].isenabled = true;
                        }
                    }
                }

            }
            BODUploadComponent comp = new BODUploadComponent();
            comp.component.componentMaster = new();
            comp.component.componentMaster.BrokerId = brokerid;
            comp.component.componentMaster.SiteId = siteid;
            comp.Components = componentMasters;



            if (isAjax == 1)
            {
                var json = JsonConvert.SerializeObject(componentMasters);
                return Json(json);
            }
            return View(comp);
        }
        public IActionResult UploadFile(int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            List<FileMasterInfo> fileMasters = new List<FileMasterInfo>();
            var fileMaster = CoreProcess.agentSessionCache.GetFileMasterInfo(brokerid, siteid);
            if (fileMaster.Item1 == true && fileMaster.Item2.Count > 0)
            {
                fileMasters = fileMaster.Item2.Where(x => x.IsUploadBeforeBOD == true).ToList();
            }
            BODUploadFileView file = new BODUploadFileView();
            file.fileMasterInfo.BrokerId = brokerid;
            file.fileMasterInfo.SiteId = siteid;
            //file.fileMasterInfo.SiteId = fileMasters.FirstOrDefault().SiteId;
            file.fileMastersInfo = fileMasters;

            return View(file);
        }
        public IActionResult UploadFileAfterBOD(int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            List<FileMasterInfo> fileMasters = new List<FileMasterInfo>();
            var fileMaster = CoreProcess.agentSessionCache.GetFileMasterInfo(brokerid, siteid);
            if (fileMaster.Item1 == true && fileMaster.Item2.Count > 0)
            {
                fileMasters = fileMaster.Item2.Where(x => x.IsUploadBeforeBOD == false).ToList();
            }
            BODUploadFileView file = new BODUploadFileView();
            file.fileMasterInfo.BrokerId = brokerid;
            file.fileMasterInfo.SiteId = siteid;
            file.fileMastersInfo = fileMasters;

            return View(file);
        }
        public IActionResult TechnicalInfo(int brokerid, int siteid ,int isAjax = 0)
        {
            if(!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            List<ComponentsTechnicalInfo> infos = new();
            var info = CoreProcess.agentSessionCache.GetTechnicalInfo(brokerid, siteid);
            if (info != null)
            {
                infos = info;
            }
            TechnicalInfoViewModel tecinfo = new TechnicalInfoViewModel();
            tecinfo.BrokerId = brokerid;
            tecinfo.SiteId = siteid;
            tecinfo.TechnicalInfos = infos;

            if (isAjax == 1)
            {
                var json = JsonConvert.SerializeObject(infos);
                return Json(json);
            }
            return View(tecinfo);
        }

        [HttpGet]
        public IActionResult Cancel(int brokerId, int siteId)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return RedirectToAction("Index", new {brokerId=brokerId, siteId = siteId});
        }

        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
