﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Security.Claims;

namespace LoginSignupCore.Controllers
{
    public class AgentMasterController : Controller
    {

        private readonly AgentRepository _agentRepository;
        public AgentMasterController()
        {
            _agentRepository = new();
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult AgentMaster()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            return RedirectToAction("AgentMasters");

        }
        [HttpPost]
        public IActionResult Agent(AgentMaster agentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var agent = new AgentMaster()
            {
                AgentId = 0,
                AgentName = agentMaster.AgentName,
                BrokerId = agentMaster.BrokerId,
                SiteName = agentMaster.SiteName,
                BrokerSiteId = agentMaster.BrokerSiteId,
                nvcInstanceIP = agentMaster.nvcInstanceIP,
                DtmCreationDate = DateTime.Now,
                IntCreatedBy = globals.User_ID,
                Remarks = agentMaster.Remarks
            };

            //remove validation for other fields
            //var requiredfields = typeof(AgentMaster).GetProperties().Where(p => Attribute.IsDefined(p, typeof(RequiredAttribute))).Select(p=>p.Name);
            //foreach (var key in ModelState.Keys)
            //{
            //    if (!requiredfields.Contains(key) && ModelState[key].Errors.Count > 0)
            //        ModelState[key].Errors.Clear();
            //}

            if (ModelState.IsValid)
            {
                try
                {
                    _agentRepository.InsertUpdateData(agent);
                }
                catch (Exception ex)
                {
                    throw;
                }
                BrokerSites sites = new BrokerSites()
                {
                    IntBrokerId = agentMaster.BrokerSiteId,
                    Id = agentMaster.BrokerSiteId,
                    NvcSiteName = agentMaster.SiteName
                };
                return RedirectToAction("AgentMasters", agentMaster);
            }
            else
            {
                foreach (var item in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(item.ErrorMessage);
                }
                return RedirectToAction("AgentMasters", agentMaster);
            }
           
            
        }
       
        public IActionResult AgentMasters(AgentMaster master)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            AgentMastersViewModel AgentsView = new();
            try
            {
                AgentsView.Agents = _agentRepository.GetAllAgents(master.BrokerId, master.BrokerSiteId);
                AgentsView.Agent = new();
                AgentsView.Agent.BrokerSiteId = master.BrokerSiteId;
                AgentsView.Agent.BrokerId = master.BrokerId;
                AgentsView.Agent.SiteName = master.SiteName;
                AgentsView.Agent.AgentId = master.AgentId;
            }
            catch (Exception ex)
            {
                throw;
            }
            return View(AgentsView);
        }
        //[HttpGet]
        //public IActionResult AgentMasters(int siteid, int brokerid,string sitename)
        //{
        //    ClaimsPrincipal claimUser = HttpContext.User;
        //    if (!claimUser.Identity.IsAuthenticated)
        //    {
        //        return RedirectToAction("Login", "Account");

        //    }
        //    AgentMastersViewModel AgentsView = new();
        //    try
        //    {
        //        AgentsView.Agents = _agentRepository.GetAllAgents(brokerid, siteid);
        //        AgentsView.Agent = new();
        //        AgentsView.Agent.BrokerSiteId = siteid;
        //        AgentsView.Agent.BrokerId = brokerid;
        //        AgentsView.Agent.SiteName = sitename;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //    return View(AgentsView);
        //}

        [HttpGet("Agent/{id}/{sitename}")]
        public IActionResult Agent(int id, string sitename)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            AgentMaster agentMaster = _agentRepository.GetAgentById(id);
            return RedirectToAction("AgentMasters",agentMaster);
        }
        [HttpPost]
        public IActionResult Edit(AgentMaster agentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }

            int id = Convert.ToInt32(Request.Form["Id"]);
            var IsActive = Request.Form["mvalue"];
            ViewBag.mvalue = IsActive;
            var agent = new AgentMaster()
            {
                AgentId = agentMaster.AgentId,
                IsActive = agentMaster.IsActive,
                DtmUpdationDate = DateTime.Now,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Agent updated."
            };
            try
            {
                int rows = _agentRepository.UpdateIsActiveData(agent);
                agentMaster.AgentId = 0;
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentMasters", agentMaster);
        }
        [HttpPost]
        public IActionResult Update(AgentMaster agentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var agent = new AgentMaster()
            {
                AgentId = agentMaster.AgentId,
                AgentName = agentMaster.AgentName,
                nvcInstanceIP = agentMaster.nvcInstanceIP,
                DtmUpdationDate = DateTime.Now,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Agent Updated."
            };
            try
            {
                int rows = _agentRepository.UpdateData(agent);
                agentMaster.AgentId = 0;
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentMasters", agentMaster);

        }
        [HttpGet("AgentMaster/Delete/{id}/{bid}/{sid}/{sitename}")]
        public IActionResult Delete(int id, int bid, int sid,string sitename)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var agent = new AgentMaster()
            {
                AgentId = id,
                BrokerId= bid,
                BrokerSiteId=sid,
                SiteName = sitename,
                IsDeleted = 1,
                DtmUpdationDate = DateTime.Now,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Agent Deleted."
            };
            try
            {
                int rows = _agentRepository.DeleteData(agent);
                agent.AgentId = 0;
            }
            catch (Exception ex)
            {
                throw;
            }

            return RedirectToAction("AgentMasters", agent);

        }
        [HttpGet("AgentMaster/UpdateIsActive/{id}/{bid}/{sid}")]
        public IActionResult UpdateIsActive(int isActive, int bid, int sid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var agent = new AgentMaster()
            {
                AgentId = isActive,
                IsDeleted = 1,
                DtmUpdationDate = DateTime.Now,
                IntUpdatedBy = globals.User_ID,
                Remarks = "Agent updated."
            };
            try
            {
                int rows = _agentRepository.UpdateIsActiveData(agent);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("AgentMasters", new { siteid = sid, brokerid = bid });

        }
        [HttpGet]
        public IActionResult AgentsStatus(int brokerid, int siteid)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            List<AgentMaster> AgentsView = new();
            try
            {
                AgentsView = _agentRepository.GetAllAgents(brokerid,siteid );
            }
            catch (Exception ex)
            {
                throw;
            }
            return View(AgentsView);
        }
        [HttpGet("AgentMaster/AgentFile/{id}/{brid}/{sid}/{sitename}")]
        public IActionResult AgentFile(int id,int brid,int sid, string sitename)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            AgentMaster agentMaster = _agentRepository.GetAgentById(id);
            agentMaster.SiteName = sitename;
            agentMaster.BrokerId = brid;
            agentMaster.BrokerSiteId= sid;
           
            return PartialView("Agent", agentMaster);
        }
        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }
    }
}
