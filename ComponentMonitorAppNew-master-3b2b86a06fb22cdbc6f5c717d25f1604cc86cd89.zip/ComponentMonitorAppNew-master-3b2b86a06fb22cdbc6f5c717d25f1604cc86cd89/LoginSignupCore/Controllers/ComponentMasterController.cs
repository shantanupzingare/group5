﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using System.Data;
using CTCL.BinaryProtocol.Common.CTCL.Enum;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;

namespace LoginSignupCore.Controllers
{
    public class ComponentMasterController : Controller
    {
        private readonly ComponentMasterRepository componentMasterRepository;
        private readonly ApplicatonDBContext _dbcontext;

        public ComponentMasterController(ApplicatonDBContext context)
        {
            componentMasterRepository = new();
            _dbcontext = context;
        }
        public IActionResult Components()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!(claimUser.Identity.IsAuthenticated))
            {
                globals.User_ID = 0;
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpGet]
        public IActionResult ComponentFile(int id)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var component = componentMasterRepository.GetcompById(id);
            return PartialView("Components", component);
        }



        public IActionResult Clear()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = null;
            return RedirectToAction("DisplayData", "ComponentMaster");
        }

        public async Task<IActionResult> Logout()
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            globals.User_ID = 0;
            return RedirectToAction("Login", "Account");
        }

        [HttpPost]
        public IActionResult Components(ComponentMaster componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;

            try
            {
                if (ModelState.IsValid)
                {
                    componentMasterRepository.InsertComponentMasterData(componentMaster);
                    ViewBag.successStatus = 1;
                    return RedirectToAction("DisplayData");
                }
            }
            catch (Exception ex)
            {
                // ViewBag.successStatus = 0;
                string msg = string.Empty;
                if (!string.IsNullOrEmpty(ex.Message))
                {
                    var arr = ex.Message.Split(".");
                    msg = arr[1]+":"+arr[3];
                    //ViewBag.message = msg;
                }
                if (ex.Message.Contains("unique_priority"))
                {
                    TempData["ErrorMessage"] = "Priority already exists, Kindly modify the priority and retry! ";
                }
                else if (ex.Message.Contains("PK__Componen__238B7F484AB5AB5F"))
                {
                    TempData["ErrorMessage"] = "CompomnentId already exists, Kindly modify the componentid and retry!";
                }
                return RedirectToAction("DisplayData", componentMaster);
            }
            return RedirectToAction("DisplayData", componentMaster);
        }

        public IActionResult DisplayData(ComponentMaster componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var componentMasters = componentMasterRepository.Get();
            componentMaster.Components = componentMasters;
            //ViewBag.model = componentMasters;
            return View(componentMaster);
        }

        [HttpPost]
        public IActionResult ComponentMasterUpdate(ComponentMaster componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.successStatus = 0;
            try
            {
                var id = componentMaster.Id;
                var componentName = componentMaster.NvcComponentName;
                var dtmupdateon = DateTime.Now;
                var intUpdatedBy = globals.User_ID;
                var isActive = 1;
                string mvalue = Request.Form["BitIsActive"];

                if (mvalue == "1")
                {
                    isActive = 1;
                }
                else if (mvalue == "on")
                {
                    isActive = 1;
                }
                else if (mvalue == "1,on")
                {
                    isActive = 1;
                }
                else if (mvalue == "0,on")
                {
                    isActive = 1;
                }
                else
                {
                    isActive = 0;
                }

                try
                {
                    if (ModelState.IsValid)
                    {
                        var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                        {
                            if (cmd.Connection.State != ConnectionState.Open)
                            {
                                cmd.Connection.Open();
                            }
                            cmd.CommandText = "update ComponentMaster set intComponentId='" + componentMaster.IntComponentId + "',NvcComponentName='" + componentName + "',numCpuThreshold ='" + componentMaster.CpuThreshold + "',numRamThreshold = '" + componentMaster.RamThreshold + "',intPriority = '" + componentMaster.IntPriority+ "',intUpdatedBy ='" + intUpdatedBy + "',dtmUpdatedOn='" + dtmupdateon + "',BitIsActive='" + 1 + "' where intId='" + componentMaster.Id + "'";
                            cmd.ExecuteNonQuery();
                            cmd.Connection.Close();

                            ViewBag.Status = 1;
                            ViewBag.successStatus = 1;

                            ViewBag.model = componentMaster;
                            return RedirectToAction("DisplayData", "ComponentMaster");
                        }
                    }

                }
                catch (Exception ee)
                {
                    ViewBag.Status = 0;
                    ViewBag.successStatus = 0;
                    return RedirectToAction("Edit", "ComponentMaster");

                }
            }
            catch (Exception ex)
            {
                ViewBag.Status = 0;
                ViewBag.successStatus = 0;
                return RedirectToAction("Edit", "ComponentMaster");
            }
            ViewBag.Status = 0;
            ViewBag.successStatus = 0;
            TempData["componentmaster"] = componentMaster;
            return RedirectToAction("DisplayData", "ComponentMaster");
        }


        public IActionResult Edit(ComponentMaster _componentMaster)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var data = new ComponentMaster()
            {
                Id = _componentMaster.Id,
                //BitIsActive = Convert.ToInt32(Request.Form["mvalue"]),
                BitIsActive = _componentMaster.BitIsActive,
                NvcComponentName = _componentMaster.NvcComponentName,
                CpuThreshold = _componentMaster.CpuThreshold,
                IntPriority = _componentMaster.IntPriority


            };
            //int id = Convert.ToInt32(Request.Form["IntComponentId"]);
            //var IsActive = Request.Form["mvalue"];
            //ViewBag.mvalue = IsActive;

            return RedirectToAction("DisplayData", data);
        }


        public IActionResult UpdateIsActive(int id, int isActive)
        {
            if (!CheckAuth())
            {
                return RedirectToAction("Login", "Account");
            }
            var comp = new ComponentMaster()
            {
                Id = id,
                BitIsActive = isActive,
                DtmUpdatedOn = DateTime.Now,
                IntUpdatedBy = globals.User_ID
            };
            try
            {
                int rows = componentMasterRepository.UpdateIsActiveData(comp);
            }
            catch (Exception ex)
            {
                throw;
            }
            return RedirectToAction("DisplayData");

        }



        public bool CheckAuth()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return false;
            }
            return true;
        }

    }
}
