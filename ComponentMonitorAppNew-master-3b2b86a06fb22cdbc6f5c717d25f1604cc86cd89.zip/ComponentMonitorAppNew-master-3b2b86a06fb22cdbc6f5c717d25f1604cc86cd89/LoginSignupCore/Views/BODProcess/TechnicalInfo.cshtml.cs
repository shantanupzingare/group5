using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginSignupCore.Views.BODProcess
{
    public class TechnicalInfoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
