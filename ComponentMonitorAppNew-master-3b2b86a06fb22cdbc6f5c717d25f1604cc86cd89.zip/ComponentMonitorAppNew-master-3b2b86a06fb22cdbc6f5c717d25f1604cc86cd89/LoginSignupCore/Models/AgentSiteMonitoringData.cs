﻿using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;

public partial class AgentSiteMonitoringData
{
    public int Id { get; set; }

    public int IntBrokerId { get; set; }

    public int IntSiteId { get; set; }

    public int IntAttributeType { get; set; }

    public int? IntComponentId { get; set; }

    public int? IntInstanceId { get; set; }

    public int? IntParameterId { get; set; }

    public string? NvcComponentName { get; set; }

    public string NvcValue { get; set; } = null!;

    public DateTime DtmTimestamp { get; set; }

    public bool BitIsActive { get; set; }

    public bool BitIsDelete { get; set; }
}
