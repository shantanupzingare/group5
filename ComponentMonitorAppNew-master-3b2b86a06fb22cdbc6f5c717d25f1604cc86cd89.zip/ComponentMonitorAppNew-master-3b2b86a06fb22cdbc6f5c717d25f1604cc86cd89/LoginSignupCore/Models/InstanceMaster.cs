﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models;


[Table("InstanceMaster")]
public partial class InstanceMaster
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("intInstanceId")]
    public int IntInstanceId { get; set; }

    [Column("intComponentId")]
    public int IntComponentId { get; set; }

    [Column("nvcInstanceName")]
    [StringLength(64)]
    public string? NvcInstanceName { get; set; }

    [Column("nvcInstanceIP")]
    [StringLength(64)]
    public string? NvcInstanceIp { get; set; }

    [Column("intPort")]
    [StringLength(15)]
    public string? IntPort { get; set; }

    [Column("dtmCreatedOn")]
    public DateTime DtmCreatedOn { get; set; }

    [Column("intCreatedBy")]
    public int? IntCreatedBy { get; set; }

    [Column("dtmUpdatedOn")]
    public DateTime? DtmUpdatedOn { get; set; }

    [Column("intUpdatedBy")]
    public int? IntUpdatedBy { get; set; }

    [Column("bitIsActive")]
    public int BitIsActive { get; set; }

    [Column("bitIsDelete")]
    public int BitIsDelete { get; set; }

    [Column("dtmStartDate")]
    public DateTime DtmStartDate { get; set; }

    [Column("dtmEndDate")]
    public DateTime? DtmEndDate { get; set; }

    public int? VersionNo { get; set; }

    public int? CapacityWeightage { get; set; }

    [Column("nvcBrokerSiteId")]
    public string NvcBrokerSiteId { get; set; }
}
