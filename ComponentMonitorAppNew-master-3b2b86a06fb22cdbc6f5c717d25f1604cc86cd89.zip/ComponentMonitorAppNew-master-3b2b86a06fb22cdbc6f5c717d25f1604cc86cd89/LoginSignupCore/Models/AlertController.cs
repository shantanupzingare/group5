﻿using LoginSignupCore.Data;
using LoginSignupCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Text;
using LoginSignupCore.Migrations;
using System.Data;
using Microsoft.AspNetCore.Components;
using System.Text.RegularExpressions;

namespace LoginSignupCore.Controllers
{
    public class AlertController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;
       
        public IActionResult Alert()
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");

            }
            return View(new AlertThreshold());
        }

        public AlertController(ApplicationDbContext context)
        {
            _dbcontext = context;
        }

        [HttpPost]
        public IActionResult Alert(AlertThreshold alertThreshold)
        {
            ViewBag.successStatus = 0;
            try
            {
                alertThreshold.IntCreatedBy = globals.User_ID;
                alertThreshold.BitIsDelete = 0;
                alertThreshold.BitIsActive = 1;
                alertThreshold.DtmCreatedOn = DateTime.Now.Date;
                _dbcontext.AlertThresholds.Add(alertThreshold);
                _dbcontext.SaveChanges();
                ViewBag.successStatus = 1;
                alertThreshold = null;
                return View(alertThreshold);
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return View(alertThreshold);
        }

        [HttpPost]
        public IActionResult AlertUpdate(AlertThreshold alertThreshold)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.successStatus = 0;
            try
            {
                        int id = Convert.ToInt32(Request.Form["Id"]);
                        int intParamId = Convert.ToInt32(Request.Form["IntParamId"]);
                        int intComponentId = Convert.ToInt32(Request.Form["IntComponentId"]);
                        string componentName = Request.Form["ComponentName"];
                        string brokerSiteId = Request.Form["BrokerSiteId"];                        

                        int intThresholdValue = Convert.ToInt32(Request.Form["IntThresholdValue"]);
                        DateTime dtmupdateon = DateTime.Now;
                        int intUpdatedBy = globals.User_ID;
                        var bitIsActive = 0;
                        string mvalue = Request.Form["BitIsActive"];

                        if (mvalue == "1")
                        {
                            bitIsActive = 1;
                        }
                        else if (mvalue == "on") 
                        {
                            bitIsActive = 1;
                        }
                        else if (mvalue == "1,on") 
                        {
                            bitIsActive = 1;
                        }
                        else if (mvalue == "0,on")
                        {
                            bitIsActive = 1;
                        }
                        else
                        {
                            bitIsActive = 0;
                        }

                        try
                        {
                            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
                            {
                                if (cmd.Connection.State != ConnectionState.Open)
                                {
                                    cmd.Connection.Open();
                                }
                                cmd.CommandText = "update AlertThreshold set IntParamId='" + intParamId + "',IntComponentId='" + intComponentId + "',ComponentName='" + componentName + "', BrokerSiteId='" + brokerSiteId + "', intThresholdValue ='" + intThresholdValue + "' , iniUpdatedBy ='" + intUpdatedBy + "',dtmUpdatedOn='" + dtmupdateon + "', bitIsActive = '" + bitIsActive + "' where Id = '" + id + "'";
                                cmd.ExecuteNonQuery();
                                cmd.Connection.Close();

                                ViewBag.Status = 1;

                                ViewBag.model = alertThreshold;
                                return RedirectToAction("DisplayData", "Alert");
                            }

                        }
                        catch (Exception ee)
                        {
                            ViewBag.Status = 0;
                            return RedirectToAction("Alert", "Alert");

                        }

                _dbcontext.SaveChanges();
                ViewBag.successStatus = 1;
                alertThreshold = null;
                return RedirectToAction("DisplayData", "Alert");
            }
            catch (Exception ex)
            {
                ViewBag.successStatus = 0;
            }
            return RedirectToAction("Alert", "Alert");
        }

        [HttpPost]
        public IActionResult Clear(AlertThreshold alertThreshold)
        {
            ViewBag.successStatus = null;
            return RedirectToAction("Alert", "Alert");
        }
       
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            globals.User_ID = 0;
            return RedirectToAction("Login", "Account");
            
        }


        [HttpPost]
        public IActionResult Edit(AlertThreshold _alertThreshold)
        {
            ClaimsPrincipal claimUser = HttpContext.User;
            if (!claimUser.Identity.IsAuthenticated)
            {

                return RedirectToAction("Login", "Account");

            }
            
            int id = Convert.ToInt32(Request.Form["Id"]);
            var bitIsActive = Request.Form["mvalue"];
            ViewBag.mvalue = bitIsActive;

            return View(_alertThreshold);
        }

        public IActionResult DisplayData()
        {

            List<AlertThreshold> alertThresholds = new List<AlertThreshold>();
            var cmd = _dbcontext.Database.GetDbConnection().CreateCommand();
            if (cmd.Connection.State != ConnectionState.Open)
            {
                cmd.Connection.Open();
            }
            cmd.CommandText = "Select id, intparamid, intcomponentid, componentname, brokersiteid, intthresholdvalue, Cast(bitIsActive as Integer) bitIsActive from AlertThreshold where bitIsDelete = 0";

            Microsoft.Data.SqlClient.SqlDataReader dataread = (Microsoft.Data.SqlClient.SqlDataReader)cmd.ExecuteReader();
            if (dataread.HasRows)
            {
                while (dataread.Read())
                {

                    alertThresholds.Add(new AlertThreshold
                    {
                        Id = dataread.GetInt32(0),
                        IntParamId = dataread.GetInt32(1),
                        IntComponentId = dataread.GetInt32(2),
                        ComponentName = dataread.GetString(3),
                        BrokerSiteId = dataread.GetString(4),
                        IntThresholdValue = dataread.GetInt32(5),
                        BitIsActive = dataread.GetInt32(6)
                    }); ; ; ;

                }
                cmd.Connection.Close();
                
                ViewBag.model = alertThresholds;
                return View();
            }
            return View(); 
        }


    }   
}
