﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;
[Keyless]
public partial class VwInfoStatsData
{
    public string? Intcomponentid { get; set; }

    public string? NvccomponentName { get; set; }

    public string? Intinstanceid { get; set; }

    public string? NvcInstanceName { get; set; }

    public string? NvcInstanceIp { get; set; }

    public string? IntPort { get; set; }

    public string? BrokerName { get; set; }

    public int VarBrokerId { get; set; }

    public int? ParamId { get; set; }

    public string? ParameterName { get; set; }

    public string? NvcReference { get; set; }

    public string? NvcValue { get; set; }

    public int? IntSiteId { get; set; }

    public string? NvcSiteName { get; set; }

    public DateTime? DtmTimestamp { get; set; }
}
