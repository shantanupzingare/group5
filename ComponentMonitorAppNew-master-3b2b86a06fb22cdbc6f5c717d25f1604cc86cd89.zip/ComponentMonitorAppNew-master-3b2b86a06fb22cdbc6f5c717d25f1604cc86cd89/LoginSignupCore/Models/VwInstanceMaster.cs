﻿using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models;
[Keyless]
public partial class VwInstanceMaster
{
    public int IntInstanceId { get; set; }

    public int IntComponentId { get; set; }

    public string? NvcInstanceName { get; set; }

    public string? NvcInstanceIp { get; set; }

    public string? IntPort { get; set; }

    public DateTime DtmCreatedOn { get; set; }

    public int? IntCreatedBy { get; set; }

    public DateTime? DtmUpdatedOn { get; set; }

    public int? IntUpdatedBy { get; set; }

    public int? BitIsActive { get; set; }

    public int? BitIsDelete { get; set; }

    public DateTime DtmStartDate { get; set; }

    public DateTime? DtmEndDate { get; set; }

    public int? VersionNo { get; set; }

    public int? CapacityWeightage { get; set; }

    public string? NvcComponentName { get; set; }

    public string? NvcBrokerSiteId { get; set; }

    public string? NvcBrokerSiteName { get; set; }
}
