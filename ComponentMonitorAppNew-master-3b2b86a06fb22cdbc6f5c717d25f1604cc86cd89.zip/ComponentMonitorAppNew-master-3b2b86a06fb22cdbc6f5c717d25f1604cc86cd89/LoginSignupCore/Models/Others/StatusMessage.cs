﻿using Newtonsoft.Json;

namespace LoginSignupCore.Models.Others
{
    public class StatusMessage : MsgHeader
    {
        [JsonProperty("isSucessStatus")]
        public bool IsSucessStatus { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }
    }
}
