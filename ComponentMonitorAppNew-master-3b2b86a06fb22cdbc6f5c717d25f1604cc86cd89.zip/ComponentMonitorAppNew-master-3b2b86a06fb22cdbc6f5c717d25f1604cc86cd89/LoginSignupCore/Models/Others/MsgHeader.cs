﻿using Newtonsoft.Json;

namespace LoginSignupCore.Models.Others
{
    public class MsgHeader
    {
        [JsonProperty("messageCode")]
        public int MessageCode { get; set; }

        [JsonProperty("brokerId")]
        public int BrokerId { get; set; }

        [JsonProperty("siteId")]
        public int SiteId { get; set; }

        [JsonProperty("agentId")]
        public int AgentId { get; set; }
    }
}
