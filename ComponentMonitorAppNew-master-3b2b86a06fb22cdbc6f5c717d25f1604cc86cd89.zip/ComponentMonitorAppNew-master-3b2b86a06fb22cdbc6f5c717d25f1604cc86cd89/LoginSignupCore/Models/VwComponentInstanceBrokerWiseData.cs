﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;
[Keyless]
public partial class VwComponentInstanceBrokerWiseData
{
    
    public string? Segment { get; set; }

    public int? Intcomponentid { get; set; }

    public string? NvccomponentName { get; set; }

    public int? IntinstanceId { get; set; }

    public string? NvcInstanceName { get; set; }

    public string? NvcInstanceIp { get; set; }

    public string? IntPort { get; set; }

    public string? BrokerName { get; set; }

    public string? VarBrokerId { get; set; }

    public int? IntTraderId { get; set; }

    public string? NvcGripAddress { get; set; }

    public string? NvcLocalIpaddress { get; set; }

    public int? IntGportNo { get; set; }

    public int? IntLocalPortNo { get; set; }

    public int? SmiBoxId { get; set; }

    public int? KeepAliveTimeout { get; set; }

    public int? LineThresholdThrottle { get; set; }
}
