﻿using LoginSignupCore.MasterCache;

namespace LoginSignupCore.Models
{
    public class BODUploadFileView
    {
        public FileMasterInfo fileMasterInfo { get; set; } = new FileMasterInfo();
        public List<FileMasterInfo> fileMastersInfo { get; set; } = new List<FileMasterInfo>();
    }
}
