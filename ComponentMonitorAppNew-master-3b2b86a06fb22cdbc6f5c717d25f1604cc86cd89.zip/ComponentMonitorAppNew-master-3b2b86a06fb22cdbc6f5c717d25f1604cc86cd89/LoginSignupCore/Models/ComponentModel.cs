﻿namespace LoginSignupCore.Models
{
    public class ComponentModel
    {
        public Component component { get; set; } = new Component();
        public List<ComponentDropDown> list { get; set; } = new List<ComponentDropDown>();
    }
}
