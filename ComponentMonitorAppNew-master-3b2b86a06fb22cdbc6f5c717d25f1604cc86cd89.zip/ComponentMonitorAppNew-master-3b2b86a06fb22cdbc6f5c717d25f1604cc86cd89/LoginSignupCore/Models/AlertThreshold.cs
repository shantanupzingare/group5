﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models { 
   
    [Table("AlertThreshold")]
    public partial class AlertThreshold
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public int Id { get; set; }

        [Column("intParamID")]
        public int IntParamId { get; set; }

        [Column("intComponentId")]
        public int? IntComponentId { get; set; }

        [StringLength(64)]
        public string? ComponentName { get; set; }

        [Column("BrokerSiteID")]
        [StringLength(16)]
        public string? BrokerSiteId { get; set; }

        [Column("intThresholdValue")]
        public int IntThresholdValue { get; set; }

        [Column("intCreatedBy")]
        public int IntCreatedBy { get; set; }

        [Column("dtmCreatedOn")]
        public DateTime DtmCreatedOn { get; set; }

        [Column("iniUpdatedBy")]
        public int? IniUpdatedBy { get; set; }

        [Column("dtmUpdatedOn")]
        public DateTime? DtmUpdatedOn { get; set; }

        [Required]
        [Column("bitIsActive")]
        public int BitIsActive { get; set; }

        [Column("bitIsDelete")]
        public int BitIsDelete { get; set; }

        //[NotMapped]

        //public string intParamIdstring { get; set; }

        //[StringLength(3)]
        //[Unicode(false)]
        //public string ComponentId { get; set; }
        //[StringLength(64)]
        //public string ParameterName { get; set; }

    }
}
