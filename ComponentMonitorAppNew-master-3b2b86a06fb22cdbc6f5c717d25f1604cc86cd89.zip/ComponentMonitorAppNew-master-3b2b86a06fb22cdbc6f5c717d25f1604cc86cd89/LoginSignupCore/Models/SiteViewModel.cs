﻿namespace LoginSignupCore.Models
{
    public class SiteViewModel
    {
        public List<BrokerSites> sites { get; set; }
        public string brokerName { get; set; }
    }
}
