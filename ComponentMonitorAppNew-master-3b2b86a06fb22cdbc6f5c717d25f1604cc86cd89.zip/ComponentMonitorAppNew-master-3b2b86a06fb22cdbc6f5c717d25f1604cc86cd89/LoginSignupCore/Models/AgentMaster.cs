﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations;

namespace LoginSignupCore.Models
{
    public partial class AgentMaster
    {
        public int AgentId { get; set; }
        [Required(ErrorMessage="AgentName required")]
        public string AgentName { get; set; }
        public string? SiteName { get; set; }
        public int BrokerId { get; set; }
        public int BrokerSiteId { get; set; }
        [Required(ErrorMessage = "nvcInstanceIP required")]
        public string nvcInstanceIP { get; set; }
        public int IsActive { get; set; }

        public int IsDeleted { get; set; }

        public int IntCreatedBy { get; set; }

        public DateTime? DtmCreationDate { get; set; }

        public int? IntUpdatedBy { get; set; }

        public DateTime? DtmUpdationDate { get; set; }
        public string Remarks { get; set; } 
    }
}
