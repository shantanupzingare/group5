﻿using DotNetty.Transport.Channels;

namespace LoginSignupCore.Models
{
    public class globals
    {
        public static int User_ID;
        public static string Broker_Site = "Please Select";
        public static string Component_Name = "Please Select";
        public static int Component_ID;
        public static string componentname;
        public static string BrokerIdList;
        public static int BrokerId;
        public static string BrokerId_update;
        public static string Instance_id;
        public static string BrokerName;
        public static int IsActive;
        public static string Instance_Name = "Please Select";
        public static string Parameter_Name = "Please Select";
        public static int Timer = 0;
    }
}
