﻿namespace LoginSignupCore.Models
{
    public class BrokerSitesModel
    {
        public int Id { get; set; }

        public string NvcSiteName { get; set; } = null!;
        public string NvcMasterFilePath { get; set; } = null!;

        public string BrokerName { get; set; } = null!;
        public int IntBrokerId { get; set; }

        public int IsActive { get; set; }

        public int IsDeleted { get; set; }

        public int IntCreatedBy { get; set; }

        public DateTime? DtmCreationDate { get; set; }

        public int? IntUpdatedBy { get; set; }

        public DateTime? DtmUpdationDate { get; set; }
    }
}
