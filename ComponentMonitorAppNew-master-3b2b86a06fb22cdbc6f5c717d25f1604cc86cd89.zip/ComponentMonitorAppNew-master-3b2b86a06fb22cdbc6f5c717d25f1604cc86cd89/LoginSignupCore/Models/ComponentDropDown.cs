﻿namespace LoginSignupCore.Models
{
    public class ComponentDropDown
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Priority { get; set; }
    }
}
