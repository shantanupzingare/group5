﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models;

public partial class UserloginCred
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("admin")]
    [StringLength(50)]
    public string Admin { get; set; } = null!;

    [Column("password")]
    [StringLength(50)]
    public string Password { get; set; } = null!;
}
