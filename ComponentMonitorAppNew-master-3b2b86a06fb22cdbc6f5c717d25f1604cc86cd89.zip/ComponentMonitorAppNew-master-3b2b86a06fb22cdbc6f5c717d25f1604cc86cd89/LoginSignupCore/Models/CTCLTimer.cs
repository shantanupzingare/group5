﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;
[Keyless]
public partial class CTCLTimer
{
    public int? TimerinMins { get; set; }
}
