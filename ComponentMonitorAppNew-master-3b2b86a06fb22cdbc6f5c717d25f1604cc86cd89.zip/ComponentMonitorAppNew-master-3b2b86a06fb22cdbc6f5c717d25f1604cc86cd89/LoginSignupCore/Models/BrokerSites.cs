﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LoginSignupCore.Models;

public partial class BrokerSites
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Please Enter Site Name")]
    public string NvcSiteName { get; set; } = null!;
    [Required(ErrorMessage = "Please Enter MasterFilePath Name")]
    public string NvcMasterFilePath { get; set; } = null!;

    public int IntBrokerId { get; set; }

    public int IsActive { get; set; }

    public int IsDeleted { get; set; }

    public int IntCreatedBy { get; set; }

    public DateTime? DtmCreationDate { get; set; }

    public int? IntUpdatedBy { get; set; }

    public DateTime? DtmUpdationDate { get; set; }
}
