﻿using System.ComponentModel.DataAnnotations;

namespace LoginSignupCore.Models
{
    public class Component
    {
        public int Id { get; set; }
        public int AgentId { get; set; }
        public int BrokerId { get; set; }
        public int SiteId { get; set; }
        public string? ComponentName { get; set; }
        public string? AgentName { get; set; }
        public int ComponentType { get; set; }
        public int InstanceId { get; set; }
        [Required(ErrorMessage = "ExePath required")]
        public string ExePath { get; set; }
        public string? CmdParam { get; set; }
        public Boolean IsRunAsService { get; set; }
        public string ServiceName { get; set; }
        
        public int Priority { get; set; }
        public int IsActive { get; set; }

        public int IsDeleted { get; set; }

        public int IntCreatedBy { get; set; }

        public DateTime DtmCreationDate { get; set; }

        public int? IntUpdatedBy { get; set; }

        public DateTime DtmUpdationDate { get; set; }
        public string Remarks { get; set; }

        public List<ComponentDropDown> com { get; set; }    = new List<ComponentDropDown>();
    }
}
