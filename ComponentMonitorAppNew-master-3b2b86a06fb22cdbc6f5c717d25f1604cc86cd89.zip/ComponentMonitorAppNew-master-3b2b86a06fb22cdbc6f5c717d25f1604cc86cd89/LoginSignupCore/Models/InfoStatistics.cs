﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;
[Keyless]
public partial class InfoStatistics
{
    public int IntInfoId { get; set; }

    public int IntBrokerId { get; set; }

    public int IntSiteId { get; set; }

    public int IntComponentId { get; set; }

    public int IntInstanceId { get; set; }

    public int IntParamId { get; set; }

    public string? NvcReference { get; set; }

    public string? NvcValue { get; set; }

    public DateTime DtmCreatedOn { get; set; }

    public int? IntCreatedBy { get; set; }

    public DateTime? DtmUpdatedOn { get; set; }

    public int? IntUpdatedBy { get; set; }

    public int BitIsActive { get; set; }

    public int BitIsDelete { get; set; }

    public DateTime? DtmTimeStamp { get; set; }
}
