﻿namespace LoginSignupCore.Models
{
    public class AgentwiseFileViewModel
    {
        public List<AgentwiseFiles> Files { get; set; } = new List<AgentwiseFiles>();
        public AgentwiseFiles File { get; set; } = new AgentwiseFiles();
    }
}
