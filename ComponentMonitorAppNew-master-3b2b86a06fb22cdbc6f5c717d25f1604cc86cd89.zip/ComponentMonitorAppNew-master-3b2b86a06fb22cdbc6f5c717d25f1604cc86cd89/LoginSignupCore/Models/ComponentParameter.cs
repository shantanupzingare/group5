﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models
{
    [Table("ComponentParameter")]
    public partial class ComponentParameter
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("ParamId")]
        public int ParamId { get; set; }

        [StringLength(3)]
        [Unicode(false)]
        public string ComponentId { get; set; }

        [StringLength(3)]
        [Unicode(false)]
        public string InstanceId { get; set; }

        [StringLength(64)]
        public string ParameterName { get; set; }

        [StringLength(256)]
        public string Remarks { get; set; }

        [Column("dtmCreatedOn", TypeName = "datetime")]
        public DateTime? DtmCreatedOn { get; set; }

        [Column("intCreatedBy")]
        public int IntCreatedBy { get; set; }

        [Column("dtmUpdatedOn", TypeName = "datetime")]
        public DateTime? DtmUpdatedOn { get; set; }

        [Column("intUpdatedBy")]
        public int IntUpdatedBy { get; set; }

        [Column("bitIsActive")]
        public int BitIsActive { get; set; }

        [Column("bitIsDelete")]
        public int BitIsDelete { get; set; }

        [Required]
        [Column("bitAttributeType")]
        public int BitAttributeType { get; set; }

        [Column("brokerSiteId")]
        public string BrokerSiteId { get; set; }

        //public string ParamIdForList { get { return ParamId + " - " + ParameterName; } }
    }
}
