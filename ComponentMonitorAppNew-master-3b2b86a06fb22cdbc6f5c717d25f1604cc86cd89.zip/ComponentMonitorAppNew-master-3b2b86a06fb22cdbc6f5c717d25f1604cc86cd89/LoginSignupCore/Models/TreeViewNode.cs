﻿namespace LoginSignupCore.Models
{
    public class TreeViewNode
    {
        public int id { get; set; } //brokerid
        public int cid { get; set; } //cityid
        public string parent { get; set; }
        public string text { get; set; }
    }
}
