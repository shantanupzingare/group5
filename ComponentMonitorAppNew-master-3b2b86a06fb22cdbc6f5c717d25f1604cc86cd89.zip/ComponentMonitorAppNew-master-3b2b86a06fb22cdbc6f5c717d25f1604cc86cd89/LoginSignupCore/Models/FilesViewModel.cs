﻿namespace LoginSignupCore.Models
{
    public class FilesViewModel
    {
        public AgentwiseFiles file { get; set; } = new AgentwiseFiles();
        public List<FileDropDown> list { get; set; } = new List<FileDropDown>();
    }
}
