﻿namespace LoginSignupCore.Models
{
    public class DictionaryOfTreeViewModl
    {
        public Dictionary<int, List<TreeViewNode>> MenuItem { get; set; }
        public Dictionary<int, string> BokerName { get; set; }
    }
}
