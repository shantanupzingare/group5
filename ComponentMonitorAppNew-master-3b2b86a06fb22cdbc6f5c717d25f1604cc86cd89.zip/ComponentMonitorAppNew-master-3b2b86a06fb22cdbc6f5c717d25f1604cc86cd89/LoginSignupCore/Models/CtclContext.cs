﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models;

public partial class CtclContext : DbContext
{
    public CtclContext(DbContextOptions<CtclContext> options)
        : base(options)
    {
    }

    public virtual DbSet<BrokerSiteCredentials> BrokerSiteCredentials { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BrokerSiteCredentials>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("id");
            entity.Property(e => e.IntBrokerId).HasColumnName("intBrokerId");
            entity.Property(e => e.IntSiteId).HasColumnName("intSiteId");
            entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            entity.Property(e => e.NvcComment).HasColumnName("nvcComment");
            entity.Property(e => e.NvcWebSocketToken).HasColumnName("nvcWebSocketToken");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
