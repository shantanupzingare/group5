﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace LoginSignupCore.Models
{
    public class User
    {
        [DefaultValue (0)]
        public int Id { get; set; }

        [Required (ErrorMessage ="Please enter a valid email address")]
        [EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter a password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool KeepLoggedin { get; set; }
    }
}
