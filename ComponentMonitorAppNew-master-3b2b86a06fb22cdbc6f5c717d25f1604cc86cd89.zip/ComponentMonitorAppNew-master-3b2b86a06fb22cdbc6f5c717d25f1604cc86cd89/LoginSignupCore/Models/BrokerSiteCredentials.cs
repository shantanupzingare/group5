﻿using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;

public partial class BrokerSiteCredentials
{
    public int Id { get; set; }

    public int IntBrokerId { get; set; }

    public int IntSiteId { get; set; }

    public string? NvcWebSocketToken { get; set; }

    public string? NvcComment { get; set; }

    public int IsActive { get; set; }

    public int IsDelete { get; set; }
}
