﻿namespace LoginSignupCore.Models
{
    public class ComponentViewModel
    {
        public List<Component> Components { get; set; } = new List<Component>();
        public Component Component { get; set; } = new Component();
    }
}
