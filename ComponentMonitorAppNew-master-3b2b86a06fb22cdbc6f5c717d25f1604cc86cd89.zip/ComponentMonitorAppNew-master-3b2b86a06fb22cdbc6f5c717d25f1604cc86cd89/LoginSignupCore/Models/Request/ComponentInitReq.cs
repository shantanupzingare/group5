﻿using LoginSignupCore.Models.Others;
using Newtonsoft.Json;

namespace LoginSignupCore.Models.Request
{
    public class ComponentInitReq : MsgHeader
    {
        [JsonProperty("componentType")]
        public int ComponentType { get; set; }

        [JsonProperty("instanceId")]
        public int InstanceId { get; set; }

        [JsonProperty("isRunAsService")]
        public bool IsRunAsService { get; set; }

        [JsonProperty("requestId")]
        public string RequestId { get; set; }
    }
}
