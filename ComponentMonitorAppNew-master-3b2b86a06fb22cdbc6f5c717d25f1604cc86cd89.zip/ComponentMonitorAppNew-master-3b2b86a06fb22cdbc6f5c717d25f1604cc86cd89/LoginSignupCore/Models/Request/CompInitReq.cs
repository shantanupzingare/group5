﻿using Newtonsoft.Json;

namespace LoginSignupCore.Models.Request
{
    public class CompInitReq
    {
        [JsonProperty("brokerId")]
        public int BrokerId { get; set; }

        [JsonProperty("siteId")]
        public int SiteId { get; set; }

        [JsonProperty("agentId")]
        public int AgentId { get; set; }

        [JsonProperty("compId")]
        public int CompId { get; set; }

        [JsonProperty("instanceId")]
        public int InstanceId { get; set; }
    }
}
