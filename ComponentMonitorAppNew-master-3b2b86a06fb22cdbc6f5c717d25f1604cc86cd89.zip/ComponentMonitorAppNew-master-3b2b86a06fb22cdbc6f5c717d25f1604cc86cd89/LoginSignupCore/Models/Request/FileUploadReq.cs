﻿using LoginSignupCore.Models.Others;
using Newtonsoft.Json;

namespace LoginSignupCore.Models.Request
{
    public class FileUploadReq : MsgHeader
    {
        [JsonProperty("requestId")]
        public string RequestId { get; set; }
    }
}
