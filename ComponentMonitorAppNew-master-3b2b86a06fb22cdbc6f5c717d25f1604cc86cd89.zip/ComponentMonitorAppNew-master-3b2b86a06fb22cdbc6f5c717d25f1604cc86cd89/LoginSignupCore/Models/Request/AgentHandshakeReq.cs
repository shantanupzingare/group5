﻿using LoginSignupCore.Models.Others;
using Newtonsoft.Json;

namespace LoginSignupCore.Models.Request
{
    public class AgentHandshakeReq : MsgHeader
    {
        [JsonProperty("ip")]
        public string IP { get; set; }
    }
}
