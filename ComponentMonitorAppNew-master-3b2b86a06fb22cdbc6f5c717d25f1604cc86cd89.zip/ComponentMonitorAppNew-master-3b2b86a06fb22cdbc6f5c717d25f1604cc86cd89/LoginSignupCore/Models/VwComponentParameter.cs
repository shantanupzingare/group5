﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;
[Keyless]
public partial class VwComponentParameter
{
    public string? Intcomponentid { get; set; }

    public string? NvccomponentName { get; set; }

    public string? Intinstanceid { get; set; }

    public string? NvcInstanceName { get; set; }

    public string? BrokerSiteName { get; set; }

    public int VarBrokerId { get; set; }

    public int? ParamId { get; set; }

    public string? ParameterName { get; set; }

    public int? IntSiteId { get; set; }

    public string? NvcBrokerName { get; set; }

    public string? NvcSiteName { get; set; }

    public string? BrokerSiteId { get; set; }

    public int BitAttributeType { get; set; }

    public int BitIsActive { get; set; }

    public string? Remarks { get; set; }
}
