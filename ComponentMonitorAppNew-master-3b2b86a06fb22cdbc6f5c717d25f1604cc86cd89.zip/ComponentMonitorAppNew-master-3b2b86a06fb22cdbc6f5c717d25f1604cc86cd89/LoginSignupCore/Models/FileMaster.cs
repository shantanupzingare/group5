﻿using CTCL.BinaryProtocol.Common.CTCL.Enum;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace LoginSignupCore.Models
{
    public class FileMaster
    {
        public int id { get; set; }
        public CTCL_ExchangeIdentifier SegmentId { get; set; }
        public int FileType { get; set; }
        [Required (ErrorMessage ="file is not find")]
        public string FileName { get; set; }
        public int Priority { get; set; }
        public bool UploadBeforeBod { get; set; }
        public string nvcDestinationPath { get; set; }
        public int isActive { get; set; }
        public int isDeleted { get; set; }
        public string Remarks { get; set; }
        public DateTime? IntCreatedOn { get; set; }
        public int IntCreatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }
        public int UpdatedBy { get; set; }
    }
}
