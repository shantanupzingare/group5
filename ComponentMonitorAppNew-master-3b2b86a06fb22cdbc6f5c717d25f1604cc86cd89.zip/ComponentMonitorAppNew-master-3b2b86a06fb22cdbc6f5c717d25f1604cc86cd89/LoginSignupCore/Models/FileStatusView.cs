﻿using LoginSignupCore.Models.Response;

namespace LoginSignupCore.Models
{
    public class FileStatusView
    {
        public FileStatus file { get; set; } = new FileStatus();
        public List<FileStatus> fileStatus { get; set; } = new List<FileStatus>();
    }
}
