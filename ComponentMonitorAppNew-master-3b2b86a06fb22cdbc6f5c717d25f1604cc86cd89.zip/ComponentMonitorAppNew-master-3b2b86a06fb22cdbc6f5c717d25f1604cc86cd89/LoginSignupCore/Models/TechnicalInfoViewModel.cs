﻿using LoginSignupCore.MasterCache;

namespace LoginSignupCore.Models
{
    public class TechnicalInfoViewModel
    {
        public int BrokerId;
        public int SiteId;

        //public ComponentsTechnicalInfo Info { get; set; } = new ComponentsTechnicalInfo();
        public List<ComponentsTechnicalInfo> TechnicalInfos { get; set; } = new List<ComponentsTechnicalInfo>();
    }
}
