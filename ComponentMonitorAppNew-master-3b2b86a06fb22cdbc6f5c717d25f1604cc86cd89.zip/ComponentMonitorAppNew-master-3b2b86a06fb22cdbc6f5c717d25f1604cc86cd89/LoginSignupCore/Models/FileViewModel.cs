﻿namespace LoginSignupCore.Models
{
    public class FileViewModel
    {
        public List<FileMaster> files { get; set; }  = new List<FileMaster>();

        public FileMaster file { get; set; } = new FileMaster();
    }
}
