﻿using LoginSignupCore.MasterCache;
using System.Text.Json.Serialization;

namespace LoginSignupCore.Models
{
    public class BODUploadComponent
    {
        
        public MasterCache.Component component { get; set; } = new MasterCache.Component();
        public List<LoginSignupCore.MasterCache.Component> Components { get; set; } = new List<MasterCache.Component>();
    }
}
