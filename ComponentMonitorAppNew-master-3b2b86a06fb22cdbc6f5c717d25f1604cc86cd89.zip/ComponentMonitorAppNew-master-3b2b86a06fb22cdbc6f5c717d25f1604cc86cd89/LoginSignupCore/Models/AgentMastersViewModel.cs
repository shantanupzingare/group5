﻿namespace LoginSignupCore.Models
{
    public class AgentMastersViewModel
    {
        public List<AgentMaster> Agents { get; set; } = new List<AgentMaster>();
        public AgentMaster Agent { get; set; } = new AgentMaster();
    }
}
