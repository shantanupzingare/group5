﻿namespace LoginSignupCore.Models
{
    public class FileDropDown
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
