﻿using LoginSignupCore.MasterCache;
using LoginSignupCore.Models.Response;

namespace LoginSignupCore.Models
{
    public class TechnicalInfo
    {
        public ComponentsTechnicalInfo technicalInfo { get; set; } = new ComponentsTechnicalInfo();
        public List<ComponentsTechnicalInfo> technicalInfos { get; set; } = new List<ComponentsTechnicalInfo>();
    }
}
