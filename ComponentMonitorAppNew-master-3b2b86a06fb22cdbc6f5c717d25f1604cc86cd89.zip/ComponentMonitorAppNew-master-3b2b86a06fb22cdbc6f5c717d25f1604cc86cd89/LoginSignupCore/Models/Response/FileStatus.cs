﻿using LoginSignupCore.Models.Others;
using Newtonsoft.Json;

namespace LoginSignupCore.Models.Response
{
    public class FileStatus : StatusMessage
    {
        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("segment")]
        public int Segment { get; set; }

        [JsonProperty("fileType")]
        public int FileType { get; set; }

        [JsonProperty("timeStamp")]
        public DateTime TimeStamp { get; set; }
    }
}
