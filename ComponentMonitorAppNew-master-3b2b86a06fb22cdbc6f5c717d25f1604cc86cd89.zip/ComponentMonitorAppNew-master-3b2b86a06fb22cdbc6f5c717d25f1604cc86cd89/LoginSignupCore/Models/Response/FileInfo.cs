﻿using LoginSignupCore.Models.Others;
using Newtonsoft.Json;

namespace LoginSignupCore.Models.Response
{
    public class FileInfo : MsgHeader
    {
        [JsonProperty("masterPath")]
        public string MasterPath { get; set; }

        [JsonProperty("files")]
        public List<FilePathInfo> Files { get; set; }
    }

    public class FilePathInfo
    {
        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("filePriority")]
        public int FilePriority { get; set; }

        [JsonProperty("segment")]
        public int Segment { get; set; }

        [JsonProperty("fileType")]
        public int FileType { get; set; }

        [JsonProperty("isUploadBeforeBod")]
        public bool IsUploadBeforeBod { get; set; }

        [JsonProperty("destinationPath")]
        public string DestinationPath { get; set; }
    }
}
