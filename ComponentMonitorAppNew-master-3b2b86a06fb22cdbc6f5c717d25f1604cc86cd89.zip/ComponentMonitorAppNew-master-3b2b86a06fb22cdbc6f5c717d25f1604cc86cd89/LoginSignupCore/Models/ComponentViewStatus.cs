﻿using LoginSignupCore.Models.Response;

namespace LoginSignupCore.Models
{
    public class ComponentViewStatus
    {

        public int BrokerId;

        public int SiteId;
       // public ComponentStatus componentStatus { get; set; } = new ComponentStatus();
        public List<ComponentStatus> ComponentsStatus { get; set; } = new List<ComponentStatus>();
    }
}
