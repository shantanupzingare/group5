﻿using System;
using System.Collections.Generic;

namespace LoginSignupCore.Models;

public partial class BrokerMaster
{
    public int Id { get; set; }

    public string? NvcBrokerName { get; set; }

    public int IsActive { get; set; }

    public int IsDeleted { get; set; }

    public int IntCreatedBy { get; set; }

    public DateTime DtmCreationDate { get; set; }

    public int? IntUpdatedBy { get; set; }

    public DateTime DtmUpdationDate { get; set; }
}
