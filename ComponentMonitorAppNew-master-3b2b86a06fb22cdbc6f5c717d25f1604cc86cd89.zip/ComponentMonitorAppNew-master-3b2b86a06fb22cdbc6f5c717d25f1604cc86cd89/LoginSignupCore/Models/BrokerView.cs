﻿namespace LoginSignupCore.Models
{
    public class BrokerView
    {
        public List<BrokerMaster> brokers { get; set; } = new List<BrokerMaster>();

        public BrokerMaster broker { get; set; } = new BrokerMaster();
    }
}
