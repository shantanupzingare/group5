﻿using Microsoft.EntityFrameworkCore;

namespace LoginSignupCore.Models;
[Keyless]
public partial class VwAlertThreshold
{
    public int Id { get; set; }

    public int IntParamId { get; set; }

    public int? IntComponentId { get; set; }

    public string? ComponentName { get; set; }

    public string? BrokerSiteName { get; set; }

    public string? BrokerSiteId { get; set; }

    public int IntThresholdValue { get; set; }

    public string? ParameterName { get; set; }

    public int? ParamId { get; set; }

    public int BitIsActive { get; set; }
}
