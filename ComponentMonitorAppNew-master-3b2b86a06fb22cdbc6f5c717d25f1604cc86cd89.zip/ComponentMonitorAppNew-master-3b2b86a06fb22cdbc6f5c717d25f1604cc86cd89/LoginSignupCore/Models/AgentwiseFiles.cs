﻿namespace LoginSignupCore.Models
{
    public class AgentwiseFiles
    {
        public int Id { get; set; }
        public int AgentId { get; set; }
        public string AgentName { get; set; }
        public int BrokerId { get; set; }
        public int SiteId { get; set; }
        public int FileId { get; set; }
        public string FileName { get; set; }
        public int IsActive { get; set; }

        public int IsDeleted { get; set; }

        public int IntCreatedBy { get; set; }

        public DateTime DtmCreationDate { get; set; }

        public int? IntUpdatedBy { get; set; }

        public DateTime DtmUpdationDate { get; set; }
        public string Remarks { get; set; }
    }
}
