﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerDBComponent.MessageProcessor.Entity
{
    public class CMA_InfoStatistics_forDB
    {
        public int infoID { get; set; }
        public int BrokerID { get; set; }
        public int SiteID { get; set; }
        public int ComponentID { get; set; }
        public int InstanceID { get; set; }
        public int ParamID { get; set; }
        public char Reference { get; set; }
        public char nvcValue { get; set; }
       
    }
}

