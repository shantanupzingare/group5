﻿namespace ConsumerDBComponent.MessageProcessor.Entity
{
    public class CMA_InfoMaster_forDb
    {
        public int infoID { get; set; }
        public int BrokerID { get; set; }
        public int SiteID { get; set; }
        public int ComponentID { get; set; }
        public int InstanceID { get; set; }
        public int ParamID { get; set; }
        public int ParamAttribute { get; set; }
        public int BrokerSiteInstanceID { get; set; }

    }
}



