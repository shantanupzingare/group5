﻿using LoginSignupCore.Models;

namespace LoginSignupCore.ViewModels
{
    public class CommonViewModel
    {
        //public ComponentParameter ComponentParameter { get; set; }
        //public AlertThreshold AlertThreshold { get; set; }
        public VwComponentInstanceBrokerWiseData VwComponentInstanceBrokerWiseData { get; set; }
        //public globals globals { get; set; }
    }
}
